// Bill header, footer, contact details and the UPI payment QR: settings, validation, permissions, QR encoder.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-billcfg-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; delete process.env.SEED_DEMO;
let base, server, db; const tok = {};
const call = async (who, method, url, body) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tok[who] } : {}) }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };
before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call(null, 'GET', '/api/users')).json;
  for (const [n, p] of [['Owner', '1234'], ['Cashier', '3333'], ['Kitchen', '4444']]) tok[n] = (await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === n).id, pin: p })).json.token;
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });

import { qrMatrix, upiLink } from '../public/js/qr.js';

test('bill layout defaults come with every bill, and everyone signed in can read them', async () => {
  const sale = (await call('Owner', 'GET', '/api/menu-items')).json.find((m) => !m.off && (m.prices.default ?? 0) > 0);
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: sale.id, qty: 1 }] })).json.order;
  const b = (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json;
  assert.equal(b.layout.upi.enabled, false); assert.equal(b.layout.footer, 'Thank you! Order again soon.'); assert.equal(b.layout.show.customer, true);
  assert.equal((await call('Cashier', 'GET', '/api/bill-layout')).status, 200); assert.equal((await call(null, 'GET', '/api/bill-layout')).status, 401);
});

test('only the owner changes the bill, and a UPI ID is checked', async () => {
  assert.equal((await call('Cashier', 'PUT', '/api/settings', { bill: { footer: 'x' } })).status, 403);
  assert.equal((await call('Owner', 'PUT', '/api/settings', { bill: { upi: { enabled: true, vpa: 'not a upi id' } } })).status, 400, 'bad UPI ID refused');
  assert.equal((await call('Owner', 'PUT', '/api/settings', { bill: { upi: { enabled: true, vpa: '' } } })).status, 400, 'cannot switch on without an ID');
  const ok = await call('Owner', 'PUT', '/api/settings', { bill: { tagline: 'Home-style Bihari food', phone: '+91 98765 43210', footer: 'Come again!', footer_note: 'No returns on food', header_note: 'Pure veg', show: { gstin: false, tax_split: false }, upi: { enabled: true, vpa: 'waayu@okhdfcbank', payee: 'Waayu Kitchen', when: 'always', note: 'Bill {bill_no}' } } });
  assert.equal(ok.status, 200);
  const cfg = (await call('Owner', 'GET', '/api/settings')).json.bill;
  assert.equal(cfg.tagline, 'Home-style Bihari food'); assert.equal(cfg.upi.enabled, true); assert.equal(cfg.upi.vpa, 'waayu@okhdfcbank'); assert.equal(cfg.upi.when, 'always'); assert.equal(cfg.show.gstin, false); assert.equal(cfg.show.customer, true, 'unlisted switches keep their value');
  const sale = (await call('Owner', 'GET', '/api/menu-items')).json.find((m) => !m.off && (m.prices.default ?? 0) > 0);
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: sale.id, qty: 1 }] })).json.order;
  const b = (await call('Cashier', 'GET', `/api/orders/${o.id}/bill`)).json;
  assert.equal(b.layout.footer, 'Come again!'); assert.equal(b.layout.upi.vpa, 'waayu@okhdfcbank'); assert.equal(b.layout.upi.payee, 'Waayu Kitchen');
  const off = await call('Owner', 'PUT', '/api/settings', { bill: { upi: { enabled: false, vpa: 'waayu@okhdfcbank' } } });
  assert.equal(off.status, 200); assert.equal((await call('Owner', 'GET', '/api/settings')).json.bill.upi.enabled, false);
});

test('the UPI link is the standard one, with the amount to the paisa', () => {
  const l = upiLink({ vpa: 'waayu@okhdfcbank', payee: 'Waayu Kitchen & Co', amount: 653.5, note: 'Bill B1042' });
  assert.equal(l, 'upi://pay?pa=waayu%40okhdfcbank&pn=Waayu%20Kitchen%20%26%20Co&am=653.50&cu=INR&tn=Bill%20B1042');
});

test('the QR encoder draws a valid-looking symbol', () => {
  const m = qrMatrix('hello'), n = m.length; assert.equal(n, 21, 'version 1');
  for (const [ox, oy] of [[0, 0], [n - 7, 0], [0, n - 7]]) { assert.ok(m[oy][ox] && m[oy][ox + 6] && m[oy + 6][ox] && m[oy + 6][ox + 6], 'finder corners'); assert.ok(!m[oy + 1][ox + 1] && m[oy + 3][ox + 3], 'finder centre'); }
  assert.ok(m[8][n - 8 + 0] !== undefined && m[n - 8][8] === true, 'dark module');
  assert.ok(qrMatrix(upiLink({ vpa: 'a.long.name@oksbi', payee: 'The Very Long Cloud Kitchen Name', amount: 12345.5, note: 'Bill B104200' })).length <= 57);
  assert.throws(() => qrMatrix('z'.repeat(400)), /too long/);
});
