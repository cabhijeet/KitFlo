// Menu tests on a fresh kitchen loaded with the real menu from server/menu-data.json (sizes, photos, descriptions).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-menu-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; delete process.env.SEED_DEMO;
let base, server, db, token;
const call = async (method, url, body) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };

before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call('GET', '/api/users')).json; token = (await call('POST', '/api/login', { user_id: users.find((u) => u.name === 'Owner').id, pin: '1234' })).json.token;
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });

const menu = async () => (await call('GET', '/api/menu-items')).json;
const DATA = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, '../server/menu-data.json'), 'utf8'));
const DISHES = new Set(DATA.map((r) => r.catalogue_id || r.name)).size;

test('the real menu loads with every size, description, photo, id and the sheet costs', async () => {
  const m = await menu(); assert.equal(m.length, DATA.length); assert.equal(new Set(m.map((x) => x.group_key)).size, DISHES);
  const mp = m.filter((x) => x.name === 'Matar Paneer'); assert.equal(mp.length, 3);
  assert.deepEqual(mp.map((x) => x.prices.default), [239, 409, 709], 'sizes ordered Portion, Half, Full');
  assert.ok(mp.every((x) => x.variant_id && x.catalogue_id === '758281344' && x.description && x.image_url));
  assert.ok(!m.some((x) => /\.$/.test(x.category)), 'no stray full stops in category names');
  assert.equal(m.filter((x) => x.off).length, DATA.filter((r) => r.in_stock === false).length, 'dishes that only appear in the cost sheet start switched off');
  const cost = m.find((x) => x.name === 'Lychee Mojito'); assert.equal(cost.ingredient_cost, 50); assert.equal(cost.op_cost, 19); assert.equal(cost.pack_cost, 12); assert.equal(cost.mrp, 129);
  assert.equal(cost.food_cost, 50); assert.equal(cost.net_margin, 129 - 50 - 19 - 12);
});

test('importing the same rows again updates, never duplicates', async () => {
  const rows = DATA;
  const r = await call('POST', '/api/menu-items/import', { rows }); assert.equal(r.status, 200);
  assert.equal(r.json.created, 0); assert.equal(r.json.updated, DATA.length); assert.equal((await menu()).length, DATA.length);
  const bad = await call('POST', '/api/menu-items/import', { rows: [{ name: 'No price dish', category: 'Test' }] }); assert.equal(bad.json.errors.length, 1);
});

test('editing a dish keeps its sizes together, and a recipe makes stock and cost real', async () => {
  const inv = await call('POST', '/api/inventory-items', { name: 'Paneer', unit: 'kg', unit_cost: 400, opening_qty: 10, reorder_level: 1, par_level: 5 }); const item = inv.json;
  const mp = (await menu()).filter((x) => x.name === 'Matar Paneer'); const key = mp[0].group_key;
  const half = mp.find((x) => /Half/.test(x.variant_name));
  const payload = { shared: { name: 'Matar Paneer', category: 'Curry Bowls', subcategory: 'Curry Bowls', description: 'Edited', image_url: mp[0].image_url, gst_rate: 5, catalogue_id: '758281344' },
    variants: mp.map((v) => ({ id: v.id, variant_name: v.variant_name, variant_id: v.variant_id, prices: v.prices, off: false, recipe: v.id === half.id ? [{ inventory_item_id: item.id, qty_per_portion: 0.2, wastage_pct: 0 }] : [] })) };
  const s = await call('PUT', `/api/menu-groups/${encodeURIComponent(key)}`, payload); assert.equal(s.status, 200);
  const after = (await menu()).filter((x) => x.name === 'Matar Paneer'); assert.equal(after.length, 3); assert.ok(after.every((x) => x.description === 'Edited'));
  assert.equal(after.find((x) => x.id === half.id).recipe_cost, 80);
  const o = await call('POST', '/api/orders', { channel: 'walkin', accept: true, items: [{ menu_item_id: half.id, qty: 2 }] }); assert.equal(o.status, 201);
  assert.match(o.json.order.items[0].name, /Matar Paneer · Half/); assert.equal(o.json.order.items[0].unit_price, 409);
  const left = (await call('GET', '/api/inventory-items')).json.find((i) => i.id === item.id).on_hand; assert.ok(Math.abs(left - 9.6) < 1e-6, `paneer left ${left}`);
});

test('a switched-off size cannot be bought on the website', async () => {
  const lassi = (await menu()).find((x) => x.name === 'Sattu Paratha'); await call('POST', `/api/menu-items/${lassi.id}/availability`, { off: true });
  const pub = (await call('GET', '/api/public/menu')).json.items; assert.ok(!pub.some((x) => x.id === lassi.id));
  const r = await call('POST', '/api/public/checkout', { customer: { name: 'T', phone: '9000000009' }, address: 'x', items: [{ menu_item_id: lassi.id, qty: 1 }] }); assert.equal(r.status, 400);
});
