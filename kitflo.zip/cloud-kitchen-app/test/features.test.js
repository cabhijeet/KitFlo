// Category stop, counter discounts, bill contents, sheet costs and menu engineering, on a fresh kitchen with the real menu.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-feat-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; delete process.env.SEED_DEMO;
let base, server, db; const tok = {};
const call = async (who, method, url, body) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tok[who] } : {}) }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };
before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call(null, 'GET', '/api/users')).json;
  for (const [n, p] of [['Owner', '1234'], ['Cashier', '3333'], ['Kitchen', '4444']]) tok[n] = (await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === n).id, pin: p })).json.token;
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });
const menu = async () => (await call('Owner', 'GET', '/api/menu-items')).json;
const onSale = async (pred = () => true) => (await menu()).find((m) => !m.off && m.available !== false && pred(m));
const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.011, `${msg}: ${a} vs ${b}`);

test('stopping a category hides it everywhere and keeps single-dish switches', async () => {
  const m = await menu(); const cat = 'Parathas'; const inCat = m.filter((x) => x.category === cat); assert.ok(inCat.length);
  const offOne = inCat[0]; await call('Owner', 'POST', `/api/menu-items/${offOne.id}/availability`, { off: true });
  assert.equal((await call('Cashier', 'POST', '/api/menu-categories/availability', { name: cat, off: true })).status, 403, 'cashier cannot stop a category');
  const r = await call('Kitchen', 'POST', '/api/menu-categories/availability', { name: cat, off: true }); assert.equal(r.status, 200); assert.equal(r.json.off, true);
  const pub = (await call(null, 'GET', '/api/public/menu')).json; assert.ok(!pub.items.some((x) => x.category === cat), 'website no longer lists the category'); assert.ok(pub.paused.includes(cat));
  const target = inCat.find((x) => x.id !== offOne.id);
  assert.equal((await call(null, 'POST', '/api/public/checkout', { customer: { name: 'T', phone: '9000000011' }, address: 'x', items: [{ menu_item_id: target.id, qty: 1 }] })).status, 400, 'checkout refuses a stopped category');
  assert.ok((await call('Owner', 'GET', '/api/menu-categories')).json.find((c) => c.name === cat).off);
  await call('Kitchen', 'POST', '/api/menu-categories/availability', { name: cat, off: false });
  const pub2 = (await call(null, 'GET', '/api/public/menu')).json; assert.ok(pub2.items.some((x) => x.id === target.id), 'back on after restart');
  assert.ok(!pub2.items.some((x) => x.id === offOne.id), 'the dish switched off on its own stays off');
  await call('Owner', 'POST', `/api/menu-items/${offOne.id}/availability`, { off: false });
});

test('a timed stop restarts by itself, and a past restart time is refused', async () => {
  assert.equal((await call('Owner', 'POST', '/api/menu-categories/availability', { name: 'Extras', off: true, until: new Date(Date.now() - 1000).toISOString() })).status, 400);
  const until = new Date(Date.now() + 1500).toISOString();
  assert.equal((await call('Owner', 'POST', '/api/menu-categories/availability', { name: 'Extras', off: true, until })).status, 200);
  assert.ok((await call('Owner', 'GET', '/api/menu-categories')).json.find((c) => c.name === 'Extras').off);
  await new Promise((r) => setTimeout(r, 1800));
  assert.ok(!(await call('Owner', 'GET', '/api/menu-categories')).json.find((c) => c.name === 'Extras').off, 'back on after the time passes');
});

test('counter discounts: percent, fixed, with a promo, no code needed', async () => {
  const m = await onSale((x) => (x.prices.default ?? 0) >= 100 && x.gst_rate === 5); const price = m.prices.default;
  const place = (md, extra = {}) => call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: m.id, qty: 2 }], manual_discount: md, ...extra });
  const none = (await place(undefined)).json.order;
  const pct = (await place({ type: 'percent', value: 10, reason: 'Regular customer' })).json.order;
  near(pct.manual_discount, price * 2 * 0.1, '10% of the subtotal'); near(pct.discount, pct.manual_discount, 'total discount'); assert.equal(pct.discount_reason, 'Regular customer');
  near(pct.tax, none.tax * 0.9, 'GST is charged on the discounted amount'); near(pct.total, pct.subtotal - pct.discount + pct.tax + pct.packaging_fee, 'total adds up');
  const fixed = (await place({ type: 'fixed', value: 25 })).json.order; near(fixed.manual_discount, 25, 'fixed rupees'); assert.equal(fixed.discount_type, 'fixed');
  const huge = (await place({ type: 'fixed', value: 99999 })).json.order; near(huge.discount, huge.subtotal, 'never more than the subtotal'); near(huge.total, huge.packaging_fee, 'only packaging is left');
  assert.equal((await place({ type: 'percent', value: 0 })).json.order.manual_discount, 0, 'zero means no discount');
  assert.equal((await place({ type: 'percent', value: 150 })).status, 400, 'over 100% is refused');
});

test('cashier discounts are capped by the limit, owner is not, and platforms cannot use it', async () => {
  const m = await onSale((x) => (x.prices.default ?? 0) >= 100); const items = [{ menu_item_id: m.id, qty: 1 }];
  assert.equal((await call('Cashier', 'POST', '/api/orders', { channel: 'walkin', items, manual_discount: { type: 'percent', value: 50 } })).status, 403);
  assert.equal((await call('Cashier', 'POST', '/api/orders', { channel: 'walkin', items, manual_discount: { type: 'percent', value: 20 } })).status, 201);
  assert.equal((await call('Owner', 'PUT', '/api/settings', { discount_limit_pct: 60 })).status, 200);
  assert.equal((await call('Cashier', 'POST', '/api/orders', { channel: 'walkin', items, manual_discount: { type: 'percent', value: 50 } })).status, 201, 'limit is adjustable');
  assert.equal((await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items, manual_discount: { type: 'percent', value: 90 } })).status, 201);
  const pub = await call(null, 'POST', '/api/public/checkout', { customer: { name: 'T', phone: '9000000012' }, address: 'x', items, manual_discount: { type: 'percent', value: 90 } });
  assert.equal(pub.status, 201); assert.equal(pub.json.discount, 0, 'website visitors cannot give themselves a discount');
});

test('the bill carries customer details, unique item count and the discount lines', async () => {
  const ms = (await menu()).filter((x) => !x.off && (x.prices.default ?? 0) > 0).slice(0, 3);
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'whatsapp', customer: { name: 'Rhea Sharma', phone: '9876543210' }, address: 'Flat 4B, Green Park', notes: 'Less spicy',
    items: [{ menu_item_id: ms[0].id, qty: 2 }, { menu_item_id: ms[1].id, qty: 1 }, { menu_item_id: ms[2].id, qty: 3 }], manual_discount: { type: 'percent', value: 10, reason: 'Birthday' } })).json.order;
  const b = (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json;
  assert.equal(b.customer, 'Rhea Sharma'); assert.equal(b.phone, '9876543210'); assert.equal(b.address, 'Flat 4B, Green Park'); assert.equal(b.notes, 'Less spicy');
  assert.equal(b.unique_items, 3); assert.equal(b.total_qty, 6); assert.equal(b.lines.length, 3);
  assert.equal(b.manual_discount, o.manual_discount); assert.equal(b.discount_reason, 'Birthday'); assert.equal(b.discount_type, 'percent'); near(b.cgst + b.sgst, o.tax, 'tax split');
  const same = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: ms[0].id, qty: 1 }, { menu_item_id: ms[0].id, qty: 4 }] })).json.order;
  assert.equal((await call('Owner', 'GET', `/api/orders/${same.id}/bill`)).json.unique_items, 1, 'the same dish twice counts once');
});

test('sheet ingredient cost drives food cost and profit when there is no recipe', async () => {
  const m = await onSale((x) => x.ingredient_cost > 0 && !x.has_recipe); assert.ok(m, 'a costed dish exists');
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', accept: true, items: [{ menu_item_id: m.id, qty: 3 }] })).json.order;
  near(o.food_cost, m.ingredient_cost * 3, 'order food cost'); near(o.order_profit, o.net_sales - o.commission - o.food_cost, 'order profit');
  assert.equal(m.food_cost, m.ingredient_cost); assert.ok(m.net_margin < m.prices.default - m.ingredient_cost + 0.01, 'net margin also subtracts operational and packaging cost');
});

test('menu engineering rates dishes from the sales sheet, leaves uncosted ones out, and prefers real orders later', async () => {
  const e = (await call('Owner', 'GET', '/api/analytics/menu-engineering?source=sheet')).json;
  assert.equal(e.source, 'sheet'); assert.ok(e.baseline_units > 4000); const rated = e.items.filter((i) => ['Star', 'Plowhorse', 'Puzzle', 'Dog'].includes(i.class)); assert.ok(rated.length > 5);
  assert.equal(Object.values(e.counts).reduce((a, b) => a + b, 0), e.items.length);
  for (const i of rated) { assert.ok(i.costed); const hiPop = i.mix_pct >= e.thresholds.popularity_pct, hiCm = i.cm >= e.thresholds.avg_cm; assert.equal(i.class, hiPop && hiCm ? 'Star' : hiPop ? 'Plowhorse' : hiCm ? 'Puzzle' : 'Dog', i.name); }
  assert.ok(e.items.filter((i) => i.class === 'Needs cost').every((i) => i.food_cost === null), 'no cost, no rating');
  assert.equal((await call('Cashier', 'GET', '/api/analytics/menu-engineering')).status, 403);
  assert.equal((await call('Owner', 'PUT', '/api/targets', { monthly_operational_cost: 120000, avg_ticket: 300, cost_share_pct: 40, days: 30 })).status, 200);
  const t = (await call('Owner', 'GET', '/api/analytics/menu-engineering')).json.targets; near(t.required_monthly_sales, 300000, 'monthly sales needed'); near(t.required_per_day, 10000, 'per day'); near(t.required_tickets_per_day, 33.33, 'bills per day');
  assert.equal((await call('Owner', 'POST', '/api/menu-sales', { rows: [{ name: 'Lychee Mojito', qty: 10, amount: 1290 }] })).status, 200);
  assert.equal((await call('Owner', 'GET', '/api/analytics/menu-engineering?source=sheet')).json.baseline_units, 10, 'new sales sheet replaces the old one');
});
