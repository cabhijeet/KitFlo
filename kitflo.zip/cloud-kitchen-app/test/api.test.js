// End-to-end API tests against a real server on a throwaway database. Run: npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-test-'));
process.env.DATA_DIR = dir; process.env.AGGREGATOR_WEBHOOK_SECRET = 'test-secret'; process.env.NODE_ENV = 'test'; process.env.SEED_DEMO = '1';
let base, server, db; const tokens = {};
const call = async (who, method, url, body, headers = {}) => {
  const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tokens[who] } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  let json = null; try { json = await r.json(); } catch { /* empty */ }
  return { status: r.status, json };
};
const login = async (name, pin) => { const users = (await call(null, 'GET', '/api/users')).json; const u = users.find((x) => x.name === name); const r = await call(null, 'POST', '/api/login', { user_id: u.id, pin }); assert.equal(r.status, 200); tokens[name] = r.json.token; };

before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`;
  db = await import('../server/db.js');
  for (const [n, p] of [['Owner', '1234'], ['Manager', '2222'], ['Cashier', '3333'], ['Kitchen', '4444'], ['Marketer', '5555']]) await login(n, p);
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });

const items = () => call('Owner', 'GET', '/api/inventory-items').then((r) => r.json);
const dish = async (name) => (await call('Owner', 'GET', '/api/menu-items')).json.find((m) => m.name === name);

test('wrong PIN is rejected, right PIN signs in', async () => {
  const users = (await call(null, 'GET', '/api/users')).json;
  const r = await call(null, 'POST', '/api/login', { user_id: users[0].id, pin: '0000' }); assert.equal(r.status, 401);
  assert.equal((await call(null, 'GET', '/api/orders')).status, 401);
});

test('roles are enforced on the server', async () => {
  assert.equal((await call('Cashier', 'GET', '/api/expenses')).status, 403);
  assert.equal((await call('Cashier', 'GET', '/api/analytics/profit/live')).status, 403);
  assert.equal((await call('Kitchen', 'POST', '/api/orders', { channel: 'walkin', items: [] })).status, 403);
  assert.equal((await call('Marketer', 'GET', '/api/orders')).status, 403);
  assert.equal((await call('Marketer', 'GET', '/api/social/posts')).status, 200);
  assert.equal((await call('Cashier', 'GET', '/api/settings')).status, 403);
});

test('placing an order deducts stock, cancelling puts it back', async () => {
  const d = await dish('Chicken Dum Biryani'); const before = await items();
  const r = await call('Cashier', 'POST', '/api/orders', { channel: 'walkin', accept: true, items: [{ menu_item_id: d.id, qty: 2 }] });
  assert.equal(r.status, 201); assert.equal(r.json.order.status, 'accepted');
  const mid = await items();
  for (const l of d.recipe) { const b = before.find((i) => i.id === l.inventory_item_id).on_hand, m = mid.find((i) => i.id === l.inventory_item_id).on_hand; assert.ok(m < b, `${l.ingredient} should drop`); }
  const c = await call('Cashier', 'POST', `/api/orders/${r.json.order.id}/status`, { status: 'cancelled', reason: 'test' }); assert.equal(c.status, 200);
  const after_ = await items();
  for (const i of before) assert.ok(Math.abs(after_.find((x) => x.id === i.id).on_hand - i.on_hand) < 1e-6, `${i.name} restored`);
  const again = await call('Cashier', 'POST', `/api/orders/${r.json.order.id}/status`, { status: 'cancelled' }); assert.equal(again.status, 200);
  assert.ok(Math.abs((await items()).find((x) => x.id === d.recipe[0].inventory_item_id).on_hand - before.find((x) => x.id === d.recipe[0].inventory_item_id).on_hand) < 1e-6, 'double cancel does not restore twice');
});

test('invalid status jumps are refused', async () => {
  const d = await dish('Sweet Lassi'); const r = await call('Cashier', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: d.id, qty: 1 }] });
  assert.equal((await call('Cashier', 'POST', `/api/orders/${r.json.order.id}/status`, { status: 'ready' })).status, 400);
});

test('aggregator webhook is authenticated and idempotent', async () => {
  const body = { channel: 'swiggy', order_id: 'SW-T-1', items: [{ name: 'Sweet Lassi', qty: 1, price: 90 }], customer: { name: 'T', phone: '9000000001' } };
  assert.equal((await call(null, 'POST', '/api/webhooks/aggregator/dyno', body)).status, 401);
  assert.equal((await call(null, 'POST', '/api/webhooks/aggregator/dyno', body, { 'x-webhook-secret': 'wrong' })).status, 401);
  const a = await call(null, 'POST', '/api/webhooks/aggregator/dyno', body, { 'x-webhook-secret': 'test-secret' }); assert.equal(a.status, 200); assert.equal(a.json.duplicate, false);
  const b = await call(null, 'POST', '/api/webhooks/aggregator/dyno', body, { 'x-webhook-secret': 'test-secret' }); assert.equal(b.json.duplicate, true); assert.equal(b.json.order_no, a.json.order_no);
  const o = (await call('Owner', 'GET', '/api/orders')).json.filter((x) => x.channel_order_id === 'SW-T-1'); assert.equal(o.length, 1);
  assert.ok(o[0].commission > 0, 'commission snapshot taken');
});

test('Idempotency-Key makes a retried POST safe', async () => {
  const d = await dish('Masala Fries'); const h = { 'idempotency-key': 'k-' + Date.now() }; const body = { channel: 'walkin', items: [{ menu_item_id: d.id, qty: 1 }] };
  const a = await call('Cashier', 'POST', '/api/orders', body, h), b = await call('Cashier', 'POST', '/api/orders', body, h);
  assert.equal(a.json.order.id, b.json.order.id);
});

test('profit equals sales minus commission, food cost and expenses', async () => {
  const live = (await call('Owner', 'GET', '/api/analytics/profit/live')).json; const t = live.today;
  const parts = ['net', 'sales', 'commission', 'food_cost', 'wastage', 'expenses'].filter((k) => k in t);
  assert.ok(parts.includes('net') && parts.includes('sales'), 'profit payload shape');
  const calc = t.sales - (t.commission || 0) - (t.food_cost || 0) - (t.wastage || 0) - (t.expenses || 0);
  assert.ok(Math.abs(calc - t.net) < 0.02, `net ${t.net} vs computed ${calc}`);
  const before = t.net; const e = await call('Owner', 'POST', '/api/expenses', { category: 'Utilities', amount: 500 }); assert.equal(e.status, 201);
  const after_ = (await call('Owner', 'GET', '/api/analytics/profit/live')).json.today.net; assert.ok(Math.abs(before - after_ - 500) < 0.02, 'expense reduces net by its amount');
});

test('recurring expense posts once when confirmed', async () => {
  const today = new Date().toISOString().slice(0, 10);
  const r = await call('Owner', 'POST', '/api/recurring-expenses', { name: 'Test rent', category: 'Rent', amount: 1000, frequency: 'monthly', next_due: today, auto_post: false });
  assert.equal(r.status, 201); const id = r.json.id ?? r.json.rule?.id;
  const list = (await call('Owner', 'GET', '/api/recurring-expenses')).json; const row = list.find((x) => x.name === 'Test rent'); assert.ok(row);
  const before = (await call('Owner', 'GET', '/api/expenses', null)).json.rows?.length ?? 0;
  assert.equal((await call('Owner', 'POST', `/api/recurring-expenses/${row.id}/confirm`)).status, 200);
  const next = (await call('Owner', 'GET', '/api/recurring-expenses')).json.find((x) => x.id === row.id); assert.ok(next.next_due > today, 'next due moved forward');
  void id; void before;
});

test('surplus stock drafts a promo post that waits for approval', async () => {
  const inv = await items(); const it = inv.find((i) => i.par_level > 0);
  await call('Owner', 'PATCH', `/api/inventory-items/${it.id}`, { par_level: Math.max(0.01, it.on_hand / 3) });
  const countAuto = async () => { const x = (await call('Owner', 'GET', '/api/social/posts')).json; return (x.posts || x).filter((p) => p.origin === 'automation').length; };
  const beforeN = await countAuto();
  await call('Owner', 'POST', '/api/events', { type: 'stock.surplus', payload: { item_id: it.id, item: it.name, on_hand: it.on_hand, unit: it.unit } }).catch(() => {});
  await new Promise((r) => setTimeout(r, 600));
  const runs = (await call('Owner', 'GET', '/api/automations/runs')).json; assert.ok(Array.isArray(runs));
  assert.equal(await countAuto(), beforeN + 1, 'one new automation post');
  const newest = ((await call('Owner', 'GET', '/api/social/posts')).json.posts || (await call('Owner', 'GET', '/api/social/posts')).json).filter((p) => p.origin === 'automation').sort((a, b) => b.id - a.id)[0];
  assert.notEqual(newest.status, 'published', 'auto post is not published without approval');
});

test('public checkout validates input, places a website order and can be tracked', async () => {
  const menu = (await call(null, 'GET', '/api/public/menu')).json; const m = menu.items[0]; assert.ok(m);
  assert.equal((await call(null, 'POST', '/api/public/checkout', { customer: { name: 'Web', phone: '123' }, items: [{ menu_item_id: m.id, qty: 1 }], address: 'x' })).status, 400);
  const r = await call(null, 'POST', '/api/public/checkout', { customer: { name: 'Web', phone: '9000000002' }, items: [{ menu_item_id: m.id, qty: 1 }], address: 'Test street' });
  assert.equal(r.status, 201); assert.ok(r.json.total > 0);
  const t = await call(null, 'GET', `/api/public/track?order_no=${r.json.order_no}&phone=9000000002`); assert.equal(t.status, 200); assert.equal(t.json.status, 'new');
  assert.equal((await call(null, 'GET', `/api/public/track?order_no=${r.json.order_no}&phone=9111111111`)).status, 404, 'wrong phone cannot see the order');
});

test('repeated wrong PINs lock the account, even from other addresses', async () => {
  const users = (await call(null, 'GET', '/api/users')).json; const u = users.find((x) => x.name === 'Marketer');
  let last; for (let i = 0; i < 12; i++) last = await call(null, 'POST', '/api/login', { user_id: u.id, pin: '9' + String(i).padStart(3, '0') });
  assert.equal(last.status, 429);
  const right = await call(null, 'POST', '/api/login', { user_id: u.id, pin: '5555' }); assert.equal(right.status, 429, 'correct PIN is refused while locked');
});
