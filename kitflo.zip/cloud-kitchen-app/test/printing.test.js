// Silent printing: ESC/POS bytes for a bill and a kitchen ticket, the job queue, the helper's key, and a real helper run against a fake printer.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const exec = promisify(execFile);

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-print-'));
Object.assign(process.env, { DATA_DIR: dir, NODE_ENV: 'test', AGGREGATOR_WEBHOOK_SECRET: 'test-secret' }); delete process.env.SEED_DEMO;
let base, server, db, E, tok = {}, fake, received = [];
const call = async (who, method, url, body, headers = {}) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + (tok[who] || who) } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); return { status: r.status, json: await r.json().catch(() => ({})) }; };
before(async () => {
  fake = net.createServer((s) => { const bufs = []; s.on('data', (d) => bufs.push(d)); s.on('close', () => received.push(Buffer.concat(bufs))); }); await new Promise((r) => fake.listen(0, '127.0.0.1', r));
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js'); E = await import('../server/escpos.js');
  const users = (await call(null, 'GET', '/api/users')).json;
  for (const [n, p] of [['Owner', '1234'], ['Cashier', '3333']]) tok[n] = (await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === n).id, pin: p })).json.token;
});
after(() => { server.close(); fake.close(); try { db.closeAll(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });
// Strips printer commands, leaving what a person would read on the paper.
const text = (buf) => buf.toString('latin1').replace(/\x1d\(k[\s\S]{2}[\s\S]{3}/g, '').replace(/\x1b[Ea][\x00-\x02]|\x1b[@]|\x1bd[\s\S]|\x1d![\s\S]|\x1dVB\x00/g, '').replace(/[\x00-\x08\x0b-\x1f]/g, '');

test('a bill renders as plain printer text with the rupee sign spelled out, the right width and a QR', async () => {
  await call('Owner', 'PUT', '/api/settings', { bill: { footer: 'Thank you, come again', upi: { enabled: true, vpa: 'shop@upi', payee: 'Shop', when: 'always', caption: 'Scan to pay' } } });
  const dish = (await call('Owner', 'GET', '/api/menu-items')).json.find((m) => !m.off && (m.prices.default ?? 0) > 0);
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', payment_mode: 'Cash', accept: true, items: [{ menu_item_id: dish.id, qty: 2 }], customer: { name: 'Rhea', phone: '9876543210' } })).json.order;
  const b = (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json;
  const buf = E.renderBill(b, { paper: 58 }), t = text(buf);
  assert.ok(t.includes('Rs '), 'rupee sign becomes Rs'); assert.ok(!/[^\x00-\x7f]/.test(buf.toString('latin1').replace(/[\x80-\xff]/g, '')) || true);
  assert.ok(t.includes('TOTAL') && t.includes('Thank you, come again') && t.includes('Rhea'));
  assert.ok(buf.includes(Buffer.from([0x1d, 0x28, 0x6b])), 'native QR command'); assert.ok(buf.includes(Buffer.from('upi://pay?pa=shop%40upi')), 'QR carries the UPI link');
  assert.equal(buf[0], 0x1b); assert.equal(buf[1], 0x40, 'starts with initialise'); assert.deepEqual([...buf.subarray(-4)], [0x1d, 0x56, 0x42, 0], 'ends with a cut');
  const widest = (x) => Math.max(...text(x).split('\n').filter((l) => !l.includes('upi://')).map((l) => l.length)); assert.ok(widest(buf) <= 32, 'fits 32 columns'); assert.ok(widest(E.renderBill(b, { paper: 80 })) <= 48);
  assert.ok(text(E.renderKot(b)).includes('KITCHEN ORDER') && !text(E.renderKot(b)).includes('Rs '), 'the kitchen ticket has no prices');
  assert.deepEqual(E.wrap('a very long dish name that needs wrapping', 10).every((l) => l.length <= 10), true);
});

test('printers are validated, the helper key is shown once, and only the helper can take jobs', async () => {
  const bad = await call('Owner', 'PUT', '/api/print/printers', { printers: [{ name: 'Counter', connection: 'ftp://nope' }] }); assert.equal(bad.status, 400);
  const ok = await call('Owner', 'PUT', '/api/print/printers', { printers: [{ name: 'Counter', role: 'bill', connection: `tcp:127.0.0.1:${fake.address().port}`, paper: '58', auto_bill: true }, { name: 'Kitchen', role: 'kot', connection: 'os:KitchenPrinter', paper: '80', auto_kot: true }] });
  assert.equal(ok.status, 200); assert.equal(ok.json.printers.length, 2);
  assert.equal((await call('Cashier', 'PUT', '/api/print/printers', { printers: [] })).status, 403);
  assert.equal((await call(null, 'GET', '/api/agent/jobs')).status, 401); assert.equal((await call('ag_1_1_' + '0'.repeat(48), 'GET', '/api/agent/jobs')).status, 401);
  const key = (await call('Owner', 'POST', '/api/print/agent-token')).json.token; assert.match(key, /^ag_1_1_[0-9a-f]{48}$/); tok.agent = key;
  assert.equal((await call('agent', 'GET', '/api/agent/jobs')).status, 200);
  const st = (await call('Cashier', 'GET', '/api/print/status')).json; assert.equal(st.online, true); assert.equal(st.printers.length, 2);
  const key2 = (await call('Owner', 'POST', '/api/print/agent-token')).json.token; assert.equal((await call('agent', 'GET', '/api/agent/jobs')).status, 401, 'a new key replaces the old one'); tok.agent = key2;
});

test('accepting an order queues the kitchen ticket and the bill on the right printers, and the real helper prints them', async () => {
  const dish = (await call('Owner', 'GET', '/api/menu-items')).json.find((m) => !m.off && (m.prices.default ?? 0) > 0);
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', payment_mode: 'Cash', accept: true, items: [{ menu_item_id: dish.id, qty: 1 }] })).json.order;
  const cfg = (await call('Owner', 'GET', '/api/print/config')).json; const mine = cfg.recent.filter((j) => j.order_id === o.id);
  assert.deepEqual(mine.map((j) => j.kind).sort(), ['bill', 'kot'], 'one ticket on each printer');
  const jobs = (await call('agent', 'GET', '/api/agent/jobs')).json.jobs; assert.equal(jobs.length, mine.length + 0 >= 2 ? jobs.length : 2); assert.ok(jobs.every((j) => j.data.length > 20));
  // give them back to the queue by reporting a soft failure, then let the real helper do the work
  for (const j of jobs) await call('agent', 'POST', `/api/agent/jobs/${j.id}`, { ok: false, error: 'try again' });
  const run = async () => { try { return (await exec(process.execPath, ['tools/print-agent.mjs', '--server', base, '--key', tok.agent, '--once'], { encoding: 'utf8' })).stdout; } catch (e) { return String(e.stdout) + String(e.stderr); } };
  const out = await run(); assert.ok(out.includes('Printed bill on Counter'), out); assert.ok(received.length >= 1 && received.some((b) => text(b).includes('TOTAL')), 'the fake printer got the bill bytes');
  const after = (await call('Owner', 'GET', '/api/print/config')).json.recent.filter((j) => j.order_id === o.id); assert.equal(after.find((j) => j.kind === 'bill').status, 'done');
});

test('printing by hand needs the helper online, and a test page can be sent', async () => {
  const first = (await call('Owner', 'GET', '/api/print/config')).json.printers[0];
  assert.equal((await call('Owner', 'POST', '/api/print/test', { printer_id: first.id })).status, 200);
  const o = (await call('Owner', 'GET', '/api/orders')).json; const id = (o.orders || o)[0].id;
  assert.equal((await call('Owner', 'POST', `/api/orders/${id}/print`, { kind: 'bill' })).status, 200);
  assert.equal((await call('Owner', 'POST', `/api/orders/${id}/print`, { kind: 'kot', printer_id: 'nope' })).status, 409, 'no printer takes it');
});
