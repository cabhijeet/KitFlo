// Hosted mode: sign-up, isolation between businesses, staff devices, plan limits, billing, signed webhook, platform API.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-hosted-'));
Object.assign(process.env, { DATA_DIR: dir, NODE_ENV: 'test', MULTI_TENANT: '1', PLATFORM_TOKEN: 'platform-token-123456', RAZORPAY_WEBHOOK_SECRET: 'whsec', RAZORPAY_KEY_ID: 'k', RAZORPAY_KEY_SECRET: 's', SELLER_STATE: 'Karnataka', SELLER_GSTIN: '29ABCDE1234F1Z5' });
delete process.env.SEED_DEMO;
let base, server, gw, C;
const links = [];
const call = async (method, url, body, headers = {}, raw) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...headers }, body: raw ?? (body ? JSON.stringify(body) : undefined) }); return { status: r.status, json: await r.json().catch(() => ({})) }; };
const authz = (t, extra = {}) => ({ authorization: 'Bearer ' + t, ...extra });
const A = {}, B = {};
before(async () => {
  gw = http.createServer((req, res) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { const j = JSON.parse(b || '{}'); links.push(j); res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ short_url: 'https://rzp.test/' + j.reference_id.replace(/\W/g, '') })); }); });
  await new Promise((r) => gw.listen(0, r)); process.env.RAZORPAY_API_BASE = `http://127.0.0.1:${gw.address().port}`;
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; C = await import('../server/control.js');
});
after(() => { server.close(); gw.close(); try { C.closeControl(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });

test('sign-up makes a business with a trial, an owner session and a shop device', async () => {
  assert.equal((await call('GET', '/api/auth/mode')).json.multi_tenant, true);
  const r = await call('POST', '/api/signup', { business: 'Alpha Bites', name: 'Asha', email: 'Asha@Example.com', phone: '98765 43210', password: 'longenough1', pin: '2468', plan: 'starter', shop_device: true });
  assert.equal(r.status, 201, JSON.stringify(r.json)); Object.assign(A, { tok: r.json.token, dev: r.json.device_key, slug: r.json.account.slug, id: r.json.account.id });
  assert.match(A.tok, /^t\d+\./); assert.match(A.dev, /^dv_\d+_/);
  const b = await call('POST', '/api/signup', { business: 'Beta Bowls', name: 'Bala', email: 'bala@example.com', password: 'longenough2', pin: '1357', shop_device: true });
  Object.assign(B, { tok: b.json.token, dev: b.json.device_key, slug: b.json.account.slug, id: b.json.account.id });
  assert.notEqual(A.id, B.id);
  assert.equal((await call('POST', '/api/signup', { business: 'Dup', name: 'x', email: 'asha@example.com', password: 'longenough1', pin: '2468' })).status, 409);
  assert.equal((await call('POST', '/api/signup', { business: 'Weak', name: 'x', email: 'w@example.com', password: 'short', pin: '2468' })).status, 400);
  const me = (await call('GET', '/api/me', null, authz(A.tok))).json; assert.equal(me.user.role, 'owner'); assert.equal(me.billing.state, 'trial'); assert.ok(me.billing.days_left >= 13);
});

test('each business sees only its own data', async () => {
  const menuA = (await call('GET', '/api/menu-items', null, authz(A.tok))).json; assert.equal(menuA.length, 0, 'a new business starts with no sample dishes');
  const mk = await call('POST', '/api/menu-items', { name: 'Alpha Burger', category: 'Burgers', prices: { default: 120 } }, authz(A.tok)); assert.ok(mk.status < 300, JSON.stringify(mk.json));
  assert.equal((await call('GET', '/api/menu-items', null, authz(A.tok))).json.length, 1);
  assert.equal((await call('GET', '/api/menu-items', null, authz(B.tok))).json.length, 0);
  const pub = await call('GET', `/api/public/menu?k=${A.slug}`); assert.equal(pub.status, 200); assert.ok(JSON.stringify(pub.json).includes('Alpha Burger'));
  assert.ok(!JSON.stringify((await call('GET', `/api/public/menu?k=${B.slug}`)).json).includes('Alpha Burger'));
  assert.equal((await call('GET', '/api/public/menu')).status, 400, 'a public page must say which business');
  assert.equal((await call('GET', '/api/menu-items', null, authz('t999.fake'))).status >= 400, true);
});

test('staff names and PIN sign-in only work on approved devices', async () => {
  assert.equal((await call('GET', '/api/users')).status, 403);
  assert.equal((await call('GET', '/api/users', null, { 'x-device': 'dv_2_' + '0'.repeat(48) })).status, 403);
  const ua = (await call('GET', '/api/users', null, { 'x-device': A.dev })).json; assert.deepEqual(ua.map((u) => u.name), ['Asha']);
  const ub = (await call('GET', '/api/users', null, { 'x-device': B.dev })).json; assert.deepEqual(ub.map((u) => u.name), ['Bala']);
  const ok = await call('POST', '/api/login', { user_id: ua[0].id, pin: '2468' }, { 'x-device': A.dev }); assert.equal(ok.status, 200); assert.match(ok.json.token, /^t\d+\./);
  assert.equal((await call('POST', '/api/login', { user_id: ua[0].id, pin: '2468' })).status, 403, 'no device, no PIN screen');
  assert.equal((await call('POST', '/api/login', { user_id: ua[0].id, pin: '0000' }, { 'x-device': A.dev })).status, 401);
  const list = (await call('GET', '/api/staff-devices', null, authz(A.tok))).json; assert.equal(list.length, 1);
  assert.equal((await call('DELETE', `/api/staff-devices/${list[0].id}`, null, authz(A.tok))).status, 200);
  assert.equal((await call('GET', '/api/users', null, { 'x-device': A.dev })).status, 403, 'a revoked device stops working');
});

test('email sign-in works and wrong passwords are refused', async () => {
  assert.equal((await call('POST', '/api/account/login', { email: 'asha@example.com', password: 'nope-nope' })).status, 401);
  const r = await call('POST', '/api/account/login', { email: 'ASHA@example.com', password: 'longenough1', shop_device: true, device_name: 'Counter tablet' });
  assert.equal(r.status, 200); assert.ok(r.json.device_key); assert.equal(r.json.account.slug, A.slug); A.tok = r.json.token; A.dev = r.json.device_key;
});

test('plan limits are enforced by the server and a downgrade is refused when usage is too high', async () => {
  for (const [i, n] of ['Cook1', 'Cook2'].entries()) assert.equal((await call('POST', '/api/admin/users', { name: n, role: 'cashier', pin: '11' + (10 + i) }, authz(A.tok))).status, 201);
  const over = await call('POST', '/api/admin/users', { name: 'Cook3', role: 'cashier', pin: '1199' }, authz(A.tok)); assert.equal(over.status, 403); assert.equal(over.json.code, 'plan_limit');
  assert.equal((await call('POST', '/api/admin/outlets', { name: 'Second' }, authz(A.tok))).status, 403, 'Starter has one outlet');
  assert.equal((await call('POST', '/api/billing/plan', { plan: 'pro' }, authz(A.tok))).status, 200);
  assert.equal((await call('POST', '/api/admin/users', { name: 'Cook3', role: 'cashier', pin: '1199' }, authz(A.tok))).status, 201);
  assert.equal((await call('POST', '/api/billing/plan', { plan: 'starter' }, authz(A.tok))).status, 400, 'four people do not fit Starter');
});

test('when the trial ends the app pauses but billing stays open; paying through the signed webhook restores it', async () => {
  C.updateAccount(B.id, { trial_ends: new Date(Date.now() - 864e5).toISOString() });
  const blocked = await call('GET', '/api/menu-items', null, authz(B.tok)); assert.equal(blocked.status, 402); assert.equal(blocked.json.code, 'subscription_required');
  assert.equal((await call('GET', '/api/me', null, authz(B.tok))).json.billing.ok, false);
  assert.equal((await call('POST', '/api/billing/details', { gstin: 'bad' }, authz(B.tok))).status, 400);
  assert.equal((await call('POST', '/api/billing/details', { gstin: '29AAAAA0000A1Z5', billing_name: 'Beta Bowls LLP', billing_state: 'Karnataka' }, authz(B.tok))).status, 200);
  await call('POST', '/api/billing/plan', { plan: 'growth', cycle: 'monthly' }, authz(B.tok));
  const inv = await call('POST', '/api/billing/invoice', {}, authz(B.tok)); assert.equal(inv.status, 200, JSON.stringify(inv.json));
  assert.match(inv.json.pay_link, /^https:\/\/rzp\.test\//); assert.equal(inv.json.taxable, 1299); assert.equal(inv.json.total, 1532.82);
  assert.equal(links.at(-1).amount, 153282, 'the gateway is asked in paise'); assert.equal(links.at(-1).reference_id, inv.json.number);
  const again = await call('POST', '/api/billing/invoice', {}, authz(B.tok)); assert.equal(again.json.number, inv.json.number, 'the same open invoice is reused');
  const full = (await call('GET', `/api/billing/invoices/${encodeURIComponent(inv.json.number)}`, null, authz(B.tok))).json; assert.equal(full.cgst, 116.91); assert.equal(full.sgst, 116.91); assert.equal(full.igst, 0, 'same state: CGST + SGST');
  const evt = JSON.stringify({ event: 'payment_link.paid', payload: { payment_link: { entity: { reference_id: inv.json.number } }, payment: { entity: { id: 'pay_1' } } } });
  const sign = (b) => crypto.createHmac('sha256', 'whsec').update(b).digest('hex');
  assert.equal((await call('POST', '/api/webhooks/razorpay', null, { 'x-razorpay-signature': 'deadbeef', 'x-razorpay-event-id': 'e1' }, evt)).status, 400);
  assert.equal((await call('GET', '/api/menu-items', null, authz(B.tok))).status, 402, 'an unsigned call changes nothing');
  const ok = await call('POST', '/api/webhooks/razorpay', null, { 'x-razorpay-signature': sign(evt), 'x-razorpay-event-id': 'e2' }, evt); assert.equal(ok.status, 200); assert.equal(ok.json.settled, true);
  const paidUntil = C.accountById(B.id).paid_until;
  assert.equal((await call('GET', '/api/menu-items', null, authz(B.tok))).status, 200);
  const dup = await call('POST', '/api/webhooks/razorpay', null, { 'x-razorpay-signature': sign(evt), 'x-razorpay-event-id': 'e2' }, evt); assert.equal(dup.json.duplicate, true);
  const dup2 = await call('POST', '/api/webhooks/razorpay', null, { 'x-razorpay-signature': sign(evt), 'x-razorpay-event-id': 'e3' }, evt); assert.equal(dup2.json.settled, false, 'a replayed payment does not extend the plan twice');
  assert.equal(C.accountById(B.id).paid_until, paidUntil);
});

test('a different state gets IGST; yearly costs ten months', async () => {
  const g = C.splitGst(1000, 'Maharashtra', ''); assert.deepEqual(g, { cgst: 0, sgst: 0, igst: 180 });
  assert.equal(C.priceFor('growth', 'yearly', 2), 25980);
});

test('the operator API needs its own token and can pause, extend and impersonate', async () => {
  assert.equal((await call('GET', '/api/platform/accounts')).status, 401);
  assert.equal((await call('GET', '/api/platform/accounts', null, authz(A.tok))).status, 401);
  const P = authz('platform-token-123456');
  const list = (await call('GET', '/api/platform/accounts', null, P)).json; assert.ok(list.length >= 3);
  assert.equal((await call('PATCH', `/api/platform/accounts/${A.id}`, { status: 'suspended' }, P)).status, 200);
  assert.equal((await call('GET', '/api/menu-items', null, authz(A.tok))).status, 402);
  assert.equal((await call('PATCH', `/api/platform/accounts/${A.id}`, { status: 'active', paid_until: new Date(Date.now() + 30 * 864e5).toISOString() }, P)).status, 200);
  assert.equal((await call('GET', '/api/menu-items', null, authz(A.tok))).status, 200);
  const imp = await call('POST', `/api/platform/accounts/${A.id}/impersonate`, { reason: 'support' }, P); assert.equal(imp.status, 200); assert.match(imp.json.token, /^t\d+\./);
  assert.ok(C.eventsFor(A.id).some((e) => e.kind === 'platform.impersonate'), 'support access is logged');
});
