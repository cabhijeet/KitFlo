// Integration partners: each has its own secret and outbound address, and orders map to the right channel.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-int-'));
const received = [];
const relay = http.createServer((req, res) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { received.push({ auth: req.headers.authorization, body: JSON.parse(b || '{}') }); res.end('{}'); }); });
await new Promise((r) => relay.listen(0, '127.0.0.1', r));
Object.assign(process.env, { DATA_DIR: dir, NODE_ENV: 'test', AGGREGATOR_WEBHOOK_SECRET: 'shared', LIMETRAY_WEBHOOK_SECRET: 'lime-secret', LIMETRAY_OUTBOUND_URL: `http://127.0.0.1:${relay.address().port}/lt`, LIMETRAY_OUTBOUND_TOKEN: 'lt-token' });
delete process.env.SEED_DEMO;
let base, server, db, token;
const call = async (method, url, body, headers = {}) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(token && !headers['x-webhook-secret'] ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };

before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call('GET', '/api/users')).json; token = (await call('POST', '/api/login', { user_id: users.find((u) => u.name === 'Owner').id, pin: '1234' })).json.token;
});
after(() => { server.close(); relay.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });

const order = (id, extra = {}) => ({ order_id: id, customer: { name: 'Test', phone: '9000000011' }, items: [{ name: 'Sattu Paratha', quantity: 1, price: 209 }], ...extra });

test('each partner uses its own secret, others fall back to the shared one', async () => {
  assert.equal((await call('POST', '/api/webhooks/aggregator/limetray', order('LT1', { source: 'Swiggy' }), { 'x-webhook-secret': 'shared' })).status, 401, 'LimeTray refuses the shared secret once it has its own');
  assert.equal((await call('POST', '/api/webhooks/aggregator/limetray', order('LT1', { source: 'Swiggy' }), { 'x-webhook-secret': 'lime-secret' })).status, 200);
  assert.equal((await call('POST', '/api/webhooks/aggregator/foodengine', order('FE1', { source: 'Zomato' }), { 'x-webhook-secret': 'shared' })).status, 200, 'FoodEngine uses the shared secret');
  assert.equal((await call('POST', '/api/webhooks/aggregator/nobody', order('X1'), { 'x-webhook-secret': 'shared' })).status, 404);
});

test('orders land on the right channel, and are not duplicated', async () => {
  const orders = async () => (await call('GET', '/api/orders')).json;
  const swiggy = (await orders()).find((o) => o.channel_order_id === 'LT1'); assert.equal(swiggy.channel, 'swiggy');
  assert.equal((await orders()).find((o) => o.channel_order_id === 'FE1').channel, 'zomato');
  const own = await call('POST', '/api/webhooks/aggregator/limetray', order('LT2', { source: 'LimeTray Website' }), { 'x-webhook-secret': 'lime-secret' }); assert.equal(own.status, 200);
  assert.equal((await orders()).find((o) => o.channel_order_id === 'LT2').channel, 'website');
  const noHint = await call('POST', '/api/webhooks/aggregator/foodengine', order('FE2'), { 'x-webhook-secret': 'shared' }); assert.equal(noHint.status, 200, 'FoodEngine order with no source is the website channel');
  assert.equal((await orders()).find((o) => o.channel_order_id === 'FE2').channel, 'website');
  const dup = await call('POST', '/api/webhooks/aggregator/limetray', order('LT2', { source: 'LimeTray Website' }), { 'x-webhook-secret': 'lime-secret' }); assert.equal(dup.json.duplicate, true);
  const dyno = await call('POST', '/api/webhooks/aggregator/dyno', order('D1'), { 'x-webhook-secret': 'shared' }); assert.equal(dyno.status, 400, 'Dyno order with no channel is still refused');
});

test('accepting an order sends it to LimeTray with its own token', async () => {
  assert.equal((await call('PATCH', '/api/channels/swiggy', { integration_provider: 'limetray', provider_store_id: 'OUTLET-7' })).status, 200);
  const o = (await call('GET', '/api/orders')).json.find((x) => x.channel_order_id === 'LT1');
  received.length = 0; const r = await call('POST', `/api/orders/${o.id}/status`, { status: 'accepted' }); assert.equal(r.status, 200);
  await new Promise((r2) => setTimeout(r2, 400));
  assert.equal(received.length, 1); assert.equal(received[0].auth, 'Bearer lt-token');
  assert.equal(received[0].body.provider, 'limetray'); assert.equal(received[0].body.action, 'accept');
  assert.equal(received[0].body.payload.channel_order_id, 'LT1'); assert.equal(received[0].body.payload.store_id, 'OUTLET-7');
});

test('the website channel can use a partner, and unknown partners are refused', async () => {
  assert.equal((await call('PATCH', '/api/channels/website', { integration_provider: 'foodengine' })).status, 200);
  assert.equal((await call('PATCH', '/api/channels/website', { integration_provider: 'madeup' })).status, 400);
});
