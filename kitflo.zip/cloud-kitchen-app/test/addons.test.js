// Add-ons: groups attached to dishes, server-side pricing, required and limited choices, stock use, cancel reversal, public ordering.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-addons-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; process.env.AGGREGATOR_WEBHOOK_SECRET = 'test-secret'; delete process.env.SEED_DEMO;
let base, server, db; const tok = {};
const call = async (who, method, url, body, headers = {}) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tok[who] } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };
before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call(null, 'GET', '/api/users')).json;
  for (const [n, p] of [['Owner', '1234'], ['Cashier', '3333'], ['Kitchen', '4444']]) tok[n] = (await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === n).id, pin: p })).json.token;
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });

const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.011, `${msg}: ${a} vs ${b}`);
const dishes = async () => (await call('Owner', 'GET', '/api/menu-items')).json.filter((m) => !m.off && m.available && (m.prices.default ?? 0) > 0);
let d1, d2, extras, size, cheese, sauce;

test('an add-on group with a price and cost can be made and attached to chosen dishes', async () => {
  [d1, d2] = await dishes();
  const r = await call('Owner', 'POST', '/api/addons', { name: 'Extras', min_pick: 0, max_pick: 3, addons: [{ name: 'Extra cheese', price: 20, cost: 8 }, { name: 'Peri peri dip', price: 15, cost: 5 }], item_ids: [d1.id] });
  assert.equal(r.status, 201); extras = r.json; assert.equal(extras.addons.length, 2); assert.deepEqual(extras.item_ids, [d1.id]);
  [cheese, sauce] = extras.addons;
  const m = (await call('Owner', 'GET', '/api/menu-items')).json;
  assert.deepEqual(m.find((x) => x.id === d1.id).addon_group_ids, [extras.id]); assert.deepEqual(m.find((x) => x.id === d2.id).addon_group_ids, []);
  assert.equal((await call('Cashier', 'POST', '/api/addons', { name: 'Nope', addons: [] })).status, 403, 'cashiers cannot edit add-ons');
});

test('the order price is the dish price plus add-ons, worked out by the server', async () => {
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: d1.id, qty: 2, addons: [{ id: cheese.id, qty: 2 }, { id: sauce.id }], unit_price: 1 }] })).json.order;
  const each = d1.prices.default + 40 + 15; near(o.items[0].unit_price, each, 'unit price'); near(o.subtotal, each * 2, 'subtotal');
  assert.equal(o.items[0].modifiers, '+ 2× Extra cheese, Peri peri dip'); assert.equal(o.items[0].addons.length, 2); assert.equal(o.items[0].addons[0].price, 20);
  const m = (await call('Owner', 'GET', '/api/menu-items')).json.find((x) => x.id === d1.id), base = m.food_cost;
  near(o.items[0].unit_cost, base + 2 * 8 + 5, 'cost includes add-on cost');
});

test('add-ons from another dish, unknown add-ons and too many choices are refused', async () => {
  const bad = async (items) => (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items })).status;
  assert.equal(await bad([{ menu_item_id: d2.id, addons: [{ id: cheese.id }] }]), 400, 'not attached to this dish');
  assert.equal(await bad([{ menu_item_id: d1.id, addons: [{ id: 99999 }] }]), 400);
  assert.equal(await bad([{ menu_item_id: d1.id, addons: [{ id: cheese.id, qty: 3 }, { id: sauce.id }] }]), 400, 'max 3');
});

test('a required group must be chosen, and a switched-off add-on cannot be sold', async () => {
  const r = await call('Owner', 'POST', '/api/addons', { name: 'Size', min_pick: 1, max_pick: 1, addons: [{ name: 'Regular', price: 0 }, { name: 'Large', price: 50, cost: 20 }], item_ids: [d1.id] });
  size = r.json; const post = (items) => call('Owner', 'POST', '/api/orders', { channel: 'walkin', items });
  const none = await post([{ menu_item_id: d1.id }]); assert.equal(none.status, 400); assert.match(none.json.error, /Size/);
  assert.equal((await post([{ menu_item_id: d1.id, addons: [{ id: size.addons[0].id }, { id: size.addons[1].id }] }])).status, 400, 'only one size');
  const ok = await post([{ menu_item_id: d1.id, addons: [{ id: size.addons[1].id }] }]); assert.equal(ok.status, 201); near(ok.json.order.items[0].unit_price, d1.prices.default + 50, 'large');
  await call('Owner', 'PUT', `/api/addons/${size.id}`, { ...size, addons: size.addons.map((a) => ({ ...a, off: a.name === 'Large' })) });
  assert.equal((await post([{ menu_item_id: d1.id, addons: [{ id: size.addons[1].id }] }])).status, 400, 'Large is off');
  assert.equal((await post([{ menu_item_id: d1.id, addons: [{ id: size.addons[0].id }] }])).status, 201);
});

test('apply to everything adds the group to every dish, and removing a group frees the dishes', async () => {
  const r = await call('Owner', 'POST', '/api/addons', { name: 'Notes', addons: [{ name: 'No onion', price: 0 }], apply_to: 'all' });
  const all = (await call('Owner', 'GET', '/api/menu-items')).json; assert.ok(all.length > 3); assert.ok(all.every((m) => m.addon_group_ids.includes(r.json.id)));
  assert.equal((await call('Owner', 'DELETE', `/api/addons/${r.json.id}`)).status, 200);
  assert.ok((await call('Owner', 'GET', '/api/menu-items')).json.every((m) => !m.addon_group_ids.includes(r.json.id)));
  const one = await call('Owner', 'PUT', `/api/menu-items/${d2.id}/addons`, { group_ids: [extras.id] }); assert.deepEqual(one.json.addon_group_ids, [extras.id]);
});

test('an add-on tied to a stock item uses it up when the order is accepted and gives it back on cancel', async () => {
  const inv = (await call('Owner', 'POST', '/api/inventory-items', { name: 'Cheese slices', unit: 'pc', reorder_level: 1, par_level: 20, unit_cost: 6 })).json;
  await call('Owner', 'POST', '/api/stock-movements', { inventory_item_id: inv.id, type: 'purchase', qty: 10, unit_cost: 6 });
  const g = (await call('Owner', 'POST', '/api/addons', { name: 'Stocked', addons: [{ name: 'Slice', price: 10, inventory_item_id: inv.id, qty_per_use: 2 }], item_ids: [d1.id] })).json;
  const left = async () => (await call('Owner', 'GET', '/api/inventory-items')).json.find((i) => i.id === inv.id).on_hand;
  const before = await left();
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', accept: true, items: [{ menu_item_id: d1.id, qty: 3, addons: [{ id: g.addons[0].id }, { id: size.addons[0].id }] }] })).json.order;
  near(o.items[0].unit_cost - (await call('Owner', 'GET', '/api/menu-items')).json.find((x) => x.id === d1.id).food_cost, 12, 'cost from stock price: 2 x 6');
  near(await left(), before - 6, 'used 2 x 3');
  await call('Owner', 'POST', `/api/orders/${o.id}/status`, { status: 'cancelled', reason: 'Customer changed mind' });
  near(await left(), before, 'given back');
  const unavailable = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: d1.id, addons: [{ id: g.addons[0].id }, { id: size.addons[0].id }], qty: 1 }] })).status; assert.equal(unavailable, 201);
});

test('the bill and ticket carry the add-ons, and the add-on sales report adds them up', async () => {
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: d1.id, qty: 1, addons: [{ id: cheese.id }, { id: size.addons[0].id }], modifiers: 'well done' }] })).json.order;
  assert.match(o.items[0].modifiers, /Extra cheese.*well done/);
  const b = (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json; assert.match(b.lines[0].modifiers, /Extra cheese/);
  const s = (await call('Owner', 'GET', '/api/addons/sales?days=7')).json, ch = s.find((x) => x.name === 'Extra cheese');
  assert.ok(ch && ch.qty >= 3 && ch.revenue >= 60 && ch.profit > 0, JSON.stringify(ch));
});

test('website checkout prices add-ons and only lists add-ons that can be sold', async () => {
  await call('Owner', 'PUT', '/api/settings', { business: { name: 'Test Kitchen' } });
  const menu = (await call(null, 'GET', '/api/public/menu')).json; assert.ok(menu.addon_groups.length >= 2); const item = menu.items.find((i) => i.id === d1.id); assert.ok(item.addon_group_ids.includes(extras.id));
  assert.ok(menu.addon_groups.every((g) => g.addons.every((a) => a.id !== size.addons[1].id)), 'switched-off Large is hidden');
  const r = await call(null, 'POST', '/api/public/checkout', { customer: { name: 'Asha', phone: '9876501234' }, address: '12 Lake Rd', items: [{ menu_item_id: d1.id, qty: 1, addons: [{ id: cheese.id }, { id: size.addons[0].id }] }] });
  assert.equal(r.status, 201); const o = (await call('Owner', 'GET', '/api/orders?channel=website')).json.find((x) => x.order_no === r.json.order_no); near(o.subtotal, d1.prices.website ?? d1.prices.default + 20, 'website price with cheese');
  assert.equal((await call(null, 'POST', '/api/public/checkout', { customer: { name: 'Asha', phone: '9876501234' }, address: 'x', items: [{ menu_item_id: d1.id, qty: 1 }] })).status, 400, 'required Size missing');
});
