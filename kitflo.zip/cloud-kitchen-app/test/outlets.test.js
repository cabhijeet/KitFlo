// Several outlets: each has its own menu, customers, stock, orders and settings. Access, switching, public pages, webhooks, summary.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-outlets-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; process.env.AGGREGATOR_WEBHOOK_SECRET = 'test-secret'; delete process.env.SEED_DEMO;
let base, server, mod; const tok = {};
const call = async (who, method, url, body, headers = {}) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tok[who] } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* none */ } return { status: r.status, json }; };
const login = async (name, pin, as = name) => { const users = (await call(null, 'GET', '/api/users')).json; const r = await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === name).id, pin }); assert.equal(r.status, 200, `${name} signs in`); tok[as] = r.json.token; return r.json; };
before(async () => {
  mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`;
  await login('Owner', '1234'); await login('Owner', '1234', 'OwnerB'); await login('Manager', '2222'); await login('Cashier', '3333');
});
after(() => { server.close(); fs.rmSync(dir, { recursive: true, force: true }); });
const menu = async (who) => (await call(who, 'GET', '/api/menu-items')).json;
const sellable = async (who) => (await menu(who)).filter((m) => !m.off && m.available !== false && (m.prices.default ?? 0) > 0);
let outlet2;

test('a new outlet can start from another outlet’s menu, with nothing else carried over', async () => {
  const main = await call('Owner', 'POST', '/api/orders', { channel: 'walkin', customer: { name: 'Main Customer', phone: '9111111111' }, items: [{ menu_item_id: (await sellable('Owner'))[0].id, qty: 1 }] }); assert.equal(main.status, 201);
  assert.equal((await call('Manager', 'POST', '/api/admin/outlets', { name: 'X' })).status, 403, 'only the owner adds outlets');
  const r = await call('Owner', 'POST', '/api/admin/outlets', { name: 'Koramangala', city: 'Bengaluru', code: 'kr', copy_from: 1, copy: { menu: true, rates: true, rules: true } });
  assert.equal(r.status, 201); outlet2 = r.json; assert.equal(outlet2.slug, 'koramangala'); assert.equal(outlet2.code, 'KR');
  assert.equal((await call('OwnerB', 'POST', '/api/outlets/switch', { outlet_id: outlet2.id })).status, 200);
  const m1 = await menu('Owner'), m2 = await menu('OwnerB');
  assert.equal(m2.length, m1.length, 'menu copied'); assert.ok(m2.length > 50);
  assert.equal((await call('OwnerB', 'GET', '/api/orders?status=completed&from=2000-01-01')).json.length, 0, 'no orders carried over');
  assert.equal((await call('OwnerB', 'GET', '/api/customers')).json.length, 0, 'no customers carried over');
  assert.equal((await call('OwnerB', 'GET', '/api/settings')).json.business.name, 'Koramangala', 'own business details');
  assert.ok((await call('OwnerB', 'GET', '/api/settings')).json.channels.every((c) => !c.provider_store_id), 'partner store ids are not copied');
});

test('orders, customers, stock and prices stay inside their own outlet', async () => {
  const d1 = (await sellable('Owner'))[1], d2 = (await sellable('OwnerB')).find((m) => m.name === d1.name && m.variant_name === d1.variant_name) || (await sellable('OwnerB'))[1];
  const b = await call('OwnerB', 'POST', '/api/orders', { channel: 'walkin', customer: { name: 'Bengaluru Guest', phone: '9222222222' }, items: [{ menu_item_id: d2.id, qty: 2 }] });
  assert.equal(b.status, 201); assert.equal(b.json.order.order_no, 1001, 'each outlet counts its own orders');
  const bill = (await call('OwnerB', 'GET', `/api/orders/${b.json.order.id}/bill`)).json; assert.equal(bill.bill_no, 'KR1001'); assert.equal(bill.business.name, 'Koramangala'); assert.equal(bill.outlet.name, 'Koramangala');
  assert.equal((await call('Owner', 'GET', `/api/orders/${b.json.order.id}/bill`)).status === 200 && (await call('Owner', 'GET', `/api/orders/${b.json.order.id}/bill`)).json.business.name !== 'Koramangala', true, 'the other outlet cannot see it (same id is a different order there)');
  const c1 = (await call('Owner', 'GET', '/api/customers')).json.map((c) => c.name), c2 = (await call('OwnerB', 'GET', '/api/customers')).json.map((c) => c.name);
  assert.ok(c1.includes('Main Customer') && !c1.includes('Bengaluru Guest')); assert.ok(c2.includes('Bengaluru Guest') && !c2.includes('Main Customer'));
  const n1 = (await call('Owner', 'GET', '/api/orders')).json.length;
  await call('OwnerB', 'POST', '/api/inventory-items', { name: 'Only In Bengaluru', unit: 'kg', unit_cost: 10 });
  assert.ok(!(await call('Owner', 'GET', '/api/inventory-items')).json.some((i) => i.name === 'Only In Bengaluru')); assert.ok((await call('OwnerB', 'GET', '/api/inventory-items')).json.some((i) => i.name === 'Only In Bengaluru'));
  await call('OwnerB', 'POST', `/api/menu-items/${d2.id}/availability`, { off: true });
  assert.ok((await menu('Owner')).find((m) => m.id === d1.id && m.name === d1.name).available !== false, 'switching a dish off in one outlet leaves the other alone');
  assert.equal((await call('Owner', 'GET', '/api/orders')).json.length, n1);
  await call('OwnerB', 'POST', '/api/menu-categories/availability', { name: d2.category, off: true });
  assert.ok(!(await call(null, 'GET', '/api/public/menu?outlet=koramangala')).json.items.some((x) => x.category === d2.category), 'stopped category hidden in its outlet only');
  assert.ok((await call(null, 'GET', '/api/public/menu?outlet=main')).json.items.some((x) => x.category === d2.category));
});

test('who may work where, and switching is per device', async () => {
  assert.equal((await call('Cashier', 'POST', '/api/outlets/switch', { outlet_id: outlet2.id })).status, 403);
  assert.deepEqual((await call('Cashier', 'GET', '/api/me')).json.outlets.map((o) => o.slug), ['main']);
  const users = (await call('Owner', 'GET', '/api/admin/users')).json, cash = users.find((u) => u.name === 'Cashier');
  assert.equal((await call('Manager', 'PATCH', `/api/admin/users/${cash.id}`, { outlet_ids: [1, outlet2.id] })).status, 403);
  assert.equal((await call('Owner', 'PATCH', `/api/admin/users/${cash.id}`, { outlet_ids: [1, outlet2.id] })).status, 200);
  assert.equal((await call('Cashier', 'POST', '/api/outlets/switch', { outlet_id: outlet2.id })).status, 200);
  assert.equal((await call('Cashier', 'GET', '/api/me')).json.outlet.slug, 'koramangala');
  assert.equal((await call('Owner', 'GET', '/api/me')).json.outlet.slug, 'main', 'another device is unaffected');
  await call('Owner', 'PATCH', `/api/admin/users/${cash.id}`, { outlet_ids: [1] });
  assert.equal((await call('Cashier', 'GET', '/api/me')).json.outlet.slug, 'main', 'taking access away moves the person back');
  const nu = await call('Owner', 'POST', '/api/admin/users', { name: 'Bengaluru Cashier', role: 'cashier', pin: '6543', outlet_ids: [outlet2.id] }); assert.equal(nu.status, 201);
  assert.deepEqual((await login('Bengaluru Cashier', '6543')).user.role, 'cashier'); assert.equal((await call('Bengaluru Cashier', 'GET', '/api/me')).json.outlet.slug, 'koramangala');
  const nobody = await call('Owner', 'POST', '/api/admin/users', { name: 'No Outlet', role: 'cashier', pin: '6544', outlet_ids: [] });
  const u = (await call(null, 'GET', '/api/users')).json.find((x) => x.name === 'No Outlet'); assert.equal((await call(null, 'POST', '/api/login', { user_id: u.id, pin: '6544' })).status, 403, 'cannot sign in with no outlet');
});

test('public pages and partner webhooks must say which outlet', async () => {
  assert.equal((await call(null, 'GET', '/api/public/menu')).status, 400, 'two outlets: must choose');
  assert.deepEqual((await call(null, 'GET', '/api/public/outlets')).json.map((o) => o.slug), ['main', 'koramangala']);
  assert.equal((await call(null, 'GET', '/api/public/menu?outlet=nope')).status, 404);
  const it = (await call(null, 'GET', '/api/public/menu?outlet=koramangala')).json.items[0];
  const co = await call(null, 'POST', '/api/public/checkout?outlet=koramangala', { customer: { name: 'Web Guest', phone: '9333333333' }, address: 'MG Road', items: [{ menu_item_id: it.id, qty: 1 }] }); assert.equal(co.status, 201, JSON.stringify(co.json));
  assert.ok((await call('OwnerB', 'GET', '/api/customers')).json.some((c) => c.name === 'Web Guest')); assert.ok(!(await call('Owner', 'GET', '/api/customers')).json.some((c) => c.name === 'Web Guest'));
  const body = { channel: 'swiggy', order_id: 'SW-OUT-1', items: [{ name: 'Sweet Lassi', qty: 1, price: 90 }], customer: { name: 'Sw', phone: '9444444444' } }, h = { 'x-webhook-secret': 'test-secret' };
  assert.equal((await call(null, 'POST', '/api/webhooks/aggregator/dyno', body, h)).status, 400, 'webhook without outlet is refused');
  const w = await call(null, 'POST', '/api/webhooks/aggregator/dyno?outlet=koramangala', body, h); assert.equal(w.status, 200); assert.equal(w.json.duplicate, false);
  assert.equal((await call(null, 'POST', '/api/webhooks/aggregator/dyno?outlet=koramangala', body, h)).json.duplicate, true);
  assert.ok((await call('OwnerB', 'GET', '/api/orders')).json.some((o) => o.channel_order_id === 'SW-OUT-1')); assert.ok(!(await call('Owner', 'GET', '/api/orders')).json.some((o) => o.channel_order_id === 'SW-OUT-1'));
  // find the outlet by the partner's store id
  await call('OwnerB', 'PATCH', '/api/channels/zomato', { commission_pct: 20, packaging_fee: 0, integration_provider: 'dyno', provider_store_id: 'STORE-KR-77', active: true });
  const z = await call(null, 'POST', '/api/webhooks/aggregator/dyno', { ...body, channel: 'zomato', order_id: 'ZO-OUT-1', store_id: 'STORE-KR-77' }, h); assert.equal(z.status, 200, JSON.stringify(z.json));
  assert.ok((await call('OwnerB', 'GET', '/api/orders')).json.some((o) => o.channel_order_id === 'ZO-OUT-1'));
});

test('the owner sees every outlet side by side, nobody else does', async () => {
  assert.equal((await call('Manager', 'GET', '/api/outlets/summary')).status, 403);
  const s = (await call('Owner', 'GET', '/api/outlets/summary')).json; assert.equal(s.outlets.length, 2);
  assert.ok(s.outlets.every((o) => 'sales' in o.today && 'net' in o.month)); assert.equal(s.total.today.orders, s.outlets.reduce((a, o) => a + o.today.orders, 0));
});

test('closing an outlet removes it from choices and keeps at least one open', async () => {
  assert.equal((await call('Owner', 'PATCH', `/api/admin/outlets/${outlet2.id}`, { active: false })).status, 200);
  assert.deepEqual((await call('OwnerB', 'GET', '/api/me')).json.outlets.map((o) => o.slug), ['main']); assert.equal((await call('OwnerB', 'GET', '/api/me')).json.outlet.slug, 'main', 'sessions move back to an open outlet');
  assert.equal((await call(null, 'GET', '/api/public/menu')).status, 200, 'one open outlet again: no need to say which');
  assert.equal((await call('Owner', 'PATCH', '/api/admin/outlets/1', { active: false })).status, 400);
  await call('Owner', 'PATCH', `/api/admin/outlets/${outlet2.id}`, { active: true });
});
