// GST: exclusive and inclusive prices, per-rate breakup, composition and unregistered kitchens, platform-collected GST, packaging, profit.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-gst-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; process.env.AGGREGATOR_WEBHOOK_SECRET = 'test-secret'; delete process.env.SEED_DEMO;
let base, server, db; const tok = {};
const call = async (who, method, url, body, headers = {}) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tok[who] } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };
before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call(null, 'GET', '/api/users')).json;
  for (const [n, p] of [['Owner', '1234'], ['Cashier', '3333'], ['Kitchen', '4444']]) tok[n] = (await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === n).id, pin: p })).json.token;
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });


const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.011, `${msg}: ${a} vs ${b}`);
const gst = (x) => call('Owner', 'PUT', '/api/settings', { gst: x });
const sellable = async () => (await call('Owner', 'GET', '/api/menu-items')).json.filter((m) => !m.off && (m.prices.default ?? 0) > 0);
const order = async (items, extra = {}) => (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items, ...extra })).json.order;
const bill = async (o) => (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json;
let a, b;

test('prices exclude GST by default and the tax is added on top, per dish rate', async () => {
  [a, b] = await sellable(); const cats = [...new Set((await sellable()).map((m) => m.category))];
  assert.equal((await call('Owner', 'POST', '/api/menu-gst', { rate: 5, category: a.category })).status, 200);
  const x = (await call('Owner', 'GET', '/api/settings')).json.gst; assert.deepEqual([x.mode, x.inclusive, x.default_rate, x.packaging_rate], ['regular', false, 5, 0]);
  const o = await order([{ menu_item_id: a.id, qty: 2 }]), sub = a.prices.default * 2;
  near(o.tax, sub * 0.05, 'tax'); near(o.total, sub + sub * 0.05, 'total'); assert.equal(o.tax_inclusive, 0);
  const bl = await bill(o); assert.equal(bl.gst.title, 'BILL', 'no GSTIN yet, so not a tax invoice'); assert.equal(bl.gst.breakup.length, 1); assert.equal(bl.gst.breakup[0].rate, 5); near(bl.gst.breakup[0].taxable, sub, 'taxable'); near(bl.gst.breakup[0].cgst * 2, o.tax, 'cgst+sgst');
  assert.ok(cats.length >= 1);
});

test('different dishes can carry different rates and the bill shows each', async () => {
  await call('Owner', 'PUT', '/api/settings', { business: { name: 'Test Kitchen', gstin: '29ABCDE1234F1Z5', address: 'Somewhere', fssai: '' } });
  const other = (await sellable()).find((m) => m.category !== a.category); assert.ok(other);
  await call('Owner', 'POST', '/api/menu-gst', { rate: 18, category: other.category });
  const o = await order([{ menu_item_id: a.id, qty: 1 }, { menu_item_id: other.id, qty: 1 }], { manual_discount: { type: 'percent', value: 10 } });
  const bl = await bill(o); assert.equal(bl.gst.title, 'TAX INVOICE'); assert.deepEqual(bl.gst.breakup.map((g) => g.rate), [5, 18]);
  const k = 0.9; near(bl.gst.breakup[0].cgst * 2, a.prices.default * k * 0.05, '5% tax after discount'); near(bl.gst.breakup[1].cgst * 2, other.prices.default * k * 0.18, '18% tax after discount');
  near(bl.gst.breakup.reduce((s, g) => s + g.cgst + g.sgst, 0), o.tax, 'breakup adds to the order tax'); near(o.total, o.subtotal - o.discount + o.tax, 'total');
  assert.equal((await call('Owner', 'POST', '/api/menu-gst', { rate: 5 })).status, 200);
});

test('inclusive prices: tax comes out of the price, the customer pays the menu price, sales exclude tax', async () => {
  assert.equal((await gst({ inclusive: true })).status, 200);
  const before = (await call('Owner', 'GET', '/api/analytics/summary')).json;
  const o = await order([{ menu_item_id: a.id, qty: 2 }]), sub = a.prices.default * 2;
  near(o.total, sub, 'customer pays the menu price'); near(o.tax, sub * 5 / 105, 'tax inside the price'); assert.equal(o.tax_inclusive, 1); near(o.net_sales, sub - o.tax, 'net sales leave the tax out');
  const bl = await bill(o); near(bl.gst.breakup[0].taxable + bl.gst.breakup[0].cgst + bl.gst.breakup[0].sgst, sub, 'taxable + tax = price'); assert.equal(bl.gst.inclusive, true);
  const old = await bill(await order([{ menu_item_id: a.id, qty: 1 }])); await gst({ inclusive: false });
  const again = await bill({ id: o.id }); assert.deepEqual(again.gst, bl.gst, 'an old bill does not change when settings change'); assert.equal(old.gst.inclusive, true);
  assert.ok(before);
});

test('composition and unregistered kitchens charge no tax', async () => {
  await gst({ mode: 'composition' }); let o = await order([{ menu_item_id: a.id, qty: 1 }]); assert.equal(o.tax, 0); near(o.total, a.prices.default, 'total'); let bl = await bill(o);
  assert.equal(bl.gst.title, 'BILL OF SUPPLY'); assert.match(bl.gst.note, /Composition/); assert.equal(bl.cgst, 0);
  await gst({ mode: 'none' }); o = await order([{ menu_item_id: a.id, qty: 1 }]); assert.equal(o.tax, 0); assert.equal((await bill(o)).gst.title, 'BILL');
  await gst({ mode: 'regular' });
});

test('Swiggy and Zomato can be left untaxed, and packaging can carry GST', async () => {
  const body = (id) => ({ channel: 'swiggy', order_id: id, items: [{ name: a.name, qty: 1, price: 200 }], customer: { name: 'S', phone: '9555555555' } }), h = { 'x-webhook-secret': 'test-secret' };
  const taxed = await call(null, 'POST', '/api/webhooks/aggregator/dyno', body('SW-G-1'), h); assert.equal(taxed.status, 200);
  const t1 = (await call('Owner', 'GET', '/api/orders')).json.find((o) => o.channel_order_id === 'SW-G-1'); assert.ok(t1.tax > 0);
  await gst({ platform_collects: true }); await call(null, 'POST', '/api/webhooks/aggregator/dyno', body('SW-G-2'), h);
  const t2 = (await call('Owner', 'GET', '/api/orders')).json.find((o) => o.channel_order_id === 'SW-G-2'); assert.equal(t2.tax, 0, 'platform collects its own GST');
  assert.ok((await order([{ menu_item_id: a.id, qty: 1 }])).tax > 0, 'walk-in still taxed'); await gst({ platform_collects: false });
  await call('Owner', 'PATCH', '/api/channels/whatsapp', { commission_pct: 0, packaging_fee: 20, integration_provider: 'none', active: true }); await gst({ packaging_rate: 18 });
  const w = (await call('Owner', 'POST', '/api/orders', { channel: 'whatsapp', items: [{ menu_item_id: a.id, qty: 1 }] })).json.order, p = a.prices.default;
  near(w.tax, p * 0.05 + 20 * 0.18, 'item tax + packaging tax'); near(w.total, p + 20 + w.tax, 'total'); await gst({ packaging_rate: 0 });
});

test('GST settings are checked and owner-only', async () => {
  assert.equal((await gst({ mode: 'weird' })).status, 400); assert.equal((await gst({ default_rate: 55 })).status, 400); assert.equal((await gst({ packaging_rate: -1 })).status, 400);
  assert.equal((await call('Cashier', 'PUT', '/api/settings', { gst: { mode: 'none' } })).status, 403); assert.equal((await call('Cashier', 'POST', '/api/menu-gst', { rate: 0 })).status, 403);
  assert.equal((await gst({ default_rate: 12 })).status, 200);
  const nd = (await call('Owner', 'POST', '/api/menu-items', { name: 'GST Test Dish', category: 'Test', prices: { default: 100 } })).json; assert.equal(nd.gst_rate, 12, 'new dishes start at the default rate'); await gst({ default_rate: 5 });
});
