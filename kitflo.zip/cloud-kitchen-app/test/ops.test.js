// Order types, delivery and service charges, split payments, cancel reasons, day close with cash, sales exports.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ck-ops-'));
process.env.DATA_DIR = dir; process.env.NODE_ENV = 'test'; process.env.AGGREGATOR_WEBHOOK_SECRET = 'test-secret'; delete process.env.SEED_DEMO;
let base, server, db; const tok = {};
const call = async (who, method, url, body, headers = {}) => { const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(who ? { authorization: 'Bearer ' + tok[who] } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); let json = null; try { json = await r.json(); } catch { /* empty */ } return { status: r.status, json }; };
before(async () => {
  const mod = await import('../server/index.js'); server = await mod.start(0); base = `http://127.0.0.1:${server.address().port}`; db = await import('../server/db.js');
  const users = (await call(null, 'GET', '/api/users')).json;
  for (const [n, p] of [['Owner', '1234'], ['Cashier', '3333'], ['Kitchen', '4444']]) tok[n] = (await call(null, 'POST', '/api/login', { user_id: users.find((u) => u.name === n).id, pin: p })).json.token;
});
after(() => { server.close(); try { db.close?.(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });


const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.011, `${msg}: ${a} vs ${b}`);
const sellable = async () => (await call('Owner', 'GET', '/api/menu-items')).json.filter((m) => !m.off && (m.prices.default ?? 0) > 0);
const put = (b) => call('Owner', 'PUT', '/api/settings', b);
let a;

test('delivery and service charges follow the order type, with GST on them', async () => {
  a = (await sellable())[0]; const p = a.prices.default;
  assert.equal((await put({ charges: { delivery_fee: 30, delivery_free_above: 500, service_pct: 10 } })).status, 200); await put({ gst: { charge_rate: 18 } });
  const mk = async (extra) => (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: a.id, qty: 1 }], ...extra })).json.order;
  const del = await mk({ order_type: 'delivery' }); assert.equal(del.delivery_fee, 30); assert.equal(del.service_charge, 0); near(del.tax, p * 0.05 + 30 * 0.18, 'tax incl. charge'); near(del.total, p + 30 + del.tax, 'total'); near(del.net_sales, p + 30, 'charges are sales');
  const din = await mk({ order_type: 'dine_in', table_no: 'T4' }); assert.equal(din.delivery_fee, 0); near(din.service_charge, p * 0.1, 'service charge'); assert.equal(din.table_no, 'T4');
  const take = await mk({ order_type: 'takeaway' }); assert.equal(take.delivery_fee + take.service_charge, 0);
  assert.equal((await mk({})).order_type, 'takeaway', 'walk-in defaults to takeaway');
  const big = await call('Owner', 'POST', '/api/orders', { channel: 'walkin', order_type: 'delivery', items: [{ menu_item_id: a.id, qty: Math.ceil(500 / p) }] }); assert.equal(big.json.order.delivery_fee, 0, 'free delivery above the limit');
  const b = (await call('Owner', 'GET', `/api/orders/${din.id}/bill`)).json; assert.equal(b.order_type, 'dine_in'); near(b.service_charge, p * 0.1, 'bill service'); near(b.gst.breakup.reduce((s, g) => s + g.cgst + g.sgst, 0), din.tax, 'breakup = tax');
  assert.equal((await put({ charges: { delivery_fee: -5 } })).status, 400); assert.equal((await call('Cashier', 'PUT', '/api/settings', { charges: { service_pct: 5 } })).status, 403);
});

test('payments can be split, and what is still due shows on the bill', async () => {
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: a.id, qty: 2 }], payments: [{ mode: 'Cash', amount: 30 }, { mode: 'UPI', amount: 20 }] })).json.order;
  assert.equal(o.payment_mode, 'Split'); let b = (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json; assert.equal(b.paid, 50); near(b.balance, o.total - 50, 'balance due'); assert.equal(b.payments.length, 2);
  const r = await call('Cashier', 'POST', `/api/orders/${o.id}/payments`, { payments: [{ mode: 'Cash', amount: 30 }, { mode: 'UPI', amount: o.total - 30 }] }); assert.equal(r.status, 200);
  b = (await call('Owner', 'GET', `/api/orders/${o.id}/bill`)).json; near(b.balance, 0, 'settled');
  assert.equal((await call('Owner', 'POST', `/api/orders/${o.id}/payments`, { payments: [{ mode: 'Cash', amount: o.total + 50 }] })).status, 400, 'cannot overpay');
  assert.equal((await call('Owner', 'POST', `/api/orders/${o.id}/payments`, { payments: [{ mode: 'Bitcoin', amount: 10 }] })).status, 400);
  const plain = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', payment_mode: 'Card', items: [{ menu_item_id: a.id, qty: 1 }] })).json.order; const pb = (await call('Owner', 'GET', `/api/orders/${plain.id}/bill`)).json; near(pb.balance, 0, 'single-mode orders count as paid'); assert.equal(pb.payments[0].mode, 'Card');
});

test('cancelling needs a reason', async () => {
  const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', items: [{ menu_item_id: a.id, qty: 1 }] })).json.order;
  assert.equal((await call('Owner', 'POST', `/api/orders/${o.id}/status`, { status: 'cancelled' })).status, 400);
  assert.equal((await call('Owner', 'POST', `/api/orders/${o.id}/status`, { status: 'cancelled', reason: 'Customer did not pick up' })).status, 200);
  assert.ok((await call('Owner', 'GET', '/api/me')).json.config.cancel_reasons.length >= 5);
});

test('day close adds up the day, works out the cash, and is kept', async () => {
  const today = new Date().toLocaleDateString('en-CA'); const run = async (x) => { const o = (await call('Owner', 'POST', '/api/orders', { channel: 'walkin', accept: true, items: [{ menu_item_id: a.id, qty: 1 }], ...x })).json.order; for (const s of ['preparing', 'ready', 'completed']) await call('Owner', 'POST', `/api/orders/${o.id}/status`, { status: s }); return o; };
  const c = await run({ payment_mode: 'Cash', order_type: 'takeaway' }), u = await run({ payment_mode: 'UPI', order_type: 'takeaway' });
  await call('Owner', 'POST', '/api/expenses', { category: 'Gas & fuel', amount: 40, payment_mode: 'Cash', date: today });
  const r = (await call('Owner', 'GET', `/api/day-close?date=${today}`)).json.report;
  assert.ok(r.orders >= 2); near(r.cash.expenses, 40, 'cash expenses'); assert.ok(r.cash.sales >= c.total - 0.01); assert.ok(r.payments.some((p) => p.mode === 'UPI' && p.amount >= u.total - 0.01));
  near(r.tax, r.cgst + r.sgst, 'tax split'); assert.ok(r.tax_by_rate.length >= 1); assert.ok(r.cancelled.orders >= 1 && r.cancelled.reasons.some((x) => x.reason === 'Customer did not pick up'));
  near(r.net_sales, r.gross - r.discounts + r.packaging + r.delivery + r.service, 'net sales (exclusive prices)');
  const close = await call('Owner', 'POST', '/api/day-close', { date: today, opening_cash: 500, counted_cash: 500 + r.cash.sales - 40 - 10 }); assert.equal(close.status, 200);
  near(close.json.expected_cash, 500 + r.cash.sales - 40, 'expected cash'); near(close.json.variance, -10, 'short by 10'); assert.ok(close.json.report.orders >= 2);
  assert.equal((await call('Owner', 'GET', `/api/day-close?date=${today}`)).json.closed.variance, -10); assert.ok((await call('Owner', 'GET', '/api/day-close')).json.history.length >= 1);
  assert.equal((await call('Cashier', 'GET', '/api/day-close')).status, 403); assert.equal((await call('Cashier', 'POST', '/api/day-close', {})).status, 403);
});

test('sales exports list dishes and bills', async () => {
  const today = new Date().toLocaleDateString('en-CA');
  const items = (await call('Owner', 'GET', `/api/reports/sales?from=${today}&to=${today}&kind=items`)).json; assert.deepEqual(items.columns.slice(0, 2), ['Dish', 'Quantity']); assert.ok(items.rows.length >= 1);
  const bills = (await call('Owner', 'GET', `/api/reports/sales?from=${today}&to=${today}&kind=bills`)).json; assert.ok(bills.columns.includes('CGST')); assert.ok(bills.rows.length >= 2); assert.equal(bills.rows[0].length, bills.columns.length);
  assert.equal((await call('Cashier', 'GET', '/api/reports/sales')).status, 403);
});
