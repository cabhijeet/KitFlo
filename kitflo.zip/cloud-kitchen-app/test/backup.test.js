// Backups: a copy taken while running can be restored; old copies are removed; a bad name is refused.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-backup-'));
Object.assign(process.env, { DATA_DIR: dir, NODE_ENV: 'test', BACKUP_KEEP: '2' }); delete process.env.SEED_DEMO;
const db = await import('../server/db.js'); const B = await import('../server/backup.js'); const { DatabaseSync } = await import('node:sqlite');
after(() => { try { db.closeAll(); } catch { /* ignore */ } fs.rmSync(dir, { recursive: true, force: true }); });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('a backup holds a consistent copy and restoring it brings back deleted data', async () => {
  db.setSetting('marker', 'before'); fs.mkdirSync(path.join(dir, 'receipts'), { recursive: true }); fs.writeFileSync(path.join(dir, 'receipts', 'a.txt'), 'x');
  const r = await B.backupAll(); assert.ok(r.files >= 2); assert.ok(fs.existsSync(path.join(r.dir, 'kitchen.db')));
  const copy = new DatabaseSync(path.join(r.dir, 'kitchen.db')); assert.equal(copy.prepare("SELECT value FROM settings WHERE key='marker'").get().value, '"before"'); copy.close();
  db.setSetting('marker', 'after'); db.closeAll();
  const out = B.restoreBackup(r.name); assert.ok(out.restored >= 1); assert.ok(fs.existsSync(out.previous));
  assert.equal(db.getSetting('marker'), 'before', 'the old value is back');
});
test('only the newest copies are kept and unknown names are refused', async () => {
  await sleep(1100); await B.backupAll(); await sleep(1100); await B.backupAll();
  assert.equal(B.listBackups().length, 2);
  assert.throws(() => B.restoreBackup('20000101-000000'), /No such backup/);
});
