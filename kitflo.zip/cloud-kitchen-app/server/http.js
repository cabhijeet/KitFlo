// Tiny dependency-free HTTP toolkit: router, JSON body, static files, errors.
import fs from 'node:fs';
import path from 'node:path';

export class HttpError extends Error {
  constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; }
}
export const bad = (m, extra) => new HttpError(400, m, extra);

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };

export function createRouter() {
  const routes = [];
  const add = (method, pattern, ...handlers) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-zA-Z_]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    routes.push({ method, re, keys, handlers });
  };
  const r = { routes };
  for (const m of ['get', 'post', 'patch', 'put', 'delete']) r[m] = (p, ...h) => add(m.toUpperCase(), p, ...h);
  r.match = (method, pathname) => {
    for (const rt of routes) {
      if (rt.method !== method) continue;
      const m = rt.re.exec(pathname);
      if (m) { const params = {}; rt.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1])); return { rt, params }; }
    }
    return null;
  };
  return r;
}

export async function readBody(req, limit = 8 * 1024 * 1024) {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'DELETE') return {};
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > limit) throw new HttpError(413, 'Payload too large'); chunks.push(c); }
  if (!size) return {};
  const raw = Buffer.concat(chunks).toString('utf8');
  req.rawBody = raw;
  const ct = req.headers['content-type'] || '';
  if (ct.includes('application/json') || raw.trimStart().startsWith('{') || raw.trimStart().startsWith('[')) {
    try { return JSON.parse(raw); } catch { throw new HttpError(400, 'Invalid JSON'); }
  }
  return { raw };
}

export function send(res, status, data, headers = {}) {
  if (res.headersSent) return;
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': typeof data === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}

export function serveStatic(root, req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(root, rel));
  if (!file.startsWith(root)) return false;
  let st; try { st = fs.statSync(file); } catch { return false; }
  if (!st.isFile()) return false;
  const ext = path.extname(file);
  const noCache = ext === '.html' || file.endsWith('sw.js') || ext === '.webmanifest';
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': noCache ? 'no-cache' : 'public, max-age=3600', 'Content-Length': st.size });
  if (req.method === 'HEAD') return res.end(), true;
  fs.createReadStream(file).pipe(res);
  return true;
}
