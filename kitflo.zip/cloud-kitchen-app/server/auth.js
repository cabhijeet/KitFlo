import crypto from 'node:crypto';
import { gq as q, now, outletList, tenantId } from './db.js';
import { HttpError } from './http.js';

export const ROLES = ['owner', 'manager', 'cashier', 'kitchen', 'marketer'];
const SESSION_DAYS = 30;

/** In hosted mode a session token starts with the business it belongs to, so a request can be routed before anything is looked up. */
export const tokenPrefix = () => (process.env.MULTI_TENANT === '1' ? `t${tenantId()}.` : '');
export const tenantOfToken = (t) => { const m = /^t(\d+)\./.exec(String(t || '')); return m ? Number(m[1]) : null; };
export const hashPin = (pin) => { const salt = crypto.randomBytes(12).toString('hex'); return salt + ':' + crypto.scryptSync(String(pin), salt, 32).toString('hex'); };
const checkPin = (pin, stored) => {
  const [salt, h] = String(stored).split(':');
  const x = crypto.scryptSync(String(pin), salt, 32);
  const y = Buffer.from(h, 'hex');
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

/** Client address. Behind one trusted proxy (TRUST_PROXY=1) use the address that proxy appended to X-Forwarded-For. */
export const clientIp = (req) => {
  if (process.env.TRUST_PROXY === '1') { const xf = String(req.headers['x-forwarded-for'] || '').split(',').map((x) => x.trim()).filter(Boolean); if (xf.length) return xf[xf.length - 1]; }
  return req.socket.remoteAddress;
};
// Two counters: per address+user (5 misses = 1 minute) and per user from anywhere (10 misses = 5 minutes, doubling up to 1 hour).
const fails = new Map(); // `${ip}|${userId}` -> {n, until}
const userFails = new Map(); // userId -> {n, until, lock}
const wait = (ms) => `Too many attempts. Try again in ${Math.max(1, Math.ceil(ms / 60000))} minute${ms > 60000 ? 's' : ''}.`;
export function login(userId, pin, ip, device) {
  const key = `${ip}|${userId}`;
  const f = fails.get(key), uf = userFails.get(String(userId));
  if (f && f.until > Date.now()) throw new HttpError(429, wait(f.until - Date.now()));
  if (uf && uf.until > Date.now()) throw new HttpError(429, wait(uf.until - Date.now()));
  const u = q.get('SELECT * FROM users WHERE id=? AND active=1', Number(userId));
  if (!u || !checkPin(pin, u.pin_hash)) {
    const n = (f?.n || 0) + 1;
    fails.set(key, { n, until: n >= 5 ? Date.now() + 60000 : 0 });
    const un = (uf?.n || 0) + 1, lock = un >= 10 ? Math.min((uf?.lock || 150000) * 2, 3600000) : uf?.lock || 0;
    userFails.set(String(userId), { n: un >= 10 ? 0 : un, lock, until: un >= 10 ? Date.now() + lock : 0 });
    throw new HttpError(401, 'Wrong PIN');
  }
  fails.delete(key); userFails.delete(String(userId));
  return startSession(u, device);
}
function startSession(u, device) {
  const mine = outletsFor(u);
  if (!mine.length) throw new HttpError(403, 'No outlet is assigned to you. Ask the owner.');
  const token = tokenPrefix() + crypto.randomBytes(32).toString('hex');
  q.run('INSERT INTO sessions(token,user_id,device,created_at,last_seen,outlet_id) VALUES(?,?,?,?,?,?)', token, u.id, String(device || '').slice(0, 120), now(), now(), mine[0].id);
  return { token, user: { id: u.id, name: u.name, role: u.role } };
}
/** Signs in as the business owner, for someone who has just proved who they are with the account email and password. */
export function ownerSession(device) {
  const u = q.get("SELECT * FROM users WHERE role='owner' AND active=1 ORDER BY id LIMIT 1");
  if (!u) throw new HttpError(403, 'This business has no owner login. Contact support.');
  return startSession(u, device);
}

// Staff devices: a shop tablet that the owner has approved. Only these may show the list of names and take a PIN when hosted.
const sha = (x) => crypto.createHash('sha256').update(x).digest('hex');
export function createStaffDevice(label) {
  const secret = crypto.randomBytes(24).toString('hex');
  const id = Number(q.run('INSERT INTO staff_devices(label,key_hash,created_at,last_seen) VALUES(?,?,?,?)', String(label || 'Shop device').slice(0, 60), sha(secret), now(), now()).lastInsertRowid);
  return { id, key: `dv_${tenantId()}_${secret}` };
}
export const deviceTenant = (key) => { const m = /^dv_(\d+)_[0-9a-f]{48}$/.exec(String(key || '')); return m ? Number(m[1]) : null; };
export function checkStaffDevice(key) {
  const m = /^dv_(\d+)_([0-9a-f]{48})$/.exec(String(key || '')); if (!m) return null;
  const row = q.get('SELECT * FROM staff_devices WHERE key_hash=? AND revoked=0', sha(m[2]));
  if (row && Date.now() - new Date(row.last_seen || 0).getTime() > 3600000) q.run('UPDATE staff_devices SET last_seen=? WHERE id=?', now(), row.id);
  return row || null;
}
export const listStaffDevices = () => q.all('SELECT id, label, created_at, last_seen, revoked FROM staff_devices ORDER BY id DESC');
export function revokeStaffDevice(id) { q.run('UPDATE staff_devices SET revoked=1 WHERE id=?', Number(id)); return { ok: true }; }

/** Outlets this person may work in. The owner has every active outlthers only the ones the owner gave them. */
export function outletsFor(u) {
  const all = outletList(true);
  if (u.role === 'owner') return all;
  const ids = new Set(q.all('SELECT outlet_id FROM user_outlets WHERE user_id=?', u.id).map(r => r.outlet_id));
  return all.filter(o => ids.has(o.id));
}
export function switchOutlet(user, outletId) {
  const o = outletsFor(user).find(x => x.id === Number(outletId));
  if (!o) throw new HttpError(403, 'You do not have access to that outlet');
  q.run('UPDATE sessions SET outlet_id=? WHERE token=?', o.id, user.token);
  return o;
}

export function userFromToken(token) {
  if (!token) return null;
  const s = q.get('SELECT s.token, s.last_seen, s.created_at, s.outlet_id, u.id, u.name, u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND u.active=1', token);
  if (!s) return null;
  if (Date.now() - new Date(s.created_at).getTime() > SESSION_DAYS * 864e5) { q.run('DELETE FROM sessions WHERE token=?', token); return null; }
  if (Date.now() - new Date(s.last_seen).getTime() > 60000) q.run('UPDATE sessions SET last_seen=? WHERE token=?', now(), token);
  const user = { id: s.id, name: s.name, role: s.role, token: s.token };
  const mine = outletsFor(user);
  if (!mine.length) return null;
  user.outlet_id = mine.some(o => o.id === s.outlet_id) ? s.outlet_id : mine[0].id; // falls back if access was removed
  if (user.outlet_id !== s.outlet_id) q.run('UPDATE sessions SET outlet_id=? WHERE token=?', user.outlet_id, token);
  return user;
}

/** Permission matrix. Keys are capabilities the routes ask for. */
const CAN = {
  orders: ['owner', 'manager', 'cashier', 'kitchen'],
  orders_create: ['owner', 'manager', 'cashier'],
  kitchen: ['owner', 'manager', 'cashier', 'kitchen'],
  menu_read: ['owner', 'manager', 'cashier', 'kitchen', 'marketer'],
  menu_write: ['owner', 'manager'],
  stock_read: ['owner', 'manager', 'cashier', 'kitchen'],
  stock_write: ['owner', 'manager', 'kitchen'],
  expenses: ['owner', 'manager'],
  social: ['owner', 'manager', 'marketer'],
  analytics: ['owner', 'manager'],
  analytics_social: ['owner', 'manager', 'marketer'],
  automations: ['owner', 'manager'],
  customers: ['owner', 'manager', 'cashier'],
  settings: ['owner'],
};
export const can = (user, cap) => !!user && (CAN[cap] || []).includes(user.role);
export const capsFor = (user) => Object.keys(CAN).filter(c => can(user, c));
export function need(user, cap) {
  if (!user) throw new HttpError(401, 'Sign in required');
  if (!can(user, cap)) throw new HttpError(403, 'Your role cannot do this');
  return user;
}
