// Silent printing. The server turns an order into printer bytes and queues a job; a small helper on the shop PC
// (tools/print-agent.mjs) asks for jobs over a normal outbound connection and sends them to the printer. No browser dialog.
import crypto from 'node:crypto';
import { q, now, getSetting, setSetting, tenantId, outletId } from './db.js';
import { HttpError, bad } from './http.js';
import { billFor, onOrderAccepted } from './domain.js';
import { renderBill, renderKot } from './escpos.js';

const sha = (x) => crypto.createHash('sha256').update(x).digest('hex');
const ONLINE_MS = 25000;
const CONN = [/^tcp:[A-Za-z0-9.\-]{1,100}(:\d{1,5})?$/, /^device:(\/dev\/[A-Za-z0-9._\/-]{1,60}|COM\d{1,3}|\\\\\.\\[A-Za-z0-9_-]{1,40})$/, /^os:[^\u0000-\u001f"`$\;|&<>]{1,80}$/];

export const printers = () => getSetting('printers', []);
/** What the helper is doing right now. */
export function agentState() {
  const a = getSetting('print_agent', null), last = a?.last_seen ? new Date(a.last_seen).getTime() : 0;
  return { has_token: !!a?.hash, online: !!a?.hash && Date.now() - last < ONLINE_MS, last_seen: a?.last_seen || null };
}
function cleanPrinters(list) {
  if (!Array.isArray(list) || list.length > 6) throw bad('Add up to 6 printers');
  return list.map((p, i) => {
    const name = String(p.name || '').trim().slice(0, 40); if (!name) throw bad(`Give printer ${i + 1} a name`);
    const connection = String(p.connection || '').trim(); if (!CONN.some((re) => re.test(connection))) throw bad(`Printer "${name}": connection must look like tcp:192.168.1.50:9100, device:/dev/usb/lp0 or os:PrinterName`);
    if (connection.startsWith('tcp:')) { const port = Number(connection.split(':')[2] || 9100); if (port < 1 || port > 65535) throw bad(`Printer "${name}": bad port`); }
    return { id: /^[a-z0-9]{4,12}$/.test(p.id || '') ? p.id : crypto.randomBytes(4).toString('hex'), name, role: ['bill', 'kot', 'both'].includes(p.role) ? p.role : 'both', connection, paper: String(p.paper) === '80' ? '80' : '58',
      copies: Math.min(5, Math.max(1, Number(p.copies) || 1)), auto_bill: !!p.auto_bill, auto_kot: !!p.auto_kot, qr_size: Math.min(10, Math.max(3, Number(p.qr_size) || 6)) };
  });
}
const bytesFor = (kind, b, p) => { const one = kind === 'kot' ? renderKot(b, { paper: p.paper }) : renderBill(b, { paper: p.paper, qrSize: p.qr_size }); return Buffer.concat(Array.from({ length: p.copies }, () => one)); };

/** Queues a bill or kitchen ticket on every printer that takes it. Returns how many jobs were queued. */
export function enqueue(orderId, kind, { printerId, bill, force = true } = {}) {
  const b = bill || billFor(orderId); let n = 0;
  for (const p of printers()) {
    if (printerId && p.id !== printerId) continue;
    if (!printerId && !(p.role === 'both' || p.role === kind)) continue;
    if (!force && !(kind === 'kot' ? p.auto_kot : p.auto_bill)) continue;
    q.run('INSERT INTO print_jobs(kind,order_id,printer_id,data,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)', kind, orderId ?? null, p.id, bytesFor(kind, b, p), 'queued', now(), now()); n++;
  }
  if (Math.random() < 0.05) q.run("DELETE FROM print_jobs WHERE status IN ('done','failed') AND created_at < ?", new Date(Date.now() - 3 * 864e5).toISOString());
  return n;
}
// When an order is accepted, queue the tickets the owner asked to print by themselves.
onOrderAccepted((id) => {
  const ps = printers(); if (!ps.some((p) => p.auto_kot || p.auto_bill) || !agentState().has_token) return;
  const b = billFor(id); enqueue(id, 'kot', { bill: b, force: false }); enqueue(id, 'bill', { bill: b, force: false });
});

const SAMPLE = () => ({ bill_no: 'TEST1', order_no: 1, date: new Date().toISOString(), channel: 'walkin', lines: [{ name: 'Test dish', qty: 1, rate: 100, amount: 100 }, { name: 'Second dish with a longer name to check wrapping', qty: 2, rate: 50, amount: 100, modifiers: '+ Extra cheese' }],
  unique_items: 2, total_qty: 3, subtotal: 200, discount: 0, taxable: 200, cgst: 5, sgst: 5, tax: 10, packaging_fee: 0, total: 210, payment_mode: 'Cash', payments: [], balance: 0,
  gst: { mode: 'regular', inclusive: false, title: 'TEST BILL', note: '', breakup: [{ rate: 5, taxable: 200, cgst: 5, sgst: 5 }] }, business: getSetting('business', {}), layout: null, notes: 'Printer test' });

export function installPrinting(R) {
  const agent = (c) => {
    const tok = String(c.req.headers.authorization || '').replace(/^Bearer\s+/i, ''), m = /^ag_(\d+)_(\d+)_([0-9a-f]{48})$/.exec(tok), a = getSetting('print_agent', null);
    if (!m || !a?.hash || Number(m[1]) !== tenantId() || Number(m[2]) !== outletId()) throw new HttpError(401, 'Print helper key not accepted');
    const x = Buffer.from(sha(m[3])), y = Buffer.from(a.hash); if (x.length !== y.length || !crypto.timingSafeEqual(x, y)) throw new HttpError(401, 'Print helper key not accepted');
    if (!a.last_seen || Date.now() - new Date(a.last_seen).getTime() > 8000) setSetting('print_agent', { ...a, last_seen: now() });
  };
  R('GET', '/api/agent/jobs', null, (c) => {
    agent(c); const ps = printers(), byId = Object.fromEntries(ps.map((p) => [p.id, p]));
    const rows = q.all("SELECT * FROM print_jobs WHERE (status='queued' OR (status='sent' AND updated_at < ?)) AND tries < 5 ORDER BY id LIMIT 10", new Date(Date.now() - 45000).toISOString());
    const jobs = [];
    for (const r of rows) {
      const p = byId[r.printer_id]; if (!p) { q.run("UPDATE print_jobs SET status='failed', error=?, updated_at=? WHERE id=?", 'That printer was removed', now(), r.id); continue; }
      q.run("UPDATE print_jobs SET status='sent', tries=tries+1, updated_at=? WHERE id=?", now(), r.id);
      jobs.push({ id: r.id, kind: r.kind, connection: p.connection, name: p.name, data: Buffer.from(r.data).toString('base64') });
    }
    return { jobs, poll_ms: 2500 };
  });
  R('POST', '/api/agent/jobs/:id', null, (c) => {
    agent(c); const ok = !!c.body.ok;
    q.run('UPDATE print_jobs SET status=?, error=?, updated_at=? WHERE id=?', ok ? 'done' : (c.body.final ? 'failed' : 'queued'), ok ? null : String(c.body.error || 'Print failed').slice(0, 200), now(), Number(c.params.id));
    return { ok: true };
  });
  R('GET', '/api/print/status', '*', () => ({ ...agentState(), auto: printers().some((p) => p.auto_bill || p.auto_kot), printers: printers().map((p) => ({ id: p.id, name: p.name, role: p.role })) }));
  R('GET', '/api/print/config', 'settings', () => ({ printers: printers(), agent: agentState(), recent: q.all('SELECT id,kind,order_id,printer_id,status,tries,error,created_at FROM print_jobs ORDER BY id DESC LIMIT 15') }));
  R('PUT', '/api/print/printers', 'settings', (c) => { const out = cleanPrinters(c.body.printers); setSetting('printers', out); return { printers: out }; });
  R('POST', '/api/print/agent-token', 'settings', () => {
    const secret = crypto.randomBytes(24).toString('hex'); setSetting('print_agent', { hash: sha(secret), last_seen: null, created_at: now() });
    return { token: `ag_${tenantId()}_${outletId()}_${secret}` };
  });
  R('POST', '/api/print/test', 'settings', (c) => { const p = printers().find((x) => x.id === c.body.printer_id); if (!p) throw bad('Pick a printer'); if (!agentState().has_token) throw bad('Set up the print helper first'); enqueue(null, 'bill', { printerId: p.id, bill: SAMPLE() }); return { queued: 1 }; });
  R('POST', '/api/orders/:id/print', 'orders', (c) => {
    const kind = c.body.kind === 'kot' ? 'kot' : 'bill'; if (!agentState().online) throw new HttpError(409, 'The print helper is not connected. Use the browser print instead.', { code: 'helper_offline' });
    const n = enqueue(Number(c.params.id), kind, { printerId: c.body.printer_id }); if (!n) throw new HttpError(409, `No printer is set to print the ${kind === 'kot' ? 'kitchen ticket' : 'bill'}.`, { code: 'no_printer' }); return { queued: n };
  });
}
