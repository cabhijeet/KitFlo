// Bills and kitchen tickets as ESC/POS bytes for thermal printers. Mirrors the bill the browser prints (public/js/bill.js).
// Plain ASCII only: most shop printers have no rupee sign and no Indian scripts, so ₹ becomes "Rs" and other letters become "?".
const COLS = { 58: 32, 80: 48 };
const ESC = 0x1b, GS = 0x1d;
export const colsFor = (paper) => COLS[String(paper)] || 32;

const ascii = (s) => String(s ?? '').replace(/₹/g, 'Rs ').replace(/[×✕]/g, 'x').replace(/[−–—]/g, '-').replace(/[·•]/g, '-').replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/…/g, '...')
  .normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^\x20-\x7e]/g, '?');
export const money = (n) => 'Rs ' + (Math.round((Number(n) + Number.EPSILON) * 100) / 100).toFixed(2);
const qty = (n) => (Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100));
const pct = (n) => `${Math.round(n * 100) / 100}%`;
const dt = (iso) => { try { return new Date(iso).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: process.env.TZ || 'Asia/Kolkata' }); } catch { return String(iso || ''); } };
const TYPE = { dine_in: 'Dine-in', takeaway: 'Takeaway', delivery: 'Delivery' };
const CH = { walkin: 'Walk-in', website: 'Website', whatsapp: 'WhatsApp', swiggy: 'Swiggy', zomato: 'Zomato', phone: 'Phone' };

/** Word-wrap to a width; very long words are cut. */
export function wrap(text, w) {
  const out = []; for (const para of ascii(text).split(/\r?\n/)) {
    let line = '';
    for (let word of para.split(/\s+/).filter(Boolean)) {
      while (word.length > w) { if (line) { out.push(line); line = ''; } out.push(word.slice(0, w)); word = word.slice(w); }
      if (!line) line = word; else if (line.length + 1 + word.length <= w) line += ' ' + word; else { out.push(line); line = word; }
    }
    out.push(line);
  }
  return out;
}

class Doc {
  constructor(cols) { this.cols = cols; this.b = [Buffer.from([ESC, 0x40])]; }
  raw(...bytes) { this.b.push(Buffer.from(bytes)); return this; }
  text(s) { this.b.push(Buffer.from(ascii(s) + '\n', 'latin1')); return this; }
  align(a) { return this.raw(ESC, 0x61, { l: 0, c: 1, r: 2 }[a]); }
  bold(on) { return this.raw(ESC, 0x45, on ? 1 : 0); }
  size(w = 1, h = 1) { return this.raw(GS, 0x21, ((w - 1) << 4) | (h - 1)); }
  line(s, { a = 'l', bold = false, w = 1, h = 1 } = {}) { const cols = Math.floor(this.cols / w); this.align(a).bold(bold).size(w, h); for (const l of wrap(s, cols)) this.text(l); return this.size(1, 1).bold(false).align('l'); }
  rule(ch = '-') { return this.text(ch.repeat(this.cols)); }
  /** Left text and right text on one line; a long left side wraps onto the lines above. */
  row(l, r, o = {}) {
    const w = Math.floor(this.cols / (o.w || 1)); r = ascii(r); const room = Math.max(4, w - r.length - 1), ls = wrap(l, room);
    this.bold(!!o.bold).size(o.w || 1, o.h || 1); ls.slice(0, -1).forEach((x) => this.text(x));
    const last = ls[ls.length - 1] || ''; this.text(last + ' '.repeat(Math.max(1, w - last.length - r.length)) + r); return this.size(1, 1).bold(false);
  }
  qr(data, size = 6) {
    const d = Buffer.from(ascii(data), 'latin1'), n = d.length + 3;
    this.align('c').raw(GS, 0x28, 0x6b, 4, 0, 0x31, 0x41, 0x32, 0).raw(GS, 0x28, 0x6b, 3, 0, 0x31, 0x43, Math.min(16, Math.max(1, size))).raw(GS, 0x28, 0x6b, 3, 0, 0x31, 0x45, 0x31)
      .raw(GS, 0x28, 0x6b, n & 255, n >> 8, 0x31, 0x50, 0x30); this.b.push(d); this.raw(GS, 0x28, 0x6b, 3, 0, 0x31, 0x51, 0x30).text('').align('l'); return this;
  }
  finish(feed = 4) { this.raw(ESC, 0x64, feed).raw(GS, 0x56, 0x42, 0); return Buffer.concat(this.b); }
}

const upiLink = ({ vpa, payee, amount, note }) => { const p = [`pa=${encodeURIComponent(vpa)}`, `pn=${encodeURIComponent(payee || '')}`]; if (amount > 0) p.push(`am=${(Math.round(amount * 100) / 100).toFixed(2)}`); p.push('cu=INR'); if (note) p.push(`tn=${encodeURIComponent(note)}`); return `upi://pay?${p.join('&')}`; };
export function wantsQr(b) {
  const u = b.layout?.upi || {}; if (!u.enabled || !u.vpa || !(b.total > 0)) return false;
  if (['swiggy', 'zomato'].includes(b.channel) || b.payment_mode === 'Prepaid by platform') return false;
  if (b.balance > 0.005 && b.payments?.length) return true;
  return u.when === 'always' ? true : b.payment_mode === 'UPI';
}

/** The customer bill. `b` is what billFor() returns. */
export function renderBill(b, { paper = 58, qrSize = 6, feed = 4 } = {}) {
  const d = new Doc(colsFor(paper)), L = b.layout || {}, sh = L.show || {}, biz = b.business || {};
  d.line(biz.name || 'Cloud Kitchen', { a: 'c', bold: true, h: 2 });
  for (const t of [L.tagline, biz.address, L.phone && `Ph: ${L.phone}`, L.email, L.website, L.social, sh.gstin && biz.gstin && `GSTIN ${biz.gstin}`, sh.fssai && biz.fssai && `FSSAI ${biz.fssai}`, L.header_note]) if (t) d.line(t, { a: 'c' });
  if (b.gst?.title) d.line(b.gst.title, { a: 'c', bold: true });
  d.rule().row('Bill', b.bill_no, { bold: true }).row('Order', `#${b.order_no}`).row('Date', dt(b.date));
  if (sh.channel) d.row('Via', CH[b.channel] || b.channel);
  if (b.order_type) d.row('Type', (TYPE[b.order_type] || b.order_type) + (b.table_no ? ` - ${b.table_no}` : ''));
  if (sh.customer) { d.rule().line('Customer', { bold: true }); if (b.customer || b.phone || b.address) { if (b.customer) d.line(b.customer); if (b.phone) d.line(`Ph: ${b.phone}`); if (b.address) d.line(b.address); } else d.line('Walk-in customer'); }
  d.rule();
  for (const l of b.lines) { d.line(l.name, { bold: true }); if (l.modifiers) d.line('  ' + l.modifiers); d.row(`${qty(l.qty)} x ${money(l.rate)}`, money(l.amount)); }
  d.rule();
  if (sh.unique_items) d.row('Unique items', String(b.unique_items), { bold: true }); if (sh.total_qty) d.row('Total quantity', qty(b.total_qty), { bold: true });
  if (sh.unique_items || sh.total_qty) d.rule();
  d.row('Subtotal', money(b.subtotal));
  if (b.promo_discount > 0) d.row(`Promo ${b.promo_code || ''}`.trim(), '-' + money(b.promo_discount));
  if (b.manual_discount > 0) d.row('Discount', '-' + money(b.manual_discount)); else if (!(b.promo_discount > 0) && b.discount > 0) d.row('Discount', '-' + money(b.discount));
  if (b.packaging_fee) d.row('Packaging', money(b.packaging_fee)); if (b.delivery_fee) d.row('Delivery charge', money(b.delivery_fee)); if (b.service_charge) d.row('Service charge', money(b.service_charge));
  const g = b.gst;
  if (!g) { if (sh.tax_split) d.row('CGST', money(b.cgst)).row('SGST', money(b.sgst)); else d.row('GST', money(b.tax)); }
  else if (g.mode !== 'regular') { if (g.note) d.line(g.note); }
  else {
    const inc = g.inclusive ? ' (incl.)' : '', groups = (g.breakup || []).filter((x) => x.cgst + x.sgst > 0);
    if (groups.length) {
      if (!sh.tax_split) { d.row('GST' + inc, money(b.tax)); if (g.inclusive) d.line('Prices include GST'); }
      else { if (groups.length > 1 || g.inclusive) d.line(g.inclusive ? 'Prices include GST' : 'GST'); for (const x of groups) { if (groups.length > 1) d.line(`${pct(x.rate)} on ${money(x.taxable)}`); d.row(`CGST ${pct(x.rate / 2)}${inc}`, money(x.cgst)).row(`SGST ${pct(x.rate / 2)}${inc}`, money(x.sgst)); } }
    }
  }
  d.rule('=').row('TOTAL', money(b.total), { bold: true, h: 2 });
  if (sh.paid_by) { if (b.payments?.length > 1) { d.line('Paid', { bold: true }); for (const p of b.payments) d.row(p.mode, money(p.amount)); } else d.line(`Paid by ${b.payment_mode || '-'}`, { a: 'c' }); }
  if (b.balance > 0.005) d.row('Balance due', money(b.balance), { bold: true });
  if (wantsQr(b)) {
    const u = L.upi, amt = b.balance > 0.005 && b.payments?.length ? b.balance : b.total;
    d.rule(); if (u.caption) d.line(u.caption, { a: 'c', bold: true });
    d.qr(upiLink({ vpa: u.vpa, payee: u.payee || biz.name || 'Cloud Kitchen', amount: amt, note: String(u.note || '').replace(/\{bill_no\}/g, b.bill_no) }), qrSize); d.line(`${money(amt)} to ${u.vpa}`, { a: 'c' });
  }
  if (sh.notes && b.notes) { d.rule().line('Note', { bold: true }).line(b.notes); }
  d.rule(); if (L.footer) d.line(L.footer, { a: 'c', bold: true }); if (L.footer_note) d.line(L.footer_note, { a: 'c' });
  return d.finish(feed);
}

/** The kitchen ticket: big order number and quantities, no prices. */
export function renderKot(b, { paper = 58, feed = 4 } = {}) {
  const d = new Doc(colsFor(paper));
  d.line('KITCHEN ORDER', { a: 'c', bold: true }).line(`#${b.order_no}`, { a: 'c', bold: true, w: 2, h: 2 });
  if (b.order_type) d.line((TYPE[b.order_type] || b.order_type).toUpperCase() + (b.table_no ? ` - TABLE ${b.table_no}` : ''), { a: 'c', bold: true });
  d.row(CH[b.channel] || b.channel, dt(b.date)).rule();
  for (const l of b.lines) { d.line(`${qty(l.qty)} x ${l.name}`, { bold: true, h: 2 }); if (l.modifiers) d.line('   ' + l.modifiers); }
  d.rule().row('Items', `${b.unique_items} dishes, ${qty(b.total_qty)} qty`, { bold: true });
  if (b.notes) d.rule().line('NOTE: ' + b.notes, { bold: true });
  return d.finish(feed);
}
