// Core business logic: orders, billing, stock ledger, expenses, recurring costs, profit.
import { q, tx, outletId, outletById, now, ymd, addDays, dayStartISO, parseYmd, getSetting, setSetting, parseJson, round2 } from './db.js';
import { emit } from './bus.js';
import { bad, HttpError } from './http.js';
import { outbound } from './integrations/aggregator.js';

export const CHANNELS = ['swiggy', 'zomato', 'website', 'whatsapp', 'walkin'];
export const EXPENSE_CATEGORIES = ['Ingredients', 'Packaging', 'Gas & fuel', 'Rent', 'Salaries', 'Utilities', 'Marketing', 'Platform fees', 'Repairs', 'Other'];
export const PAYMENT_MODES = ['UPI', 'Cash', 'Card', 'Bank transfer', 'Prepaid by platform'];
const NEXT = { new: ['accepted', 'cancelled'], accepted: ['preparing', 'cancelled'], preparing: ['ready', 'cancelled'], ready: ['completed', 'cancelled'] };

export const normPhone = (p) => { const d = String(p || '').replace(/\D/g, ''); return d.length >= 10 ? d.slice(-10) : null; };
const num = (v, name, { min = 0, max = 1e9, required = false } = {}) => {
  if (v === undefined || v === null || v === '') { if (required) throw bad(`${name} is required`); return 0; }
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) throw bad(`${name} is not valid`);
  return n;
};
const str = (v, max = 300) => (v === undefined || v === null ? null : String(v).trim().slice(0, max) || null);
const sinceISO = (days) => new Date(Date.now() - days * 864e5).toISOString();

// ───────────────────────── Menu and recipes ─────────────────────────
const ON_HAND = '(SELECT COALESCE(SUM(qty),0) FROM stock_movements m WHERE m.inventory_item_id=i.id)';
const portion = (l) => l.qty_per_portion * (1 + (l.wastage_pct || 0) / 100);
export const priceFor = (menu, channel) => { const p = typeof menu.prices === 'string' ? parseJson(menu.prices, {}) : menu.prices; return Number(p[channel] ?? p.default ?? 0); };

export const displayName = (m) => (m.variant_name ? `${m.name} · ${m.variant_name}` : m.name);

export function menuList() {
  const catOff = categoriesOff();
  const links = new Map(); for (const l of q.all('SELECT * FROM menu_addon_groups')) { if (!links.has(l.menu_item_id)) links.set(l.menu_item_id, []); links.get(l.menu_item_id).push(l.group_id); }
  const items = q.all('SELECT * FROM menu_items ORDER BY category, sort_order, name, id');
  const lines = q.all(`SELECT r.*, i.name ingredient, i.unit, i.unit_cost, ${ON_HAND} on_hand FROM recipe_lines r JOIN inventory_items i ON i.id=r.inventory_item_id`);
  const by = new Map();
  for (const l of lines) { if (!by.has(l.menu_item_id)) by.set(l.menu_item_id, []); by.get(l.menu_item_id).push(l); }
  return items.map(m => {
    const rl = by.get(m.id) || [];
    const prices = parseJson(m.prices, {});
    const cost = round2(rl.reduce((s, l) => s + portion(l) * l.unit_cost, 0));
    const base = Number(prices.website ?? prices.default ?? 0);
    const short = rl.filter(l => l.on_hand < portion(l)).map(l => l.ingredient);
    const food = rl.length ? cost : round2(Number(m.ingredient_cost) || 0);
    const hasCost = rl.length > 0 || Number(m.ingredient_cost) > 0;
    const full = round2(food + (Number(m.op_cost) || 0) + (Number(m.pack_cost) || 0));
    return {
      id: m.id, name: m.name, display_name: displayName(m), category: m.category, subcategory: m.subcategory || '', description: m.description || '', image_url: m.image_url || '',
      catalogue_id: m.catalogue_id || '', variant_id: m.variant_id || '', variant_name: m.variant_name || '', sort_order: m.sort_order || 0, group_key: m.catalogue_id || `item-${m.id}`, has_recipe: rl.length > 0,
      addon_group_ids: links.get(m.id) || [],
      gst_rate: m.gst_rate, off: !!m.off, prices, external_ids: parseJson(m.external_ids, {}),
      recipe: rl.map(l => ({ inventory_item_id: l.inventory_item_id, ingredient: l.ingredient, unit: l.unit, qty_per_portion: l.qty_per_portion, wastage_pct: l.wastage_pct })),
      product_code: m.product_code || '', mrp: m.mrp ?? null, main_ingredients: m.main_ingredients || '', extra_ingredients: m.extra_ingredients || '', method: m.method || '',
      ingredient_cost: m.ingredient_cost ?? null, op_cost: m.op_cost ?? null, pack_cost: m.pack_cost ?? null,
      recipe_cost: cost, food_cost: food, has_cost: hasCost, total_cost: full, net_margin: base > 0 && hasCost ? round2(base - full) : null,
      margin_pct: base > 0 && hasCost ? round2((base - food) / base * 100) : null,
      cat_off: !!catOff[m.category || 'Other'] || !!catOff[m.category || ''],
      available: !m.off && !(catOff[m.category || 'Other'] || catOff[m.category || '']) && short.length === 0, short_of: short,
    };
  });
}
const recipeCost = (menuId) => {
  const rl = q.all('SELECT r.*, i.unit_cost FROM recipe_lines r JOIN inventory_items i ON i.id=r.inventory_item_id WHERE r.menu_item_id=?', menuId);
  return round2(rl.reduce((s, l) => s + portion(l) * l.unit_cost, 0));
};

const imgUrl = (u) => { const v = String(u || '').trim(); if (!v) return null; if (!/^https?:\/\/[^\s]+$/i.test(v) && !v.startsWith('/uploads/')) throw bad('Image link must start with https://'); return v.slice(0, 500); };
const COST_FIELDS = ['product_code', 'mrp', 'main_ingredients', 'extra_ingredients', 'method', 'ingredient_cost', 'op_cost', 'pack_cost'];
const optNum = (v, label) => (v === '' || v === null || v === undefined ? null : num(v, label, { max: 100000 }));
const menuCosts = (b) => [str(b.product_code, 40) || null, optNum(b.mrp, 'MRP'), str(b.main_ingredients, 4000) || null, str(b.extra_ingredients, 4000) || null, str(b.method, 6000) || null, optNum(b.ingredient_cost, 'Ingredient cost'), optNum(b.op_cost, 'Operational cost'), optNum(b.pack_cost, 'Packaging cost')];
const menuExtras = (b) => [str(b.subcategory, 60) || null, str(b.description, 1000) || null, imgUrl(b.image_url), str(b.catalogue_id, 40) || null, str(b.variant_name, 80) || null, str(b.variant_id, 40) || null, Number.isFinite(Number(b.sort_order)) ? Number(b.sort_order) : 0];

export function saveMenuItem(id, b) {
  const name = str(b.name, 80); if (!name) throw bad('Dish name is required');
  const prices = {}; for (const [k, v] of Object.entries(b.prices || {})) { if (v !== '' && v !== null && v !== undefined) prices[k] = num(v, `Price (${k})`, { max: 100000 }); }
  if (prices.default === undefined && prices.website === undefined) throw bad('Set at least a default price');
  const gst = num(b.gst_rate ?? gstCfg().default_rate, 'GST rate', { max: 40 });
  const recipe = Array.isArray(b.recipe) ? b.recipe : [];
  return tx(() => {
    if (id) {
      if (!q.get('SELECT id FROM menu_items WHERE id=?', id)) throw new HttpError(404, 'Dish not found');
      q.run('UPDATE menu_items SET name=?, category=?, prices=?, gst_rate=?, external_ids=?, off=?, subcategory=?, description=?, image_url=?, catalogue_id=?, variant_name=?, variant_id=?, sort_order=?, product_code=?, mrp=?, main_ingredients=?, extra_ingredients=?, method=?, ingredient_cost=?, op_cost=?, pack_cost=? WHERE id=?', name, str(b.category, 40), JSON.stringify(prices), gst, JSON.stringify(b.external_ids || {}), b.off ? 1 : 0, ...menuExtras(b), ...menuCosts(b), id);
    } else {
      id = Number(q.run('INSERT INTO menu_items(name,category,prices,gst_rate,external_ids,off,created_at,subcategory,description,image_url,catalogue_id,variant_name,variant_id,sort_order,product_code,mrp,main_ingredients,extra_ingredients,method,ingredient_cost,op_cost,pack_cost) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', name, str(b.category, 40), JSON.stringify(prices), gst, JSON.stringify(b.external_ids || {}), b.off ? 1 : 0, now(), ...menuExtras(b), ...menuCosts(b)).lastInsertRowid);
    }
    if (b.recipe !== undefined) {
      q.run('DELETE FROM recipe_lines WHERE menu_item_id=?', id);
      for (const l of recipe) {
        const iid = Number(l.inventory_item_id);
        if (!q.get('SELECT id FROM inventory_items WHERE id=?', iid)) throw bad('Recipe has an unknown ingredient');
        q.run('INSERT INTO recipe_lines(menu_item_id,inventory_item_id,qty_per_portion,wastage_pct) VALUES(?,?,?,?)', id, iid, num(l.qty_per_portion, 'Recipe quantity', { required: true, max: 10000 }), num(l.wastage_pct, 'Wastage', { max: 100 }));
      }
    }
    emit('menu.updated', { id });
    return menuList().find(m => m.id === id);
  });
}


// ───────────────────────── Add-ons ─────────────────────────
// A group is a set of options (Size, Extras, Spice level) that can be attached to any dish. min_pick above 0 makes the choice required;
// max_pick of 0 means no limit. Each add-on has a price, an optional cost, and can use up stock when it is sold.
const addonCost = (a, inv) => (a.cost > 0 ? a.cost : inv ? round2(inv.unit_cost * a.qty_per_use) : 0);
export function addonGroups() {
  const groups = q.all('SELECT * FROM addon_groups ORDER BY sort_order, name, id');
  const ads = q.all(`SELECT a.*, i.name inv_name, i.unit inv_unit, i.unit_cost inv_cost, ${ON_HAND} on_hand FROM addons a LEFT JOIN inventory_items i ON i.id=a.inventory_item_id ORDER BY a.sort_order, a.id`);
  const links = q.all('SELECT * FROM menu_addon_groups');
  return groups.map(g => ({
    id: g.id, name: g.name, min_pick: g.min_pick, max_pick: g.max_pick, required: g.min_pick > 0, off: !!g.off, sort_order: g.sort_order,
    item_ids: links.filter(l => l.group_id === g.id).map(l => l.menu_item_id),
    addons: ads.filter(a => a.group_id === g.id).map(a => ({
      id: a.id, name: a.name, price: a.price, cost: a.cost, inventory_item_id: a.inventory_item_id, inventory_name: a.inv_name || '', qty_per_use: a.qty_per_use, unit: a.inv_unit || '', off: !!a.off,
      available: !a.off && !(a.inventory_item_id && a.qty_per_use > 0 && a.on_hand < a.qty_per_use),
      unit_cost: addonCost(a, a.inventory_item_id ? { unit_cost: a.inv_cost } : null),
    })),
  }));
}
export function saveAddonGroup(id, b) {
  const name = str(b.name, 60); if (!name) throw bad('Give the group a name, for example Extras or Size');
  const min = Math.floor(num(b.min_pick, 'Minimum choices', { max: 20 })), max = Math.floor(num(b.max_pick, 'Maximum choices', { max: 50 }));
  if (max && min > max) throw bad('Minimum choices cannot be more than the maximum');
  const list = Array.isArray(b.addons) ? b.addons : [];
  if (list.length > 60) throw bad('Too many options in one group');
  return tx(() => {
    if (id) {
      if (!q.get('SELECT id FROM addon_groups WHERE id=?', id)) throw new HttpError(404, 'Add-on group not found');
      q.run('UPDATE addon_groups SET name=?, min_pick=?, max_pick=?, off=?, sort_order=? WHERE id=?', name, min, max, b.off ? 1 : 0, Number(b.sort_order) || 0, id);
    } else id = Number(q.run('INSERT INTO addon_groups(name,min_pick,max_pick,off,sort_order) VALUES(?,?,?,?,?)', name, min, max, b.off ? 1 : 0, Number(b.sort_order) || 0).lastInsertRowid);
    if (b.addons !== undefined) {
      const keep = [];
      list.forEach((a, i) => {
        const an = str(a.name, 60); if (!an) throw bad('Every add-on needs a name');
        const inv = a.inventory_item_id ? Number(a.inventory_item_id) : null;
        if (inv && !q.get('SELECT id FROM inventory_items WHERE id=?', inv)) throw bad('An add-on uses a stock item that does not exist');
        const f = [an, num(a.price, `Price of ${an}`, { max: 100000 }), num(a.cost, `Cost of ${an}`, { max: 100000 }), inv, inv ? num(a.qty_per_use, `Stock used by ${an}`, { max: 10000 }) : 0, a.off ? 1 : 0, i];
        if (a.id && q.get('SELECT id FROM addons WHERE id=? AND group_id=?', Number(a.id), id)) { q.run('UPDATE addons SET name=?, price=?, cost=?, inventory_item_id=?, qty_per_use=?, off=?, sort_order=? WHERE id=?', ...f, Number(a.id)); keep.push(Number(a.id)); }
        else keep.push(Number(q.run('INSERT INTO addons(name,price,cost,inventory_item_id,qty_per_use,off,sort_order,group_id) VALUES(?,?,?,?,?,?,?,?)', ...f, id).lastInsertRowid));
      });
      for (const a of q.all('SELECT id FROM addons WHERE group_id=?', id)) if (!keep.includes(a.id)) q.run('DELETE FROM addons WHERE id=?', a.id);
    }
    // Which dishes carry this group: an explicit list, or everything / whole categories in one go.
    let items = null;
    if (b.apply_to === 'all') items = q.all('SELECT id FROM menu_items').map(r => r.id);
    else if (Array.isArray(b.apply_categories)) items = q.all('SELECT id, category FROM menu_items').filter(r => b.apply_categories.includes(r.category || '')).map(r => r.id);
    else if (Array.isArray(b.item_ids)) items = b.item_ids.map(Number);
    if (items) {
      const add = b.apply_to === 'all' || Array.isArray(b.apply_categories);
      if (!add) q.run('DELETE FROM menu_addon_groups WHERE group_id=?', id);
      for (const m of items) if (q.get('SELECT id FROM menu_items WHERE id=?', m)) q.run('INSERT OR IGNORE INTO menu_addon_groups(menu_item_id,group_id) VALUES(?,?)', m, id);
    }
    emit('menu.updated', { addons: true });
    return addonGroups().find(g => g.id === id);
  });
}
export function deleteAddonGroup(id) {
  if (!q.get('SELECT id FROM addon_groups WHERE id=?', id)) throw new HttpError(404, 'Add-on group not found');
  q.run('DELETE FROM addon_groups WHERE id=?', id); emit('menu.updated', { addons: true }); return { ok: true };
}
export function setItemAddonGroups(menuItemId, groupIds) {
  if (!q.get('SELECT id FROM menu_items WHERE id=?', menuItemId)) throw new HttpError(404, 'Dish not found');
  tx(() => { q.run('DELETE FROM menu_addon_groups WHERE menu_item_id=?', menuItemId); for (const g of groupIds || []) if (q.get('SELECT id FROM addon_groups WHERE id=?', Number(g))) q.run('INSERT OR IGNORE INTO menu_addon_groups(menu_item_id,group_id) VALUES(?,?)', menuItemId, Number(g)); });
  emit('menu.updated', { id: menuItemId }); return menuList().find(m => m.id === menuItemId);
}
/** Checks a customer's picks against the groups attached to the dish and prices them from the database, never from the request. */
export function resolveAddons(menuItemId, picks) {
  const asked = new Map(); for (const p of Array.isArray(picks) ? picks : []) { const aid = Number(p?.id ?? p); const n = Math.max(1, Math.min(9, Math.floor(Number(p?.qty) || 1))); if (aid) asked.set(aid, (asked.get(aid) || 0) + n); }
  const groups = addonGroups().filter(g => !g.off && g.item_ids.includes(menuItemId));
  const out = []; let price = 0, cost = 0;
  for (const g of groups) {
    let count = 0;
    for (const a of g.addons) {
      const n = asked.get(a.id); if (!n) continue;
      if (!a.available) throw bad(`${a.name} is not available right now`);
      count += n; asked.delete(a.id);
      const inv = a.inventory_item_id ? q.get('SELECT unit_cost FROM inventory_items WHERE id=?', a.inventory_item_id) : null;
      const uc = addonCost(a, inv);
      out.push({ id: a.id, group: g.name, name: a.name, price: a.price, cost: uc, qty: n, inventory_item_id: a.inventory_item_id || null, qty_per_use: a.qty_per_use || 0 });
      price += a.price * n; cost += uc * n;
    }
    if (count < g.min_pick) throw bad(`Choose ${g.min_pick > 1 ? `at least ${g.min_pick}` : 'one'} from ${g.name}`);
    if (g.max_pick && count > g.max_pick) throw bad(`Choose at most ${g.max_pick} from ${g.name}`);
  }
  if (asked.size) throw bad('One of the chosen add-ons does not belong to this dish');
  return { list: out, price: round2(price), cost: round2(cost) };
}
export const addonText = (list) => list.map(a => `${a.qty > 1 ? a.qty + '× ' : ''}${a.name}`).join(', ');
/** What add-ons earned over a period, for the Menu page. */
export function addonSales(days = 30) {
  const rows = q.all(`SELECT oi.addons, oi.qty FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.addons IS NOT NULL AND o.status!='cancelled' AND o.placed_at>=?`, sinceISO(days));
  const by = new Map();
  for (const r of rows) for (const a of parseJson(r.addons, [])) {
    const k = `${a.group}|${a.name}`, e = by.get(k) || { group: a.group, name: a.name, qty: 0, revenue: 0, cost: 0 };
    e.qty += a.qty * r.qty; e.revenue += a.price * a.qty * r.qty; e.cost += (a.cost || 0) * a.qty * r.qty; by.set(k, e);
  }
  return [...by.values()].map(e => ({ ...e, revenue: round2(e.revenue), profit: round2(e.revenue - e.cost) })).sort((a, b) => b.revenue - a.revenue);
}

// ───────────────────────── Inventory ─────────────────────────
export function inventoryList() {
  const rows = q.all(`SELECT i.*, s.name supplier, ${ON_HAND} on_hand,
    (SELECT COALESCE(-SUM(qty),0) FROM stock_movements m WHERE m.inventory_item_id=i.id AND m.type IN ('sale','reversal') AND m.moved_at>=?) used7
    FROM inventory_items i LEFT JOIN suppliers s ON s.id=i.supplier_id ORDER BY i.category, i.name`, sinceISO(7));
  const today = parseYmd(ymd());
  return rows.map(r => {
    const on = Math.round(r.on_hand * 1000) / 1000;
    const exp = r.expiry_date ? Math.ceil((parseYmd(r.expiry_date) - today) / 864e5) : null;
    const daily = r.used7 / 7;
    return {
      id: r.id, name: r.name, category: r.category, unit: r.unit, reorder_level: r.reorder_level, par_level: r.par_level, unit_cost: r.unit_cost,
      supplier_id: r.supplier_id, supplier: r.supplier, expiry_date: r.expiry_date, on_hand: on,
      days_of_cover: daily > 0 ? Math.round(on / daily * 10) / 10 : null, expires_in_days: exp,
      low: on <= r.reorder_level,
      surplus: on > 0 && r.par_level > 0 && (on > r.par_level || (exp !== null && exp <= 2 && on > r.par_level * 0.6)),
    };
  });
}

export function saveInventoryItem(id, b) {
  const name = str(b.name, 80); if (!name) throw bad('Item name is required');
  const f = [name, str(b.category, 40), str(b.unit, 12) || 'kg', num(b.reorder_level, 'Reorder level'), num(b.par_level, 'Par level'), num(b.unit_cost, 'Unit cost'), b.supplier_id ? Number(b.supplier_id) : null, str(b.expiry_date, 10)];
  return tx(() => {
    if (id) {
      if (!q.get('SELECT id FROM inventory_items WHERE id=?', id)) throw new HttpError(404, 'Item not found');
      q.run('UPDATE inventory_items SET name=?, category=?, unit=?, reorder_level=?, par_level=?, unit_cost=?, supplier_id=?, expiry_date=? WHERE id=?', ...f, id);
    } else {
      id = Number(q.run('INSERT INTO inventory_items(name,category,unit,reorder_level,par_level,unit_cost,supplier_id,expiry_date) VALUES(?,?,?,?,?,?,?,?)', ...f).lastInsertRowid);
      const opening = num(b.opening_qty, 'Opening quantity');
      if (opening > 0) addMovement({ item_id: id, type: 'opening', qty: opening, unit_cost: f[5], note: 'Opening stock' });
    }
    return inventoryList().find(i => i.id === id);
  });
}

export function addMovement({ item_id, type, qty, order_id = null, expense_id = null, unit_cost = 0, by = null, note = null }) {
  return Number(q.run('INSERT INTO stock_movements(inventory_item_id,type,qty,order_id,expense_id,unit_cost,moved_at,by_user,note) VALUES(?,?,?,?,?,?,?,?,?)', item_id, type, qty, order_id, expense_id, unit_cost, now(), by, note).lastInsertRowid);
}

export function recordWastage(b, user) {
  const item = q.get('SELECT * FROM inventory_items WHERE id=?', Number(b.inventory_item_id));
  if (!item) throw bad('Unknown item');
  const type = b.type === 'adjustment' ? 'adjustment' : 'wastage';
  const qty = type === 'wastage' ? -num(b.qty, 'Quantity', { required: true, min: 0.0001 }) : num(b.qty, 'Quantity', { required: true, min: -1e6 });
  if (qty === 0) throw bad('Quantity cannot be zero');
  addMovement({ item_id: item.id, type, qty, unit_cost: item.unit_cost, by: user?.name, note: str(b.note, 200) });
  emit('stock.changed', { item_id: item.id, type });
  checkStockEvents();
  return inventoryList().find(i => i.id === item.id);
}

export function recordPurchase(b, user) {
  const item = q.get('SELECT * FROM inventory_items WHERE id=?', Number(b.inventory_item_id));
  if (!item) throw bad('Unknown item');
  const qty = num(b.qty, 'Quantity', { required: true, min: 0.0001 });
  const unitCost = num(b.unit_cost, 'Cost per unit', { required: true, min: 0 });
  const vendor = str(b.supplier, 80);
  const out = tx(() => {
    let sid = item.supplier_id;
    if (vendor) {
      q.run('INSERT INTO suppliers(name,last_purchase_at) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET last_purchase_at=excluded.last_purchase_at', vendor, now());
      sid = q.get('SELECT id FROM suppliers WHERE name=?', vendor).id;
    }
    q.run('UPDATE inventory_items SET unit_cost=?, supplier_id=?, expiry_date=COALESCE(?, expiry_date) WHERE id=?', unitCost, sid, str(b.expiry_date, 10), item.id);
    const exp = Number(q.run('INSERT INTO expenses(date,category,amount,vendor,payment_mode,source,notes,entered_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)', ymd(), 'Ingredients', round2(qty * unitCost), vendor, str(b.payment_mode, 30) || 'UPI', 'stock_purchase', `${qty} ${item.unit} ${item.name}`, user?.name, now()).lastInsertRowid);
    const mv = addMovement({ item_id: item.id, type: 'purchase', qty, expense_id: exp, unit_cost: unitCost, by: user?.name });
    q.run('UPDATE expenses SET movement_id=? WHERE id=?', mv, exp);
    return { expense_id: exp, movement_id: mv };
  });
  emit('stock.purchased', { item_id: item.id, qty, amount: round2(qty * unitCost) });
  emit('expense.added', { id: out.expense_id, category: 'Ingredients', amount: round2(qty * unitCost), date: ymd() });
  checkStockEvents();
  return { ...out, item: inventoryList().find(i => i.id === item.id) };
}

/** Fires stock.low once per item until it recovers; availability on aggregators is synced by the rule. */
export function checkStockEvents() {
  const lowSet = new Set(getSetting('stock_low_set', []));
  const items = inventoryList();
  for (const i of items) {
    if (i.low && !lowSet.has(i.id)) { lowSet.add(i.id); emit('stock.low', { item_id: i.id, item: i.name, on_hand: i.on_hand, unit: i.unit, reorder_level: i.reorder_level }); }
    else if (!i.low && lowSet.has(i.id)) lowSet.delete(i.id);
  }
  setSetting('stock_low_set', [...lowSet]);
}
/** Emits stock.surplus at most once per item per day. */
export function scanSurplus() {
  const seen = getSetting('surplus_seen', {});
  const today = ymd();
  let changed = false;
  for (const i of inventoryList()) {
    if (i.surplus && seen[i.id] !== today) {
      seen[i.id] = today; changed = true;
      emit('stock.surplus', { item_id: i.id, item: i.name, on_hand: i.on_hand, unit: i.unit, par_level: i.par_level, expires_in_days: i.expires_in_days });
    }
  }
  if (changed) setSetting('surplus_seen', seen);
}

// ───────────────────────── Customers ─────────────────────────
function upsertCustomer(c, channel) {
  const phone = normPhone(c?.phone);
  if (!phone) return null;
  const ex = q.get('SELECT * FROM customers WHERE phone=?', phone);
  if (ex) {
    if (!ex.name && c.name) q.run('UPDATE customers SET name=? WHERE id=?', str(c.name, 80), ex.id);
    if (c.whatsapp_opt_in) q.run('UPDATE customers SET whatsapp_opt_in=1 WHERE id=?', ex.id);
    return ex.id;
  }
  return Number(q.run('INSERT INTO customers(name,phone,email,first_channel,whatsapp_opt_in,created_at) VALUES(?,?,?,?,?,?)', str(c.name, 80), phone, str(c.email, 120), channel, c.whatsapp_opt_in ? 1 : 0, now()).lastInsertRowid);
}
export function customersList() {
  const lapsedDays = getSetting('lapsed_days', 30);
  const rows = q.all(`SELECT c.*, COUNT(o.id) order_count, COALESCE(SUM(o.total),0) lifetime_value, MAX(o.placed_at) last_order_at
    FROM customers c LEFT JOIN orders o ON o.customer_id=c.id AND o.status!='cancelled' GROUP BY c.id ORDER BY lifetime_value DESC`);
  return rows.map(r => ({
    ...r, whatsapp_opt_in: !!r.whatsapp_opt_in, lifetime_value: round2(r.lifetime_value),
    segment: !r.order_count ? 'New' : (Date.now() - new Date(r.last_order_at).getTime() > lapsedDays * 864e5 ? 'Lapsed' : (r.order_count >= 2 ? 'Repeat' : 'New')),
  }));
}

// ───────────────────────── Orders ─────────────────────────
export function orderFull(id) {
  const o = q.get('SELECT o.*, c.name customer_name, c.phone customer_phone FROM orders o LEFT JOIN customers c ON c.id=o.customer_id WHERE o.id=?', id);
  if (!o) return null;
  o.items = q.all('SELECT * FROM order_items WHERE order_id=? ORDER BY id', id).map(i => ({ ...i, addons: parseJson(i.addons, []) }));
  return decorate(o);
}
function decorate(o) {
  const prep = getSetting('prep_minutes', 25);
  o.net_sales = round2(o.subtotal - o.discount + o.packaging_fee + (o.delivery_fee || 0) + (o.service_charge || 0) - (o.tax_inclusive ? o.tax : 0));
  o.order_profit = round2(o.net_sales - o.commission - o.food_cost);
  o.promised_at = new Date(new Date(o.placed_at).getTime() + prep * 60000).toISOString();
  o.needs_review = !!o.needs_review;
  return o;
}
/** Open orders plus everything finished today, with their items. */
export function ordersBoard() {
  const rows = q.all(`SELECT o.*, c.name customer_name, c.phone customer_phone FROM orders o LEFT JOIN customers c ON c.id=o.customer_id
    WHERE o.status IN ('new','accepted','preparing','ready') OR o.placed_at >= ? ORDER BY o.placed_at DESC LIMIT 400`, dayStartISO(ymd()));
  return attachItems(rows);
}
export function ordersSearch({ status, channel, from, to, limit = 100 }) {
  const w = []; const p = [];
  if (status) { w.push('o.status=?'); p.push(status); }
  if (channel) { w.push('o.channel=?'); p.push(channel); }
  if (from) { w.push('o.placed_at>=?'); p.push(dayStartISO(from)); }
  if (to) { w.push('o.placed_at<?'); p.push(dayStartISO(ymd(addDays(parseYmd(to), 1)))); }
  const rows = q.all(`SELECT o.*, c.name customer_name, c.phone customer_phone FROM orders o LEFT JOIN customers c ON c.id=o.customer_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY o.placed_at DESC LIMIT ?`, ...p, Math.min(Number(limit) || 100, 500));
  return attachItems(rows);
}
function attachItems(rows) {
  if (!rows.length) return [];
  const ids = rows.map(r => r.id);
  const items = q.all(`SELECT * FROM order_items WHERE order_id IN (${ids.map(() => '?').join(',')}) ORDER BY id`, ...ids);
  const by = new Map();
  for (const it of items) { if (!by.has(it.order_id)) by.set(it.order_id, []); by.get(it.order_id).push({ ...it, addons: parseJson(it.addons, []) }); }
  return rows.map(r => { r.items = by.get(r.id) || []; return decorate(r); });
}

export function createOrder(inp, ctx = {}) {
  const channel = String(inp.channel || '').toLowerCase();
  if (!CHANNELS.includes(channel)) throw bad('Unknown channel');
  const cs = q.get('SELECT * FROM channel_settings WHERE channel=?', channel) || { commission_pct: 0, packaging_fee: 0, label: channel, active: 1 };
  if (!cs.active) throw bad(`${cs.label || channel} orders are switched off`);
  const raw = Array.isArray(inp.items) ? inp.items : [];
  if (!raw.length) throw bad('Order has no items');
  if (raw.length > 60) throw bad('Too many items');
  const coid = inp.channel_order_id ? String(inp.channel_order_id).slice(0, 80) : null;
  if (coid) { const d = q.get('SELECT id FROM orders WHERE channel=? AND channel_order_id=?', channel, coid); if (d) return { order: orderFull(d.id), duplicate: true }; }

  const warnings = [];
  const id = tx(() => {
    let needsReview = 0;
    const lines = raw.map(it => {
      const qty = num(it.qty ?? 1, 'Quantity', { min: 0.0001, max: 500 });
      if (it.menu_item_id) {
        const m = q.get('SELECT * FROM menu_items WHERE id=?', Number(it.menu_item_id));
        if (!m) throw bad('Unknown dish in order');
        const given = ctx.trustPrices && it.unit_price != null, ad = resolveAddons(m.id, it.addons);
        const price = given ? num(it.unit_price, 'Price') : round2(priceFor(m, channel) + ad.price);
        const note = str(it.modifiers, 200), mods = [ad.list.length ? '+ ' + addonText(ad.list) : '', note || ''].filter(Boolean).join(' · ') || null;
        return { menu_item_id: m.id, name: displayName(m), qty, unit_price: price, unit_cost: round2((recipeCost(m.id) || round2(Number(m.ingredient_cost) || 0)) + ad.cost), gst_rate: m.gst_rate, modifiers: mods ? mods.slice(0, 300) : null, addons: ad.list.length ? JSON.stringify(ad.list) : null };
      }
      needsReview = 1;
      return { menu_item_id: null, name: str(it.name, 80) || 'Unmapped item', qty, unit_price: num(it.unit_price, 'Price'), unit_cost: 0, gst_rate: num(it.gst_rate, 'GST', { max: 40 }), modifiers: str(it.modifiers, 200), addons: null };
    });
    const subtotal = round2(lines.reduce((s, l) => s + l.unit_price * l.qty, 0));
    let discount = ctx.trustPrices ? num(inp.discount, 'Discount') : 0;
    let promo = null;
    if (inp.promo_code) {
      const code = String(inp.promo_code).trim().toUpperCase();
      const p = q.get('SELECT * FROM promos WHERE code=? AND (valid_until IS NULL OR valid_until>=?)', code, now());
      if (p) {
        const base = lines.filter(l => !p.menu_item_id || l.menu_item_id === p.menu_item_id).reduce((s, l) => s + l.unit_price * l.qty, 0);
        if (base > 0) { discount += round2(base * p.pct / 100); promo = code; } else warnings.push('Promo code does not apply to these dishes');
      } else warnings.push('Promo code is not valid');
    }
    // Manual discount at the counter: no code needed. Percent applies to what is left after any promo; fixed is a rupee amount.
    let manual = 0, dType = null, dValue = null, dReason = null;
    const md = inp.manual_discount;
    if (md && ctx.user?.role && Number(md.value) > 0) {
      dType = md.type === 'fixed' ? 'fixed' : 'percent'; dValue = num(md.value, 'Discount', { min: 0.01, max: dType === 'percent' ? 100 : 100000 }); dReason = str(md.reason, 80) || null;
      const left = Math.max(0, subtotal - Math.min(discount, subtotal));
      manual = round2(dType === 'percent' ? left * dValue / 100 : Math.min(dValue, left));
      const limit = Number(getSetting('discount_limit_pct', 30));
      if (ctx.user.role === 'cashier' && subtotal > 0 && manual / subtotal * 100 > limit + 0.001) throw new HttpError(403, `Discounts above ${limit}% need a manager or the owner`);
    }
    discount = Math.min(round2(discount + manual), subtotal);
    const packaging = ctx.trustPrices && inp.packaging_fee != null ? num(inp.packaging_fee, 'Packaging fee') : (channel === 'walkin' ? 0 : Number(cs.packaging_fee || 0));
    const own = ['walkin', 'whatsapp', 'website'].includes(channel), oType = ORDER_TYPES.includes(inp.order_type) ? inp.order_type : (channel === 'walkin' ? 'takeaway' : 'delivery'), cc = chargesCfg();
    const net = subtotal - discount;
    const deliveryFee = !ctx.trustPrices && own && oType === 'delivery' && cc.delivery_fee > 0 && !(cc.delivery_free_above > 0 && net >= cc.delivery_free_above) ? cc.delivery_fee : 0;
    const serviceCharge = !ctx.trustPrices && own && oType === 'dine_in' && cc.service_pct > 0 ? round2(net * cc.service_pct / 100) : 0;
    const g = gstCfg(), gc = { ...g, mode: g.platform_collects && (channel === 'swiggy' || channel === 'zomato') ? 'none' : g.mode };
    const { tax, total } = computeTax(lines, discount, packaging, gc, deliveryFee + serviceCharge);
    const pays = cleanPayments(inp.payments, total);
    const commission = round2((subtotal - discount) * Number(cs.commission_pct || 0) / 100);
    const foodCost = round2(lines.reduce((s, l) => s + l.unit_cost * l.qty, 0));
    const custId = upsertCustomer(inp.customer, channel);
    const orderNo = Number(q.get('SELECT COALESCE(MAX(order_no),1000)+1 n FROM orders').n);
    const oid = Number(q.run(`INSERT INTO orders(order_no,channel,channel_order_id,customer_id,status,placed_at,subtotal,discount,tax,packaging_fee,commission,total,payment_mode,food_cost,promo_code,notes,address,needs_review,created_by,manual_discount,discount_type,discount_value,discount_reason,tax_inclusive,pack_gst_rate,tax_mode,order_type,table_no,delivery_fee,service_charge,payments,charge_gst_rate)
      VALUES(?,?,?,?,'new',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, orderNo, channel, coid, custId, inp.placed_at && ctx.trustPrices ? new Date(inp.placed_at).toISOString() : now(), subtotal, discount, tax, packaging, commission, total,
      (pays ? (pays.length > 1 ? 'Split' : pays[0].mode) : str(inp.payment_mode, 30)) || (channel === 'swiggy' || channel === 'zomato' ? 'Prepaid by platform' : 'UPI'), foodCost, promo, str(inp.notes, 500), str(inp.address, 300), needsReview, ctx.user?.name || channel, manual, dType, dValue, dReason, gc.inclusive ? 1 : 0, gc.packaging_rate, gc.mode, oType, str(inp.table_no, 12) || null, deliveryFee, serviceCharge, pays ? JSON.stringify(pays) : null, gc.charge_rate).lastInsertRowid);
    for (const l of lines) q.run('INSERT INTO order_items(order_id,menu_item_id,name,qty,unit_price,unit_cost,gst_rate,modifiers,addons) VALUES(?,?,?,?,?,?,?,?,?)', oid, l.menu_item_id, l.name, l.qty, l.unit_price, l.unit_cost, l.gst_rate, l.modifiers, l.addons);
    return oid;
  });
  const order = orderFull(id);
  emit('order.received', { id, order_no: order.order_no, channel, total: order.total, needs_review: order.needs_review });
  if (ctx.accept) return { order: setOrderStatus(id, 'accepted', ctx.user), duplicate: false, warnings };
  return { order, duplicate: false, warnings };
}

const acceptedHooks = [];
/** Lets another module (printing) act when an order is accepted, inside the same business and outlet. */
export const onOrderAccepted = (fn) => acceptedHooks.push(fn);
export function setOrderStatus(id, to, user, reason) {
  const o = q.get('SELECT * FROM orders WHERE id=?', id);
  if (!o) throw new HttpError(404, 'Order not found');
  if (o.status === to) return orderFull(id);
  if (!(NEXT[o.status] || []).includes(to)) throw bad(`An order that is ${o.status} cannot become ${to}`);
  tx(() => {
    const t = now();
    if (to === 'accepted') {
      q.run('UPDATE orders SET status=?, accepted_at=? WHERE id=?', to, t, id);
      if (!o.deducted) {
        for (const it of q.all('SELECT * FROM order_items WHERE order_id=? AND menu_item_id IS NOT NULL', id)) {
          for (const l of q.all('SELECT r.*, i.unit_cost FROM recipe_lines r JOIN inventory_items i ON i.id=r.inventory_item_id WHERE r.menu_item_id=?', it.menu_item_id)) {
            addMovement({ item_id: l.inventory_item_id, type: 'sale', qty: -round3(portion(l) * it.qty), order_id: id, unit_cost: l.unit_cost, by: user?.name });
          }
          for (const a of parseJson(it.addons, [])) {
            if (!a.inventory_item_id || !(a.qty_per_use > 0)) continue;
            const inv = q.get('SELECT unit_cost FROM inventory_items WHERE id=?', a.inventory_item_id); if (!inv) continue;
            addMovement({ item_id: a.inventory_item_id, type: 'sale', qty: -round3(a.qty_per_use * a.qty * it.qty), order_id: id, unit_cost: inv.unit_cost, by: user?.name, note: `Add-on: ${a.name}` });
          }
        }
        q.run('UPDATE orders SET deducted=1 WHERE id=?', id);
      }
    } else if (to === 'ready') q.run('UPDATE orders SET status=?, ready_at=? WHERE id=?', to, t, id);
    else if (to === 'completed') q.run('UPDATE orders SET status=?, completed_at=? WHERE id=?', to, t, id);
    else if (to === 'cancelled') {
      if (!str(reason, 200) && user?.role) throw bad('Say why the order is being cancelled');
      q.run('UPDATE orders SET status=?, cancel_reason=? WHERE id=?', to, str(reason, 200), id);
      if (o.deducted) {
        for (const m of q.all("SELECT * FROM stock_movements WHERE order_id=? AND type='sale'", id)) addMovement({ item_id: m.inventory_item_id, type: 'reversal', qty: -m.qty, order_id: id, unit_cost: m.unit_cost, by: user?.name, note: 'Order cancelled' });
        q.run('UPDATE orders SET deducted=0 WHERE id=?', id);
      }
    } else q.run('UPDATE orders SET status=? WHERE id=?', to, id);
  });
  const order = orderFull(id);
  emit(`order.${to}`, { id, order_no: order.order_no, channel: order.channel, total: order.total, by: user?.name });
  if (to === 'accepted') for (const fn of acceptedHooks) { try { fn(id); } catch (e) { console.error('accepted hook failed:', e.message); } }
  if (to === 'accepted' || to === 'cancelled') checkStockEvents();
  notifyAggregator(order, to);
  return order;
}
const round3 = n => Math.round(n * 1000) / 1000;

function notifyAggregator(order, to) {
  if (!['swiggy', 'zomato', 'website'].includes(order.channel) || !order.channel_order_id) return;
  const cs = q.get('SELECT * FROM channel_settings WHERE channel=?', order.channel);
  if (!cs || cs.integration_provider === 'none') return;
  const action = { accepted: 'accept', ready: 'mark_ready', cancelled: 'reject', completed: 'complete' }[to];
  if (action) outbound(cs.integration_provider, action, { channel: order.channel, store_id: cs.provider_store_id, channel_order_id: order.channel_order_id, order_no: order.order_no, reason: order.cancel_reason }).catch(() => {});
}

// ───────────────────────── GST ─────────────────────────
// Per outlet. mode: regular (GST by each dish's rate), composition (no tax collected on bills), none (not registered).
// inclusive: menu prices already contain GST, so tax is taken out of the price instead of added on top.
export const GST_DEFAULTS = { mode: 'regular', inclusive: false, default_rate: 5, packaging_rate: 0, charge_rate: 0, platform_collects: false };
export const GST_MODES = ['regular', 'composition', 'none'];
export const gstCfg = () => ({ ...GST_DEFAULTS, ...getSetting('gst', {}) });
export function saveGstCfg(x) {
  const cur = gstCfg(), rate = (v, name) => { const n = Number(v); if (!(n >= 0 && n <= 40)) throw bad(`${name} must be between 0 and 40`); return Math.round(n * 100) / 100; };
  const out = {
    mode: x.mode === undefined ? cur.mode : (GST_MODES.includes(x.mode) ? x.mode : (() => { throw bad('Pick regular, composition or not registered'); })()),
    inclusive: x.inclusive === undefined ? cur.inclusive : !!x.inclusive,
    default_rate: x.default_rate === undefined ? cur.default_rate : rate(x.default_rate, 'Default GST rate'),
    packaging_rate: x.packaging_rate === undefined ? cur.packaging_rate : rate(x.packaging_rate, 'GST on packaging'),
    charge_rate: x.charge_rate === undefined ? cur.charge_rate : rate(x.charge_rate, 'GST on delivery and service charges'),
    platform_collects: x.platform_collects === undefined ? cur.platform_collects : !!x.platform_collects,
  };
  setSetting('gst', out); return out;
}
/** Tax for one order. lines: {unit_price, qty, gst_rate}. Returns the tax, the per-rate breakup, and what the customer pays. */
export function computeTax(lines, discount, packaging, c, extra = 0) {
  const subtotal = lines.reduce((s, l) => s + l.unit_price * l.qty, 0), k = subtotal > 0 ? 1 - Math.min(discount, subtotal) / subtotal : 1, by = new Map();
  const add = (rate, gross) => {
    if (!(gross > 0)) return;
    const r = c.mode === 'regular' ? Number(rate) || 0 : 0, tax = c.inclusive ? gross * r / (100 + r) : gross * r / 100, g = by.get(r) || { rate: r, taxable: 0, tax: 0 };
    g.tax += tax; g.taxable += c.inclusive ? gross - tax : gross; by.set(r, g);
  };
  for (const l of lines) add(l.gst_rate, l.unit_price * l.qty * k);
  add(c.packaging_rate, packaging); add(c.charge_rate, extra);
  const breakup = [...by.values()].sort((a, b) => a.rate - b.rate).map(g => ({ rate: g.rate, taxable: round2(g.taxable), tax: round2(g.tax) }));
  const tax = round2(breakup.reduce((s, g) => s + g.tax, 0));
  return { tax, breakup, total: round2(subtotal - discount + packaging + extra + (c.inclusive ? 0 : tax)) };
}
/** Sets every dish (or one category) to one GST rate. */
export function setMenuGst(rate, category) {
  const n = Number(rate); if (!(n >= 0 && n <= 40)) throw bad('GST rate must be between 0 and 40');
  const r = category ? q.run('UPDATE menu_items SET gst_rate=? WHERE category=?', n, category) : q.run('UPDATE menu_items SET gst_rate=?', n);
  emit('menu.changed', {}); return { updated: Number(r.changes) };
}

// ───────────────────────── Order types and charges ─────────────────────────
export const ORDER_TYPES = ['dine_in', 'takeaway', 'delivery'];
export const CANCEL_REASONS = ['Customer request', 'Customer did not pick up', 'Wrong or duplicate order', 'Item out of stock', 'Kitchen too busy', 'Delivery not possible', 'Payment problem', 'Other'];
export const CHARGE_DEFAULTS = { delivery_fee: 0, delivery_free_above: 0, service_pct: 0 };
export const chargesCfg = () => ({ ...CHARGE_DEFAULTS, ...getSetting('charges', {}) });
export function saveChargesCfg(x) {
  const n = (v, name, max) => { const k = Number(v ?? 0); if (!(k >= 0 && k <= max)) throw bad(`${name} is not valid`); return Math.round(k * 100) / 100; }, cur = chargesCfg();
  const out = { delivery_fee: x.delivery_fee === undefined ? cur.delivery_fee : n(x.delivery_fee, 'Delivery charge', 2000), delivery_free_above: x.delivery_free_above === undefined ? cur.delivery_free_above : n(x.delivery_free_above, 'Free delivery above', 100000), service_pct: x.service_pct === undefined ? cur.service_pct : n(x.service_pct, 'Service charge', 30) };
  setSetting('charges', out); return out;
}
/** Payments as a list of { mode, amount }. Orders made before split payments count as paid in full by their one mode. */
export const paymentsOf = (o) => { const l = parseJson(o.payments, null); return Array.isArray(l) && l.length ? l : [{ mode: o.payment_mode || 'UPI', amount: o.total }]; };
function cleanPayments(list, total) {
  if (!Array.isArray(list) || !list.length) return null;
  const out = list.map(p => ({ mode: str(p.mode, 30), amount: round2(Number(p.amount)) })).filter(p => p.mode && p.amount > 0);
  if (!out.length) return null;
  if (out.some(p => !PAYMENT_MODES.includes(p.mode))) throw bad('Pick a valid payment mode');
  const sum = round2(out.reduce((s, p) => s + p.amount, 0));
  if (sum > total + 0.01) throw bad(`Payments add up to more than the bill (${sum} of ${total})`);
  return out;
}
export function setPayments(id, list, user) {
  const o = q.get('SELECT * FROM orders WHERE id=?', id); if (!o) throw new HttpError(404, 'Order not found');
  const out = cleanPayments(list, o.total); if (!out) throw bad('Add at least one payment');
  const sum = round2(out.reduce((s, p) => s + p.amount, 0));
  q.run('UPDATE orders SET payments=?, payment_mode=? WHERE id=?', JSON.stringify(out), out.length > 1 ? 'Split' : out[0].mode, id);
  emit('order.updated', { id, by: user?.name, paid: sum }); return orderFull(id);
}

// What the printed bill says and shows. Shared by every device, so all counters print the same bill.
export const BILL_DEFAULTS = {
  tagline: '', phone: '', email: '', website: '', social: '', header_note: '', footer: 'Thank you! Order again soon.', footer_note: '',
  show: { channel: true, customer: true, gstin: true, fssai: true, unique_items: true, total_qty: true, tax_split: true, notes: true, paid_by: true },
  upi: { enabled: false, vpa: '', payee: '', when: 'upi', note: 'Bill {bill_no}', caption: 'Scan to pay with any UPI app' },
};
const VPA = /^[A-Za-z0-9._-]{2,64}@[A-Za-z][A-Za-z0-9.-]{1,30}$/;
export const billCfg = () => { const s = getSetting('bill', {}); return { ...BILL_DEFAULTS, ...s, show: { ...BILL_DEFAULTS.show, ...(s.show || {}) }, upi: { ...BILL_DEFAULTS.upi, ...(s.upi || {}) } }; };
export function saveBillCfg(x) {
  const t = (v, n) => String(v ?? '').replace(/[\u0000-\u0008\u000b-\u001f]/g, '').slice(0, n), cur = billCfg(), u = x.upi || {};
  const out = { tagline: t(x.tagline, 80), phone: t(x.phone, 40), email: t(x.email, 80), website: t(x.website, 80), social: t(x.social, 80), header_note: t(x.header_note, 200), footer: t(x.footer, 200), footer_note: t(x.footer_note, 300), show: { ...cur.show }, upi: { ...cur.upi } };
  for (const k of Object.keys(BILL_DEFAULTS.show)) if (x.show && k in x.show) out.show[k] = !!x.show[k];
  if (x.upi) {
    const vpa = t(u.vpa, 80).trim();
    if (u.enabled && !VPA.test(vpa)) throw bad('Enter a valid UPI ID such as name@bank');
    if (vpa && !VPA.test(vpa)) throw bad('That UPI ID does not look right. It should look like name@bank');
    out.upi = { enabled: !!u.enabled, vpa, payee: t(u.payee, 60).trim(), when: u.when === 'always' ? 'always' : 'upi', note: t(u.note ?? 'Bill {bill_no}', 40), caption: t(u.caption, 60) };
  }
  setSetting('bill', out); return out;
}

/** Per-rate tax split for one stored order, rebuilt from what the order itself remembers. The last rate absorbs any paisa of rounding. */
function taxBreakup(o) {
  const mode = o.tax_mode || 'regular', inclusive = !!o.tax_inclusive;
  const t = computeTax(o.items.map(i => ({ unit_price: i.unit_price, qty: i.qty, gst_rate: i.gst_rate })), o.discount, o.packaging_fee, { mode, inclusive, packaging_rate: o.pack_gst_rate || 0, charge_rate: o.charge_gst_rate ?? 0 }, (o.delivery_fee || 0) + (o.service_charge || 0));
  return t;
}
export function billFor(id) {
  const o = orderFull(id);
  if (!o) throw new HttpError(404, 'Order not found');
  const lines = o.items.map(i => ({ name: i.name, qty: i.qty, rate: i.unit_price, amount: round2(i.qty * i.unit_price), gst_rate: i.gst_rate, modifiers: i.modifiers }));
  const promoPart = round2(Math.max(0, o.discount - (o.manual_discount || 0)));
  const biz = getSetting('business', { name: 'Cloud Kitchen', gstin: '', address: '', fssai: '' }), mode = o.tax_mode || 'regular', inclusive = !!o.tax_inclusive;
  // Per-rate breakup, rebuilt from what the order stored so an old bill never changes when GST settings do. The last rate absorbs any paisa of rounding.
  const t = taxBreakup(o);
  const breakup = t.breakup.map(g => ({ ...g }));
  const diff = round2(o.tax - t.tax); if (breakup.length && Math.abs(diff) <= 0.05) breakup[breakup.length - 1].tax = round2(breakup[breakup.length - 1].tax + diff);
  const taxable = round2(breakup.reduce((s, g) => s + g.taxable, 0) || (o.subtotal - o.discount));
  const title = mode === 'regular' ? (biz.gstin ? 'TAX INVOICE' : 'BILL') : mode === 'composition' ? 'BILL OF SUPPLY' : 'BILL';
  const note = mode === 'composition' ? 'Composition taxable person, not eligible to collect tax on supplies.' : '';
  const outlet = outletById(outletId());
  return {
    bill_no: `${outlet?.code || 'B'}${o.order_no}`, order_no: o.order_no, date: o.placed_at, channel: o.channel, customer: o.customer_name || null, phone: o.customer_phone || null, address: o.address || null, notes: o.notes || null, lines,
    unique_items: new Set(lines.map(l => l.name)).size, total_qty: round2(lines.reduce((s, l) => s + l.qty, 0)),
    promo_code: o.promo_code || null, promo_discount: o.promo_code ? promoPart : 0, manual_discount: o.manual_discount || 0, discount_type: o.discount_type || null, discount_value: o.discount_value ?? null, discount_reason: o.discount_reason || null,
    subtotal: o.subtotal, discount: o.discount, taxable, cgst: round2(o.tax / 2), sgst: round2(o.tax / 2), tax: o.tax, packaging_fee: o.packaging_fee, total: o.total, payment_mode: o.payment_mode,
    order_type: o.order_type || null, table_no: o.table_no || null, delivery_fee: o.delivery_fee || 0, service_charge: o.service_charge || 0,
    payments: paymentsOf(o), paid: round2(paymentsOf(o).reduce((x, p) => x + p.amount, 0)), balance: round2(Math.max(0, o.total - paymentsOf(o).reduce((x, p) => x + p.amount, 0))),
    gst: { mode, inclusive, title, note, breakup: breakup.map(g => ({ rate: g.rate, taxable: g.taxable, cgst: round2(g.tax / 2), sgst: round2(g.tax / 2) })) },
    business: biz, outlet: outlet ? { id: outlet.id, name: outlet.name } : null, layout: billCfg(),
  };
}

// ───────────────────────── Expenses ─────────────────────────
export function addExpense(b, user, extra = {}) {
  const category = String(b.category || '');
  if (!EXPENSE_CATEGORIES.includes(category)) throw bad('Pick a valid category');
  const amount = num(b.amount, 'Amount', { required: true, min: 0.01, max: 1e8 });
  const date = /^\d{4}-\d{2}-\d{2}$/.test(b.date || '') ? b.date : ymd();
  const id = Number(q.run('INSERT INTO expenses(date,category,amount,gst_amount,vendor,payment_mode,receipt,source,recurring_id,notes,entered_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
    date, category, round2(amount), num(b.gst_amount, 'GST'), str(b.vendor, 80), str(b.payment_mode, 30), str(b.receipt, 200), extra.source || 'manual', extra.recurring_id || null, str(b.notes, 300), user?.name, now()).lastInsertRowid);
  emit('expense.added', { id, category, amount: round2(amount), date });
  return q.get('SELECT * FROM expenses WHERE id=?', id);
}
export function deleteExpense(id) {
  const e = q.get('SELECT * FROM expenses WHERE id=?', id);
  if (!e) throw new HttpError(404, 'Expense not found');
  if (e.movement_id) throw bad('This expense came from a stock purchase. Adjust the stock instead.');
  q.run('DELETE FROM expenses WHERE id=?', id);
  emit('expense.deleted', { id });
}

const rollDate = (r) => {
  const d = parseYmd(r.next_due);
  if (r.frequency === 'daily') d.setDate(d.getDate() + 1);
  else if (r.frequency === 'weekly') d.setDate(d.getDate() + 7);
  else if (r.frequency === 'yearly') d.setFullYear(d.getFullYear() + 1);
  else d.setMonth(d.getMonth() + 1);
  return ymd(d);
};
export function postRecurring(rid, user, source = 'recurring') {
  const r = q.get('SELECT * FROM recurring_expenses WHERE id=?', rid);
  if (!r) throw new HttpError(404, 'Recurring cost not found');
  tx(() => {
    addExpense({ category: r.category, amount: r.amount, date: r.next_due, notes: r.name }, user, { source, recurring_id: r.id });
    q.run('UPDATE recurring_expenses SET next_due=? WHERE id=?', rollDate(r), r.id);
  });
}
export function skipRecurring(rid) {
  const r = q.get('SELECT * FROM recurring_expenses WHERE id=?', rid);
  if (!r) throw new HttpError(404, 'Recurring cost not found');
  q.run('UPDATE recurring_expenses SET next_due=? WHERE id=?', rollDate(r), r.id);
  emit('recurring.skipped', { id: rid });
}
/** Posts every auto_post cost that is due (catching up on missed days). Others stay as reminders. */
export function runRecurring() {
  let posted = 0;
  for (const r of q.all("SELECT * FROM recurring_expenses WHERE active=1 AND auto_post=1 AND next_due<=? ORDER BY next_due", ymd())) {
    let guard = 0, cur = r;
    while (cur && cur.next_due <= ymd() && guard++ < 62) { postRecurring(r.id, null); posted++; cur = q.get('SELECT * FROM recurring_expenses WHERE id=?', r.id); }
  }
  const reminders = q.get("SELECT COUNT(*) n FROM recurring_expenses WHERE active=1 AND auto_post=0 AND next_due<=?", ymd()).n;
  if (reminders) emit('recurring.due', { count: reminders });
  return { posted, reminders };
}

export function budgetStatus() {
  const budgets = getSetting('budgets', {});
  const month = ymd().slice(0, 7);
  const spent = Object.fromEntries(q.all("SELECT category, SUM(amount) v FROM expenses WHERE substr(date,1,7)=? GROUP BY category", month).map(r => [r.category, round2(r.v)]));
  return Object.entries(budgets).map(([category, limit]) => ({ category, limit, spent: spent[category] || 0, pct: limit > 0 ? Math.round((spent[category] || 0) / limit * 100) : 0 }));
}

// ───────────────────────── Profit ─────────────────────────
export function profit(from, to) {
  const a = dayStartISO(from), b = dayStartISO(ymd(addDays(parseYmd(to), 1)));
  const o = q.get(`SELECT COUNT(*) orders, COALESCE(SUM(subtotal-discount+packaging_fee+delivery_fee+service_charge-CASE WHEN tax_inclusive=1 THEN tax ELSE 0 END),0) sales, COALESCE(SUM(commission),0) commission, COALESCE(SUM(food_cost),0) food_cost, COALESCE(SUM(total),0) billed
    FROM orders WHERE status='completed' AND completed_at>=? AND completed_at<?`, a, b);
  const opex = q.get("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE category!='Ingredients' AND date>=? AND date<=?", from, to).v;
  const ingredients = q.get("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE category='Ingredients' AND date>=? AND date<=?", from, to).v;
  const wastage = q.get("SELECT COALESCE(-SUM(qty*unit_cost),0) v FROM stock_movements WHERE type='wastage' AND moved_at>=? AND moved_at<?", a, b).v;
  const r = { orders: o.orders, sales: round2(o.sales), commission: round2(o.commission), food_cost: round2(o.food_cost), wastage: round2(wastage), opex: round2(opex), ingredients_purchased: round2(ingredients), billed: round2(o.billed) };
  r.net = round2(r.sales - r.commission - r.food_cost - r.wastage - r.opex);
  r.margin_pct = r.sales > 0 ? round2(r.net / r.sales * 100) : null;
  return r;
}
export function liveProfit() {
  const t = ymd();
  const lw = ymd(addDays(new Date(), -7));
  return { today: profit(t, t), same_day_last_week: profit(lw, lw), month: profit(t.slice(0, 7) + '-01', t), as_of: now() };
}

// ───────────────────────── Menu import / groups ─────────────────────────
const RANK = { portion: 0, half: 1, full: 2 };
const rank = (v) => RANK[String(v || '').toLowerCase().split(/\s/)[0]] ?? 9;

/** Rows look like the Menu Master sheet: category, subcategory, catalogue_id, name, variant_id, variant_name, price, description, image_url, in_stock. Matches existing dishes by variant id, then by catalogue id + size, then by name + size. */
export function importMenu(rows) {
  if (!Array.isArray(rows) || !rows.length) throw bad('No rows to import');
  if (rows.length > 2000) throw bad('Import up to 2000 rows at a time');
  const res = { created: 0, updated: 0, errors: [] };
  const sorted = rows.map((r, i) => ({ r, i })).sort((a, b) => (String(a.r.catalogue_id || a.r.name).localeCompare(String(b.r.catalogue_id || b.r.name))) || rank(a.r.variant_name) - rank(b.r.variant_name) || Number(a.r.price) - Number(b.r.price) || a.i - b.i);
  const orderOf = new Map(sorted.map((x, k) => [x.i, k]));
  tx(() => {
    rows.forEach((r, i) => {
      try {
        const name = str(r.name, 80); if (!name) throw bad('Item name is missing');
        const price = Number(r.price); if (!Number.isFinite(price) || price < 0) throw bad('Price is missing or not a number');
        const vn = str(r.variant_name, 80) && String(r.variant_name).trim().toLowerCase() !== name.toLowerCase() ? str(r.variant_name, 80) : '';
        const cat = str(r.category, 40) || 'Other';
        const found = (r.variant_id && q.get('SELECT id FROM menu_items WHERE variant_id=?', String(r.variant_id)))
          || (r.catalogue_id && q.get('SELECT id FROM menu_items WHERE catalogue_id=? AND COALESCE(variant_name,\'\')=?', String(r.catalogue_id), vn))
          || q.get('SELECT id FROM menu_items WHERE name=? COLLATE NOCASE AND COALESCE(variant_name,\'\')=? AND category=? COLLATE NOCASE', name, vn, cat);
        const cur = found ? menuList().find((m) => m.id === found.id) : null;
        const ext = { ...(cur?.external_ids || {}) }; if (r.variant_id) ext.zomato = String(r.variant_id);
        const inStock = r.in_stock === undefined ? true : !(r.in_stock === false || /^(no|n|false|0)$/i.test(String(r.in_stock).trim()));
        const body = { name, category: cat, subcategory: r.subcategory, description: r.description, image_url: r.image_url, catalogue_id: r.catalogue_id, variant_name: vn, variant_id: r.variant_id, sort_order: orderOf.get(i),
          prices: { ...(cur?.prices || {}), default: price }, gst_rate: cur?.gst_rate ?? gstCfg().default_rate, external_ids: ext, off: !inStock,
          ...Object.fromEntries(COST_FIELDS.map((f) => [f, r[f] !== undefined && r[f] !== null && String(r[f]).trim() !== '' ? r[f] : cur?.[f]])) };
        if (found) { saveMenuItem(found.id, body); res.updated++; } else { saveMenuItem(null, body); res.created++; }
      } catch (e) { res.errors.push({ row: i + 1, name: String(r?.name || ''), error: e.message }); }
    });
  });
  return res;
}

/** Save one dish with all its sizes in one step. shared: name, category, subcategory, description, image_url, gst_rate, catalogue_id. */
export function saveMenuGroup(key, b) {
  const sh = b.shared || {}; const vars = Array.isArray(b.variants) ? b.variants : [];
  if (!str(sh.name, 80)) throw bad('Dish name is required');
  if (!vars.length) throw bad('Add at least one size or price');
  return tx(() => {
    const catId = (key && !key.startsWith('item-') ? key : sh.catalogue_id) || `L${Date.now()}`;
    const existing = key ? menuList().filter((m) => m.group_key === key) : [];
    if (key && !existing.length) throw new HttpError(404, 'Dish not found');
    const keep = new Set();
    vars.forEach((v, i) => {
      const cur = v.id ? existing.find((m) => m.id === Number(v.id)) : null;
      if (v.id && !cur) throw bad('A size does not belong to this dish');
      const ext = { ...(cur?.external_ids || {}) }; if (v.variant_id) ext.zomato = String(v.variant_id); else if (cur && !v.variant_id) delete ext.zomato;
      const saved = saveMenuItem(cur ? cur.id : null, { ...(cur || {}), name: sh.name, category: sh.category, subcategory: sh.subcategory, description: sh.description, image_url: sh.image_url, gst_rate: sh.gst_rate ?? cur?.gst_rate ?? gstCfg().default_rate,
        catalogue_id: catId, variant_name: vars.length > 1 || v.variant_name ? v.variant_name : '', variant_id: v.variant_id, sort_order: i, prices: v.prices || cur?.prices, external_ids: ext, off: !!v.off, recipe: v.recipe,
        ...Object.fromEntries(COST_FIELDS.map((f) => [f, f in v ? v[f] : cur?.[f]])) });
      keep.add(saved.id);
      // Add-on groups follow the dish: every size carries the same ones. A new size copies what its siblings have.
      const want = Array.isArray(sh.addon_group_ids) ? sh.addon_group_ids : (!cur && existing[0] ? existing[0].addon_group_ids : null);
      if (want) { q.run('DELETE FROM menu_addon_groups WHERE menu_item_id=?', saved.id); for (const gid of want) if (q.get('SELECT id FROM addon_groups WHERE id=?', Number(gid))) q.run('INSERT OR IGNORE INTO menu_addon_groups(menu_item_id,group_id) VALUES(?,?)', saved.id, Number(gid)); }
    });
    for (const m of existing) if (!keep.has(m.id)) {
      if (q.get('SELECT 1 x FROM order_items WHERE menu_item_id=? LIMIT 1', m.id)) throw bad(`${m.display_name} has order history. Switch it off instead of removing it.`);
      q.run('DELETE FROM menu_items WHERE id=?', m.id);
    }
    emit('menu.updated', { key });
    return menuList().filter((m) => keep.has(m.id));
  });
}


// ───────────────────────── Categories: stop and restart a whole category ─────────────────────────
/** {categoryName: {since, until|null, by}}. Entries past their "until" time are dropped when read. */
export function categoriesOff() {
  const s = getSetting('categories_off', {}); let changed = false; const t = Date.now();
  for (const [k, v] of Object.entries(s)) if (v.until && new Date(v.until).getTime() <= t) { delete s[k]; changed = true; (globalThis.__resumed ||= []).push(k); }
  if (changed) setSetting('categories_off', s);
  return s;
}
export function categoryList() {
  const off = categoriesOff(); const by = new Map();
  for (const m of q.all('SELECT category, off FROM menu_items')) { const c = m.category || 'Other'; const e = by.get(c) || { name: c, items: 0, sold_out: 0 }; e.items++; if (m.off) e.sold_out++; by.set(c, e); }
  return [...by.values()].sort((a, b) => a.name.localeCompare(b.name)).map(e => ({ ...e, off: !!off[e.name], since: off[e.name]?.since || null, until: off[e.name]?.until || null, by: off[e.name]?.by || null }));
}
export function setCategoryOff(name, off, { until = null } = {}, user) {
  const cat = categoryList().find(c => c.name === name); if (!cat) throw new HttpError(404, 'Category not found');
  let untilIso = null;
  if (off && until) { const t = new Date(until); if (Number.isNaN(t.getTime()) || t.getTime() <= Date.now()) throw bad('Pick a restart time in the future'); untilIso = t.toISOString(); }
  const s = getSetting('categories_off', {});
  if (off) s[name] = { since: now(), until: untilIso, by: user?.name || null }; else delete s[name];
  setSetting('categories_off', s);
  emit('menu.updated', { category: name, off: !!off });
  syncCategoryStock(name, !off);
  return categoryList().find(c => c.name === name);
}
/** Tell Swiggy/Zomato (through the aggregator adapter) which dishes of a category can be sold. Dishes switched off one by one stay off. */
export function syncCategoryStock(name, inStock) {
  const chans = q.all("SELECT * FROM channel_settings WHERE channel IN ('swiggy','zomato','website') AND integration_provider!='none'"); if (!chans.length) return;
  for (const m of menuList().filter(x => (x.category || 'Other') === name))
    for (const ch of chans) outbound(ch.integration_provider, 'set_stock', { channel: ch.channel, store_id: ch.provider_store_id, item_id: m.external_ids[ch.channel] || null, name: m.display_name, in_stock: inStock && !m.off }).catch(() => {});
}
/** Called by the scheduler: categories whose restart time has passed come back on. */
export function resumeCategories() {
  categoriesOff(); const done = globalThis.__resumed || []; globalThis.__resumed = [];
  for (const name of done) { emit('menu.updated', { category: name, off: false, auto: true }); emit('notice', { level: 'info', text: `${name} is back on the menu.` }); syncCategoryStock(name, true); }
  return done;
}


// ───────────────────────── Menu engineering ─────────────────────────
const nrm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
export const DEFAULT_TARGETS = { monthly_operational_cost: 150000, avg_ticket: 280, cost_share_pct: 40, days: 26 };
const ADVICE = {
  Star: 'Sells well and earns well. Keep it prominent, protect the quality and the price.',
  Plowhorse: 'Sells well but earns little. Try a small price rise, a trimmed portion or cheaper cost, or pair it with a high-margin side.',
  Puzzle: 'Earns well but few order it. Move it up the menu, improve the photo and name, or promote it.',
  Dog: 'Sells little and earns little. Rework it, replace it, or drop it unless it anchors a combo.',
};
export function saveSalesBaseline(rows) {
  if (!Array.isArray(rows) || !rows.length) throw bad('No rows to import');
  const m = new Map();
  for (const r of rows.slice(0, 5000)) { const name = str(r.name, 80); if (!name) continue; const e = m.get(name) || { name, qty: 0, amount: 0 }; e.qty += Math.max(0, Number(r.qty) || 0); e.amount += Math.max(0, Number(r.amount) || 0); m.set(name, e); }
  if (!m.size) throw bad('No valid rows found. Use columns Name, Qty, Amount.');
  setSetting('sales_baseline', [...m.values()].map(e => ({ ...e, amount: round2(e.amount) })));
  return { dishes: m.size, units: [...m.values()].reduce((s, e) => s + e.qty, 0) };
}
/** Stars, Plowhorses, Puzzles and Dogs. Popularity = share of units sold against 70% of an even share; margin = rupees left after food cost against the average margin per unit sold. */
export function menuEngineering({ days = 30, source = 'auto', category = '' } = {}) {
  days = Math.min(Math.max(Number(days) || 30, 1), 365);
  const menu = menuList();
  const from = sinceISO(days);
  const sold = new Map(q.all(`SELECT oi.menu_item_id id, SUM(oi.qty) qty, SUM(oi.qty*oi.unit_price) rev FROM order_items oi JOIN orders o ON o.id=oi.order_id
    WHERE o.status!='cancelled' AND o.placed_at>=? AND oi.menu_item_id IS NOT NULL GROUP BY oi.menu_item_id`, from).map(r => [r.id, r]));
  const orderUnits = [...sold.values()].reduce((s, r) => s + r.qty, 0);
  const baseline = getSetting('sales_baseline', []);
  const src = source === 'orders' || source === 'sheet' ? source : (orderUnits >= 100 || !baseline.length ? 'orders' : 'sheet');
  const groups = new Map();
  for (const m of menu) { if (!groups.has(m.group_key)) groups.set(m.group_key, { key: m.group_key, name: m.name, category: m.category || 'Other', variants: [] }); groups.get(m.group_key).variants.push(m); }
  const list = [...groups.values()];
  if (src === 'sheet') {
    const byName = new Map();
    for (const g of list) { const k = nrm(g.name); if (!byName.has(k)) byName.set(k, []); byName.get(k).push(g); }
    for (const g of list) { g.units = 0; g.revenue = 0; }
    for (const b of baseline) { const gs = (byName.get(nrm(b.name)) || []).sort((x, y) => (x.variants.every(v => v.off) ? 1 : 0) - (y.variants.every(v => v.off) ? 1 : 0)); if (gs[0]) { gs[0].units += b.qty; gs[0].revenue += b.amount; } }
  } else for (const g of list) { g.units = g.variants.reduce((s, v) => s + (sold.get(v.id)?.qty || 0), 0); g.revenue = round2(g.variants.reduce((s, v) => s + (sold.get(v.id)?.rev || 0), 0)); }
  for (const g of list) {
    const w = (v) => (src === 'orders' && g.units > 0 ? (sold.get(v.id)?.qty || 0) : 1), tw = g.variants.reduce((s, v) => s + w(v), 0) || 1;
    const avg = (f) => round2(g.variants.reduce((s, v) => s + f(v) * w(v), 0) / tw);
    g.costed = g.variants.every(v => v.has_cost);
    g.price = avg(v => Number(v.prices.website ?? v.prices.default ?? 0));
    g.food_cost = g.costed ? avg(v => v.food_cost) : null; g.op_cost = avg(v => v.op_cost || 0); g.pack_cost = avg(v => v.pack_cost || 0);
    g.cm = g.costed ? round2(g.price - g.food_cost) : null; g.cm_pct = g.costed && g.price > 0 ? round2(g.cm / g.price * 100) : null;
    g.full_margin = g.costed ? round2(g.price - g.food_cost - g.op_cost - g.pack_cost) : null;
    g.sizes = g.variants.length; g.on_sale = g.variants.some(v => !v.off);
  }
  const scope = list.filter(g => !category || g.category === category);
  const costed = scope.filter(g => g.costed), units = costed.reduce((s, g) => s + g.units, 0);
  const popCut = costed.length ? 0.7 / costed.length : 0; const avgCm = units > 0 ? costed.reduce((s, g) => s + g.cm * g.units, 0) / units : 0;
  for (const g of scope) {
    g.mix_pct = units > 0 ? round2(g.units / units * 100) : 0;
    if (!g.costed) g.class = 'Needs cost';
    else if (units <= 0) g.class = 'No sales';
    else { const hiPop = g.units / units >= popCut, hiCm = g.cm >= avgCm; g.class = hiPop && hiCm ? 'Star' : hiPop ? 'Plowhorse' : hiCm ? 'Puzzle' : 'Dog'; }
    g.advice = ADVICE[g.class] || (g.class === 'Needs cost' ? 'Add the ingredient cost or a recipe so this dish can be rated.' : 'No sales in this period.');
    delete g.variants;
  }
  const order = { Star: 0, Plowhorse: 1, Puzzle: 2, Dog: 3, 'No sales': 4, 'Needs cost': 5 };
  scope.sort((a, b) => order[a.class] - order[b.class] || b.units - a.units || a.name.localeCompare(b.name));
  // Break-even targets against what the kitchen is actually doing.
  const t = { ...DEFAULT_TARGETS, ...getSetting('targets', {}) };
  const reqSales = t.cost_share_pct > 0 ? t.monthly_operational_cost / (t.cost_share_pct / 100) : 0;
  const act = q.get(`SELECT COUNT(*) n, COALESCE(SUM(subtotal-discount+packaging_fee+delivery_fee+service_charge-CASE WHEN tax_inclusive=1 THEN tax ELSE 0 END),0) sales FROM orders WHERE status NOT IN ('cancelled') AND placed_at>=?`, sinceISO(30));
  return {
    source: src, days, orders_units: orderUnits, baseline_units: baseline.reduce((s, b) => s + b.qty, 0), has_baseline: baseline.length > 0,
    thresholds: { popularity_pct: round2(popCut * 100), avg_cm: round2(avgCm) }, counts: Object.fromEntries(Object.keys(order).map(k => [k, scope.filter(g => g.class === k).length])),
    categories: [...new Set(list.map(g => g.category))].sort(), items: scope,
    targets: { ...t, required_monthly_sales: round2(reqSales), required_per_day: round2(reqSales / (t.days || 26)), required_tickets_per_day: t.avg_ticket > 0 ? round2(reqSales / (t.days || 26) / t.avg_ticket) : null,
      actual_tickets_per_day: round2(act.n / 30), actual_avg_ticket: act.n ? round2(act.sales / act.n) : null, actual_sales_per_day: round2(act.sales / 30) },
  };
}

// ───────────────────────── Day close and sales reports ─────────────────────────
const CASH = 'Cash';
/** Everything a manager checks at closing: sales, tax, payments, cancellations, and the cash that should be in the drawer. */
export function dayReport(date) {
  const a = dayStartISO(date), b = dayStartISO(ymd(addDays(parseYmd(date), 1)));
  const done = q.all("SELECT id FROM orders WHERE status='completed' AND completed_at>=? AND completed_at<? ORDER BY id", a, b).map(r => orderFull(r.id));
  const cancelled = q.all("SELECT id FROM orders WHERE status='cancelled' AND placed_at>=? AND placed_at<? ORDER BY id", a, b).map(r => orderFull(r.id));
  const sum = (arr, f) => round2(arr.reduce((x, o) => x + f(o), 0));
  const group = (arr, key, f = () => 1) => { const m = new Map(); for (const o of arr) { const k = key(o); const g = m.get(k) || { orders: 0, sales: 0, billed: 0 }; g.orders += 1; g.sales += o.net_sales; g.billed += o.total; m.set(k, g); } return [...m].map(([k, g]) => ({ key: k, orders: g.orders, sales: round2(g.sales), billed: round2(g.billed) })).sort((x, y) => y.billed - x.billed); };
  const taxByRate = new Map();
  for (const o of done) for (const g of taxBreakup(o).breakup) { const t = taxByRate.get(g.rate) || { rate: g.rate, taxable: 0, tax: 0 }; t.taxable += g.taxable; t.tax += g.tax; taxByRate.set(g.rate, t); }
  const pay = new Map();
  for (const o of done) { const list = paymentsOf(o), sumP = list.reduce((x, p) => x + p.amount, 0), due = round2(o.total - sumP); for (const p of list) pay.set(p.mode, round2((pay.get(p.mode) || 0) + p.amount)); if (due > 0.005) pay.set('Not collected', round2((pay.get('Not collected') || 0) + due)); }
  const reasons = new Map(); for (const o of cancelled) reasons.set(o.cancel_reason || 'No reason', (reasons.get(o.cancel_reason || 'No reason') || 0) + 1);
  const cashExpenses = q.get("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date=? AND payment_mode=?", date, CASH).v;
  const cashSales = round2(pay.get(CASH) || 0), prev = q.get('SELECT counted_cash FROM day_closes WHERE date<? AND counted_cash IS NOT NULL ORDER BY date DESC LIMIT 1', date);
  return {
    date, orders: done.length, items_sold: sum(done, o => o.items.reduce((x, i) => x + i.qty, 0)),
    gross: sum(done, o => o.subtotal), discounts: sum(done, o => o.discount), packaging: sum(done, o => o.packaging_fee), delivery: sum(done, o => o.delivery_fee || 0), service: sum(done, o => o.service_charge || 0),
    tax: sum(done, o => o.tax), cgst: round2(sum(done, o => o.tax) / 2), sgst: round2(sum(done, o => o.tax) / 2), tax_by_rate: [...taxByRate.values()].sort((x, y) => x.rate - y.rate).map(t => ({ rate: t.rate, taxable: round2(t.taxable), tax: round2(t.tax) })),
    net_sales: sum(done, o => o.net_sales), billed: sum(done, o => o.total),
    by_channel: group(done, o => o.channel), by_type: group(done, o => o.order_type || 'unknown'),
    payments: [...pay].map(([mode, amount]) => ({ mode, amount })).sort((x, y) => y.amount - x.amount),
    cancelled: { orders: cancelled.length, value: sum(cancelled, o => o.total), reasons: [...reasons].map(([reason, n]) => ({ reason, orders: n })) },
    open_orders: q.get("SELECT COUNT(*) n FROM orders WHERE status IN ('new','accepted','preparing','ready') AND placed_at<?", b).n,
    cash: { sales: cashSales, expenses: round2(cashExpenses), suggested_opening: prev ? prev.counted_cash : 0 },
  };
}
export function closeDay(date, b, user) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) throw bad('Pick a date');
  const rep = dayReport(date), opening = b.opening_cash === undefined || b.opening_cash === '' ? 0 : num(b.opening_cash, 'Opening cash', { max: 1e7 });
  const expected = round2(opening + rep.cash.sales - rep.cash.expenses), counted = b.counted_cash === undefined || b.counted_cash === '' || b.counted_cash === null ? null : num(b.counted_cash, 'Counted cash', { max: 1e7 });
  q.run('INSERT OR REPLACE INTO day_closes(date,opening_cash,counted_cash,expected_cash,variance,notes,report,closed_by,closed_at) VALUES(?,?,?,?,?,?,?,?,?)', date, opening, counted, expected, counted === null ? null : round2(counted - expected), str(b.notes, 300), JSON.stringify(rep), user?.name, now());
  emit('day.closed', { date, variance: counted === null ? null : round2(counted - expected) });
  return getDayClose(date);
}
export function getDayClose(date) {
  const c = q.get('SELECT * FROM day_closes WHERE date=?', date); if (!c) return null;
  return { ...c, report: parseJson(c.report, null) };
}
export const dayCloses = (limit = 30) => q.all('SELECT date, opening_cash, counted_cash, expected_cash, variance, closed_by, closed_at FROM day_closes ORDER BY date DESC LIMIT ?', limit);
/** Rows for the sales exports. kind=items: one row per dish sold; kind=bills: one row per bill with tax. */
export function salesRows(from, to, kind) {
  const a = dayStartISO(from), b = dayStartISO(ymd(addDays(parseYmd(to), 1)));
  const ids = q.all("SELECT id FROM orders WHERE status='completed' AND completed_at>=? AND completed_at<? ORDER BY completed_at", a, b).map(r => r.id);
  if (kind === 'items') {
    const m = new Map();
    for (const id of ids) { const o = orderFull(id); for (const i of o.items) { const k = i.name; const r = m.get(k) || { item: k, qty: 0, amount: 0 }; r.qty += i.qty; r.amount += i.qty * i.unit_price; m.set(k, r); } }
    return { columns: ['Dish', 'Quantity', 'Amount before discount'], rows: [...m.values()].sort((x, y) => y.amount - x.amount).map(r => [r.item, round2(r.qty), round2(r.amount)]) };
  }
  const rows = ids.map(id => { const o = orderFull(id), bl = billFor(id), pm = paymentsOf(o).map(p => `${p.mode} ${p.amount}`).join(' + ');
    return [bl.bill_no, (o.completed_at || '').slice(0, 10), o.channel, o.order_type || '', o.customer_name || '', o.subtotal, o.discount, o.packaging_fee + (o.delivery_fee || 0) + (o.service_charge || 0), bl.taxable, round2(o.tax / 2), round2(o.tax / 2), o.total, pm, bl.business.gstin || '']; });
  return { columns: ['Bill', 'Date', 'Channel', 'Type', 'Customer', 'Subtotal', 'Discount', 'Charges', 'Taxable value', 'CGST', 'SGST', 'Total', 'Payments', 'GSTIN'], rows };
}
