// Social scheduler: composer, calendar, approval queue, auto-publish, engagement pulls, promo attribution.
// Publishing adapters: "mock" (default, simulated) and "meta" (Facebook Page + Instagram via Graph API; needs tokens).
import { q, now, tx, parseJson, round2, ymd, addDays } from './db.js';
import { emit } from './bus.js';
import { bad, HttpError } from './http.js';
import { logIntegration } from './integrations/aggregator.js';

export const PLATFORMS = ['Instagram', 'Facebook', 'Google Business', 'WhatsApp Status'];
const EDITABLE = ['draft', 'pending_approval', 'scheduled', 'failed'];

const hash = (n) => { let h = 2166136261 ^ n; for (let i = 0; i < 4; i++) { h = Math.imul(h ^ (h >>> 13), 16777619); } return h >>> 0; };
const rng = (seed) => () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

const adapters = {
  mock: {
    simulated: true,
    async publish(post, platform) { return { id: `sim_${post.id}_${platform.replace(/\W/g, '').toLowerCase()}` }; },
    metrics(post) {
      const r = rng(hash(post.id));
      const h = Math.max(0.2, (Date.now() - new Date(post.published_at).getTime()) / 36e5);
      const reach = Math.round((300 + r() * 900) * (1 - Math.exp(-h / 10)));
      const eng = 0.03 + r() * 0.07;
      return { reach, impressions: Math.round(reach * (1.2 + r() * 0.4)), likes: Math.round(reach * eng * 0.8), comments: Math.round(reach * eng * 0.1), shares: Math.round(reach * eng * 0.1), clicks: Math.round(reach * 0.02 * (1 + r() * 2)) };
    },
  },
  // Not exercised against live credentials in this build: verify with a test page before relying on it.
  meta: {
    simulated: false,
    async publish(post, platform) {
      const v = 'v21.0', base = `https://graph.facebook.com/${v}`;
      const media = post.media && post.media.startsWith('/') ? (process.env.PUBLIC_BASE_URL || '') + post.media : post.media;
      const post_ = async (url, params) => {
        const r = await fetch(url, { method: 'POST', signal: AbortSignal.timeout(15000), headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(params) });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j.error?.message || `Graph API ${r.status}`);
        return j;
      };
      if (platform === 'Facebook') {
        if (!process.env.META_PAGE_ID || !process.env.META_PAGE_TOKEN) throw new Error('META_PAGE_ID / META_PAGE_TOKEN not set');
        const j = media ? await post_(`${base}/${process.env.META_PAGE_ID}/photos`, { url: media, caption: post.caption, access_token: process.env.META_PAGE_TOKEN })
                        : await post_(`${base}/${process.env.META_PAGE_ID}/feed`, { message: post.caption, access_token: process.env.META_PAGE_TOKEN });
        return { id: j.post_id || j.id };
      }
      if (platform === 'Instagram') {
        if (!process.env.META_IG_USER_ID || !process.env.META_PAGE_TOKEN) throw new Error('META_IG_USER_ID / META_PAGE_TOKEN not set');
        if (!media || !/^https?:/.test(media)) throw new Error('Instagram needs a public image URL (set PUBLIC_BASE_URL)');
        const c = await post_(`${base}/${process.env.META_IG_USER_ID}/media`, { image_url: media, caption: post.caption, access_token: process.env.META_PAGE_TOKEN });
        const p = await post_(`${base}/${process.env.META_IG_USER_ID}/media_publish`, { creation_id: c.id, access_token: process.env.META_PAGE_TOKEN });
        return { id: p.id };
      }
      throw new Error(`${platform} is not connected for live publishing`);
    },
    metrics() { return null; },
  },
};
const adapter = () => adapters[process.env.SOCIAL_ADAPTER === 'meta' ? 'meta' : 'mock'];
export const adapterName = () => (process.env.SOCIAL_ADAPTER === 'meta' ? 'meta' : 'mock');

const shape = (p) => ({ ...p, platforms: parseJson(p.platforms, []), winner: !!p.winner, simulated: !!p.simulated,
  engagement_rate: p.reach > 0 ? round2((p.likes + p.comments + p.shares) / p.reach * 100) : null });

export function postsList({ status, from, to } = {}) {
  const w = [], p = [];
  if (status) { w.push('status=?'); p.push(status); }
  if (from) { w.push('(scheduled_at>=? OR scheduled_at IS NULL)'); p.push(new Date(from + 'T00:00:00').toISOString()); }
  if (to) { w.push('(scheduled_at<? OR scheduled_at IS NULL)'); p.push(new Date(ymd(addDays(new Date(to + 'T00:00:00'), 1)) + 'T00:00:00').toISOString()); }
  const rows = q.all(`SELECT * FROM social_posts ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY COALESCE(scheduled_at, created_at) DESC LIMIT 300`, ...p);
  const attr = new Map(q.all(`SELECT promo_code, COUNT(*) n, COALESCE(SUM((subtotal-discount+packaging_fee+delivery_fee+service_charge-CASE WHEN tax_inclusive=1 THEN tax ELSE 0 END)),0) rev, COALESCE(SUM((subtotal-discount+packaging_fee+delivery_fee+service_charge-CASE WHEN tax_inclusive=1 THEN tax ELSE 0 END)-commission-food_cost),0) profit, COALESCE(SUM(discount),0) disc
    FROM orders WHERE promo_code IS NOT NULL AND status!='cancelled' GROUP BY promo_code`).map(r => [r.promo_code, r]));
  return rows.map(r => { const s = shape(r), a = r.promo_code && attr.get(r.promo_code);
    s.attributed_orders = a ? a.n : 0; s.attributed_revenue = a ? round2(a.rev) : 0; s.attributed_profit = a ? round2(a.profit) : 0; s.discount_given = a ? round2(a.disc) : 0; return s; });
}

function clean(b, existing) {
  const caption = String(b.caption ?? existing?.caption ?? '').trim();
  if (!caption) throw bad('Write a caption');
  if (caption.length > 2200) throw bad('Caption is too long (2,200 characters max)');
  const platforms = (b.platforms ?? parseJson(existing?.platforms, [])).filter(p => PLATFORMS.includes(p));
  if (!platforms.length) throw bad('Pick at least one platform');
  let at = b.scheduled_at ?? existing?.scheduled_at ?? null;
  if (at) { const d = new Date(at); if (isNaN(d)) throw bad('Schedule time is not valid'); at = d.toISOString(); }
  return { title: String(b.title ?? existing?.title ?? caption.slice(0, 40)).slice(0, 80), caption, platforms, at, media: b.media ?? existing?.media ?? null, promo_code: b.promo_code ? String(b.promo_code).toUpperCase().slice(0, 24) : (existing?.promo_code ?? null), menu_item_id: b.menu_item_id ?? existing?.menu_item_id ?? null };
}

export function createPost(b, user) {
  const c = clean(b);
  const wantsSchedule = b.status === 'scheduled' || (b.status === undefined && c.at);
  if (wantsSchedule && !c.at) throw bad('Pick a time to schedule');
  const status = wantsSchedule ? 'scheduled' : 'draft';
  const id = Number(q.run('INSERT INTO social_posts(title,caption,media,platforms,scheduled_at,status,origin,menu_item_id,promo_code,created_at,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
    c.title, c.caption, c.media, JSON.stringify(c.platforms), c.at, status, 'manual', c.menu_item_id, c.promo_code, now(), user?.name).lastInsertRowid);
  emit('post.created', { id, status });
  return postsList().find(p => p.id === id);
}
export function updatePost(id, b) {
  const p = q.get('SELECT * FROM social_posts WHERE id=?', id);
  if (!p) throw new HttpError(404, 'Post not found');
  if (!EDITABLE.includes(p.status)) throw bad('A published post cannot be edited');
  const c = clean(b, p);
  let status = b.status && EDITABLE.includes(b.status) ? b.status : p.status;
  if (status === 'scheduled' && !c.at) throw bad('Pick a time to schedule');
  if (status === 'failed') status = 'scheduled';
  q.run('UPDATE social_posts SET title=?, caption=?, media=?, platforms=?, scheduled_at=?, status=?, promo_code=?, error=NULL, attempts=0 WHERE id=?', c.title, c.caption, c.media, JSON.stringify(c.platforms), c.at, status, c.promo_code, id);
  emit('post.updated', { id, status });
  return postsList().find(x => x.id === id);
}
export function approvePost(id) {
  const p = q.get('SELECT * FROM social_posts WHERE id=?', id);
  if (!p) throw new HttpError(404, 'Post not found');
  if (p.status !== 'pending_approval' && p.status !== 'draft') throw bad('Only drafts can be approved');
  const at = p.scheduled_at && new Date(p.scheduled_at) > new Date() ? p.scheduled_at : nextSlot().toISOString();
  q.run("UPDATE social_posts SET status='scheduled', scheduled_at=? WHERE id=?", at, id);
  emit('post.approved', { id });
  return postsList().find(x => x.id === id);
}
export function deletePost(id) {
  const p = q.get('SELECT * FROM social_posts WHERE id=?', id);
  if (!p) throw new HttpError(404, 'Post not found');
  if (p.status === 'publishing') throw bad('This post is being published right now');
  q.run('DELETE FROM social_posts WHERE id=?', id);
  emit('post.deleted', { id });
}

export async function publishPost(id) {
  const claimed = q.run("UPDATE social_posts SET status='publishing' WHERE id=? AND status IN ('scheduled','draft','pending_approval','failed')", id);
  if (!claimed.changes) return null;
  const p = q.get('SELECT * FROM social_posts WHERE id=?', id);
  const ad = adapter(), ids = [], errs = [];
  for (const pf of parseJson(p.platforms, [])) {
    try { const r = await ad.publish(p, pf); ids.push(`${pf}:${r.id}`); logIntegration('social', 'out', 'publish', { id, pf }, 'ok'); }
    catch (e) { errs.push(`${pf}: ${e.message}`); logIntegration('social', 'out', 'publish', { id, pf }, `error: ${e.message}`); }
  }
  if (!errs.length) {
    q.run("UPDATE social_posts SET status='published', published_at=?, platform_post_id=?, simulated=?, error=NULL WHERE id=?", now(), ids.join(' '), ad.simulated ? 1 : 0, id);
    emit('post.published', { id, title: p.title, simulated: ad.simulated });
    pullMetrics();
  } else {
    const attempts = p.attempts + 1;
    if (attempts < 3) { q.run("UPDATE social_posts SET status='scheduled', attempts=?, error=?, scheduled_at=? WHERE id=?", attempts, errs.join('; '), new Date(Date.now() + attempts * 120000).toISOString(), id); }
    else { q.run("UPDATE social_posts SET status='failed', attempts=?, error=? WHERE id=?", attempts, errs.join('; '), id); emit('post.failed', { id, title: p.title, error: errs.join('; ') }); }
  }
  return postsList().find(x => x.id === id);
}
export async function publishDue() {
  for (const p of q.all("SELECT id FROM social_posts WHERE status='scheduled' AND scheduled_at<=? ORDER BY scheduled_at LIMIT 10", now())) await publishPost(p.id);
}

/** Pulls engagement for published posts, then marks posts above the median engagement rate as winners. */
export function pullMetrics() {
  const ad = adapter();
  for (const p of q.all("SELECT * FROM social_posts WHERE status='published'")) {
    const m = ad.metrics(p);
    if (m) q.run('UPDATE social_posts SET reach=?, impressions=?, likes=?, comments=?, shares=?, clicks=?, metrics_at=? WHERE id=?', m.reach, m.impressions, m.likes, m.comments, m.shares, m.clicks, now(), p.id);
  }
  const rates = q.all("SELECT id, (likes+comments+shares)*1.0/reach r FROM social_posts WHERE status='published' AND reach>0").sort((a, b) => a.r - b.r);
  if (rates.length >= 3) {
    const median = rates[Math.floor(rates.length / 2)].r;
    for (const x of rates) q.run('UPDATE social_posts SET winner=? WHERE id=?', x.r > median ? 1 : 0, x.id);
  }
}

export function nextSlot() {
  const d = new Date(); d.setHours(19, 0, 0, 0);
  if (d < new Date()) { d.setDate(d.getDate() + 1); d.setHours(12, 30, 0, 0); }
  return d;
}

const slug = s => s.replace(/[^a-z0-9]/gi, '').toUpperCase();
/** Creates a promo code plus a post for a dish. Used by automations (surplus, slow day). */
export function draftPromoPost({ menu, discountPct = 15, headline, triggerNote, ruleId = null, approval = true, origin = 'automation' }) {
  const slot = nextSlot();
  return tx(() => {
    let code = `${slug(menu.name).slice(0, 8)}${discountPct}`, n = 1;
    while (q.get('SELECT code FROM promos WHERE code=?', code)) code = `${slug(menu.name).slice(0, 8)}${discountPct}${++n}`;
    const price = menu.prices.website ?? menu.prices.default;
    const caption = `${headline || `${menu.name} is on offer`} ${discountPct}% off ${menu.name} (now ₹${Math.round(price * (1 - discountPct / 100))}). Use code ${code} on our website or WhatsApp. Valid till ${new Date(slot.getTime() + 864e5).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}. Fresh from the kitchen.`;
    const id = Number(q.run('INSERT INTO social_posts(title,caption,platforms,scheduled_at,status,origin,rule_id,trigger_note,menu_item_id,promo_code,created_at,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      `${menu.name} ${discountPct}% off`, caption, JSON.stringify(['Instagram', 'Facebook']), slot.toISOString(), approval ? 'pending_approval' : 'scheduled', origin, ruleId, triggerNote, menu.id, code, now(), 'Automation').lastInsertRowid);
    q.run('INSERT INTO promos(code,pct,menu_item_id,valid_until,post_id,created_at) VALUES(?,?,?,?,?,?)', code, discountPct, menu.id, new Date(slot.getTime() + 864e5).toISOString(), id, now());
    emit('post.drafted', { id, title: `${menu.name} ${discountPct}% off`, needs_approval: approval, promo_code: code });
    return id;
  });
}

/** Template-based caption options (no external AI service is called). */
export function captionSuggestions({ dish, price, offer, code }) {
  const d = String(dish || 'Our special').slice(0, 60), p = price ? ` for just ₹${Math.round(price)}` : '';
  const o = offer ? ` ${offer}.` : '', c = code ? ` Use code ${String(code).toUpperCase()} to claim it.` : '';
  return [
    `Fresh, hot and on its way: ${d}${p}.${o}${c} Order on Swiggy, Zomato or our website.`,
    `Craving something good? ${d} is ready when you are${p}.${o}${c}`,
    `${d}. Made to order, packed with care${p}.${o}${c} Tap to order tonight.`,
  ];
}
