// Automation engine: rules are rows (trigger, conditions, actions). Runs are logged, retried 3 times, and surfaced to the owner.
import { tenantId, q, now, ymd, parseJson, getSetting, setSetting, parseYmd, addDays, withOutlet, withTenant, outletList, outletId as outletIdNow } from './db.js';
import { activeTenantIds } from './control.js';
import { bus, emit, broadcast } from './bus.js';
import { menuList, inventoryList, runRecurring, budgetStatus, liveProfit, setOrderStatus, scanSurplus, resumeCategories } from './domain.js';
import { draftPromoPost, publishDue, pullMetrics } from './social.js';
import { outbound } from './integrations/aggregator.js';

const fill = (t, p) => String(t || '').replace(/\{(\w+)\}/g, (_, k) => (p[k] ?? ''));
const OPS = { eq: (a, b) => a == b, ne: (a, b) => a != b, gt: (a, b) => a > b, gte: (a, b) => a >= b, lt: (a, b) => a < b, lte: (a, b) => a <= b };
const passes = (conds, payload) => conds.every(c => (OPS[c.op] || OPS.eq)(payload[c.field], c.value));

const ACTIONS = {
  /** stock.surplus -> draft a discounted promo post for the highest-margin dish that uses the surplus ingredient. */
  async create_promo_post({ evt, rule, params }) {
    const itemId = evt.payload.item_id;
    const floor = Number(params.min_margin_pct ?? 45);
    const dishes = menuList().filter(m => m.available && m.recipe.some(l => l.inventory_item_id === itemId) && (m.margin_pct ?? 0) >= floor).sort((a, b) => b.margin_pct - a.margin_pct);
    if (!dishes.length) return `No available dish above ${floor}% margin uses ${evt.payload.item}`;
    const note = `Surplus: ${evt.payload.item}, ${evt.payload.on_hand} ${evt.payload.unit} on hand` + (evt.payload.expires_in_days != null && evt.payload.expires_in_days <= 2 ? `, expires in ${evt.payload.expires_in_days} day(s)` : '');
    const dup = q.get("SELECT id FROM social_posts WHERE origin='automation' AND menu_item_id=? AND substr(created_at,1,10)=?", dishes[0].id, now().slice(0, 10));
    if (dup) return `Post for ${dishes[0].name} already drafted today`;
    const id = draftPromoPost({ menu: dishes[0], discountPct: Number(params.discount_pct ?? 15), headline: 'Limited time:', triggerNote: note, ruleId: rule.id, approval: !!rule.requires_approval });
    return `Drafted post #${id} for ${dishes[0].name}`;
  },
  /** stock.low -> take affected dishes off aggregator menus. Dish availability in POS/website is computed live from stock. */
  async sync_availability({ evt }) {
    const dishes = menuList().filter(m => m.recipe.some(l => l.inventory_item_id === evt.payload.item_id));
    let pushed = 0;
    for (const ch of q.all("SELECT * FROM channel_settings WHERE channel IN ('swiggy','zomato','website') AND active=1 AND integration_provider!='none'")) {
      for (const d of dishes.filter(x => !x.available)) { await outbound(ch.integration_provider, 'set_stock', { channel: ch.channel, store_id: ch.provider_store_id, item_id: d.external_ids[ch.channel] || null, name: d.name, in_stock: false }); pushed++; }
    }
    return `${dishes.filter(d => !d.available).length} dish(es) sold out; ${pushed} aggregator update(s) sent`;
  },
  async notify({ evt, params }) { const text = fill(params.text, evt.payload); emit('notice', { level: params.level || 'info', text }); return text; },
  async post_recurring() { const r = runRecurring(); return `${r.posted} recurring cost(s) posted, ${r.reminders} waiting for confirmation`; },
  async recalc_profit() {
    const p = liveProfit();
    broadcast({ type: 'profit.updated', payload: { net: p.today.net, sales: p.today.sales }, at: now() }, ['owner', 'manager']);
    return `Net profit today ${p.today.net}`;
  },
  async check_budget({ evt }) {
    const cat = evt.payload.category;
    const b = budgetStatus().find(x => x.category === cat);
    if (!b || b.pct < 100) return 'Within budget';
    const month = ymd().slice(0, 7), seen = getSetting('budget_alerted', {});
    if (seen[cat] === month) return 'Already alerted this month';
    seen[cat] = month; setSetting('budget_alerted', seen);
    emit('budget.exceeded', { category: cat, spent: b.spent, limit: b.limit });
    emit('notice', { level: 'warn', text: `${cat} spend ₹${Math.round(b.spent)} is over the ₹${Math.round(b.limit)} budget`, roles: ['owner', 'manager'] });
    return `${cat} over budget`;
  },
  async auto_accept({ evt }) { setOrderStatus(evt.payload.id, 'accepted', { name: 'Auto-accept' }); return `Accepted order #${evt.payload.order_no}`; },
  /** Orders so far today are well below the same weekday's usual pace -> draft a promo for the best-margin dish. */
  async slow_day_offer({ rule, params }) {
    const today = ymd(); if (getSetting('slow_day_done') === today) return 'Already checked today';
    const cutoff = new Date(); const hhmm = cutoff.getHours() * 60 + cutoff.getMinutes();
    let n = 0, count = 0;
    for (let w = 1; w <= 4; w++) {
      const d = addDays(new Date(), -7 * w); const s = new Date(d); s.setHours(0, 0, 0, 0); const e = new Date(d); e.setHours(Math.floor(hhmm / 60), hhmm % 60, 0, 0);
      count += q.get("SELECT COUNT(*) n FROM orders WHERE status!='cancelled' AND placed_at>=? AND placed_at<?", s.toISOString(), e.toISOString()).n; n++;
    }
    const avg = count / n;
    const todayN = q.get("SELECT COUNT(*) n FROM orders WHERE status!='cancelled' AND placed_at>=?", new Date(parseYmd(today)).toISOString()).n;
    setSetting('slow_day_done', today);
    if (avg < 3 || todayN >= avg * Number(params.threshold ?? 0.6)) return `Orders ${todayN} vs usual ${avg.toFixed(1)}: no action`;
    const dish = menuList().filter(m => m.available && (m.margin_pct ?? 0) >= Number(params.min_margin_pct ?? 50)).sort((a, b) => b.margin_pct - a.margin_pct)[0];
    if (!dish) return 'No eligible dish';
    const id = draftPromoPost({ menu: dish, discountPct: Number(params.discount_pct ?? 10), headline: 'Slow afternoon, sweet deal:', triggerNote: `Orders today ${todayN} vs usual ${avg.toFixed(1)} by this time`, ruleId: rule.id, approval: !!rule.requires_approval });
    return `Drafted post #${id} for ${dish.name}`;
  },
};
export const ACTION_TYPES = Object.keys(ACTIONS);

async function runRule(rule, evt) {
  const actions = parseJson(rule.actions, []);
  let lastErr = null, outputs = [];
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt) await new Promise(r => setTimeout(r, attempt * 500));
    try {
      outputs = [];
      for (const a of actions) {
        const fn = ACTIONS[a.type];
        if (!fn) throw new Error(`Unknown action "${a.type}"`);
        outputs.push(await fn({ evt, rule, params: a }));
      }
      lastErr = null; break;
    } catch (e) { lastErr = e; }
  }
  const status = lastErr ? 'failed' : 'ok';
  q.run('INSERT INTO automation_runs(rule_id,rule_name,event_type,input,status,output,error,at) VALUES(?,?,?,?,?,?,?,?)', rule.id, rule.name, evt.type, JSON.stringify(evt.payload).slice(0, 1000), status, outputs.join(' | ').slice(0, 1000), lastErr ? String(lastErr.message).slice(0, 500) : null, now());
  q.run('UPDATE automation_rules SET run_count=run_count+1, last_run_at=?, last_error=? WHERE id=?', now(), lastErr ? String(lastErr.message).slice(0, 300) : null, rule.id);
  if (q.get('SELECT COUNT(*) n FROM automation_runs').n > 600) q.run('DELETE FROM automation_runs WHERE id < (SELECT MAX(id) FROM automation_runs) - 400');
  emit('automation.run', { rule: rule.name, status });
  if (lastErr) emit('notice', { level: 'bad', text: `Automation "${rule.name}" failed: ${lastErr.message}`, roles: ['owner', 'manager'] });
}

async function handleEvent(evt) {
  if (evt.type.startsWith('automation.') || evt.type === 'notice') return;
  for (const rule of q.all('SELECT * FROM automation_rules WHERE active=1')) {
    if (!rule.trigger.split(',').map(s => s.trim()).includes(evt.type)) continue;
    if (!passes(parseJson(rule.conditions, []), evt.payload)) continue;
    try { await runRule(rule, evt); } catch (e) { console.error('rule error', e); }
  }
}

export async function runRuleNow(id) {
  const rule = q.get('SELECT * FROM automation_rules WHERE id=?', id);
  if (!rule) return null;
  const trig = rule.trigger.split(',')[0].trim();
  await runRule(rule, { type: trig, payload: { manual: true }, at: now() });
  return q.get('SELECT * FROM automation_rules WHERE id=?', id);
}

let started = false;
export function startAutomations() {
  if (started) return; started = true;
  bus.on('event', (evt) => setImmediate(() => withTenant(evt.tenant || 1, () => withOutlet(evt.outlet || 1, () => handleEvent(evt))).catch(e => console.error('automation error', e))));
  const last = new Map(); // outlet id -> when each slow job last ran
  const tickOutlet = async () => {
    const id = `${tenantId()}:${outletIdNow()}`, l = last.get(id) || { metrics: 0, surplus: 0 }; last.set(id, l);
    const d = new Date(), hour = d.getHours(), today = ymd(d);
    await publishDue();
    resumeCategories();
    if (Date.now() - l.metrics > 5 * 60000) { l.metrics = Date.now(); pullMetrics(); }
    if (Date.now() - l.surplus > 10 * 60000) { l.surplus = Date.now(); scanSurplus(); }
    if (hour >= 6 && getSetting('sched_morning') !== today) { setSetting('sched_morning', today); emit('schedule.morning', {}); }
    if (hour >= 11 && hour < 16 && getSetting('sched_slow_day') !== today) { setSetting('sched_slow_day', today); emit('schedule.slow_day', {}); }
  };
  const tick = async () => {
    for (const t of activeTenantIds()) {
      try { await withTenant(t, async () => { for (const o of outletList(true)) { try { await withOutlet(o.id, tickOutlet); } catch (e) { console.error(`scheduler error (${t}/${o.slug})`, e); } } }); }
      catch (e) { console.error(`scheduler error (business ${t})`, e); }
    }
  };
  setTimeout(tick, 3000).unref();
  setInterval(tick, 30000).unref();
}
