// Hosted mode (MULTI_TENANT=1): many businesses on one server. Sign-up, email sign-in, approved staff devices, plan billing,
// GST invoices, a payment link with a signed webhook, plan limits, and the operator's own admin API.
import crypto from 'node:crypto';
import { q, gq, now, tenantId, withTenant, outletList, tenantExists } from './db.js';
import { HttpError, bad } from './http.js';
import { ownerSession, tenantOfToken, deviceTenant, checkStaffDevice, createStaffDevice, listStaffDevices, revokeStaffDevice } from './auth.js';
import { seedTenant } from './seed.js';
import * as C from './control.js';
import { backupAll, listBackups } from './backup.js';

const { MULTI, PLANS } = C;
/** Routes that do not belong to one business, so no business has to be named to reach them. */
export const tenantless = (p) => /^(\/healthz|\/api\/auth\/mode|\/api\/signup|\/api\/account\/login|\/api\/webhooks\/razorpay|\/api\/platform\/.*)$/.test(p);
/** Routes a business can still reach after its trial or plan has ended, so the owner can pay. */
export const gateExempt = (p) => /^\/api\/(me|logout|billing(\/.*)?|auth\/.*)$/.test(p);

/** Which business a request is for, worked out before anything is read. null means it did not say. */
export function tenantFromRequest(req, url, token) {
  const t = tenantOfToken(token); if (t) return t;
  const dev = deviceTenant(req.headers['x-device']); if (dev) return dev;
  const ag = /^ag_(\d+)_/.exec(token || ''); if (ag) return Number(ag[1]);
  const k = url.searchParams.get('k') || req.headers['x-account'];
  if (k) { const a = C.accountBySlug(k); return a ? a.id : null; }
  return null;
}

// ───────── small rate limiter ─────────
const tries = new Map();
const hit = (key, max, windowMs) => { const t = Date.now(), a = (tries.get(key) || []).filter((x) => t - x < windowMs); a.push(t); tries.set(key, a); return a.length > max; };
const misses = new Map();
setInterval(() => { const t = Date.now(); for (const [k, v] of tries) if (!v.some((x) => t - x < 3600000)) tries.delete(k); }, 600000).unref();

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const GSTIN = /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
const DUMMY = C.hashPassword('not-a-real-password');
const ipOf = (req) => (process.env.TRUST_PROXY === '1' ? String(req.headers['x-forwarded-for'] || '').split(',').pop().trim() : '') || req.socket.remoteAddress;
const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const pub = (a) => ({ id: a.id, slug: a.slug, business: a.business, status: a.status, plan: a.plan });

// ───────── plan limits ─────────
/** Throws when the business has reached what its plan allows. Does nothing outside hosted mode. */
export function checkLimit(kind) {
  if (!MULTI()) return;
  const a = C.accountById(tenantId()); if (!a) return;
  const p = PLANS[a.plan] || PLANS.growth;
  if (kind === 'users' && p.users) {
    const n = gq.get("SELECT COUNT(*) n FROM users WHERE active=1").n;
    if (n >= p.users) throw new HttpError(403, `The ${p.name} plan allows ${p.users} people. Upgrade the plan to add more.`, { code: 'plan_limit' });
  }
  if (kind === 'outlets' && p.outlets) {
    if (outletList(true).length >= p.outlets) throw new HttpError(403, `The ${p.name} plan covers ${p.outlets} outlet. Choose Pro for several outlets.`, { code: 'plan_limit' });
  }
}

// ───────── billing ─────────
const gatewayOn = () => !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
/** Everything the billing screen and the paywall need, for the business the request is for. */
export function billingSummary() {
  const a = C.accountById(tenantId()); if (!a) return null;
  const st = C.accessState(a), outlets = Math.max(1, outletList(true).length), plan = PLANS[a.plan] || PLANS.growth;
  const price = C.priceFor(a.plan, a.cycle, outlets), g = C.splitGst(price, a.billing_state, a.gstin);
  const open = C.openInvoice(a.id);
  return {
    ok: st.ok, state: st.state || st.code, code: st.code || null, message: st.message || '', days_left: st.days_left ?? null, renew_soon: !!st.renew_soon, grace_left: st.grace_left ?? null,
    plan: a.plan, plan_name: plan.name, cycle: a.cycle, trial_ends: a.trial_ends, paid_until: a.paid_until, outlets,
    price_ex_gst: price, gst: r2(g.cgst + g.sgst + g.igst), total: r2(price + g.cgst + g.sgst + g.igst), gst_pct: C.GST_PCT,
    limits: { users: plan.users, outlets: plan.outlets }, plans: PLANS, online_payments: gatewayOn(), manual_payment_note: process.env.MANUAL_PAYMENT_NOTE || '',
    details: { gstin: a.gstin || '', billing_name: a.billing_name || '', billing_address: a.billing_address || '', billing_state: a.billing_state || '' },
    open_invoice: open && { number: open.number, total: open.total, pay_link: open.pay_link, plan: open.plan, cycle: open.cycle },
  };
}
async function createPaymentLink(inv, a) {
  const base = process.env.RAZORPAY_API_BASE || 'https://api.razorpay.com';
  const res = await fetch(`${base}/v1/payment_links`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Basic ' + Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64') },
    body: JSON.stringify({ amount: Math.round(inv.total * 100), currency: 'INR', reference_id: inv.number, description: `KitFlo ${C.PLANS[inv.plan]?.name || inv.plan}, ${inv.cycle}, ${inv.outlets} outlet${inv.outlets > 1 ? 's' : ''}`,
      customer: { name: a.billing_name || a.business, email: a.email || undefined, contact: a.phone || undefined }, notify: { sms: false, email: false }, reminder_enable: false,
      callback_url: process.env.PUBLIC_URL || undefined, callback_method: process.env.PUBLIC_URL ? 'get' : undefined }),
    signal: AbortSignal.timeout(15000),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || !j.short_url) throw new HttpError(502, 'The payment service did not give a link. Please try again.', { detail: j?.error?.description });
  return j.short_url;
}
/** The open invoice for what the business has now, made if there is none. */
async function ensureInvoice(a) {
  const outlets = Math.max(1, outletList(true).length); let inv = C.openInvoice(a.id);
  if (inv && (inv.plan !== a.plan || inv.cycle !== a.cycle || inv.outlets !== outlets)) { C.recordEvent(a.id, 'invoice.void', { number: inv.number }); C.voidInvoice(inv.id); inv = null; }
  if (!inv) inv = C.createInvoice(a, { outlets, from: a.paid_until && new Date(a.paid_until) > new Date() ? a.paid_until : undefined });
  if (gatewayOn() && !inv.pay_link) { C.setInvoiceLink(inv.id, await createPaymentLink(inv, a)); inv = C.invoiceById(inv.id); }
  return inv;
}

// ───────── scheduled work ─────────
/** Once an hour: businesses close to renewal get their next invoice ready. */
export async function renewalTick() {
  for (const a of C.listAccounts()) {
    if (a.id === 1 || a.status !== 'active') continue;
    const left = (new Date(a.paid_until).getTime() - Date.now()) / 864e5;
    if (left > 5 || C.openInvoice(a.id)) continue;
    try { await withTenant(a.id, () => ensureInvoice(C.accountById(a.id))); } catch (e) { console.error('renewal invoice failed', a.slug, e.message); }
  }
}
export function startHosted() {
  if (!MULTI()) return;
  C.accountById(1);
  setTimeout(() => renewalTick().catch(() => {}), 10000).unref();
  setInterval(() => renewalTick().catch(() => {}), 3600000).unref();
}

// ───────── routes ─────────
export function installHosted(R) {
  R('GET', '/api/auth/mode', null, () => ({ multi_tenant: MULTI(), signups: MULTI() && process.env.SIGNUPS !== 'closed', plans: PLANS, trial_days: C.TRIAL_DAYS }));

  R('POST', '/api/signup', null, async (c) => {
    if (!MULTI() || process.env.SIGNUPS === 'closed') throw new HttpError(404, 'Sign-ups are closed');
    if (hit('su|' + ipOf(c.req), 8, 3600000)) throw new HttpError(429, 'Too many sign-ups from this address. Try again later.');
    const b = c.body, business = String(b.business || '').trim().slice(0, 60), name = String(b.name || '').trim().slice(0, 40), email = String(b.email || '').trim().toLowerCase().slice(0, 120);
    const phone = String(b.phone || '').replace(/\D/g, '').slice(-10), plan = PLANS[b.plan] ? b.plan : 'growth';
    if (!business) throw bad('Enter your business name'); if (!name) throw bad('Enter your name'); if (!EMAIL.test(email)) throw bad('Enter a valid email address');
    if (String(b.password || '').length < 8) throw bad('Password must be at least 8 characters'); if (!/^\d{4,8}$/.test(String(b.pin || ''))) throw bad('Your sign-in PIN must be 4 to 8 digits');
    if (C.accountByEmail(email)) throw new HttpError(409, 'An account with this email already exists. Sign in instead.');
    const a = C.insertAccount({ business, owner_name: name, email, phone: phone || null, pass_hash: C.hashPassword(b.password), plan });
    let sess;
    try { sess = withTenant(a.id, () => { seedTenant({ business, ownerName: name, pin: String(b.pin) }); return ownerSession(c.req.headers['user-agent']); }); }
    catch (e) { C.updateAccount(a.id, { status: 'cancelled', email: null, notes: 'Set-up failed: ' + e.message }); throw e; }
    C.recordEvent(a.id, 'signup', { email, plan });
    const dev = b.shop_device ? withTenant(a.id, () => createStaffDevice(String(b.device_name || 'Shop device'))) : null;
    c.status = 201; return { ...sess, account: pub(a), device_key: dev?.key };
  });

  R('POST', '/api/account/login', null, (c) => {
    if (!MULTI()) throw new HttpError(404, 'Not found');
    const email = String(c.body.email || '').trim().toLowerCase(), ip = ipOf(c.req), k1 = `al|${ip}|${email}`, k2 = `al|${email}`;
    const m1 = misses.get(k1), m2 = misses.get(k2);
    if ((m1 && m1.until > Date.now()) || (m2 && m2.until > Date.now())) throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
    const a = C.accountByEmail(email), ok = C.checkPassword(c.body.password, a ? a.pass_hash : DUMMY) && !!a;
    if (!ok) {
      const n1 = (m1?.n || 0) + 1, n2 = (m2?.n || 0) + 1; misses.set(k1, { n: n1, until: n1 >= 5 ? Date.now() + 60000 : 0 }); misses.set(k2, { n: n2 >= 12 ? 0 : n2, until: n2 >= 12 ? Date.now() + 300000 : 0 });
      throw new HttpError(401, 'Wrong email or password');
    }
    misses.delete(k1); misses.delete(k2);
    if (a.status === 'suspended' || a.status === 'cancelled') throw new HttpError(403, C.accessState(a).message);
    const out = withTenant(a.id, () => { const s = ownerSession(String(c.body.device_name || c.req.headers['user-agent'] || '').slice(0, 120)); const d = c.body.shop_device ? createStaffDevice(String(c.body.device_name || 'Shop device')) : null; return { ...s, device_key: d?.key }; });
    C.updateAccount(a.id, { last_login: now() });
    return { ...out, account: pub(a) };
  });

  // Approved shop devices: the only places that may show staff names and take a PIN.
  R('GET', '/api/staff-devices', 'settings', () => listStaffDevices());
  R('POST', '/api/staff-devices', 'settings', (c) => { c.status = 201; return createStaffDevice(c.body.label); });
  R('DELETE', '/api/staff-devices/:id', 'settings', (c) => revokeStaffDevice(c.params.id));

  R('GET', '/api/billing', '*', (c) => {
    if (!MULTI()) return { hosted: false };
    const s = billingSummary(); return c.user.role === 'owner' ? { hosted: true, ...s } : { hosted: true, ok: s.ok, state: s.state, message: s.message, days_left: s.days_left };
  });
  R('POST', '/api/billing/plan', 'settings', (c) => {
    if (!MULTI()) throw new HttpError(404, 'Not found'); const a = C.accountById(tenantId());
    const plan = c.body.plan ?? a.plan, cycle = c.body.cycle ?? a.cycle;
    if (!PLANS[plan]) throw bad('Pick a plan'); if (!['monthly', 'yearly'].includes(cycle)) throw bad('Pick monthly or yearly');
    const p = PLANS[plan];
    if (p.users && gq.get('SELECT COUNT(*) n FROM users WHERE active=1').n > p.users) throw bad(`${p.name} allows ${p.users} people. Switch some people off first.`);
    if (p.outlets && outletList(true).length > p.outlets) throw bad(`${p.name} covers ${p.outlets} outlet. Close the others first or choose Pro.`);
    C.updateAccount(a.id, { plan, cycle }); C.recordEvent(a.id, 'plan.change', { plan, cycle }); return billingSummary();
  });
  R('POST', '/api/billing/details', 'settings', (c) => {
    if (!MULTI()) throw new HttpError(404, 'Not found'); const b = c.body, g = String(b.gstin || '').trim().toUpperCase();
    if (g && !GSTIN.test(g)) throw bad('That GSTIN does not look right. It has 15 characters, for example 29ABCDE1234F1Z5.');
    C.updateAccount(tenantId(), { gstin: g || null, billing_name: String(b.billing_name || '').trim().slice(0, 80) || null, billing_address: String(b.billing_address || '').trim().slice(0, 300) || null, billing_state: String(b.billing_state || '').trim().slice(0, 40) || null });
    return billingSummary();
  });
  R('POST', '/api/billing/invoice', 'settings', async () => {
    if (!MULTI()) throw new HttpError(404, 'Not found'); const a = C.accountById(tenantId()), st = C.accessState(a);
    if (st.state === 'active' && !st.renew_soon) throw bad('Nothing to pay yet. Your plan runs until ' + a.paid_until.slice(0, 10) + '.');
    const inv = await ensureInvoice(a); return { number: inv.number, total: inv.total, pay_link: inv.pay_link, taxable: inv.taxable };
  });
  R('GET', '/api/billing/invoices', 'settings', () => (MULTI() ? C.invoicesFor(tenantId()).map(({ buyer, ...i }) => i) : []));
  R('GET', '/api/billing/invoices/:number', 'settings', (c) => {
    const i = MULTI() ? C.invoiceByNumber(decodeURIComponent(c.params.number)) : null; if (!i || i.account_id !== tenantId()) throw new HttpError(404, 'Invoice not found');
    return { ...i, seller: C.seller(), gst_pct: C.GST_PCT };
  });

  // Payment gateway webhook: the body is signed with the webhook secret. Anything unsigned is refused.
  R('POST', '/api/webhooks/razorpay', null, (c) => {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET; if (!secret) throw new HttpError(404, 'Not found');
    const sig = String(c.req.headers['x-razorpay-signature'] || ''), want = crypto.createHmac('sha256', secret).update(c.req.rawBody || '').digest('hex');
    const a = Buffer.from(sig), b = Buffer.from(want); if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new HttpError(400, 'Bad signature');
    const ev = c.body, evId = String(c.req.headers['x-razorpay-event-id'] || ''), type = ev.event;
    if (evId && !C.recordEvent(null, 'razorpay.' + type, { id: evId }, evId)) return { ok: true, duplicate: true };
    if (type === 'payment_link.paid' || type === 'payment.captured') {
      const ref = ev.payload?.payment_link?.entity?.reference_id || ev.payload?.payment?.entity?.notes?.reference_id, payId = ev.payload?.payment?.entity?.id || '';
      const inv = ref && C.invoiceByNumber(ref);
      if (inv) { const r = C.settleInvoice(inv.id, payId || 'razorpay'); C.recordEvent(inv.account_id, 'invoice.paid', { number: inv.number, ref: payId }); return { ok: true, settled: !r.already }; }
    }
    return { ok: true, ignored: true };
  });

  // ───── the operator's own admin API (set PLATFORM_TOKEN to turn it on) ─────
  const platform = (c) => {
    const t = process.env.PLATFORM_TOKEN; if (!t || t.length < 16) throw new HttpError(404, 'Not found');
    const got = String(c.req.headers.authorization || '').replace(/^Bearer\s+/i, ''); const x = Buffer.from(got), y = Buffer.from(t);
    if (x.length !== y.length || !crypto.timingSafeEqual(x, y)) throw new HttpError(401, 'Not allowed');
  };
  R('GET', '/api/platform/accounts', null, (c) => { platform(c); return C.listAccounts().map((a) => ({ ...a, access: C.accessState(a) })); });
  R('GET', '/api/platform/invoices', null, (c) => { platform(c); return C.allInvoices().map(({ buyer, ...i }) => i); });
  R('PATCH', '/api/platform/accounts/:id', null, (c) => {
    platform(c); const a = C.accountById(c.params.id); if (!a) throw new HttpError(404, 'Account not found'); const b = c.body, patch = {};
    if (b.status) { if (!['trial', 'active', 'suspended', 'cancelled'].includes(b.status)) throw bad('Bad status'); patch.status = b.status; }
    if (b.plan) { if (!PLANS[b.plan]) throw bad('Bad plan'); patch.plan = b.plan; }
    if (Number(b.trial_extend_days) > 0) patch.trial_ends = new Date(Math.max(Date.now(), new Date(a.trial_ends || 0).getTime()) + Number(b.trial_extend_days) * 864e5).toISOString();
    if (b.paid_until) patch.paid_until = new Date(b.paid_until).toISOString(); if (b.notes !== undefined) patch.notes = String(b.notes).slice(0, 500);
    C.recordEvent(a.id, 'platform.edit', patch); return C.updateAccount(a.id, patch);
  });
  R('POST', '/api/platform/accounts/:id/payments', null, async (c) => {
    platform(c); const a = C.accountById(c.params.id); if (!a) throw new HttpError(404, 'Account not found');
    let inv = c.body.invoice ? C.invoiceByNumber(c.body.invoice) : null; if (inv && inv.account_id !== a.id) throw bad('That invoice belongs to another account');
    if (!inv) inv = await withTenant(a.id, () => { const outlets = Math.max(1, outletList(true).length); return C.createInvoice(a, { outlets }); });
    const r = C.settleInvoice(inv.id, String(c.body.ref || 'manual').slice(0, 80)); C.recordEvent(a.id, 'payment.manual', { invoice: inv.number, ref: c.body.ref });
    return { invoice: r.invoice.number, status: r.invoice.status, paid_until: r.account.paid_until };
  });
  R('GET', '/api/platform/backups', null, (c) => { platform(c); return listBackups(); });
  R('POST', '/api/platform/backups', null, async (c) => { platform(c); const r = await backupAll(); return { name: r.name, files: r.files, bytes: r.bytes }; });
  R('POST', '/api/platform/accounts/:id/impersonate', null, (c) => {
    platform(c); const a = C.accountById(c.params.id); if (!a) throw new HttpError(404, 'Account not found');
    C.recordEvent(a.id, 'platform.impersonate', { by: 'operator', reason: String(c.body.reason || '').slice(0, 200) });
    return withTenant(a.id, () => ownerSession('Operator support session'));
  });
}
export { checkStaffDevice, tenantExists };
