// First-run setup: users, channels, automation rules, and your own menu from menu-data.json, or with SEED_DEMO=1 a realistic 30-day demo kitchen with its own dishes.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { q, tx, now, ymd, addDays, setSetting, getSetting, round2 } from './db.js';
import { hashPin } from './auth.js';
import { addMovement, priceFor, menuList, createOrder, setOrderStatus, importMenu } from './domain.js';
import { pullMetrics } from './social.js';

const PROD = process.env.NODE_ENV === 'production';
const mulberry = (a) => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };

export function firstRun() {
  if (q.get('SELECT COUNT(*) n FROM users').n > 0) return null;
  const demo = process.env.SEED_DEMO === '1';
  const fixed = { Owner: '1234', Manager: '2222', Cashier: '3333', Kitchen: '4444', Marketer: '5555' };
  const creds = [];
  tx(() => {
    for (const [name, pin0] of Object.entries(fixed)) {
      const pin = PROD ? String(crypto.randomInt(100000, 999999)) : pin0;
      q.run('INSERT INTO users(name,role,pin_hash) VALUES(?,?,?)', name, name.toLowerCase(), hashPin(process.env[`${name.toUpperCase()}_PIN`] || pin));
      creds.push({ name, pin: process.env[`${name.toUpperCase()}_PIN`] || pin });
      q.run('INSERT OR IGNORE INTO user_outlets(user_id, outlet_id) SELECT last_insert_rowid(), 1');
    }
    seedOutletBasics('Cloud Kitchen');
  });
  if (demo) { seedDemo(); seedLive(); } else seedMenu();
  return creds;
}

/** What every outlet starts with: sales channels, business name, budgets and the standard automations. Runs inside the outlet's own database. */
/** A brand-new business in hosted mode: its owner, its channels and rules, and nothing else (no sample menu; the owner imports their own). */
export function seedTenant({ business, ownerName, pin }) {
  tx(() => {
    q.run('INSERT INTO users(name,role,pin_hash) VALUES(?,?,?)', ownerName, 'owner', hashPin(pin));
    q.run('INSERT OR IGNORE INTO user_outlets(user_id, outlet_id) SELECT last_insert_rowid(), 1');
    seedOutletBasics(business);
    q.run("UPDATE outlets SET name=? WHERE id=1", business);
  });
}

export function seedOutletBasics(name) {
  tx(() => {
    for (const c of [['swiggy', 'Swiggy', 22, 0], ['zomato', 'Zomato', 20, 0], ['website', 'Website', 3, 10], ['whatsapp', 'WhatsApp', 2, 10], ['walkin', 'Walk-in', 0, 0]])
      q.run('INSERT INTO channel_settings(channel,label,commission_pct,packaging_fee,integration_provider) VALUES(?,?,?,?,?)', c[0], c[1], c[2], c[3], (c[0] === 'swiggy' || c[0] === 'zomato') ? 'dyno' : 'none');
    setSetting('business', { name, gstin: '', fssai: '', address: '' });
    setSetting('prep_minutes', 25); setSetting('lapsed_days', 30);
    setSetting('budgets', { 'Packaging': 6000, 'Gas & fuel': 5000, 'Marketing': 4000, 'Utilities': 6000 });
    const rule = (name, trigger, actions, o = {}) => q.run('INSERT INTO automation_rules(name,trigger,conditions,actions,active,requires_approval,description) VALUES(?,?,?,?,?,?,?)', name, trigger, JSON.stringify(o.conditions || []), JSON.stringify(actions), o.active ?? 1, o.approval ?? 0, o.description || '');
    rule('Surplus stock → promo post', 'stock.surplus', [{ type: 'create_promo_post', discount_pct: 15, min_margin_pct: 45 }], { approval: 1, description: 'When an ingredient is above par or close to expiry, draft a discounted post for the best-margin dish that uses it.' });
    rule('Sold-out guard', 'stock.low', [{ type: 'sync_availability' }, { type: 'notify', level: 'warn', text: '{item} is low ({on_hand} {unit} left). Dishes using it may be sold out.' }], { description: 'When an ingredient runs low, mark dishes sold out on delivery apps and alert every device.' });
    rule('Live profit', 'order.completed,expense.added,expense.deleted,stock.changed', [{ type: 'recalc_profit' }], { description: 'Recalculate net profit whenever an order completes or an expense changes.' });
    rule('Recurring costs', 'schedule.morning', [{ type: 'post_recurring' }], { description: 'Every morning post due recurring costs (auto-post ones) or remind you to confirm the rest.' });
    rule('Budget alerts', 'expense.added', [{ type: 'check_budget' }], { description: 'Warn the owner once a month when a category passes its budget.' });
    rule('Slow-day offer', 'schedule.slow_day', [{ type: 'slow_day_offer', threshold: 0.6, discount_pct: 10, min_margin_pct: 50 }], { approval: 1, description: 'At 11:00, if orders are well below the same weekday\'s pace, draft a promo post.' });
    rule('Auto-accept website and WhatsApp orders', 'order.received', [{ type: 'auto_accept' }], { active: 0, conditions: [{ field: 'channel', op: 'ne', value: 'walkin' }], description: 'Accept incoming orders without a tap. Off by default.' });
  });
}

/** The kitchen's real menu (Menu Master sheet). Recipes are left empty on purpose: add them on the Menu page so food cost and stock deduction are real. */
function seedMenu() {
  const file = path.join(import.meta.dirname, 'menu-data.json');
  if (!fs.existsSync(file)) return;
  const sales = path.join(import.meta.dirname, 'menu-sales.json');
  if (fs.existsSync(sales)) setSetting('sales_baseline', JSON.parse(fs.readFileSync(sales, 'utf8')));
  const r = importMenu(JSON.parse(fs.readFileSync(file, 'utf8')));
  if (r.errors.length) console.log(`Menu import: ${r.created} added, ${r.errors.length} rows skipped`, r.errors.slice(0, 3));
}

function seedDemo() {
  const R = mulberry(20261020);
  const D = (days, h, m) => { const d = addDays(new Date(), days); d.setHours(h, m, 0, 0); return d; };
  tx(() => {
    const sup = (n, p) => Number(q.run('INSERT INTO suppliers(name,phone) VALUES(?,?)', n, p).lastInsertRowid);
    const s1 = sup('Fresh Farms Veg', '9800000001'), s2 = sup('Daily Dairy', '9800000002'), s3 = sup('Meat Mart', '9800000003'), s4 = sup('Kirana Wholesale', '9800000004');
    // name, unit, cost, reorder, par, current, supplier, expiryDays
    const inv = {}; const target = {};
    for (const [name, cat, unit, cost, re, par, cur, s, exp] of [
      ['Paneer', 'Dairy', 'kg', 320, 3, 8, 6.5, s2, 4], ['Tomato', 'Veg', 'kg', 40, 5, 14, 11, s1, 3], ['Onion', 'Veg', 'kg', 35, 6, 16, 13, s1, null], ['Potato', 'Veg', 'kg', 30, 5, 14, 12, s1, null],
      ['Butter', 'Dairy', 'kg', 520, 1, 3, 2.2, s2, 20], ['Cream', 'Dairy', 'l', 220, 1.5, 4, 3, s2, 5], ['Yogurt', 'Dairy', 'kg', 70, 3, 6, 11, s2, 2],
      ['Rice', 'Dry', 'kg', 78, 10, 30, 24, s4, null], ['Dal', 'Dry', 'kg', 120, 3, 8, 6, s4, null], ['Ghee', 'Dry', 'kg', 620, 0.5, 2, 1.4, s4, null], ['Sugar', 'Dry', 'kg', 45, 2, 6, 4, s4, null],
      ['Milk powder', 'Dry', 'kg', 380, 1, 3, 2, s4, null], ['Cooking oil', 'Dry', 'l', 140, 3, 10, 7, s4, null], ['Chicken', 'Meat', 'kg', 210, 4, 12, 9, s3, 2], ['Tortilla wraps', 'Dry', 'pc', 6, 14, 60, 36, s4, null],
    ]) {
      inv[name] = Number(q.run('INSERT INTO inventory_items(name,category,unit,reorder_level,par_level,unit_cost,supplier_id,expiry_date) VALUES(?,?,?,?,?,?,?,?)', name, cat, unit, re, par, cost, s, exp == null ? null : ymd(addDays(new Date(), exp))).lastInsertRowid);
      target[inv[name]] = cur;
    }
    const dishes = [
      ['Paneer Butter Masala Bowl', 'Bowls', 249, { Paneer: .12, Tomato: .1, Butter: .02, Cream: .03, Rice: .15 }],
      ['Butter Chicken Bowl', 'Bowls', 289, { Chicken: .18, Tomato: .1, Butter: .02, Cream: .03, Rice: .15 }],
      ['Chicken Dum Biryani', 'Biryani', 299, { Chicken: .2, Rice: .18, Onion: .08, Yogurt: .05, 'Cooking oil': .03 }],
      ['Veg Dum Biryani', 'Biryani', 229, { Potato: .1, Rice: .18, Onion: .08, Yogurt: .05, 'Cooking oil': .03 }],
      ['Dal Tadka Combo', 'Combos', 189, { Dal: .1, Rice: .15, Onion: .05, Ghee: .01 }],
      ['Paneer Tikka Wrap', 'Wraps', 169, { Paneer: .09, 'Tortilla wraps': 1, Onion: .04, Yogurt: .04 }],
      ['Chicken Tikka Wrap', 'Wraps', 179, { Chicken: .1, 'Tortilla wraps': 1, Onion: .04, Yogurt: .04 }],
      ['Masala Fries', 'Sides', 99, { Potato: .2, 'Cooking oil': .05 }],
      ['Sweet Lassi', 'Drinks', 79, { Yogurt: .15, Sugar: .02 }],
      ['Gulab Jamun (2 pc)', 'Desserts', 89, { 'Milk powder': .05, Sugar: .04, Ghee: .01, 'Cooking oil': .02 }],
    ];
    const menuIds = [];
    dishes.forEach(([name, cat, price, rec], i) => {
      const prices = { default: price, website: price, whatsapp: price, walkin: price, swiggy: Math.round(price * 1.1), zomato: Math.round(price * 1.1) };
      const id = Number(q.run('INSERT INTO menu_items(name,category,prices,gst_rate,external_ids,created_at) VALUES(?,?,?,?,?,?)', name, cat, JSON.stringify(prices), 5, JSON.stringify({ swiggy: `SW-${100 + i}`, zomato: `ZM-${200 + i}` }), now()).lastInsertRowid);
      menuIds.push(id);
      for (const [ing, qty] of Object.entries(rec)) q.run('INSERT INTO recipe_lines(menu_item_id,inventory_item_id,qty_per_portion,wastage_pct) VALUES(?,?,?,?)', id, inv[ing], qty, 3);
    });

    // customers
    const names = ['Aarav', 'Diya', 'Rohan', 'Meera', 'Kabir', 'Ananya', 'Vikram', 'Isha', 'Arjun', 'Sneha', 'Rahul', 'Pooja', 'Nikhil', 'Kavya', 'Sameer', 'Tara', 'Dev', 'Riya', 'Karan', 'Neha', 'Manav', 'Simran', 'Aditya', 'Zoya', 'Yash', 'Priya', 'Harsh', 'Nandini', 'Ishaan', 'Anika'];
    const cust = names.map((n, i) => Number(q.run('INSERT INTO customers(name,phone,first_channel,whatsapp_opt_in,created_at) VALUES(?,?,?,?,?)', n, `98${String(10000000 + i * 137913).slice(0, 8)}`, 'website', R() < 0.6 ? 1 : 0, now()).lastInsertRowid));

    // marketing posts + promos (published in the past) so attribution has data
    const mkPost = (title, caption, code, pct, daysAgo, dish) => {
      const at = D(-daysAgo, 19, 0).toISOString();
      const pid = Number(q.run("INSERT INTO social_posts(title,caption,platforms,scheduled_at,status,origin,menu_item_id,promo_code,published_at,simulated,created_at,created_by) VALUES(?,?,?,?,'published','manual',?,?,?,1,?,'Marketer')", title, caption, JSON.stringify(['Instagram', 'Facebook']), at, menuIds[dish], code, at, at).lastInsertRowid);
      if (code) q.run('INSERT INTO promos(code,pct,menu_item_id,valid_until,post_id,created_at) VALUES(?,?,?,?,?,?)', code, pct, menuIds[dish], D(-daysAgo + 2, 23, 0).toISOString(), pid, at);
      return { code, pct, since: D(-daysAgo, 19, 0), until: D(-daysAgo + 2, 23, 0), dish: menuIds[dish] };
    };
    const promos = [
      mkPost('Biryani weekend', 'Weekend is for biryani. 15% off Chicken Dum Biryani with code BIRYANI15.', 'BIRYANI15', 15, 20, 2),
      mkPost('Wrap Wednesday', 'Wrap Wednesday: 10% off Paneer Tikka Wrap with code WRAP10.', 'WRAP10', 10, 12, 5),
      mkPost('Lassi cooler', 'Beat the heat. 20% off Sweet Lassi with code LASSI20.', 'LASSI20', 20, 6, 8),
      mkPost('Behind the kitchen', 'Meet the team that packs your dinner. Fresh every day.', null, 0, 9, 0),
    ];

    // order history
    const chans = [['swiggy', .34], ['zomato', .30], ['website', .12], ['whatsapp', .08], ['walkin', .16]];
    const cs = Object.fromEntries(q.all('SELECT * FROM channel_settings').map(c => [c.channel, c]));
    const ml = Object.fromEntries(menuList().map(m => [m.id, m]));
    const pickCh = () => { let x = R(), a = 0; for (const [c, w] of chans) { a += w; if (x < a) return c; } return 'walkin'; };
    const usage = {}; let no = 1000; const nowD = new Date();
    for (let day = -30; day <= 0; day++) {
      const dow = addDays(new Date(), day).getDay();
      const n = Math.round((13 + R() * 8) * (dow === 0 || dow === 6 ? 1.35 : 1) * (day > -4 ? 1 + (day + 30) / 120 : 1));
      for (let k = 0; k < n; k++) {
        const hourPool = [12, 12, 13, 13, 14, 19, 20, 20, 21, 21, 22];
        const h = hourPool[Math.floor(R() * hourPool.length)], m = Math.floor(R() * 60);
        const placed = D(day, h, m);
        if (placed.getTime() > nowD.getTime() - 70 * 60000) continue;
        const ch = pickCh(), c = cs[ch];
        const count = 1 + Math.floor(R() * 3), chosen = new Set();
        const lines = [];
        for (let i = 0; i < count; i++) { const id = menuIds[Math.floor(R() * menuIds.length)]; if (chosen.has(id)) continue; chosen.add(id); lines.push({ id, qty: 1 + (R() < 0.3 ? 1 : 0) }); }
        const promo = (ch === 'website' || ch === 'whatsapp') && R() < 0.35 ? promos.find(p => p.code && p.since <= placed && placed <= p.until && lines.some(l => l.id === p.dish)) : null;
        let sub = 0, tax = 0, cost = 0, disc = 0;
        for (const l of lines) { const p = priceFor(ml[l.id], ch); sub += p * l.qty; tax += p * l.qty * 0.05; cost += ml[l.id].recipe_cost * l.qty; if (promo && promo.dish === l.id) disc += p * l.qty * promo.pct / 100; }
        if (!promo && (ch === 'swiggy' || ch === 'zomato') && R() < 0.25) disc = sub * (0.05 + R() * 0.05);
        disc = round2(disc); sub = round2(sub); tax = round2(tax * (1 - disc / sub));
        const pack = ch === 'website' || ch === 'whatsapp' ? 10 : 0;
        const comm = round2((sub - disc) * c.commission_pct / 100);
        const cancelled = R() < 0.03;
        const acc = new Date(placed.getTime() + (1 + R() * 2) * 60000), rdy = new Date(acc.getTime() + (12 + R() * 16) * 60000), done = new Date(rdy.getTime() + (18 + R() * 17) * 60000);
        const custId = (ch === 'website' || ch === 'whatsapp' || ch === 'walkin') && R() < 0.9 ? cust[Math.floor(R() * cust.length)] : null;
        const oid = Number(q.run(`INSERT INTO orders(order_no,channel,channel_order_id,customer_id,status,placed_at,accepted_at,ready_at,completed_at,subtotal,discount,tax,packaging_fee,commission,total,payment_mode,food_cost,promo_code,deducted,created_by)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, ++no, ch, (ch === 'swiggy' || ch === 'zomato') ? `${ch.slice(0, 2).toUpperCase()}${700000 + no}` : null, custId, cancelled ? 'cancelled' : 'completed', placed.toISOString(),
          cancelled ? null : acc.toISOString(), cancelled ? null : rdy.toISOString(), cancelled ? null : done.toISOString(), sub, disc, tax, pack, comm, round2(sub - disc + tax + pack),
          ch === 'swiggy' || ch === 'zomato' ? 'Prepaid by platform' : (R() < 0.6 ? 'UPI' : 'Cash'), round2(cost), promo ? promo.code : null, cancelled ? 0 : 1, 'seed').lastInsertRowid);
        for (const l of lines) {
          q.run('INSERT INTO order_items(order_id,menu_item_id,name,qty,unit_price,unit_cost,gst_rate) VALUES(?,?,?,?,?,?,5)', oid, l.id, ml[l.id].name, l.qty, priceFor(ml[l.id], ch), ml[l.id].recipe_cost);
          if (!cancelled) for (const r of ml[l.id].recipe) { const used = r.qty_per_portion * 1.03 * l.qty; usage[r.inventory_item_id] = (usage[r.inventory_item_id] || 0) + used;
            q.run("INSERT INTO stock_movements(inventory_item_id,type,qty,order_id,unit_cost,moved_at,by_user) VALUES(?,?,?,?,?,?,'seed')", r.inventory_item_id, 'sale', -Math.round(used * 1000) / 1000, oid, 0, acc.toISOString()); }
        }
      }
    }
    // opening stock sized so that today's on-hand equals the targets above
    for (const [id, cur] of Object.entries(target)) addMovement({ item_id: Number(id), type: 'opening', qty: Math.round((cur + (usage[id] || 0)) * 1000) / 1000, unit_cost: 0, by: 'seed', note: 'Opening stock' });
    q.run("UPDATE stock_movements SET moved_at=? WHERE type='opening'", D(-31, 9, 0).toISOString());

    // expenses
    const ex = (daysAgo, cat, amt, vendor, mode, src = 'manual', notes = null) => q.run('INSERT INTO expenses(date,category,amount,vendor,payment_mode,source,notes,entered_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)', ymd(addDays(new Date(), -daysAgo)), cat, amt, vendor, mode, src, notes, 'seed', now());
    for (let d = 29; d >= 0; d -= 2 + Math.floor(R() * 2)) ex(d, 'Ingredients', Math.round((3500 + R() * 5500) / 10) * 10, ['Fresh Farms Veg', 'Daily Dairy', 'Meat Mart', 'Kirana Wholesale'][Math.floor(R() * 4)], 'UPI');
    for (const d of [27, 20, 13, 6]) ex(d, 'Packaging', 1500 + Math.round(R() * 700), 'PackIt Supplies', 'UPI');
    for (const d of [26, 15, 3]) ex(d, 'Gas & fuel', 1450 + Math.round(R() * 200), 'Gas agency', 'Cash');
    ex(24, 'Marketing', 1200, 'Instagram boost', 'Card'); ex(10, 'Marketing', 1500, 'Local flyers', 'Cash');
    ex(18, 'Utilities', 4200, 'Electricity board', 'UPI'); ex(8, 'Repairs', 2200, 'Cold storage service', 'Cash');
    const first = new Date(); first.setDate(1);
    q.run("INSERT INTO expenses(date,category,amount,vendor,payment_mode,source,notes,entered_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)", ymd(first), 'Rent', 35000, 'Landlord', 'Bank transfer', 'recurring', 'Kitchen rent', 'seed', now());
    q.run("INSERT INTO expenses(date,category,amount,vendor,payment_mode,source,notes,entered_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)", ymd(first), 'Salaries', 60000, 'Staff', 'Bank transfer', 'recurring', 'Monthly salaries', 'seed', now());
    const nextFirst = new Date(first.getFullYear(), first.getMonth() + 1, 1);
    for (const [name, cat, amt, freq, due, auto] of [['Kitchen rent', 'Rent', 35000, 'monthly', ymd(nextFirst), 0], ['Salaries', 'Salaries', 60000, 'monthly', ymd(nextFirst), 0], ['Internet and POS software', 'Utilities', 2400, 'monthly', ymd(new Date()), 0], ['Gas cylinder rental', 'Gas & fuel', 300, 'weekly', ymd(addDays(new Date(), 2)), 1]])
      q.run('INSERT INTO recurring_expenses(name,category,amount,frequency,next_due,auto_post) VALUES(?,?,?,?,?,?)', name, cat, amt, freq, due, auto);
    setSetting('demo', true);
  });
  pullMetrics();
}

/** A few open orders so the board and kitchen display are not empty on first look. */
function seedLive() {
  const m = menuList(); const id = (n) => m.find(x => x.name.startsWith(n)).id;
  createOrder({ channel: 'swiggy', channel_order_id: 'SW90001', items: [{ menu_item_id: id('Chicken Dum'), qty: 1 }, { menu_item_id: id('Masala'), qty: 1 }], customer: { name: 'Priya' }, address: 'Indiranagar' }, { user: { name: 'seed' } });
  createOrder({ channel: 'zomato', channel_order_id: 'ZM90002', items: [{ menu_item_id: id('Paneer Butter'), qty: 2 }], notes: 'Less spicy' }, { user: { name: 'seed' } });
  const a = createOrder({ channel: 'website', items: [{ menu_item_id: id('Dal Tadka'), qty: 1 }, { menu_item_id: id('Sweet Lassi'), qty: 2 }], customer: { name: 'Aarav', phone: '9810000000' } }, { user: { name: 'seed' }, accept: true });
  const b = createOrder({ channel: 'walkin', items: [{ menu_item_id: id('Butter Chicken'), qty: 1 }, { menu_item_id: id('Gulab'), qty: 1 }] }, { user: { name: 'seed' }, accept: true });
  setOrderStatus(b.order.id, 'preparing', { name: 'seed' });
}
