import { q, ymd, addDays, parseYmd, dayStartISO, round2 } from './db.js';
import { HttpError } from './http.js';
import { profit, inventoryList, customersList, budgetStatus, CHANNELS } from './domain.js';
import { postsList } from './social.js';

export function range(qs) {
  const re = /^\d{4}-\d{2}-\d{2}$/;
  const to = re.test(qs.to || '') ? qs.to : ymd();
  const days = Math.min(Math.max(Number(qs.days) || 7, 1), 366);
  const from = re.test(qs.from || '') ? qs.from : ymd(addDays(parseYmd(to), -(days - 1)));
  if (from > to) throw new HttpError(400, 'From date is after To date');
  return { from, to };
}
const iso = (from, to) => [dayStartISO(from), dayStartISO(ymd(addDays(parseYmd(to), 1)))];

export function summary(from, to) {
  const cur = profit(from, to);
  const n = Math.round((parseYmd(to) - parseYmd(from)) / 864e5) + 1;
  const prev = profit(ymd(addDays(parseYmd(from), -n)), ymd(addDays(parseYmd(from), -1)));
  const series = [];
  for (let i = 0; i < Math.min(n, 92); i++) { const d = ymd(addDays(parseYmd(from), i)); const p = profit(d, d); series.push({ date: d, sales: p.sales, orders: p.orders, net: p.net }); }
  const [a, b] = iso(from, to);
  const prep = q.get("SELECT AVG((julianday(ready_at)-julianday(accepted_at))*1440) m FROM orders WHERE status='completed' AND ready_at IS NOT NULL AND accepted_at IS NOT NULL AND completed_at>=? AND completed_at<?", a, b).m;
  return { range: { from, to }, ...cur, avg_order_value: cur.orders ? round2(cur.sales / cur.orders) : 0, avg_prep_minutes: prep == null ? null : Math.round(prep * 10) / 10, previous: { net: prev.net, sales: prev.sales, orders: prev.orders }, series };
}

export function channels(from, to) {
  const [a, b] = iso(from, to);
  const rows = q.all(`SELECT channel, COUNT(*) orders, SUM((subtotal-discount+packaging_fee+delivery_fee+service_charge-CASE WHEN tax_inclusive=1 THEN tax ELSE 0 END)) sales, SUM(commission) commission, SUM(food_cost) food_cost
    FROM orders WHERE status='completed' AND completed_at>=? AND completed_at<? GROUP BY channel`, a, b);
  return CHANNELS.map(c => {
    const r = rows.find(x => x.channel === c) || { orders: 0, sales: 0, commission: 0, food_cost: 0 };
    const sales = round2(r.sales || 0), comm = round2(r.commission || 0), food = round2(r.food_cost || 0);
    return { channel: c, orders: r.orders, sales, commission: comm, commission_pct: sales ? round2(comm / sales * 100) : 0, food_cost: food, profit: round2(sales - comm - food), margin_pct: sales ? round2((sales - comm - food) / sales * 100) : null, aov: r.orders ? round2(sales / r.orders) : 0 };
  });
}

export function menuPerformance(from, to) {
  const [a, b] = iso(from, to);
  return q.all(`SELECT i.name, SUM(i.qty) units, SUM(i.qty*i.unit_price) revenue, SUM(i.qty*i.unit_cost) cost
    FROM order_items i JOIN orders o ON o.id=i.order_id WHERE o.status='completed' AND o.completed_at>=? AND o.completed_at<? GROUP BY i.name ORDER BY revenue DESC`, a, b)
    .map(r => ({ name: r.name, units: r.units, revenue: round2(r.revenue), cost: round2(r.cost), margin_pct: r.revenue ? round2((r.revenue - r.cost) / r.revenue * 100) : null }));
}

export function expensesBreakdown(from, to) {
  const by = q.all('SELECT category, SUM(amount) amount, COUNT(*) n FROM expenses WHERE date>=? AND date<=? GROUP BY category ORDER BY amount DESC', from, to).map(r => ({ ...r, amount: round2(r.amount) }));
  const total = round2(by.reduce((s, r) => s + r.amount, 0));
  return { range: { from, to }, total, by_category: by, budgets: budgetStatus() };
}

export function inventoryAnalytics(from, to) {
  const [a, b] = iso(from, to);
  const waste = new Map(q.all("SELECT inventory_item_id id, -SUM(qty) qty, -SUM(qty*unit_cost) cost FROM stock_movements WHERE type='wastage' AND moved_at>=? AND moved_at<? GROUP BY inventory_item_id", a, b).map(r => [r.id, r]));
  return inventoryList().map(i => ({ ...i, wastage_qty: waste.get(i.id)?.qty || 0, wastage_cost: round2(waste.get(i.id)?.cost || 0), stock_value: round2(i.on_hand * i.unit_cost) }));
}

export function customersAnalytics() {
  const list = customersList();
  const count = (s) => list.filter(c => c.segment === s).length;
  const repeat = list.filter(c => c.order_count >= 2).length;
  return { total: list.length, new: count('New'), repeat: count('Repeat'), lapsed: count('Lapsed'), repeat_rate_pct: list.length ? Math.round(repeat / list.length * 100) : 0, top: list.slice(0, 8).map(c => ({ name: c.name || c.phone, orders: c.order_count, lifetime_value: c.lifetime_value, segment: c.segment })), lapsed_opted_in: list.filter(c => c.segment === 'Lapsed' && c.whatsapp_opt_in).length };
}

export function socialAnalytics() {
  const posts = postsList({ status: 'published' });
  const per = {};
  for (const p of posts) for (const pf of p.platforms) { const x = per[pf] || (per[pf] = { platform: pf, posts: 0, reach: 0, engagement: 0 }); x.posts++; x.reach += p.reach; x.engagement += p.likes + p.comments + p.shares; }
  return { simulated: posts.some(p => p.simulated), posts, by_platform: Object.values(per).map(x => ({ ...x, engagement_rate_pct: x.reach ? round2(x.engagement / x.reach * 100) : null })) };
}
export function socialRoi() {
  return postsList({ status: 'published' }).filter(p => p.promo_code).map(p => ({ id: p.id, title: p.title, promo_code: p.promo_code, orders: p.attributed_orders, revenue: p.attributed_revenue, discount_given: p.discount_given, profit: p.attributed_profit }))
    .sort((a, b) => b.profit - a.profit);
}

/** Plain-language findings for the top of the analytics page. Each is computed from the numbers, never invented. */
export function insights(from, to) {
  const out = [];
  const ch = channels(from, to).filter(c => c.orders > 0);
  const platforms = ch.filter(c => c.channel === 'swiggy' || c.channel === 'zomato');
  if (platforms.length) { const w = platforms.sort((a, b) => b.commission - a.commission)[0]; out.push(`${labelOf(w.channel)} took ₹${Math.round(w.commission).toLocaleString('en-IN')} in commission (${w.commission_pct}% of its sales) in this period.`); }
  if (ch.length >= 2) { const s = [...ch].sort((a, b) => b.margin_pct - a.margin_pct); out.push(`${labelOf(s[0].channel)} has the best margin at ${s[0].margin_pct}%, ${labelOf(s.at(-1).channel)} the lowest at ${s.at(-1).margin_pct}%.`); }
  const menu = menuPerformance(from, to);
  const popularLow = menu.filter(m => m.margin_pct !== null && m.margin_pct < 50).sort((a, b) => b.units - a.units)[0];
  if (popularLow) out.push(`${popularLow.name} sold ${popularLow.units} units but earns only ${popularLow.margin_pct}% margin. A small price rise or recipe change would lift profit.`);
  const over = budgetStatus().find(b => b.pct >= 100);
  if (over) out.push(`${over.category} spend is over its monthly budget (₹${Math.round(over.spent).toLocaleString('en-IN')} of ₹${Math.round(over.limit).toLocaleString('en-IN')}).`);
  const cu = customersAnalytics();
  if (cu.lapsed) out.push(`${cu.lapsed} customer${cu.lapsed === 1 ? ' has' : 's have'} not ordered for a while.`);
  const best = socialRoi()[0];
  if (best && best.orders) out.push(`Post "${best.title}" brought ${best.orders} order${best.orders === 1 ? '' : 's'} and ₹${Math.round(best.profit).toLocaleString('en-IN')} profit through code ${best.promo_code}.`);
  return out.slice(0, 5);
}
const labelOf = (c) => ({ swiggy: 'Swiggy', zomato: 'Zomato', website: 'Website', whatsapp: 'WhatsApp', walkin: 'Walk-in' }[c] || c);
