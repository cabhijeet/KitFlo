// Backups: a consistent copy of every database (VACUUM INTO, safe while the app is running), plus pictures and receipts.
// Restore is a command run with the server stopped. See the README.
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { execFile } from 'node:child_process';
import { DATA_DIR } from './db.js';

const BACKUP_DIR = () => process.env.BACKUP_DIR || path.join(DATA_DIR, 'backups');
const KEEP = () => Math.max(1, Number(process.env.BACKUP_KEEP) || 7);
const stamp = (d = new Date()) => { const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`; };
const isDb = (f) => /\.db$/.test(f);

/** Every folder that holds a business: the data folder itself (business 1) and tenants/<id>. Paths are relative to DATA_DIR. */
function businessDirs() {
  const out = ['.']; const t = path.join(DATA_DIR, 'tenants');
  if (fs.existsSync(t)) for (const n of fs.readdirSync(t)) if (/^\d+$/.test(n) && fs.statSync(path.join(t, n)).isDirectory()) out.push(path.join('tenants', n));
  return out;
}
function copyDb(src, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const d = new DatabaseSync(src); try { d.exec('PRAGMA busy_timeout=5000'); d.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`); } finally { d.close(); }
}
/** Takes one backup. Returns { name, dir, files, bytes }. */
export async function backupAll({ files = true } = {}) {
  const name = stamp(), dir = path.join(BACKUP_DIR(), name); fs.mkdirSync(dir, { recursive: true });
  const list = [];
  const control = path.join(DATA_DIR, 'control.db');
  if (fs.existsSync(control)) { copyDb(control, path.join(dir, 'control.db')); list.push('control.db'); }
  for (const b of businessDirs()) {
    const src = path.join(DATA_DIR, b);
    for (const f of fs.readdirSync(src)) {
      if (!isDb(f) || f === 'control.db') continue;
      copyDb(path.join(src, f), path.join(dir, b, f)); list.push(path.join(b, f));
    }
    if (files) for (const sub of ['media', 'receipts']) { const s = path.join(src, sub); if (fs.existsSync(s)) { fs.cpSync(s, path.join(dir, b, sub), { recursive: true }); list.push(path.join(b, sub) + '/'); } }
  }
  let bytes = 0; const walk = (p) => { for (const e of fs.readdirSync(p, { withFileTypes: true })) { const f = path.join(p, e.name); e.isDirectory() ? walk(f) : (bytes += fs.statSync(f).size); } }; walk(dir);
  fs.writeFileSync(path.join(dir, 'MANIFEST.json'), JSON.stringify({ name, at: new Date().toISOString(), files: list, bytes }, null, 1));
  prune();
  await hook(dir);
  return { name, dir, files: list.length, bytes };
}
export function listBackups() {
  const d = BACKUP_DIR(); if (!fs.existsSync(d)) return [];
  return fs.readdirSync(d).filter((n) => /^\d{8}-\d{6}$/.test(n) && fs.existsSync(path.join(d, n, 'MANIFEST.json'))).sort().reverse()
    .map((n) => { const m = JSON.parse(fs.readFileSync(path.join(d, n, 'MANIFEST.json'), 'utf8')); return { name: n, at: m.at, bytes: m.bytes, files: m.files.length }; });
}
function prune() { for (const b of listBackups().slice(KEEP())) fs.rmSync(path.join(BACKUP_DIR(), b.name), { recursive: true, force: true }); }
/** Optional: copy the backup somewhere safe, such as a bucket. BACKUP_COMMAND runs with BACKUP_PATH set to the new folder. */
function hook(dir) {
  const cmd = process.env.BACKUP_COMMAND; if (!cmd) return Promise.resolve();
  return new Promise((resolve) => execFile('/bin/sh', ['-c', cmd], { env: { ...process.env, BACKUP_PATH: dir }, timeout: 600000 }, (err, _o, stderr) => { if (err) console.error('BACKUP_COMMAND failed:', err.message, String(stderr || '').slice(0, 300)); resolve(); }));
}

/** Puts a backup back. The server must be stopped. `tenant` restores one business only. What was there is kept in <data>/before-restore-<time>. */
export function restoreBackup(name, { tenant } = {}) {
  const src = path.join(BACKUP_DIR(), name); if (!fs.existsSync(path.join(src, 'MANIFEST.json'))) throw new Error('No such backup: ' + name);
  const keep = path.join(DATA_DIR, 'before-restore-' + stamp()); fs.mkdirSync(keep, { recursive: true });
  const targets = tenant ? [Number(tenant) === 1 ? '.' : path.join('tenants', String(Number(tenant)))] : [...businessDirs(), ...fs.existsSync(path.join(src, 'tenants')) ? fs.readdirSync(path.join(src, 'tenants')).map((n) => path.join('tenants', n)) : []];
  const uniq = [...new Set(targets)]; let n = 0;
  const wipe = (live) => { if (!fs.existsSync(live)) return; for (const f of fs.readdirSync(live)) if (/\.db(-wal|-shm)?$/.test(f) && f !== 'control.db') { const k = path.join(keep, path.relative(DATA_DIR, live)); fs.mkdirSync(k, { recursive: true }); fs.renameSync(path.join(live, f), path.join(k, f)); } };
  for (const b of uniq) {
    const from = path.join(src, b), live = path.join(DATA_DIR, b); if (!fs.existsSync(from)) continue;
    wipe(live); fs.mkdirSync(live, { recursive: true });
    for (const e of fs.readdirSync(from, { withFileTypes: true })) {
      if (e.isDirectory()) { if (['media', 'receipts'].includes(e.name)) fs.cpSync(path.join(from, e.name), path.join(live, e.name), { recursive: true, force: true }); }
      else if (isDb(e.name)) { fs.copyFileSync(path.join(from, e.name), path.join(live, e.name)); n++; }
    }
  }
  if (!tenant && fs.existsSync(path.join(src, 'control.db'))) { const cur = path.join(DATA_DIR, 'control.db'); if (fs.existsSync(cur)) { fs.copyFileSync(cur, path.join(keep, 'control.db')); for (const x of ['-wal', '-shm']) fs.rmSync(cur + x, { force: true }); } fs.copyFileSync(path.join(src, 'control.db'), cur); n++; }
  return { restored: n, previous: keep };
}

let timer;
/** A nightly backup at BACKUP_HOUR (default 3 am, server time). Off in tests or when BACKUP_ENABLED=0. */
export function startBackups() {
  if (process.env.BACKUP_ENABLED === '0' || process.env.NODE_ENV === 'test') return;
  const hour = Number(process.env.BACKUP_HOUR ?? 3), tick = async () => {
    const now = new Date(); if (now.getHours() !== hour) return;
    const today = stamp(now).slice(0, 8); if (listBackups().some((b) => b.name.startsWith(today))) return;
    try { const r = await backupAll(); console.log(`Backup ${r.name} done (${r.files} items, ${(r.bytes / 1048576).toFixed(1)} MB)`); } catch (e) { console.error('Backup failed:', e.message); }
  };
  timer = setInterval(tick, 600000); timer.unref(); setTimeout(tick, 15000).unref();
}

// Command line: node server/backup.js backup | list | restore <name> [--tenant <id>]
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(import.meta.filename)) {
  const [cmd, name, ...rest] = process.argv.slice(2);
  if (cmd === 'backup') { const r = await backupAll(); console.log(`Backup ${r.name}: ${r.files} items, ${(r.bytes / 1048576).toFixed(1)} MB\n${r.dir}`); }
  else if (cmd === 'list') for (const b of listBackups()) console.log(`${b.name}  ${(b.bytes / 1048576).toFixed(1)} MB  ${b.files} items`);
  else if (cmd === 'restore' && name) { const t = rest.indexOf('--tenant'); const r = restoreBackup(name, { tenant: t >= 0 ? rest[t + 1] : undefined }); console.log(`Restored ${r.restored} database(s). The previous files were kept in ${r.previous}. Start the server again.`); }
  else { console.log('Usage: node server/backup.js backup | list | restore <name> [--tenant <id>]'); process.exitCode = 1; }
}
