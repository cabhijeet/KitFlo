// SQLite (built into Node 22.5+). One file, WAL mode, append-only ledgers for stock and expenses.
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { AsyncLocalStorage } from 'node:async_hooks';

export const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, 'receipts'), { recursive: true });

// One database file per outlet, so menus, customers, stock, orders, expenses and settings can never mix.
// The first file (kitchen.db) is outlet #1 and also holds what is shared: sign-ins, sessions and the list of outlets.
const MAIN_FILE = process.env.DB_PATH || path.join(DATA_DIR, 'kitchen.db');
const PRAGMAS = 'PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA synchronous=NORMAL;';
const openFile = (file) => { const d = new DatabaseSync(file); d.exec(PRAGMAS); initSchema(d); return d; };
const addCol = (d, table, col, ddl) => { if (!d.prepare(`PRAGMA table_info(${table})`).all().some(c => c.name === col)) d.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${ddl}`); };

function initSchema(db) {
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL, pin_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, device TEXT, created_at TEXT, last_seen TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS channel_settings(channel TEXT PRIMARY KEY, label TEXT, commission_pct REAL NOT NULL DEFAULT 0, packaging_fee REAL NOT NULL DEFAULT 0, integration_provider TEXT NOT NULL DEFAULT 'none', provider_store_id TEXT, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, phone TEXT, terms TEXT, last_purchase_at TEXT);
CREATE TABLE IF NOT EXISTS menu_items(id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT, prices TEXT NOT NULL DEFAULT '{}', gst_rate REAL NOT NULL DEFAULT 5, external_ids TEXT NOT NULL DEFAULT '{}', off INTEGER NOT NULL DEFAULT 0, outlet TEXT NOT NULL DEFAULT 'main', created_at TEXT);
CREATE TABLE IF NOT EXISTS inventory_items(id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT, unit TEXT NOT NULL DEFAULT 'kg', reorder_level REAL NOT NULL DEFAULT 0, par_level REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0, supplier_id INTEGER, expiry_date TEXT, outlet TEXT NOT NULL DEFAULT 'main');
CREATE TABLE IF NOT EXISTS recipe_lines(id INTEGER PRIMARY KEY, menu_item_id INTEGER NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE, inventory_item_id INTEGER NOT NULL REFERENCES inventory_items(id), qty_per_portion REAL NOT NULL, wastage_pct REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY, inventory_item_id INTEGER NOT NULL REFERENCES inventory_items(id), type TEXT NOT NULL, qty REAL NOT NULL, order_id INTEGER, expense_id INTEGER, unit_cost REAL NOT NULL DEFAULT 0, moved_at TEXT NOT NULL, by_user TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ix_mv_item ON stock_movements(inventory_item_id, moved_at);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, name TEXT, phone TEXT UNIQUE, email TEXT, first_channel TEXT, whatsapp_opt_in INTEGER NOT NULL DEFAULT 0, created_at TEXT);
CREATE TABLE IF NOT EXISTS promos(code TEXT PRIMARY KEY, pct REAL NOT NULL, menu_item_id INTEGER, valid_until TEXT, post_id INTEGER, created_at TEXT);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY, order_no INTEGER NOT NULL UNIQUE, channel TEXT NOT NULL, channel_order_id TEXT, customer_id INTEGER REFERENCES customers(id),
  status TEXT NOT NULL DEFAULT 'new', placed_at TEXT NOT NULL, accepted_at TEXT, ready_at TEXT, completed_at TEXT,
  subtotal REAL NOT NULL DEFAULT 0, discount REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0, packaging_fee REAL NOT NULL DEFAULT 0,
  commission REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, payment_mode TEXT, food_cost REAL NOT NULL DEFAULT 0,
  promo_code TEXT, notes TEXT, address TEXT, needs_review INTEGER NOT NULL DEFAULT 0, deducted INTEGER NOT NULL DEFAULT 0, cancel_reason TEXT,
  outlet TEXT NOT NULL DEFAULT 'main', created_by TEXT, UNIQUE(channel, channel_order_id));
CREATE INDEX IF NOT EXISTS ix_orders_status ON orders(status, placed_at);
CREATE INDEX IF NOT EXISTS ix_orders_done ON orders(completed_at);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE, menu_item_id INTEGER, name TEXT NOT NULL, qty REAL NOT NULL, unit_price REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, gst_rate REAL NOT NULL DEFAULT 0, modifiers TEXT);
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, date TEXT NOT NULL, category TEXT NOT NULL, amount REAL NOT NULL, gst_amount REAL NOT NULL DEFAULT 0, vendor TEXT, payment_mode TEXT, receipt TEXT, source TEXT NOT NULL DEFAULT 'manual', recurring_id INTEGER, movement_id INTEGER, notes TEXT, entered_by TEXT, outlet TEXT NOT NULL DEFAULT 'main', created_at TEXT);
CREATE INDEX IF NOT EXISTS ix_exp_date ON expenses(date);
CREATE TABLE IF NOT EXISTS recurring_expenses(id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, amount REAL NOT NULL, frequency TEXT NOT NULL DEFAULT 'monthly', next_due TEXT NOT NULL, auto_post INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS social_posts(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, caption TEXT NOT NULL, media TEXT, platforms TEXT NOT NULL DEFAULT '[]', scheduled_at TEXT, status TEXT NOT NULL DEFAULT 'draft',
  origin TEXT NOT NULL DEFAULT 'manual', rule_id INTEGER, trigger_note TEXT, menu_item_id INTEGER, promo_code TEXT, platform_post_id TEXT, published_at TEXT, error TEXT, attempts INTEGER NOT NULL DEFAULT 0,
  impressions INTEGER NOT NULL DEFAULT 0, reach INTEGER NOT NULL DEFAULT 0, likes INTEGER NOT NULL DEFAULT 0, comments INTEGER NOT NULL DEFAULT 0, shares INTEGER NOT NULL DEFAULT 0, clicks INTEGER NOT NULL DEFAULT 0,
  winner INTEGER NOT NULL DEFAULT 0, simulated INTEGER NOT NULL DEFAULT 0, metrics_at TEXT, created_at TEXT, created_by TEXT);
CREATE TABLE IF NOT EXISTS automation_rules(id INTEGER PRIMARY KEY, name TEXT NOT NULL, trigger TEXT NOT NULL, conditions TEXT NOT NULL DEFAULT '[]', actions TEXT NOT NULL DEFAULT '[]', active INTEGER NOT NULL DEFAULT 1, requires_approval INTEGER NOT NULL DEFAULT 0, description TEXT, run_count INTEGER NOT NULL DEFAULT 0, last_run_at TEXT, last_error TEXT);
CREATE TABLE IF NOT EXISTS automation_runs(id INTEGER PRIMARY KEY, rule_id INTEGER, rule_name TEXT, event_type TEXT, input TEXT, status TEXT, output TEXT, error TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, type TEXT NOT NULL, payload TEXT, at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS integration_log(id INTEGER PRIMARY KEY, provider TEXT, direction TEXT, action TEXT, payload TEXT, status TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS idempotency(key TEXT NOT NULL, scope TEXT NOT NULL, status INTEGER, response TEXT, at TEXT, PRIMARY KEY(key, scope));
CREATE TABLE IF NOT EXISTS print_jobs(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, order_id INTEGER, printer_id TEXT NOT NULL, data BLOB NOT NULL, status TEXT NOT NULL DEFAULT 'queued', tries INTEGER NOT NULL DEFAULT 0, error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS print_jobs_status ON print_jobs(status, id);
`);

// Additive migrations so an existing kitchen.db upgrades in place.
for (const [c, d] of [['subcategory', 'TEXT'], ['description', 'TEXT'], ['image_url', 'TEXT'], ['catalogue_id', 'TEXT'], ['variant_name', 'TEXT'], ['variant_id', 'TEXT'], ['sort_order', 'INTEGER NOT NULL DEFAULT 0']]) addCol(db, 'menu_items', c, d);
for (const [c, d] of [['product_code', 'TEXT'], ['mrp', 'REAL'], ['main_ingredients', 'TEXT'], ['extra_ingredients', 'TEXT'], ['method', 'TEXT'], ['ingredient_cost', 'REAL'], ['op_cost', 'REAL'], ['pack_cost', 'REAL']]) addCol(db, 'menu_items', c, d);
for (const [c, d] of [['tax_inclusive', 'INTEGER NOT NULL DEFAULT 0'], ['pack_gst_rate', 'REAL NOT NULL DEFAULT 0'], ['tax_mode', "TEXT NOT NULL DEFAULT 'regular'"]]) addCol(db, 'orders', c, d);
for (const [c, d] of [['manual_discount', 'REAL NOT NULL DEFAULT 0'], ['discount_type', 'TEXT'], ['discount_value', 'REAL'], ['discount_reason', 'TEXT']]) addCol(db, 'orders', c, d);
for (const [c, d] of [['order_type', 'TEXT'], ['table_no', 'TEXT'], ['delivery_fee', 'REAL NOT NULL DEFAULT 0'], ['service_charge', 'REAL NOT NULL DEFAULT 0'], ['payments', 'TEXT'], ['charge_gst_rate', 'REAL NOT NULL DEFAULT 0']]) addCol(db, 'orders', c, d);
db.exec('CREATE TABLE IF NOT EXISTS day_closes(date TEXT PRIMARY KEY, opening_cash REAL NOT NULL DEFAULT 0, counted_cash REAL, expected_cash REAL NOT NULL DEFAULT 0, variance REAL, notes TEXT, report TEXT, closed_by TEXT, closed_at TEXT)');
db.exec(`
CREATE TABLE IF NOT EXISTS addon_groups(id INTEGER PRIMARY KEY, name TEXT NOT NULL, min_pick INTEGER NOT NULL DEFAULT 0, max_pick INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0, off INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS addons(id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL REFERENCES addon_groups(id) ON DELETE CASCADE, name TEXT NOT NULL, price REAL NOT NULL DEFAULT 0, cost REAL NOT NULL DEFAULT 0, inventory_item_id INTEGER, qty_per_use REAL NOT NULL DEFAULT 0, off INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS menu_addon_groups(menu_item_id INTEGER NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE, group_id INTEGER NOT NULL REFERENCES addon_groups(id) ON DELETE CASCADE, PRIMARY KEY(menu_item_id, group_id));
`);
addCol(db, 'order_items', 'addons', 'TEXT');
db.exec('CREATE INDEX IF NOT EXISTS ix_menu_variant ON menu_items(variant_id); CREATE INDEX IF NOT EXISTS ix_menu_cat ON menu_items(catalogue_id);');
}

/** What the shared file of a business needs on top of the normal tables: the list of outlets and who may work where. */
function initMain(d) {
  d.exec(`
CREATE TABLE IF NOT EXISTS outlets(id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL, city TEXT, code TEXT, db_file TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT);
CREATE TABLE IF NOT EXISTS user_outlets(user_id INTEGER NOT NULL, outlet_id INTEGER NOT NULL, PRIMARY KEY(user_id, outlet_id));
CREATE TABLE IF NOT EXISTS staff_devices(id INTEGER PRIMARY KEY, label TEXT, key_hash TEXT NOT NULL, created_at TEXT, last_seen TEXT, revoked INTEGER NOT NULL DEFAULT 0);
`);
  addCol(d, 'sessions', 'outlet_id', 'INTEGER');
  if (!d.prepare('SELECT COUNT(*) n FROM outlets').get().n) {
    d.prepare("INSERT INTO outlets(id,slug,name,code,db_file,created_at) VALUES(1,'main','Main kitchen','B',NULL,?)").run(new Date().toISOString());
    // An existing kitchen keeps working: everyone who could sign in before can use outlet #1.
    d.exec('INSERT OR IGNORE INTO user_outlets(user_id, outlet_id) SELECT id, 1 FROM users');
  }
}

// Each business (tenant) has its own folder: its shared file plus one file per extra outlet. Business #1 is the folder everything already lives in,
// so a single-kitchen install is simply the first business. Hosted mode adds more under data/tenants/<id>/.
const TENANTS_DIR = path.join(DATA_DIR, 'tenants');
export const tenantDir = (tid) => (Number(tid) === 1 ? DATA_DIR : path.join(TENANTS_DIR, String(Number(tid))));
const states = new Map(); // tenant id -> { dir, file, main, handles: Map(outlet id -> db) }
function stateFor(tid) {
  let st = states.get(tid); if (st) return st;
  const dir = tenantDir(tid), file = tid === 1 ? MAIN_FILE : path.join(dir, 'kitchen.db');
  for (const sub of ['receipts', 'media']) fs.mkdirSync(path.join(dir, sub), { recursive: true });
  const main = openFile(file); initMain(main);
  st = { dir, file, main, handles: new Map([[1, main]]) }; states.set(tid, st); return st;
}
/** Whether a business folder exists, without creating one. */
export const tenantExists = (tid) => Number(tid) === 1 || fs.existsSync(path.join(tenantDir(tid), 'kitchen.db'));

const als = new AsyncLocalStorage();
export const tenantId = () => als.getStore()?.tenant || 1;
const mainDb = () => stateFor(tenantId()).main;
/** The shared file of the current business. Kept as `db` so older callers keep working. */
export const db = new Proxy({}, { get: (_, p) => { const d = mainDb(), v = d[p]; return typeof v === 'function' ? v.bind(d) : v; } });
const handleFor = (id) => {
  const st = stateFor(tenantId()); let h = st.handles.get(id);
  if (h) return h;
  const row = st.main.prepare('SELECT * FROM outlets WHERE id=?').get(id);
  if (!row) throw new Error(`Unknown outlet ${id}`);
  h = openFile(row.db_file ? path.join(st.dir, row.db_file) : st.file); st.handles.set(id, h); return h;
};
/** Runs fn (and everything it awaits) as one business. Inside, the first outlet is used until withOutlet says otherwise. */
export const withTenant = (tid, fn) => { const t = Number(tid) || 1; return als.run({ tenant: t, id: 1, db: stateFor(t).main }, fn); };
/** Runs fn against one outlet's database, within the current business. */
export const withOutlet = (id, fn) => { const oid = Number(id) || 1; return als.run({ tenant: tenantId(), id: oid, db: handleFor(oid) }, fn); };
export const outletId = () => als.getStore()?.id || 1;
const cur = () => als.getStore()?.db || stateFor(1).main;

export const outletList = (activeOnly = false) => mainDb().prepare(`SELECT * FROM outlets ${activeOnly ? 'WHERE active=1' : ''} ORDER BY id`).all().map(o => ({ ...o, active: !!o.active }));
export const outletById = (id) => mainDb().prepare('SELECT * FROM outlets WHERE id=?').get(Number(id)) || null;
export const outletBySlug = (slug) => mainDb().prepare('SELECT * FROM outlets WHERE slug=? AND active=1').get(String(slug || '').toLowerCase()) || null;
/** Adds an outlet and creates its empty database. */
export function createOutlet({ slug, name, city = '', code = '' }) {
  const id = Number(mainDb().prepare('INSERT INTO outlets(slug,name,city,code,created_at) VALUES(?,?,?,?,?)').run(slug, name, city, code, new Date().toISOString()).lastInsertRowid);
  mainDb().prepare('UPDATE outlets SET db_file=? WHERE id=?').run(`outlet-${id}.db`, id);
  handleFor(id); return id;
}
/** Copies set-up data (never orders, customers, expenses or stock counts) from one outlet's file into another's, matching columns by name. */
export function copyOutletData(fromId, toId, parts) {
  const src = outletById(fromId); if (!src) throw new Error('Unknown outlet to copy from');
  const st = stateFor(tenantId()), file = src.db_file ? path.join(st.dir, src.db_file) : st.file, d = handleFor(Number(toId));
  const copyTable = (t) => {
    const dc = d.prepare(`PRAGMA main.table_info(${t})`).all().map(c => c.name), sc = new Set(d.prepare(`PRAGMA src.table_info(${t})`).all().map(c => c.name));
    const cols = dc.filter(c => sc.has(c)).join(','); if (cols) d.exec(`INSERT OR REPLACE INTO main.${t}(${cols}) SELECT ${cols} FROM src.${t}`);
  };
  const copySettings = (keys) => { for (const k of keys) { const r = d.prepare('SELECT value FROM src.settings WHERE key=?').get(k); if (r) d.prepare('INSERT OR REPLACE INTO main.settings(key,value) VALUES(?,?)').run(k, r.value); } };
  d.prepare('ATTACH DATABASE ? AS src').run(file);
  try {
    d.exec('BEGIN');
    if (parts.menu) { for (const t of ['suppliers', 'inventory_items', 'menu_items', 'recipe_lines', 'addon_groups', 'addons', 'menu_addon_groups']) copyTable(t); copySettings(['sales_baseline']); }
    if (parts.rates) {
      d.exec('DELETE FROM main.channel_settings'); copyTable('channel_settings'); d.exec("UPDATE main.channel_settings SET provider_store_id=NULL");
      copySettings(['gst', 'bill', 'prep_minutes', 'lapsed_days', 'discount_limit_pct', 'budgets']);
    }
    if (parts.rules) { d.exec('DELETE FROM main.automation_rules'); copyTable('automation_rules'); }
    d.exec('COMMIT');
  } catch (e) { try { d.exec('ROLLBACK'); } catch {} throw e; }
  finally { d.exec('DETACH DATABASE src'); }
}
export function closeAll() { for (const st of states.values()) for (const h of st.handles.values()) { try { h.close(); } catch { /* already closed */ } } states.clear(); }

/** Query helpers. `q` follows the current outlet; `gq` always talks to the shared file (users, sessions, outlets). */
const helpers = (get) => ({
  all: (sql, ...p) => get().prepare(sql).all(...p),
  get: (sql, ...p) => get().prepare(sql).get(...p),
  run: (sql, ...p) => get().prepare(sql).run(...p),
});
export const q = helpers(cur);
export const gq = helpers(mainDb);

const depths = new WeakMap();
/** Run fn atomically; nested calls join the outer transaction. */
export function tx(fn) {
  const d = cur(), depth = depths.get(d) || 0;
  if (depth > 0) return fn();
  d.exec('BEGIN IMMEDIATE');
  depths.set(d, 1);
  try { const r = fn(); d.exec('COMMIT'); return r; }
  catch (e) { try { d.exec('ROLLBACK'); } catch {} throw e; }
  finally { depths.set(d, 0); }
}
// ---- time helpers. The server runs in the kitchen's time zone (TZ env, default Asia/Kolkata). ----
export const now = () => new Date().toISOString();
const pad = n => String(n).padStart(2, '0');
export const ymd = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
export const dayStartISO = (dateStr) => new Date(dateStr + 'T00:00:00').toISOString();
export const parseYmd = (s) => new Date(s + 'T00:00:00');

export const getSetting = (key, fallback = null) => {
  const r = q.get('SELECT value FROM settings WHERE key=?', key);
  if (!r) return fallback;
  try { return JSON.parse(r.value); } catch { return fallback; }
};
export const setSetting = (key, value) => { q.run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, JSON.stringify(value)); };

export const parseJson = (s, fb) => { try { return s ? JSON.parse(s) : fb; } catch { return fb; } };
export const round2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
