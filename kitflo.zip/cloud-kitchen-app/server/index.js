process.env.TZ = process.env.TZ || 'Asia/Kolkata';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { q, gq, db, withOutlet, withTenant, tenantId, tenantDir, outletId, outletList, outletById, outletBySlug, createOutlet, copyOutletData, closeAll, tx, now, ymd, addDays, parseYmd, getSetting, setSetting, parseJson, round2, DATA_DIR } from './db.js';
import { HttpError, bad, createRouter, readBody, send, serveStatic } from './http.js';
import { bus, emit, openStream, connectedDevices } from './bus.js';
import { login, clientIp, userFromToken, need, can, capsFor, hashPin, ROLES, outletsFor, switchOutlet } from './auth.js';
import * as D from './domain.js';
import * as S from './social.js';
import * as A from './analytics.js';
import { startAutomations, ACTION_TYPES, runRuleNow } from './automations.js';
import { normalizeInbound, resolveItems, outbound, PROVIDERS, webhookSecretFor, providerStatus } from './integrations/aggregator.js';
import * as WA from './integrations/whatsapp.js';
import { firstRun, seedOutletBasics } from './seed.js';
import * as C from './control.js';
import { installPrinting } from './printing.js';
import { backupAll, listBackups, startBackups } from './backup.js';
import { installHosted, startHosted, tenantFromRequest, tenantless, gateExempt, checkLimit, billingSummary } from './hosted.js';
import { checkStaffDevice } from './auth.js';

const PROD = process.env.NODE_ENV === 'production';
const SIM_ON = () => process.env.ENABLE_SIMULATOR === '1' || (!PROD && process.env.ENABLE_SIMULATOR !== '0');
const PUBLIC_DIR = path.resolve(import.meta.dirname, '../public');
/** Each business keeps its own pictures and receipts. Business 1 keeps them where they always were. */
const mediaDir = (tid = tenantId()) => { const d = path.join(tenantDir(tid), 'media'); fs.mkdirSync(d, { recursive: true }); return d; };
const receiptDir = () => { const d = path.join(tenantDir(tenantId()), 'receipts'); fs.mkdirSync(d, { recursive: true }); return d; };
const HANDLED = Symbol('handled');

const router = createRouter();
/** R(method, path, cap, handler): cap null = public, '*' = any signed-in user, otherwise a capability from auth.js. */
const R = (method, p, cap, fn) => router[method.toLowerCase()](p, async (ctx) => {
  if (cap === '*') { if (!ctx.user) throw new HttpError(401, 'Sign in required'); } else if (cap) need(ctx.user, cap);
  return fn(ctx);
});
const id = (ctx) => { const n = Number(ctx.params.id); if (!Number.isInteger(n) || n < 1) throw bad('Bad id'); return n; };

// ───────────────────────── Public / auth ─────────────────────────
R('GET', '/healthz', null, () => ({ ok: true, at: now(), devices: connectedDevices() }));
installHosted(R);
installPrinting(R);
R('GET', '/api/admin/backups', 'settings', () => (C.MULTI() ? [] : listBackups()));
R('POST', '/api/admin/backups', 'settings', async () => { if (C.MULTI()) throw new HttpError(404, 'Not found'); const r = await backupAll(); return { name: r.name, files: r.files, bytes: r.bytes }; });
R('GET', '/api/users', null, () => gq.all("SELECT id, name, role FROM users WHERE active=1 ORDER BY id"));
R('POST', '/api/login', null, ({ body, req }) => login(body.user_id, body.pin, clientIp(req), body.device || req.headers['user-agent']));
R('POST', '/api/logout', '*', ({ user }) => { gq.run('DELETE FROM sessions WHERE token=?', user.token); return { ok: true }; });
R('GET', '/api/me', '*', ({ user }) => {
  const priv = can(user, 'analytics');
  return {
    user: { id: user.id, name: user.name, role: user.role }, caps: capsFor(user), outlet: outletById(user.outlet_id) && { id: user.outlet_id, name: outletById(user.outlet_id).name, slug: outletById(user.outlet_id).slug }, outlets: outletsFor(user).map(o => ({ id: o.id, name: o.name, slug: o.slug, city: o.city })),
    billing: C.MULTI() ? (() => { const b = billingSummary(); return b && { ok: b.ok, state: b.state, message: b.message, days_left: b.days_left, renew_soon: b.renew_soon, plan: b.plan, plan_name: b.plan_name }; })() : undefined,
    hosted: C.MULTI() || undefined,
    config: {
      channels: q.all('SELECT channel, label, commission_pct, active FROM channel_settings'), expense_categories: D.EXPENSE_CATEGORIES, payment_modes: D.PAYMENT_MODES, cancel_reasons: D.CANCEL_REASONS, order_types: D.ORDER_TYPES, charges: D.chargesCfg(), platforms: S.PLATFORMS,
      business: getSetting('business', {}), prep_minutes: getSetting('prep_minutes', 25), discount_limit_pct: getSetting('discount_limit_pct', 30), social_adapter: S.adapterName(), demo: !!getSetting('demo', false), simulator: SIM_ON(),
      integrations: priv ? integrationStatus() : undefined,
    },
  };
});
const integrationStatus = () => ({
  aggregator_webhook_secret_set: !!process.env.AGGREGATOR_WEBHOOK_SECRET, aggregator_outbound_configured: !!process.env.AGGREGATOR_OUTBOUND_URL, providers: providerStatus(),
  whatsapp_configured: !!(process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_ID), social_adapter: S.adapterName(), connected_devices: connectedDevices(),
});
R('GET', '/api/stream', '*', ({ req, res, user }) => { openStream(req, res, user); return HANDLED; });

// ───────────────────────── Orders and kitchen ─────────────────────────
R('GET', '/api/orders', 'orders', ({ query }) => (query.status || query.channel || query.from || query.to) ? D.ordersSearch(query) : D.ordersBoard());
R('POST', '/api/orders', 'orders_create', (ctx) => {
  const r = D.createOrder({ ...ctx.body, channel: ctx.body.channel || 'walkin' }, { user: ctx.user, accept: !!ctx.body.accept });
  ctx.status = r.duplicate ? 200 : 201; return r;
});
R('GET', '/api/orders/:id', 'orders', (c) => { const o = D.orderFull(id(c)); if (!o) throw new HttpError(404, 'Order not found'); return o; });
R('PATCH', '/api/orders/:id', 'orders_create', (c) => {
  const o = q.get('SELECT * FROM orders WHERE id=?', id(c)); if (!o) throw new HttpError(404, 'Order not found');
  if (['completed', 'cancelled'].includes(o.status)) throw bad('Finished orders cannot be edited');
  const b = c.body;
  q.run('UPDATE orders SET notes=COALESCE(?,notes), address=COALESCE(?,address), payment_mode=COALESCE(?,payment_mode) WHERE id=?', b.notes ?? null, b.address ?? null, b.payment_mode ?? null, o.id);
  emit('order.updated', { id: o.id }); return D.orderFull(o.id);
});
R('POST', '/api/orders/:id/status', 'orders', (c) => {
  const to = String(c.body.status || '');
  if (c.user.role === 'kitchen' && !['accepted', 'preparing', 'ready'].includes(to)) throw new HttpError(403, 'Kitchen can accept, start and mark orders ready');
  return D.setOrderStatus(id(c), to, c.user, c.body.reason);
});
R('DELETE', '/api/orders/:id', 'orders_create', (c) => D.setOrderStatus(id(c), 'cancelled', c.user, c.query.reason || 'Cancelled'));
R('POST', '/api/orders/:id/payments', 'orders_create', (c) => D.setPayments(id(c), c.body.payments, c.user));
R('GET', '/api/orders/:id/bill', 'orders', (c) => D.billFor(id(c)));
R('GET', '/api/kitchen/queue', 'kitchen', () => {
  const orders = D.ordersSearch({ limit: 300 }).filter(o => ['accepted', 'preparing'].includes(o.status)).sort((a, b) => a.promised_at.localeCompare(b.promised_at));
  const totals = new Map();
  for (const o of orders) for (const i of o.items) totals.set(i.name, (totals.get(i.name) || 0) + i.qty);
  return { orders, to_prepare: [...totals].map(([name, qty]) => ({ name, qty })).sort((a, b) => b.qty - a.qty) };
});

// ───────────────────────── Inbound channels ─────────────────────────
const secretOk = (req, provider) => {
  const secret = webhookSecretFor(provider) || (PROD ? null : 'dev-secret');
  const got = String(req.headers['x-webhook-secret'] || '');
  if (!secret) throw new HttpError(503, 'Webhook secret is not configured on the server');
  return got.length === secret.length && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(secret));
};
function ingestAggregator(provider, body) {
  const n = normalizeInbound(provider, body);
  if (!n.channel) throw bad('Could not tell which channel the order is from (Swiggy, Zomato or your website)');
  if (!n.channel_order_id) throw bad('Order has no channel_order_id');
  if (!n.items.length) throw bad('Order has no items');
  const r = D.createOrder({ ...n, items: resolveItems(n.channel, n.items) }, { user: { name: provider }, trustPrices: true });
  if (r.order.needs_review) emit('notice', { level: 'warn', text: `Order #${r.order.order_no} has dishes that are not mapped to your menu. Check it before accepting.`, roles: ['owner', 'manager', 'cashier'] });
  return { ok: true, order_no: r.order.order_no, duplicate: r.duplicate };
}
R('POST', '/api/webhooks/aggregator/:provider', null, (c) => {
  const prov = c.params.provider.toLowerCase().slice(0, 20);
  if (!PROVIDERS.includes(prov)) throw new HttpError(404, 'Unknown integration partner');
  if (!secretOk(c.req, prov)) throw new HttpError(401, 'Bad webhook secret');
  D_log('in', prov, c.body);
  return ingestAggregator(prov, c.body);
});
const D_log = (dir, prov, body) => q.run('INSERT INTO integration_log(provider,direction,action,payload,status,at) VALUES(?,?,?,?,?,?)', prov, dir, 'order', JSON.stringify(body).slice(0, 2000), 'received', now());
R('GET', '/api/webhooks/whatsapp', null, ({ query, res }) => { const ch = WA.verifySubscription(query); if (ch === null) throw new HttpError(403, 'Verification failed'); send(res, 200, ch); return HANDLED; });
R('POST', '/api/webhooks/whatsapp', null, async (c) => { if (!WA.signatureOk(c.req)) throw new HttpError(401, 'Bad signature'); await WA.handleInbound(c.body); return { ok: true }; });

// ───────────────────────── Website ordering (public) ─────────────────────────
const hits = new Map();
const limited = (ip, max, windowMs) => { const t = Date.now(); const a = (hits.get(ip) || []).filter(x => t - x < windowMs); a.push(t); hits.set(ip, a); return a.length > max; };
setInterval(() => { const t = Date.now(); for (const [k, v] of hits) if (!v.some(x => t - x < 600000)) hits.delete(k); }, 300000).unref();
R('GET', '/api/public/menu', null, () => ({ paused: D.categoryList().filter(c => c.off).map(c => c.name), business: getSetting('business', {}).name || 'Kitchen', addon_groups: D.addonGroups().filter(g => !g.off).map(g => ({ id: g.id, name: g.name, min_pick: g.min_pick, max_pick: g.max_pick, addons: g.addons.filter(a => a.available).map(a => ({ id: a.id, name: a.name, price: a.price })) })), items: D.menuList().filter(m => m.available).map(m => ({ id: m.id, addon_group_ids: m.addon_group_ids, group_key: m.group_key, name: m.name, variant_name: m.variant_name, category: m.category, subcategory: m.subcategory, description: m.description, image_url: m.image_url, price: m.prices.website ?? m.prices.default })) }));
R('POST', '/api/public/checkout', null, (c) => {
  if (limited('co|' + clientIp(c.req), 10, 600000)) throw new HttpError(429, 'Too many orders from this device. Try again shortly.');
  const b = c.body;
  if (!D.normPhone(b.customer?.phone)) throw bad('Enter a valid 10-digit phone number');
  if (!String(b.customer?.name || '').trim()) throw bad('Enter your name');
  if (!String(b.address || '').trim()) throw bad('Enter a delivery address');
  const items = (Array.isArray(b.items) ? b.items : []).map(i => ({ menu_item_id: i.menu_item_id, qty: i.qty, addons: i.addons, modifiers: String(i.modifiers || '').slice(0, 120) || undefined }));
  for (const it of items) { const m = D.menuList().find(x => x.id === Number(it.menu_item_id)); if (!m || !m.available) throw bad(`${m ? m.name : 'A dish'} is not available right now`); }
  const r = D.createOrder({ channel: 'website', customer: { name: b.customer.name, phone: b.customer.phone }, address: b.address, notes: b.notes, items, promo_code: b.promo_code, payment_mode: 'Pay on delivery' }, { user: { name: 'Website' } });
  c.status = 201;
  return { order_no: r.order.order_no, total: r.order.total, discount: r.order.discount, warnings: r.warnings };
});
R('GET', '/api/public/track', null, (c) => {
  if (limited('tr|' + clientIp(c.req), 30, 600000)) throw new HttpError(429, 'Slow down');
  const o = q.get('SELECT o.order_no, o.status, o.placed_at, o.total, c.phone FROM orders o LEFT JOIN customers c ON c.id=o.customer_id WHERE o.order_no=? AND o.channel=?', Number(c.query.order_no), 'website');
  if (!o || !c.query.phone || D.normPhone(c.query.phone) !== o.phone) throw new HttpError(404, 'Order not found');
  return { order_no: o.order_no, status: o.status, placed_at: o.placed_at, total: o.total };
});

// ───────────────────────── Menu ─────────────────────────
R('POST', '/api/menu-gst', 'menu_write', (c) => D.setMenuGst(c.body.rate, c.body.category ? String(c.body.category) : null));
R('GET', '/api/menu-items', 'menu_read', () => D.menuList());
R('GET', '/api/addons', 'menu_read', () => D.addonGroups());
R('GET', '/api/addons/sales', 'menu_read', (c) => D.addonSales(Math.min(365, Math.max(1, Number(c.query.days) || 30))));
R('POST', '/api/addons', 'menu_write', (c) => { c.status = 201; return D.saveAddonGroup(null, c.body); });
R('PUT', '/api/addons/:id', 'menu_write', (c) => D.saveAddonGroup(id(c), c.body));
R('DELETE', '/api/addons/:id', 'menu_write', (c) => D.deleteAddonGroup(id(c)));
R('PUT', '/api/menu-items/:id/addons', 'menu_write', (c) => D.setItemAddonGroups(id(c), c.body.group_ids));
R('GET', '/api/menu-categories', 'menu_read', () => D.categoryList());
R('POST', '/api/menu-categories/availability', 'stock_write', (c) => D.setCategoryOff(String(c.body.name || ''), !!c.body.off, { until: c.body.until }, c.user));
R('GET', '/api/analytics/menu-engineering', 'analytics', ({ query }) => D.menuEngineering({ days: query.days, source: query.source, category: query.category }));
R('PUT', '/api/targets', 'analytics', (c) => {
  const b = c.body, t = {};
  for (const [k, lo, hi] of [['monthly_operational_cost', 0, 1e8], ['avg_ticket', 1, 1e5], ['cost_share_pct', 1, 100], ['days', 1, 31]]) { const n = Number(b[k]); if (!Number.isFinite(n) || n < lo || n > hi) throw bad(`${k.replace(/_/g, ' ')} must be between ${lo} and ${hi}`); t[k] = n; }
  setSetting('targets', t); return { ok: true };
});
R('POST', '/api/menu-sales', 'menu_write', (c) => D.saveSalesBaseline(c.body.rows));
R('POST', '/api/menu-items/import', 'menu_write', (c) => { const r = D.importMenu(c.body.rows); emit('menu.updated', { import: true }); return r; });
R('POST', '/api/menu-groups', 'menu_write', (c) => { c.status = 201; return D.saveMenuGroup(null, c.body); });
R('PUT', '/api/menu-groups/:key', 'menu_write', (c) => D.saveMenuGroup(c.params.key, c.body));
R('DELETE', '/api/menu-groups/:key', 'menu_write', (c) => {
  const rows = D.menuList().filter(m => m.group_key === c.params.key); if (!rows.length) throw new HttpError(404, 'Dish not found');
  if (rows.some(m => q.get('SELECT 1 x FROM order_items WHERE menu_item_id=? LIMIT 1', m.id))) throw bad('This dish has order history. Switch it off instead of deleting it.');
  tx(() => rows.forEach(m => q.run('DELETE FROM menu_items WHERE id=?', m.id))); emit('menu.updated', { key: c.params.key }); return { ok: true };
});
R('POST', '/api/menu-items', 'menu_write', (c) => { c.status = 201; return D.saveMenuItem(null, c.body); });
R('PATCH', '/api/menu-items/:id', 'menu_write', (c) => D.saveMenuItem(id(c), { ...D.menuList().find(m => m.id === id(c)), ...c.body }));
R('PUT', '/api/menu-items/:id/recipe', 'menu_write', (c) => D.saveMenuItem(id(c), { ...D.menuList().find(m => m.id === id(c)), recipe: c.body.recipe || [] }));
R('GET', '/api/menu-items/:id/recipe', 'menu_read', (c) => (D.menuList().find(m => m.id === id(c)) || (() => { throw new HttpError(404, 'Dish not found'); })()).recipe);
R('DELETE', '/api/menu-items/:id', 'menu_write', (c) => {
  if (q.get('SELECT 1 x FROM order_items WHERE menu_item_id=? LIMIT 1', id(c))) throw bad('This dish has order history. Switch it off instead of deleting it.');
  q.run('DELETE FROM menu_items WHERE id=?', id(c)); emit('menu.updated', { id: id(c) }); return { ok: true };
});
R('POST', '/api/menu-items/:id/availability', 'stock_write', async (c) => {
  const m = D.menuList().find(x => x.id === id(c)); if (!m) throw new HttpError(404, 'Dish not found');
  const off = c.body.off ? 1 : 0;
  q.run('UPDATE menu_items SET off=? WHERE id=?', off, m.id);
  for (const ch of q.all("SELECT * FROM channel_settings WHERE channel IN ('swiggy','zomato','website') AND integration_provider!='none'"))
    outbound(ch.integration_provider, 'set_stock', { channel: ch.channel, store_id: ch.provider_store_id, item_id: m.external_ids[ch.channel] || null, name: m.name, in_stock: !off }).catch(() => {});
  emit('menu.updated', { id: m.id, off: !!off });
  return D.menuList().find(x => x.id === m.id);
});

// ───────────────────────── Inventory ─────────────────────────
R('GET', '/api/inventory-items', 'stock_read', () => D.inventoryList());
R('POST', '/api/inventory-items', 'menu_write', (c) => { c.status = 201; const r = D.saveInventoryItem(null, c.body); emit('stock.changed', { item_id: r.id }); D.checkStockEvents(); return r; });
R('PATCH', '/api/inventory-items/:id', 'menu_write', (c) => { const cur = q.get('SELECT * FROM inventory_items WHERE id=?', id(c)); if (!cur) throw new HttpError(404, 'Item not found'); const r = D.saveInventoryItem(id(c), { ...cur, ...c.body }); emit('stock.changed', { item_id: r.id }); D.checkStockEvents(); return r; });
R('DELETE', '/api/inventory-items/:id', 'menu_write', (c) => {
  if (q.get('SELECT 1 x FROM recipe_lines WHERE inventory_item_id=? LIMIT 1', id(c))) throw bad('A dish recipe uses this item. Remove it from the recipe first.');
  if (q.get("SELECT 1 x FROM stock_movements WHERE inventory_item_id=? AND type NOT IN ('opening') LIMIT 1", id(c))) throw bad('This item has stock history and cannot be deleted.');
  tx(() => { q.run('DELETE FROM stock_movements WHERE inventory_item_id=?', id(c)); q.run('DELETE FROM inventory_items WHERE id=?', id(c)); }); emit('stock.changed', {}); return { ok: true };
});
R('GET', '/api/inventory/alerts', 'stock_read', () => {
  const items = D.inventoryList();
  return {
    low: items.filter(i => i.low), surplus: items.filter(i => i.surplus), expiring: items.filter(i => i.expires_in_days !== null && i.expires_in_days <= 2 && i.on_hand > 0),
    purchase_list: items.filter(i => i.on_hand < i.par_level && (i.low || i.on_hand < i.par_level * 0.6)).map(i => ({ id: i.id, name: i.name, unit: i.unit, on_hand: i.on_hand, suggested_qty: Math.ceil((i.par_level - i.on_hand) * 10) / 10, est_cost: round2((i.par_level - i.on_hand) * i.unit_cost), supplier: i.supplier })),
  };
});
R('GET', '/api/stock-movements', 'stock_read', ({ query }) => q.all(`SELECT m.*, i.name item, i.unit FROM stock_movements m JOIN inventory_items i ON i.id=m.inventory_item_id ${query.item_id ? 'WHERE m.inventory_item_id=?' : ''} ORDER BY m.id DESC LIMIT ?`, ...(query.item_id ? [Number(query.item_id)] : []), Math.min(Number(query.limit) || 60, 300)));
R('POST', '/api/stock-movements', 'stock_write', (c) => {
  c.status = 201;
  if (c.body.type === 'purchase') { if (!can(c.user, 'expenses') && c.user.role !== 'kitchen') throw new HttpError(403, 'Your role cannot record purchases'); return D.recordPurchase(c.body, c.user); }
  return D.recordWastage(c.body, c.user);
});
R('GET', '/api/suppliers', 'stock_read', () => q.all('SELECT * FROM suppliers ORDER BY name'));
R('POST', '/api/suppliers', 'menu_write', (c) => { const n = String(c.body.name || '').trim(); if (!n) throw bad('Supplier name is required'); q.run('INSERT INTO suppliers(name,phone,terms) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET phone=excluded.phone, terms=excluded.terms', n, c.body.phone || null, c.body.terms || null); c.status = 201; return q.get('SELECT * FROM suppliers WHERE name=?', n); });

// ───────────────────────── Customers ─────────────────────────
R('GET', '/api/customers', 'customers', ({ query }) => { let l = D.customersList(); if (query.phone) { const p = D.normPhone(query.phone); l = l.filter(c => c.phone === p); } if (query.segment) l = l.filter(c => c.segment === query.segment); return l; });
R('GET', '/api/customers/:id/orders', 'customers', (c) => { const rows = q.all("SELECT id FROM orders WHERE customer_id=? ORDER BY placed_at DESC LIMIT 50", id(c)).map(r => D.orderFull(r.id)); const fav = {}; rows.forEach(o => o.items.forEach(i => fav[i.name] = (fav[i.name] || 0) + i.qty)); return { orders: rows, favourites: Object.entries(fav).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, qty]) => ({ name, qty })) }; });
R('PATCH', '/api/customers/:id', 'customers', (c) => { q.run('UPDATE customers SET name=COALESCE(?,name), email=COALESCE(?,email), whatsapp_opt_in=COALESCE(?,whatsapp_opt_in) WHERE id=?', c.body.name ?? null, c.body.email ?? null, c.body.whatsapp_opt_in === undefined ? null : (c.body.whatsapp_opt_in ? 1 : 0), id(c)); return q.get('SELECT * FROM customers WHERE id=?', id(c)); });

// ───────────────────────── Expenses ─────────────────────────
R('GET', '/api/expenses', 'expenses', ({ query }) => {
  const w = [], p = [];
  if (query.from) { w.push('date>=?'); p.push(query.from); } if (query.to) { w.push('date<=?'); p.push(query.to); }
  if (query.category) { w.push('category=?'); p.push(query.category); } if (query.source) { w.push('source=?'); p.push(query.source); }
  const rows = q.all(`SELECT * FROM expenses ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY date DESC, id DESC LIMIT 500`, ...p);
  return { rows, total: round2(rows.reduce((s, r) => s + r.amount, 0)) };
});
R('POST', '/api/expenses', 'expenses', (c) => { c.status = 201; return D.addExpense(c.body, c.user); });
R('PATCH', '/api/expenses/:id', 'expenses', (c) => {
  const e = q.get('SELECT * FROM expenses WHERE id=?', id(c)); if (!e) throw new HttpError(404, 'Expense not found');
  if (e.movement_id) throw bad('This expense came from a stock purchase. Adjust the stock instead.');
  const b = { ...e, ...c.body };
  if (!D.EXPENSE_CATEGORIES.includes(b.category)) throw bad('Pick a valid category');
  const amt = Number(b.amount); if (!(amt > 0)) throw bad('Amount is not valid');
  q.run('UPDATE expenses SET date=?, category=?, amount=?, vendor=?, payment_mode=?, notes=? WHERE id=?', b.date, b.category, round2(amt), b.vendor, b.payment_mode, b.notes, e.id);
  emit('expense.updated', { id: e.id }); return q.get('SELECT * FROM expenses WHERE id=?', e.id);
});
R('DELETE', '/api/expenses/:id', 'expenses', (c) => { D.deleteExpense(id(c)); return { ok: true }; });
R('GET', '/api/recurring-expenses', 'expenses', () => q.all('SELECT * FROM recurring_expenses ORDER BY next_due'));
const recurClean = (b) => {
  if (!D.EXPENSE_CATEGORIES.includes(b.category)) throw bad('Pick a valid category');
  if (!(Number(b.amount) > 0)) throw bad('Amount is not valid');
  if (!['daily', 'weekly', 'monthly', 'yearly'].includes(b.frequency)) throw bad('Pick a frequency');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.next_due || '')) throw bad('Pick the next due date');
  if (!String(b.name || '').trim()) throw bad('Give it a name');
  return [String(b.name).trim().slice(0, 80), b.category, Number(b.amount), b.frequency, b.next_due, b.auto_post ? 1 : 0, b.active === false ? 0 : 1];
};
R('POST', '/api/recurring-expenses', 'expenses', (c) => { c.status = 201; const r = q.run('INSERT INTO recurring_expenses(name,category,amount,frequency,next_due,auto_post,active) VALUES(?,?,?,?,?,?,?)', ...recurClean(c.body)); return q.get('SELECT * FROM recurring_expenses WHERE id=?', Number(r.lastInsertRowid)); });
R('PATCH', '/api/recurring-expenses/:id', 'expenses', (c) => { const cur = q.get('SELECT * FROM recurring_expenses WHERE id=?', id(c)); if (!cur) throw new HttpError(404, 'Not found'); q.run('UPDATE recurring_expenses SET name=?, category=?, amount=?, frequency=?, next_due=?, auto_post=?, active=? WHERE id=?', ...recurClean({ ...cur, ...c.body }), cur.id); return q.get('SELECT * FROM recurring_expenses WHERE id=?', cur.id); });
R('DELETE', '/api/recurring-expenses/:id', 'expenses', (c) => { q.run('DELETE FROM recurring_expenses WHERE id=?', id(c)); return { ok: true }; });
R('POST', '/api/recurring-expenses/:id/confirm', 'expenses', (c) => { D.postRecurring(id(c), c.user, 'recurring'); return { ok: true }; });
R('POST', '/api/recurring-expenses/:id/skip', 'expenses', (c) => { D.skipRecurring(id(c)); return { ok: true }; });
R('GET', '/api/budgets', 'expenses', () => D.budgetStatus());
R('PUT', '/api/budgets', 'expenses', (c) => {
  const b = {}; for (const [k, v] of Object.entries(c.body || {})) { if (!D.EXPENSE_CATEGORIES.includes(k)) continue; const n = Number(v); if (n > 0) b[k] = n; else if (v !== '' && v != null && n !== 0) throw bad('Budget is not valid'); }
  setSetting('budgets', b); emit('budget.updated', {}); return D.budgetStatus();
});

// ───────────────────────── Uploads ─────────────────────────
function saveImage(dataUrl, dir) {
  const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw bad('Upload a PNG, JPEG or WebP image');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 6 * 1024 * 1024) throw bad('Image is larger than 6 MB');
  const file = crypto.randomBytes(16).toString('hex') + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
  fs.writeFileSync(path.join(dir, file), buf);
  return file;
}
R('POST', '/api/uploads/receipt', 'expenses', (c) => ({ file: saveImage(c.body.data_url, receiptDir()) }));
R('POST', '/api/uploads/media', 'social', (c) => { const f = saveImage(c.body.data_url, mediaDir()); return { file: f, url: (tenantId() === 1 ? '/media/' : `/media/t${tenantId()}/`) + f }; });
R('GET', '/api/receipts/:file', 'expenses', ({ params, res }) => {
  if (!/^[a-f0-9]{32}\.(jpg|png|webp)$/.test(params.file)) throw new HttpError(404, 'Not found');
  const f = path.join(receiptDir(), params.file); if (!fs.existsSync(f)) throw new HttpError(404, 'Not found');
  res.writeHead(200, { 'Content-Type': params.file.endsWith('png') ? 'image/png' : params.file.endsWith('webp') ? 'image/webp' : 'image/jpeg', 'Cache-Control': 'private, max-age=3600' }); fs.createReadStream(f).pipe(res); return HANDLED;
});

// ───────────────────────── Social ─────────────────────────
R('GET', '/api/social/posts', 'social', ({ query }) => S.postsList(query));
R('POST', '/api/social/posts', 'social', (c) => { c.status = 201; return S.createPost(c.body, c.user); });
R('GET', '/api/social/posts/:id', 'social', (c) => S.postsList().find(p => p.id === id(c)) || (() => { throw new HttpError(404, 'Post not found'); })());
R('PATCH', '/api/social/posts/:id', 'social', (c) => S.updatePost(id(c), c.body));
R('DELETE', '/api/social/posts/:id', 'social', (c) => { S.deletePost(id(c)); return { ok: true }; });
R('POST', '/api/social/posts/:id/approve', 'social', (c) => S.approvePost(id(c)));
R('POST', '/api/social/posts/:id/publish-now', 'social', async (c) => { const r = await S.publishPost(id(c)); if (!r) throw bad('This post cannot be published now'); return r; });
R('GET', '/api/social/posts/:id/metrics', 'social', (c) => { const p = S.postsList().find(x => x.id === id(c)); if (!p) throw new HttpError(404, 'Post not found'); const { reach, impressions, likes, comments, shares, clicks, engagement_rate, attributed_orders, attributed_revenue, attributed_profit } = p; return { reach, impressions, likes, comments, shares, clicks, engagement_rate, attributed_orders, attributed_revenue, attributed_profit, simulated: p.simulated }; });
R('GET', '/api/social/calendar', 'social', ({ query }) => { const from = query.from || ymd(); const to = query.to || ymd(addDays(parseYmd(from), 6)); return { from, to, posts: S.postsList({ from, to }).filter(p => p.scheduled_at) }; });
R('POST', '/api/social/captions/suggest', 'social', (c) => ({ options: S.captionSuggestions(c.body), note: 'Template-based suggestions. Edit before posting.' }));
R('GET', '/api/social/accounts', 'social', () => ({ adapter: S.adapterName(), live: S.adapterName() === 'meta', platforms: S.PLATFORMS.map(p => ({ platform: p, connected: S.adapterName() === 'meta' ? (p === 'Facebook' ? !!process.env.META_PAGE_TOKEN : p === 'Instagram' ? !!(process.env.META_PAGE_TOKEN && process.env.META_IG_USER_ID) : false) : false })) }));

// ───────────────────────── Automations ─────────────────────────
const ruleOut = (r) => ({ ...r, conditions: parseJson(r.conditions, []), actions: parseJson(r.actions, []), active: !!r.active, requires_approval: !!r.requires_approval });
R('GET', '/api/automations', 'automations', () => ({ rules: q.all('SELECT * FROM automation_rules ORDER BY id').map(ruleOut), action_types: ACTION_TYPES }));
R('POST', '/api/automations', 'automations', (c) => {
  const b = c.body; if (!String(b.name || '').trim() || !String(b.trigger || '').trim()) throw bad('Name and trigger are required');
  const actions = Array.isArray(b.actions) ? b.actions : []; if (actions.some(a => !ACTION_TYPES.includes(a.type))) throw bad('Unknown action type');
  const r = q.run('INSERT INTO automation_rules(name,trigger,conditions,actions,active,requires_approval,description) VALUES(?,?,?,?,?,?,?)', String(b.name).trim(), String(b.trigger).trim(), JSON.stringify(b.conditions || []), JSON.stringify(actions), b.active === false ? 0 : 1, b.requires_approval ? 1 : 0, b.description || '');
  c.status = 201; return ruleOut(q.get('SELECT * FROM automation_rules WHERE id=?', Number(r.lastInsertRowid)));
});
R('PATCH', '/api/automations/:id', 'automations', (c) => {
  const cur = q.get('SELECT * FROM automation_rules WHERE id=?', id(c)); if (!cur) throw new HttpError(404, 'Rule not found');
  const b = { ...ruleOut(cur), ...c.body };
  if (!Array.isArray(b.actions) || b.actions.some(a => !ACTION_TYPES.includes(a.type))) throw bad('Unknown action type');
  q.run('UPDATE automation_rules SET name=?, trigger=?, conditions=?, actions=?, active=?, requires_approval=?, description=? WHERE id=?', b.name, b.trigger, JSON.stringify(b.conditions), JSON.stringify(b.actions), b.active ? 1 : 0, b.requires_approval ? 1 : 0, b.description || '', cur.id);
  return ruleOut(q.get('SELECT * FROM automation_rules WHERE id=?', cur.id));
});
R('DELETE', '/api/automations/:id', 'automations', (c) => { q.run('DELETE FROM automation_rules WHERE id=?', id(c)); return { ok: true }; });
R('POST', '/api/automations/:id/test', 'automations', async (c) => { const r = await runRuleNow(id(c)); if (!r) throw new HttpError(404, 'Rule not found'); return { rule: ruleOut(r), latest_run: q.get('SELECT * FROM automation_runs WHERE rule_id=? ORDER BY id DESC LIMIT 1', r.id) }; });
R('GET', '/api/automations/runs', 'automations', ({ query }) => q.all('SELECT * FROM automation_runs ORDER BY id DESC LIMIT ?', Math.min(Number(query.limit) || 40, 200)));
R('GET', '/api/events', 'automations', ({ query }) => q.all('SELECT id,type,payload,at FROM events ORDER BY id DESC LIMIT ?', Math.min(Number(query.limit) || 50, 200)));
R('POST', '/api/events', 'automations', (c) => { const t = String(c.body.type || ''); if (!/^[a-z_]+\.[a-z_]+$/.test(t)) throw bad('Event type looks like "stock.low"'); return emit(t, c.body.payload || {}); });

// ───────────────────────── Analytics ─────────────────────────
const dateOf = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : ymd());
R('GET', '/api/day-close', 'analytics', ({ query }) => { const d = dateOf(query.date); return { date: d, report: D.dayReport(d), closed: D.getDayClose(d), history: D.dayCloses(14) }; });
R('POST', '/api/day-close', 'analytics', (c) => D.closeDay(dateOf(c.body.date), c.body, c.user));
R('GET', '/api/reports/sales', 'analytics', ({ query }) => { const to = dateOf(query.to), from = dateOf(query.from || to); return D.salesRows(from, to, query.kind === 'items' ? 'items' : 'bills'); });
R('GET', '/api/analytics/profit/live', 'analytics', () => D.liveProfit());
R('GET', '/api/analytics/summary', 'analytics', ({ query }) => { const r = A.range(query); return A.summary(r.from, r.to); });
R('GET', '/api/analytics/channels', 'analytics', ({ query }) => { const r = A.range(query); return A.channels(r.from, r.to); });
R('GET', '/api/analytics/menu', 'analytics', ({ query }) => { const r = A.range(query); return A.menuPerformance(r.from, r.to); });
R('GET', '/api/analytics/expenses', 'analytics', ({ query }) => { const r = A.range(query); return A.expensesBreakdown(r.from, r.to); });
R('GET', '/api/analytics/inventory', 'analytics', ({ query }) => { const r = A.range(query); return A.inventoryAnalytics(r.from, r.to); });
R('GET', '/api/analytics/customers', 'analytics', () => A.customersAnalytics());
R('GET', '/api/analytics/social', 'analytics_social', () => A.socialAnalytics());
R('GET', '/api/analytics/social/roi', 'analytics_social', () => A.socialRoi());
R('GET', '/api/analytics/insights', 'analytics', ({ query }) => { const r = A.range(query); return { insights: A.insights(r.from, r.to) }; });

// ───────────────────────── Settings and admin ─────────────────────────
R('GET', '/api/bill-layout', '*', () => ({ layout: D.billCfg(), business: getSetting('business', {}) }));
R('GET', '/api/settings', 'settings', () => ({ business: getSetting('business', {}), prep_minutes: getSetting('prep_minutes', 25), lapsed_days: getSetting('lapsed_days', 30), discount_limit_pct: getSetting('discount_limit_pct', 30), bill: D.billCfg(), gst: D.gstCfg(), charges: D.chargesCfg(), channels: q.all('SELECT * FROM channel_settings'), integrations: integrationStatus() }));
R('PUT', '/api/settings', 'settings', (c) => {
  const b = c.body;
  if (b.business) { const x = b.business; setSetting('business', { name: String(x.name || '').slice(0, 80), gstin: String(x.gstin || '').slice(0, 20), fssai: String(x.fssai || '').slice(0, 20), address: String(x.address || '').slice(0, 200) }); }
  if (b.bill) D.saveBillCfg(b.bill);
  if (b.gst) D.saveGstCfg(b.gst);
  if (b.charges) D.saveChargesCfg(b.charges);
  if (b.prep_minutes !== undefined) { const n = Number(b.prep_minutes); if (!(n >= 5 && n <= 180)) throw bad('Prep time must be 5 to 180 minutes'); setSetting('prep_minutes', n); }
  if (b.lapsed_days !== undefined) { const n = Number(b.lapsed_days); if (!(n >= 7 && n <= 365)) throw bad('Lapsed days must be 7 to 365'); setSetting('lapsed_days', n); }
  if (b.discount_limit_pct !== undefined) { const n = Number(b.discount_limit_pct); if (!(n >= 0 && n <= 100)) throw bad('Cashier discount limit must be 0 to 100 percent'); setSetting('discount_limit_pct', n); }
  emit('settings.updated', {}); return { ok: true };
});
R('PATCH', '/api/channels/:channel', 'settings', (c) => {
  const ch = q.get('SELECT * FROM channel_settings WHERE channel=?', c.params.channel); if (!ch) throw new HttpError(404, 'Unknown channel');
  const b = { ...ch, ...c.body };
  const comm = Number(b.commission_pct), pack = Number(b.packaging_fee);
  if (!(comm >= 0 && comm <= 60) || !(pack >= 0 && pack <= 500)) throw bad('Commission must be 0 to 60% and packaging fee 0 to 500');
  if (!['none', ...PROVIDERS].includes(b.integration_provider)) throw bad('Unknown integration provider');
  q.run('UPDATE channel_settings SET commission_pct=?, packaging_fee=?, integration_provider=?, provider_store_id=?, active=? WHERE channel=?', comm, pack, b.integration_provider, b.provider_store_id || null, b.active ? 1 : 0, ch.channel);
  emit('settings.updated', {}); return q.get('SELECT * FROM channel_settings WHERE channel=?', ch.channel);
});
R('GET', '/api/integrations/log', 'analytics', ({ query }) => q.all('SELECT * FROM integration_log ORDER BY id DESC LIMIT ?', Math.min(Number(query.limit) || 40, 200)));
R('GET', '/api/admin/users', 'settings', () => { const links = gq.all('SELECT user_id, outlet_id FROM user_outlets'); return gq.all('SELECT id, name, role, active FROM users ORDER BY id').map(u => ({ ...u, active: !!u.active, outlet_ids: u.role === 'owner' ? 'all' : links.filter(l => l.user_id === u.id).map(l => l.outlet_id) })); });
/** Gives a person access to chosen outlets (the owner always has all of them). */
function setUserOutlets(uid, ids, fallback) {
  const valid = new Set(outletList().map(o => o.id)), want = (Array.isArray(ids) ? ids : fallback).map(Number).filter(n => valid.has(n));
  gq.run('DELETE FROM user_outlets WHERE user_id=?', uid); for (const o of new Set(want)) gq.run('INSERT INTO user_outlets(user_id, outlet_id) VALUES(?,?)', uid, o);
}
const pinOk = (p) => /^\d{4,8}$/.test(String(p || ''));
R('POST', '/api/admin/users', 'settings', (c) => {
  checkLimit('users'); const { name, role, pin } = c.body; if (!String(name || '').trim()) throw bad('Name is required'); if (!ROLES.includes(role)) throw bad('Pick a role'); if (!pinOk(pin)) throw bad('PIN must be 4 to 8 digits');
  const r = gq.run('INSERT INTO users(name,role,pin_hash) VALUES(?,?,?)', String(name).trim().slice(0, 40), role, hashPin(pin)), uid = Number(r.lastInsertRowid);
  setUserOutlets(uid, c.body.outlet_ids, [c.user.outlet_id]); c.status = 201; return { id: uid };
});
R('PATCH', '/api/admin/users/:id', 'settings', (c) => {
  const u = gq.get('SELECT * FROM users WHERE id=?', id(c)); if (!u) throw new HttpError(404, 'User not found');
  const b = c.body, role = b.role ?? u.role, active = b.active === undefined ? u.active : (b.active ? 1 : 0);
  if (!ROLES.includes(role)) throw bad('Pick a role');
  if (active && !u.active) checkLimit('users');
  if (u.role === 'owner' && (role !== 'owner' || !active) && gq.get("SELECT COUNT(*) n FROM users WHERE role='owner' AND active=1").n <= 1) throw bad('There must be at least one active owner');
  if (b.pin !== undefined && !pinOk(b.pin)) throw bad('PIN must be 4 to 8 digits');
  if (Array.isArray(b.outlet_ids)) setUserOutlets(u.id, b.outlet_ids, []);
  gq.run('UPDATE users SET name=?, role=?, active=?, pin_hash=? WHERE id=?', String(b.name ?? u.name).trim().slice(0, 40), role, active, b.pin !== undefined ? hashPin(b.pin) : u.pin_hash, u.id);
  if (!active || b.pin !== undefined) gq.run('DELETE FROM sessions WHERE user_id=?', u.id);
  return { ok: true };
});
R('GET', '/api/sessions', 'settings', () => gq.all('SELECT substr(s.token,1,12) id, u.name user, u.role, s.device, s.created_at, s.last_seen FROM sessions s JOIN users u ON u.id=s.user_id ORDER BY s.last_seen DESC'));
R('DELETE', '/api/sessions/:id', 'settings', (c) => { if (!/^[a-f0-9]{12}$/.test(c.params.id)) throw bad('Bad id'); gq.run("DELETE FROM sessions WHERE substr(token,1,12)=?", c.params.id); return { ok: true }; });


// ───────────────────────── Outlets ─────────────────────────
R('POST', '/api/outlets/switch', '*', (c) => { const o = switchOutlet(c.user, c.body.outlet_id); return { ok: true, outlet: { id: o.id, name: o.name, slug: o.slug } }; });
R('GET', '/api/public/outlets', null, () => outletList(true).map(o => ({ slug: o.slug, name: o.name, city: o.city })));
const slugOf = (v) => String(v || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30);
const listOutlets = () => { const links = gq.all('SELECT user_id, outlet_id FROM user_outlets'), users = gq.all("SELECT id, name, role FROM users WHERE active=1"); return outletList().map(o => ({ ...o, people: users.filter(u => u.role === 'owner' || links.some(l => l.user_id === u.id && l.outlet_id === o.id)).map(u => ({ id: u.id, name: u.name, role: u.role })) })); };
R('GET', '/api/admin/outlets', 'settings', () => listOutlets());
R('POST', '/api/admin/outlets', 'settings', (c) => {
  checkLimit('outlets'); const b = c.body, name = String(b.name || '').trim().slice(0, 60); if (!name) throw bad('Give the outlet a name');
  const slug = slugOf(b.slug || name); if (!slug) throw bad('Outlet link name is not valid'); if (outletList().some(o => o.slug === slug)) throw bad('Another outlet already uses that link name');
  const code = String(b.code || name.replace(/[^A-Za-z]/g, '').slice(0, 2) || 'B').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'B';
  const from = b.copy_from ? Number(b.copy_from) : null; if (from && !outletById(from)) throw bad('Pick an outlet to copy from');
  const id = createOutlet({ slug, name, city: String(b.city || '').trim().slice(0, 40), code });
  withOutlet(id, () => {
    seedOutletBasics(name);
    if (from) copyOutletData(from, id, { menu: !!b.copy?.menu, rates: !!b.copy?.rates, rules: !!b.copy?.rules });
    const bz = getSetting('business', {}); setSetting('business', { ...bz, name, address: String(b.address || '').slice(0, 200) });
  });
  for (const uid of Array.isArray(b.user_ids) ? b.user_ids.map(Number) : []) gq.run('INSERT OR IGNORE INTO user_outlets(user_id, outlet_id) VALUES(?,?)', uid, id);
  c.status = 201; return listOutlets().find(o => o.id === id);
});
R('PATCH', '/api/admin/outlets/:id', 'settings', (c) => {
  const o = outletById(id(c)); if (!o) throw new HttpError(404, 'Outlet not found'); const b = c.body;
  const active = b.active === undefined ? o.active : (b.active ? 1 : 0);
  if (!active && outletList(true).filter(x => x.id !== o.id).length === 0) throw bad('Keep at least one outlet open');
  const code = b.code === undefined ? o.code : (String(b.code).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'B');
  gq.run('UPDATE outlets SET name=?, city=?, code=?, active=? WHERE id=?', String(b.name ?? o.name).trim().slice(0, 60) || o.name, String(b.city ?? o.city ?? '').trim().slice(0, 40), code, active, o.id);
  return listOutlets().find(x => x.id === o.id);
});
/** Owner's view across all outlets: today and this month side by side. */
R('GET', '/api/outlets/summary', 'settings', () => {
  const t = ymd(), m = t.slice(0, 7) + '-01', rows = outletList(true).map(o => withOutlet(o.id, () => {
    const day = D.profit(t, t), mon = D.profit(m, t), live = q.get("SELECT COUNT(*) n FROM orders WHERE status IN ('new','accepted','preparing','ready')").n;
    return { id: o.id, name: o.name, city: o.city, open_orders: live, today: { orders: day.orders, sales: day.sales, net: day.net }, month: { orders: mon.orders, sales: mon.sales, net: mon.net, margin_pct: mon.margin_pct } };
  }));
  const sum = (f) => round2(rows.reduce((s, r) => s + f(r), 0));
  return { outlets: rows, total: { today: { orders: sum(r => r.today.orders), sales: sum(r => r.today.sales), net: sum(r => r.today.net) }, month: { orders: sum(r => r.month.orders), sales: sum(r => r.month.sales), net: sum(r => r.month.net) } } };
});

// ───────────────────────── Demo helper ─────────────────────────
const FAKE = ['Rhea', 'Imran', 'Tanvi', 'Gaurav', 'Leena', 'Mohit', 'Sana', 'Varun'];
R('POST', '/api/dev/simulate-order', 'orders_create', (c) => {
  if (!SIM_ON()) throw new HttpError(404, 'Simulator is off');
  const dishes = D.menuList().filter(m => m.available); if (!dishes.length) throw bad('No dishes are available');
  const ch = Math.random() < 0.5 ? 'swiggy' : 'zomato', n = 1 + Math.floor(Math.random() * 3), picked = [];
  while (picked.length < Math.min(n, dishes.length)) { const d = dishes[Math.floor(Math.random() * dishes.length)]; if (!picked.includes(d)) picked.push(d); }
  const body = { platform: ch, order_id: `${ch.slice(0, 2).toUpperCase()}${Date.now().toString().slice(-7)}`, customer: { name: FAKE[Math.floor(Math.random() * FAKE.length)] }, items: picked.map(d => ({ item_id: d.external_ids[ch], name: d.name, quantity: 1 + (Math.random() < 0.25 ? 1 : 0), price: D.priceFor(d, ch) })), instructions: Math.random() < 0.3 ? 'No onion please' : undefined };
  c.status = 201; return ingestAggregator(PROVIDERS.includes(c.body?.provider) ? c.body.provider : 'dyno', body);
});


/** Which outlet a request belongs to. Signed-in people use the outlet they picked. Public pages and partner webhooks must name one (?outlet=slug, or the partner's store id); with a single outlet that is not needed. */
function outletForRequest(user, url, req, body, pathname) {
  if (user) return user.outlet_id;
  const slug = url.searchParams.get('outlet') || req.headers['x-outlet'];
  if (slug) { const o = outletBySlug(slug); if (!o) throw new HttpError(404, 'Unknown outlet'); return o.id; }
  const active = outletList(true);
  if (pathname.startsWith('/api/webhooks/')) {
    const sid = body && (body.store_id ?? body.storeId ?? body.outlet_id ?? body.restaurant_id ?? body.merchant_id);
    if (sid != null && sid !== '') for (const o of active) if (withOutlet(o.id, () => q.get('SELECT 1 x FROM channel_settings WHERE provider_store_id=?', String(sid)))) return o.id;
  }
  if (active.length === 1) return active[0].id;
  if (/^\/api\/(public\/(menu|checkout|track)|webhooks\/)/.test(pathname)) throw new HttpError(400, 'Say which outlet this is: add ?outlet=<link name>', { outlets: active.map(o => o.slug) });
  return 1;
}

// ───────────────────────── Server ─────────────────────────
const idem = new Set();
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'same-origin'); res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;
  try {
    if (pathname.startsWith('/api/') || pathname === '/healthz') {
      const m = router.match(req.method, pathname);
      if (!m) { if (router.routes.some(r => r.re.test(pathname))) throw new HttpError(405, 'Method not allowed'); throw new HttpError(404, 'Not found'); }
      const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
      const queryToken = (pathname === '/api/stream' || pathname.startsWith('/api/receipts/')) ? url.searchParams.get('token') : null;
      const body = await readBody(req);
      // Hosted mode: work out which business this is before anything is read, and refuse if its plan has ended.
      let tid = 1;
      if (C.MULTI() && !tenantless(pathname)) {
        tid = tenantFromRequest(req, url, bearer || queryToken);
        if (!tid && /^\/api\/(users|login)$/.test(pathname)) throw new HttpError(403, 'This device is not set up for a shop. Sign in with your business email first.', { code: 'device_unknown' });
        const acct = tid && C.accountById(tid);
        if (!acct) throw new HttpError(tid ? 404 : 400, tid ? 'Business not found' : 'Say which business this is: add ?k=<business link>');
        if (/^\/api\/(users|login)$/.test(pathname) && !withTenant(tid, () => checkStaffDevice(req.headers['x-device']))) throw new HttpError(403, 'This device is not approved for staff sign-in. Ask the owner to approve it in Settings.', { code: 'device_unknown' });
        const st = C.accessState(acct);
        if (!st.ok && !gateExempt(pathname)) throw new HttpError(402, st.message, { code: st.code });
      }
      return await withTenant(tid, async () => {
      const user = userFromToken(bearer || queryToken);
      const ctx = { req, res, params: m.params, query: Object.fromEntries(url.searchParams), body, user, status: 200 };
      const agm = /^ag_\d+_(\d+)_/.exec(bearer), oid = agm && outletById(Number(agm[1])) ? Number(agm[1]) : outletForRequest(user, url, req, ctx.body, pathname);
      return await withOutlet(oid, async () => {
      // idempotent retries for writes
      const key = req.headers['idempotency-key'];
      const scope = key && user ? `${user.id}|${req.method}|${pathname}` : null;
      if (scope) {
        const prev = q.get('SELECT status, response FROM idempotency WHERE key=? AND scope=?', String(key).slice(0, 80), scope);
        if (prev) return send(res, prev.status, prev.response, { 'Idempotent-Replay': 'true', 'Content-Type': 'application/json; charset=utf-8' });
        if (idem.has(scope + key)) throw new HttpError(409, 'The same request is already being processed');
        idem.add(scope + key);
      }
      try {
        const out = await m.rt.handlers[0](ctx);
        if (out === HANDLED || res.headersSent) return;
        const json = JSON.stringify(out ?? { ok: true });
        if (scope) { q.run('INSERT OR REPLACE INTO idempotency(key,scope,status,response,at) VALUES(?,?,?,?,?)', String(key).slice(0, 80), scope, ctx.status, json, now()); if (Math.random() < 0.02) q.run("DELETE FROM idempotency WHERE at < ?", new Date(Date.now() - 2 * 864e5).toISOString()); }
        return send(res, ctx.status, json, { 'Content-Type': 'application/json; charset=utf-8' });
      } finally { if (scope) idem.delete(scope + key); }
      });
      });
    }
    if (pathname.startsWith('/media/')) {
      const mt = /^\/media\/t(\d+)\//.exec(pathname), tid = mt ? Number(mt[1]) : 1;
      if (tid !== 1 && !(C.MULTI() && C.accountById(tid))) throw new HttpError(404, 'Not found');
      if (serveStatic(mediaDir(tid), req, res, pathname.slice(mt ? mt[0].length - 1 : 6))) return; throw new HttpError(404, 'Not found');
    }
    const p = pathname === '/order' ? '/order.html' : pathname;
    if (serveStatic(PUBLIC_DIR, req, res, p)) return;
    if (!path.extname(pathname) && serveStatic(PUBLIC_DIR, req, res, '/index.html')) return; // app routes
    throw new HttpError(404, 'Not found');
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message, ...(e.extra || {}) });
    if (e?.message?.includes('UNIQUE')) return send(res, 409, { error: 'That already exists' });
    console.error(e); return send(res, 500, { error: 'Something went wrong on the server' });
  }
});
server.requestTimeout = 30000; server.headersTimeout = 15000;

export function start(port = Number(process.env.PORT) || 3000) {
  const creds = firstRun();
  startAutomations(); startHosted(); startBackups();
  return new Promise((resolve) => server.listen(port, '0.0.0.0', () => {
    console.log(`KitFlo running on http://localhost:${server.address().port}  (TZ ${process.env.TZ})`);
    if (creds) {
      console.log('\nFirst run. Sign-in PINs (change them in Settings):');
      for (const c of creds) console.log(`  ${c.name.padEnd(9)} ${c.pin}`);
      if (!PROD && !process.env.AGGREGATOR_WEBHOOK_SECRET) console.log("\nDev webhook secret: 'dev-secret' (set AGGREGATOR_WEBHOOK_SECRET for production)");
      console.log('');
    }
    resolve(server);
  }));
}
export { server };
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(import.meta.filename)) {
  start();
  const stop = () => { server.close(() => { closeAll(); process.exit(0); }); setTimeout(() => process.exit(0), 3000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
