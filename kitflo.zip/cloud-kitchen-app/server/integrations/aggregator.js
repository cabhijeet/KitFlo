// Swiggy / Zomato integration via an aggregator partner (Dyno APIs, UrbanPiper, or a direct partner API).
//
// INBOUND  : the partner (or a small bridge on the kitchen PC) POSTs orders to  /api/webhooks/aggregator/:provider
//            with header  X-Webhook-Secret. normalizeInbound() accepts our canonical JSON and the common field spellings.
// OUTBOUND : accept / reject / mark_ready / set_stock calls are POSTed to AGGREGATOR_OUTBOUND_URL as
//            { provider, action, payload }. Point that at the partner's cloud API, or at a relay (n8n / Make / bridge
//            for a desktop-only agent). Without it, calls are logged as "skipped" so nothing breaks.
import { q, now, parseJson } from '../db.js';

export function logIntegration(provider, direction, action, payload, status) {
  try { q.run('INSERT INTO integration_log(provider,direction,action,payload,status,at) VALUES(?,?,?,?,?,?)', provider, direction, action, JSON.stringify(payload).slice(0, 2000), String(status).slice(0, 200), now());
    if (Math.random() < 0.05) q.run('DELETE FROM integration_log WHERE id < (SELECT MAX(id) FROM integration_log) - 1000'); } catch {}
}

/** Partners we can talk to. Each one can have its own secret and outbound address (LIMETRAY_WEBHOOK_SECRET, LIMETRAY_OUTBOUND_URL, ...), falling back to the shared AGGREGATOR_* values. */
export const PROVIDERS = ['dyno', 'urbanpiper', 'limetray', 'foodengine', 'direct'];
const envKey = (provider) => String(provider || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const webhookSecretFor = (provider) => process.env[`${envKey(provider)}_WEBHOOK_SECRET`] || process.env.AGGREGATOR_WEBHOOK_SECRET || null;
export const outboundFor = (provider) => ({ url: process.env[`${envKey(provider)}_OUTBOUND_URL`] || process.env.AGGREGATOR_OUTBOUND_URL || null, token: process.env[`${envKey(provider)}_OUTBOUND_TOKEN`] || process.env.AGGREGATOR_OUTBOUND_TOKEN || null });
/** What is configured for each partner, for the Settings screen. Never returns the secrets themselves. */
export const providerStatus = () => Object.fromEntries(PROVIDERS.map((p) => [p, { secret: !!webhookSecretFor(p), own_secret: !!process.env[`${envKey(p)}_WEBHOOK_SECRET`], outbound: !!outboundFor(p).url }]));

export async function outbound(provider, action, payload) {
  const { url, token } = outboundFor(provider);
  if (!url) { logIntegration(provider, 'out', action, payload, `skipped: no outbound address for ${provider}`); return { ok: false, skipped: true }; }
  try {
    const res = await fetch(url, {
      method: 'POST', signal: AbortSignal.timeout(8000),
      headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ provider, action, payload }),
    });
    logIntegration(provider, 'out', action, payload, `http ${res.status}`);
    return { ok: res.ok, status: res.status };
  } catch (e) { logIntegration(provider, 'out', action, payload, `error: ${e.message}`); return { ok: false, error: e.message }; }
}

const pick = (o, ...keys) => { for (const k of keys) { const v = k.split('.').reduce((a, p) => (a == null ? a : a[p]), o); if (v !== undefined && v !== null && v !== '') return v; } return undefined; };

export function normalizeInbound(provider, body) {
  const hint = String(pick(body, 'channel', 'platform', 'source', 'aggregator', 'order_source', 'orderSource', 'order_from', 'orderFrom', 'aggregator_name') || provider || '').toLowerCase();
  // LimeTray and FoodEngine carry Swiggy and Zomato orders and also the kitchen's own website or app. Anything that is not clearly Swiggy or Zomato is the website channel for those two.
  const ownSite = /web|app|own|direct|online|limetray|foodengine|site|store/.test(hint) || ['limetray', 'foodengine'].includes(provider);
  const channel = hint.includes('swiggy') ? 'swiggy' : hint.includes('zomato') ? 'zomato' : ownSite ? 'website' : null;
  const items = pick(body, 'items', 'order_items', 'orderItems', 'products', 'cart.items', 'order.items', 'order.products', 'line_items');
  return {
    channel,
    channel_order_id: pick(body, 'channel_order_id', 'order_id', 'orderId', 'order_number', 'orderNumber', 'order.id', 'order.order_id', 'id'),
    customer: { name: pick(body, 'customer.name', 'customer_name', 'customerName', 'name'), phone: pick(body, 'customer.phone', 'customer.mobile', 'customer_phone', 'customer_mobile', 'customerPhone', 'phone', 'mobile') },
    items: (Array.isArray(items) ? items : []).map(it => ({
      external_id: pick(it, 'external_id', 'item_id', 'itemId', 'product_id', 'productId', 'sku', 'id'), name: pick(it, 'name', 'item_name', 'itemName', 'product_name', 'productName', 'title'),
      qty: Number(pick(it, 'qty', 'quantity', 'count') ?? 1), unit_price: pick(it, 'unit_price', 'unitPrice', 'price', 'rate'), modifiers: pick(it, 'modifiers', 'notes'),
    })),
    discount: Number(pick(body, 'discount', 'discount_amount') ?? 0), packaging_fee: pick(body, 'packaging_fee', 'packaging', 'packaging_charges'),
    notes: pick(body, 'notes', 'instructions', 'special_instructions'), address: pick(body, 'address', 'delivery_address', 'deliveryAddress', 'customer.address', 'address.full'),
    payment_mode: pick(body, 'payment_mode', 'payment.mode'), placed_at: pick(body, 'placed_at', 'created_at', 'order_time'),
  };
}

/** Attach our menu_item_id to each platform item: by the partner's item id first, then by exact name. */
export function resolveItems(channel, items) {
  const menu = q.all('SELECT id, name, variant_name, external_ids FROM menu_items').map(m => ({ ...m, full: (m.variant_name ? `${m.name} · ${m.variant_name}` : m.name).toLowerCase(), ext: parseJson(m.external_ids, {}) }));
  return items.map(it => {
    const m = (it.external_id != null && menu.find(x => String(x.ext[channel] ?? '') === String(it.external_id))) ||
              (it.name && (menu.find(x => x.full === String(it.name).toLowerCase()) || (menu.filter(x => x.name.toLowerCase() === String(it.name).toLowerCase()).length === 1 ? menu.find(x => x.name.toLowerCase() === String(it.name).toLowerCase()) : null)));
    return m ? { ...it, menu_item_id: m.id } : it;
  });
}
