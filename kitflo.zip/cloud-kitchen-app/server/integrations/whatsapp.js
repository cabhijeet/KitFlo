// WhatsApp Business Cloud API: webhook verification, inbound ordering, outbound replies.
// Without WHATSAPP_TOKEN + WHATSAPP_PHONE_ID, replies are logged instead of sent.
import crypto from 'node:crypto';
import { q } from '../db.js';
import { menuList, createOrder, normPhone } from '../domain.js';
import { logIntegration } from './aggregator.js';

export function verifySubscription(query) {
  if (query['hub.mode'] === 'subscribe' && process.env.WHATSAPP_VERIFY_TOKEN && query['hub.verify_token'] === process.env.WHATSAPP_VERIFY_TOKEN) return String(query['hub.challenge']);
  return null;
}
export function signatureOk(req) {
  const secret = process.env.WHATSAPP_APP_SECRET;
  if (!secret) return true; // enforce by setting the secret in production
  const sig = String(req.headers['x-hub-signature-256'] || '').replace('sha256=', '');
  const mac = crypto.createHmac('sha256', secret).update(req.rawBody || '').digest('hex');
  return sig.length === mac.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(mac));
}

export async function sendText(to, text) {
  const token = process.env.WHATSAPP_TOKEN, phoneId = process.env.WHATSAPP_PHONE_ID;
  if (!token || !phoneId) { logIntegration('whatsapp', 'out', 'text', { to, text }, 'skipped: WHATSAPP_TOKEN / WHATSAPP_PHONE_ID not set'); return { ok: false, skipped: true }; }
  try {
    const r = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: 'POST', signal: AbortSignal.timeout(8000), headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body: text } }),
    });
    logIntegration('whatsapp', 'out', 'text', { to }, `http ${r.status}`);
    return { ok: r.ok };
  } catch (e) { logIntegration('whatsapp', 'out', 'text', { to }, `error: ${e.message}`); return { ok: false }; }
}

const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
/** Menu message grouped by dish with sizes. Long menus start with categories; "menu <category>" lists one. Stays under WhatsApp's 4096-character limit. */
function menuText(dishes, cat) {
  const price = (d) => inr(d.prices.whatsapp ?? d.prices.default ?? 0);
  const cats = [...new Set(dishes.map(d => d.category || 'Other'))];
  const pick = cat ? cats.filter(c => c.toLowerCase().includes(cat.toLowerCase())) : cats;
  const list = dishes.filter(d => pick.includes(d.category || 'Other'));
  const tail = '\n\nTo order, reply like:  order 2 paneer paratha, 1 matar paneer half';
  if (cat && !pick.length) return `No category called "${cat}". Categories: ${cats.join(', ')}.`;
  const body = (cs) => cs.map(c => { const g = new Map(); for (const d of list.filter(x => (x.category || 'Other') === c)) { if (!g.has(d.group_key)) g.set(d.group_key, []); g.get(d.group_key).push(d); } return `*${c}*\n` + [...g.values()].map(v => v.length > 1 ? `• ${v[0].name}: ` + v.map(d => `${(d.variant_name || '').split(' (')[0]} ${price(d)}`).join(' / ') : `• ${v[0].name} ${price(v[0])}`).join('\n'); }).join('\n\n');
  const full = body(pick);
  if (full.length + tail.length <= 3800) return "Today's menu:\n" + full + tail;
  return `Our menu is long. Reply "menu" and a category name, for example "menu ${cats[0]}".\n\nCategories:\n` + cats.map(c => `• ${c}`).join('\n');
}
function parseOrderText(text, dishes) {
  const body = text.replace(/^\s*order\b[:\s]*/i, '');
  const items = [], missing = [];
  for (const part of body.split(/,|\n|\band\b/i).map(s => s.trim()).filter(Boolean)) {
    const m = part.match(/^(\d+)\s*x?\s*(.+)$/i) || part.match(/^(.+?)\s*x\s*(\d+)$/i);
    let qty = 1, name = part;
    if (m) { if (/^\d+$/.test(m[1])) { qty = Number(m[1]); name = m[2]; } else { name = m[1]; qty = Number(m[2]); } }
    name = name.toLowerCase().trim();
    const dn = (x) => (x.display_name || x.name).toLowerCase();
    const loose = name.length >= 3 ? dishes.filter(x => dn(x).includes(name)) : [];
    const d = dishes.find(x => dn(x) === name) || (dishes.filter(x => x.name.toLowerCase() === name).length === 1 ? dishes.find(x => x.name.toLowerCase() === name) : null) || (loose.length === 1 ? loose[0] : null);
    if (d) items.push({ menu_item_id: d.id, qty }); else missing.push(part);
  }
  return { items, missing };
}

/** Handles Meta's webhook shape and a simplified { from, name, text } shape for testing. */
export async function handleInbound(body) {
  const msgs = [];
  for (const e of body.entry || []) for (const c of e.changes || []) {
    const v = c.value || {};
    for (const m of v.messages || []) if (m.type === 'text') msgs.push({ from: m.from, name: v.contacts?.[0]?.profile?.name, text: m.text?.body || '' });
  }
  if (body.from && body.text) msgs.push({ from: body.from, name: body.name, text: String(body.text) });
  const out = [];
  for (const m of msgs) {
    const phone = normPhone(m.from);
    const text = m.text.trim();
    const dishes = menuList().filter(d => d.available);
    let reply;
    if (/^(menu|hi|hello|hey)\b/i.test(text)) {
      reply = menuText(dishes, text.replace(/^(menu|hi|hello|hey)\b[\s:]*/i, '').trim());
    } else if (/^order\b/i.test(text)) {
      const { items, missing } = parseOrderText(text, dishes);
      if (!items.length) reply = `Sorry, I could not match: ${missing.join(', ') || 'your items'}. Send "menu" to see what is available.`;
      else {
        const { order } = createOrder({ channel: 'whatsapp', channel_order_id: 'wa_' + (m.id || Date.now()), customer: { name: m.name, phone }, items, notes: missing.length ? `Not matched: ${missing.join(', ')}` : undefined, payment_mode: 'UPI' }, { user: { name: 'WhatsApp' } });
        reply = `Order #${order.order_no} received: ${order.items.map(i => `${i.qty} x ${i.name}`).join(', ')}. Total ${inr(order.total)}.` + (missing.length ? ` Could not match: ${missing.join(', ')}.` : '') + ' We will confirm shortly.';
      }
    } else reply = 'Hi! Send "menu" to see today\'s dishes or "order 2 paneer bowl" to order.';
    out.push({ to: m.from, reply });
    sendText(m.from, reply);
  }
  return out;
}
