// The control plane for hosted mode: one small database that knows every business (account), its plan, its trial, and its invoices.
// Nothing here touches a business's own data; those live in their own folders (see db.js).
import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import path from 'node:path';
import { DATA_DIR } from './db.js';

/** Hosted mode: many businesses on one server, each signing in with an email. Off means one business, as before. */
export const MULTI = () => process.env.MULTI_TENANT === '1';
export const TRIAL_DAYS = 14, GRACE_DAYS = 3, GST_PCT = 18;
/** Prices are per outlet, before GST. users 0 and outlets 0 mean no limit. */
export const PLANS = {
  starter: { name: 'Starter', monthly: 699, yearly: 6990, users: 3, outlets: 1 },
  growth: { name: 'Growth', monthly: 1299, yearly: 12990, users: 10, outlets: 1 },
  pro: { name: 'Pro', monthly: 1999, yearly: 19990, users: 0, outlets: 0 },
};
const DAY = 864e5, iso = (t) => new Date(t).toISOString(), addDaysIso = (from, n) => iso(new Date(from).getTime() + n * DAY);

let cdb;
function open() {
  const d = new DatabaseSync(path.join(DATA_DIR, 'control.db'));
  d.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA synchronous=NORMAL;');
  d.exec(`
CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE, business TEXT NOT NULL, owner_name TEXT, email TEXT UNIQUE COLLATE NOCASE, phone TEXT, pass_hash TEXT,
  status TEXT NOT NULL DEFAULT 'trial', plan TEXT NOT NULL DEFAULT 'growth', cycle TEXT NOT NULL DEFAULT 'monthly', trial_ends TEXT, paid_until TEXT, gstin TEXT, billing_name TEXT, billing_address TEXT, billing_state TEXT,
  created_at TEXT, last_login TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL, number TEXT NOT NULL UNIQUE, issued_at TEXT NOT NULL, period_from TEXT, period_to TEXT, plan TEXT, cycle TEXT, outlets INTEGER NOT NULL DEFAULT 1,
  taxable REAL NOT NULL, cgst REAL NOT NULL DEFAULT 0, sgst REAL NOT NULL DEFAULT 0, igst REAL NOT NULL DEFAULT 0, total REAL NOT NULL, status TEXT NOT NULL DEFAULT 'due', paid_at TEXT, payment_ref TEXT, pay_link TEXT, buyer TEXT);
CREATE TABLE IF NOT EXISTS billing_events(id INTEGER PRIMARY KEY, account_id INTEGER, kind TEXT NOT NULL, event_id TEXT UNIQUE, payload TEXT, at TEXT NOT NULL);
`);
  if (!d.prepare('SELECT 1 FROM accounts WHERE id=1').get()) {
    // The business that already lives in the main folder. It is the operator's own and is never blocked for billing.
    d.prepare("INSERT INTO accounts(id,slug,business,status,plan,paid_until,created_at) VALUES(1,'default','Default business','active','pro','2099-12-31T00:00:00.000Z',?)").run(new Date().toISOString());
  }
  return d;
}
const C = () => (cdb ||= open());
export const closeControl = () => { try { cdb?.close(); } catch { /* closed */ } cdb = null; };

export const hashPassword = (pw) => { const salt = crypto.randomBytes(16).toString('hex'); return `${salt}:${crypto.scryptSync(String(pw), salt, 64).toString('hex')}`; };
export const checkPassword = (pw, stored) => {
  const [salt, h] = String(stored || '').split(':'); if (!salt || !h) return false;
  const x = crypto.scryptSync(String(pw), salt, 64), y = Buffer.from(h, 'hex'); return x.length === y.length && crypto.timingSafeEqual(x, y);
};

const one = (sql, ...p) => C().prepare(sql).get(...p) || null;
const all = (sql, ...p) => C().prepare(sql).all(...p);
const run = (sql, ...p) => C().prepare(sql).run(...p);
export const accountById = (id) => one('SELECT * FROM accounts WHERE id=?', Number(id));
export const accountBySlug = (s) => one('SELECT * FROM accounts WHERE slug=?', String(s || '').toLowerCase());
export const accountByEmail = (e) => one('SELECT * FROM accounts WHERE email=?', String(e || '').trim());
export const listAccounts = () => all('SELECT id,slug,business,owner_name,email,phone,status,plan,cycle,trial_ends,paid_until,created_at,last_login,notes FROM accounts ORDER BY id');

export const slugOf = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30);
export function uniqueSlug(base) {
  const b = slugOf(base) || 'kitchen'; let s = b, n = 1;
  while (accountBySlug(s) || ['www', 'app', 'api', 'admin', 'default', 'order', 'static', 'media'].includes(s)) s = `${b}-${++n}`;
  return s;
}
export function insertAccount({ business, owner_name, email, phone, pass_hash, plan = 'growth', cycle = 'monthly' }) {
  const t = Date.now();
  const id = Number(run('INSERT INTO accounts(slug,business,owner_name,email,phone,pass_hash,status,plan,cycle,trial_ends,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
    uniqueSlug(business), business, owner_name, email, phone, pass_hash, 'trial', plan, cycle, addDaysIso(t, TRIAL_DAYS), iso(t)).lastInsertRowid);
  return accountById(id);
}
const FIELDS = ['business', 'owner_name', 'email', 'phone', 'pass_hash', 'status', 'plan', 'cycle', 'trial_ends', 'paid_until', 'gstin', 'billing_name', 'billing_address', 'billing_state', 'last_login', 'notes'];
export function updateAccount(id, patch) {
  const keys = Object.keys(patch).filter((k) => FIELDS.includes(k)); if (!keys.length) return accountById(id);
  run(`UPDATE accounts SET ${keys.map((k) => `${k}=?`).join(', ')} WHERE id=?`, ...keys.map((k) => patch[k]), Number(id)); return accountById(id);
}
/** Businesses whose background work (scheduled automations) should run. */
export const activeTenantIds = () => (MULTI() ? all("SELECT id FROM accounts WHERE status IN ('trial','active','past_due')").map((r) => r.id).filter((id) => accessState(accountById(id)).ok) : [1]);

/** Whether a business may use the app right now, and what to tell the owner. */
export function accessState(a, at = Date.now()) {
  if (!a) return { ok: false, code: 'unknown', message: 'This business was not found.' };
  if (a.status === 'suspended') return { ok: false, code: 'suspended', message: 'This account is paused. Please contact support.' };
  if (a.status === 'cancelled') return { ok: false, code: 'cancelled', message: 'This account was closed.' };
  const days = (t) => Math.ceil((new Date(t).getTime() - at) / DAY);
  if (a.status === 'trial') {
    const left = days(a.trial_ends);
    return left > 0 ? { ok: true, state: 'trial', days_left: left, message: `Free trial: ${left} day${left === 1 ? '' : 's'} left.` } : { ok: false, code: 'subscription_required', state: 'trial_ended', message: 'Your free trial has ended. Choose a plan to keep going. Your data is safe.' };
  }
  const left = days(a.paid_until), grace = left + GRACE_DAYS;
  if (left > 0) return { ok: true, state: 'active', days_left: left, renew_soon: left <= 5, message: left <= 5 ? `Your plan renews in ${left} day${left === 1 ? '' : 's'}.` : '' };
  if (grace > 0) return { ok: true, state: 'past_due', days_left: left, grace_left: grace, message: `Payment is overdue. Please pay within ${grace} day${grace === 1 ? '' : 's'} to avoid a pause.` };
  return { ok: false, code: 'subscription_required', state: 'lapsed', message: 'Your plan has ended. Pay the open invoice to continue. Your data is safe.' };
}

// ───────── invoices ─────────
const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
/** Financial year label in India: April to March. */
const fy = (d) => { const y = d.getFullYear(), m = d.getMonth(); const a = m >= 3 ? y : y - 1; return `${a}-${String(a + 1).slice(2)}`; };
export const seller = () => ({ name: process.env.SELLER_NAME || 'KitFlo', gstin: process.env.SELLER_GSTIN || '', address: process.env.SELLER_ADDRESS || '', state: process.env.SELLER_STATE || '', sac: process.env.SELLER_SAC || '', email: process.env.SELLER_EMAIL || '' });
const stateCode = (g) => (/^\d{2}/.test(g || '') ? String(g).slice(0, 2) : '');
export function priceFor(plan, cycle, outlets) { const p = PLANS[plan]; if (!p) throw new Error('Unknown plan'); return r2((cycle === 'yearly' ? p.yearly : p.monthly) * Math.max(1, outlets)); }
/** GST split: same state as the seller means CGST and SGST, different state means IGST. If we cannot tell, IGST is the safe default for an online service. */
export function splitGst(taxable, buyerState, buyerGstin, s = seller()) {
  const total = r2(taxable * GST_PCT / 100), same = !!s.state && !!buyerState && s.state.trim().toLowerCase() === String(buyerState).trim().toLowerCase();
  const sameCode = stateCode(s.gstin) && stateCode(buyerGstin) && stateCode(s.gstin) === stateCode(buyerGstin);
  return same || sameCode ? { cgst: r2(total / 2), sgst: r2(total - r2(total / 2)), igst: 0 } : { cgst: 0, sgst: 0, igst: total };
}
export function nextInvoiceNumber(at = new Date()) {
  const label = fy(at), n = (one('SELECT COUNT(*) n FROM invoices WHERE number LIKE ?', `KF/${label}/%`).n || 0) + 1; return `KF/${label}/${String(n).padStart(5, '0')}`;
}
export function createInvoice(a, { outlets, plan = a.plan, cycle = a.cycle, from, status = 'due' }) {
  const start = from ? new Date(from) : new Date(), end = new Date(start); if (cycle === 'yearly') end.setFullYear(end.getFullYear() + 1); else end.setMonth(end.getMonth() + 1);
  const taxable = priceFor(plan, cycle, outlets), g = splitGst(taxable, a.billing_state, a.gstin);
  const total = r2(taxable + g.cgst + g.sgst + g.igst), number = nextInvoiceNumber();
  const id = Number(run('INSERT INTO invoices(account_id,number,issued_at,period_from,period_to,plan,cycle,outlets,taxable,cgst,sgst,igst,total,status,buyer) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
    a.id, number, iso(Date.now()), iso(start), iso(end), plan, cycle, Math.max(1, outlets), taxable, g.cgst, g.sgst, g.igst, total, status, JSON.stringify({ name: a.billing_name || a.business, gstin: a.gstin || '', address: a.billing_address || '', state: a.billing_state || '', email: a.email || '' })).lastInsertRowid);
  return invoiceById(id);
}
export const invoiceById = (id) => { const i = one('SELECT * FROM invoices WHERE id=?', Number(id)); return i && { ...i, buyer: JSON.parse(i.buyer || '{}') }; };
export const invoiceByNumber = (n) => { const i = one('SELECT * FROM invoices WHERE number=?', String(n)); return i && { ...i, buyer: JSON.parse(i.buyer || '{}') }; };
export const invoicesFor = (accountId) => all('SELECT * FROM invoices WHERE account_id=? ORDER BY id DESC', Number(accountId)).map((i) => ({ ...i, buyer: JSON.parse(i.buyer || '{}') }));
export const allInvoices = () => all('SELECT * FROM invoices ORDER BY id DESC LIMIT 500').map((i) => ({ ...i, buyer: JSON.parse(i.buyer || '{}') }));
export const openInvoice = (accountId) => { const i = one("SELECT * FROM invoices WHERE account_id=? AND status='due' ORDER BY id DESC LIMIT 1", Number(accountId)); return i && { ...i, buyer: JSON.parse(i.buyer || '{}') }; };
export const voidInvoice = (id) => run("UPDATE invoices SET status='void' WHERE id=? AND status='due'", Number(id));
export const setInvoiceLink = (id, link) => run('UPDATE invoices SET pay_link=? WHERE id=?', link, Number(id));
/** Marks an invoice paid and moves the account's paid-until date forward. Safe to call twice for the same invoice. */
export function settleInvoice(invoiceId, ref, at = Date.now()) {
  const inv = invoiceById(invoiceId); if (!inv) throw new Error('Invoice not found'); if (inv.status === 'paid') return { invoice: inv, account: accountById(inv.account_id), already: true };
  run("UPDATE invoices SET status='paid', paid_at=?, payment_ref=? WHERE id=?", iso(at), String(ref || '').slice(0, 80), inv.id);
  const a = accountById(inv.account_id), base = a.paid_until && new Date(a.paid_until).getTime() > at ? new Date(a.paid_until) : new Date(at), end = new Date(base);
  if (inv.cycle === 'yearly') end.setFullYear(end.getFullYear() + 1); else end.setMonth(end.getMonth() + 1);
  const acc = updateAccount(a.id, { status: 'active', paid_until: iso(end), plan: inv.plan, cycle: inv.cycle });
  return { invoice: invoiceById(inv.id), account: acc, already: false };
}
export function recordEvent(accountId, kind, payload, eventId = null) {
  try { run('INSERT INTO billing_events(account_id,kind,event_id,payload,at) VALUES(?,?,?,?,?)', accountId ?? null, kind, eventId, JSON.stringify(payload ?? {}).slice(0, 4000), iso(Date.now())); return true; }
  catch (e) { if (String(e.message).includes('UNIQUE')) return false; throw e; }
}
export const eventsFor = (accountId) => all('SELECT * FROM billing_events WHERE account_id=? ORDER BY id DESC LIMIT 50', Number(accountId));
