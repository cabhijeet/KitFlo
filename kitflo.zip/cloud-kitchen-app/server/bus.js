// Event bus: every business event is stored, fanned out to automations, and pushed to all connected devices over SSE.
import { EventEmitter } from 'node:events';
import { q, now, outletId, tenantId } from './db.js';

export const bus = new EventEmitter();
bus.setMaxListeners(50);
const clients = new Set();

export function emit(type, payload = {}) {
  const at = now();
  try {
    q.run('INSERT INTO events(type,payload,at) VALUES(?,?,?)', type, JSON.stringify(payload).slice(0, 4000), at);
    if (Math.random() < 0.02) q.run('DELETE FROM events WHERE id < (SELECT MAX(id) FROM events) - 3000');
  } catch { /* logging must never break a business action */ }
  const evt = { type, payload, at, outlet: outletId(), tenant: tenantId() };
  bus.emit('event', evt);
  broadcast(evt, Array.isArray(payload.roles) ? payload.roles : null);
  return evt;
}

/** Push to every connected device; roles limits the audience (default: all signed-in users). */
export function broadcast(evt, roles = null) {
  if (evt.outlet == null) evt = { ...evt, outlet: outletId() };
  if (evt.tenant == null) evt = { ...evt, tenant: tenantId() };
  const data = `event: msg\ndata: ${JSON.stringify(evt)}\n\n`;
  for (const c of clients) {
    if (c.tenant !== evt.tenant || c.outlet !== evt.outlet) continue; // a device only hears about its own outlet
    if (roles && !roles.includes(c.role)) continue;
    try { c.res.write(data); } catch { clients.delete(c); }
  }
}

export function openStream(req, res, user) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.write(`retry: 2000\nevent: hello\ndata: ${JSON.stringify({ user: user.name, at: now() })}\n\n`);
  const c = { res, role: user.role, userId: user.id, outlet: user.outlet_id, tenant: tenantId() };
  clients.add(c);
  req.on('close', () => clients.delete(c));
}
export const connectedDevices = () => clients.size;
setInterval(() => { for (const c of clients) { try { c.res.write(': ping\n\n'); } catch { clients.delete(c); } } }, 20000).unref();
