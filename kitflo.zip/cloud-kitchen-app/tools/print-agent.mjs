#!/usr/bin/env node
// KitFlo print helper. Runs on the shop PC (Windows, Mac or Linux) with Node 18 or newer. No packages needed.
//   node print-agent.mjs --server https://your-kitflo.example --key ag_...      keep running
//   node print-agent.mjs --server ... --key ... --once                            fetch and print what is waiting, then stop
// It only makes outbound requests, so nothing has to be opened on the shop network.
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : d; };
const SERVER = (arg('server', process.env.KITFLO_SERVER || '')).replace(/\/$/, ''), KEY = arg('key', process.env.KITFLO_KEY || ''), ONCE = process.argv.includes('--once');
if (!SERVER || !KEY) { console.error('Usage: node print-agent.mjs --server <address> --key <helper key> [--once]\nGet the key in KitFlo: Settings > Printers > Set up the print helper.'); process.exit(2); }
const log = (...a) => console.log(new Date().toLocaleTimeString(), ...a);

function toTcp(spec, data) {
  const [host, port] = spec.split(':'); // spec is "host" or "host:port"
  return new Promise((resolve, reject) => {
    const s = net.connect({ host, port: Number(port) || 9100 }); let done = false;
    const end = (err) => { if (done) return; done = true; s.destroy(); err ? reject(err) : resolve(); };
    s.setTimeout(8000, () => end(new Error(`Printer at ${host} did not answer`))); s.on('error', end);
    s.on('connect', () => s.write(data, () => setTimeout(() => end(), 400)));
  });
}
const toDevice = (p, data) => fs.promises.appendFile(p, data); // /dev/usb/lp0, COM3 or \\.\COM3
function toOs(name, data) {
  return new Promise((resolve, reject) => {
    if (process.platform === 'win32') { // the printer must be shared (Windows: Printer properties > Sharing) under this name
      const f = path.join(os.tmpdir(), `kitflo-${Date.now()}.bin`); fs.writeFileSync(f, data);
      execFile('cmd', ['/c', 'copy', '/b', f, `\\\\localhost\\${name}`], (e, _o, se) => { fs.rmSync(f, { force: true }); e ? reject(new Error(se || e.message)) : resolve(); });
    } else {
      const p = execFile('lp', ['-d', name, '-o', 'raw'], (e, _o, se) => (e ? reject(new Error(se || e.message)) : resolve())); p.stdin.end(data);
    }
  });
}
async function printOne(job) {
  const data = Buffer.from(job.data, 'base64'), c = job.connection, i = c.indexOf(':'), kind = c.slice(0, i), rest = c.slice(i + 1);
  if (kind === 'tcp') return toTcp(rest, data); if (kind === 'device') return toDevice(rest, data); if (kind === 'os') return toOs(rest, data);
  throw new Error('Unknown connection: ' + c);
}
const api = async (method, p, body) => {
  const r = await fetch(SERVER + p, { method, headers: { authorization: 'Bearer ' + KEY, 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(15000) });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.error || `HTTP ${r.status}`), { status: r.status }); return j;
};
let failed = 0;
async function cycle() {
  const { jobs, poll_ms } = await api('GET', '/api/agent/jobs');
  for (const job of jobs) {
    try { await printOne(job); await api('POST', `/api/agent/jobs/${job.id}`, { ok: true }); log(`Printed ${job.kind} on ${job.name}`); }
    catch (e) { failed++; log(`Could not print on ${job.name}: ${e.message}`); await api('POST', `/api/agent/jobs/${job.id}`, { ok: false, error: e.message }).catch(() => {}); }
  }
  return poll_ms || 2500;
}
if (ONCE) { try { await cycle(); process.exit(failed ? 1 : 0); } catch (e) { console.error(e.message); process.exit(1); } }
log(`KitFlo print helper running. Server: ${SERVER}`);
let wait = 2500;
for (;;) {
  try { wait = await cycle(); } catch (e) { if (e.status === 401) { console.error('The helper key was not accepted. Make a new one in Settings > Printers.'); process.exit(1); } wait = Math.min(30000, wait * 2); log('Waiting for the server:', e.message); }
  await new Promise((r) => setTimeout(r, wait));
}
