<p align="center"><img src="public/icons/logo.png" alt="KitFlo" width="280"></p>

# KitFlo

*Your Kitchen's Digital Nerve.*

KitFlo is the operating system for a cloud kitchen or to-go counter: one app for orders from every channel, kitchen display, stock, expenses, live profit, social posts and automations. It runs in any browser (phone, tablet, laptop, kitchen screen) and updates live across devices.

No npm packages. Needs **Node 22.5 or newer** (it uses the built-in SQLite).

## Run it

```
npm start            # http://localhost:3000
npm test             # 26 end-to-end API tests on a throwaway database
```

First start loads your menu (111 dishes, 149 sizes, from `server/menu-data.json`) and prints the sign-in PINs. Set `SEED_DEMO=1` instead to get a 30-day demo kitchen with its own dishes, recipes, stock and expenses.

| User | PIN | Can do |
|---|---|---|
| Owner | 1234 | everything |
| Manager | 2222 | everything except users and settings |
| Cashier | 3333 | orders, customers, stock view |
| Kitchen | 4444 | kitchen screen, stock |
| Marketer | 5555 | social, social insights |

In production (`NODE_ENV=production`) PINs are random and printed once. Change them under Settings.

Customers order at `/order` (no sign-in). Install the app on a tablet from the user menu.

## Menu

The **Menu** page holds every dish with its photo, description, category, subcategory, catalogue ID, sizes, price per size, variant IDs, in-stock switch, tax rate, per-channel prices and recipe.
- Tap a dish to edit it. All its sizes are edited together. Each size has its own price, variant ID and recipe, with a button to copy a recipe from another size and scale it.
- **Import CSV / Export CSV** use the same columns as your Menu Master sheet. Importing again updates dishes by Variant ID and never creates duplicates. `menu-master.csv` in this folder is your current menu in that format.
- Filters find dishes with no recipe, no photo or no description, or that are short of stock.
- Photos are links (the menu sheet has Zomato image links). They load from the internet in the browser, and if a link breaks a plain placeholder shows. Check that Zomato's image links open on your devices.
- **Recipes are empty to begin with**, so food cost shows as zero and stock does not drop until you add recipes. Add them on the Menu page, starting with your best sellers.

**Already running an older copy?** Your old database keeps its demo dishes. Delete the `data` folder to start fresh with your menu, or keep the data and use Import CSV with `menu-master.csv`.

## Stopping a category, discounts, bills and menu engineering

- **Stop a whole category:** on the Menu page each category has **Stop category** (also a switch list on the Orders screen). Choose how long: until you switch it back on, 30 minutes to 4 hours, or until 6 am tomorrow. Stopped categories disappear from the counter, your website and WhatsApp, and dishes you had switched off individually stay off when the category restarts. If Swiggy or Zomato is connected, their stock is updated too.
- **Discount without a code:** when placing an order choose **%** or **₹**, enter the amount and an optional reason. It works together with a promo code. Owner and Manager can give any discount. Cashiers are limited by a percentage you set in Settings. Aggregator orders cannot use it. The discount, who gave it and why are kept on the order and printed on the bill.
- **Bills for 58 mm printers:** open the user menu, then **Bill printing**. Choose the paper (58 mm or 80 mm) and the text size, and print a test bill. Text is bold and large, and the bill shows customer name, phone and address, the number of unique items and total quantity, the discount and GST. In the print window pick your thermal printer and its 58 mm roll size, set margins to none and turn off headers and footers. The setting is kept per device, because each device has its own printer. The layout was checked at 58 mm in a PDF render, not on a physical printer.
- **Menu engineering:** the second tab on the Menu page rates each dish as Star, Plowhorse, Puzzle or Dog from how much it sells and how many rupees it leaves after food cost, using your sales sheet or your own orders. Dishes with no cost yet are left out rather than shown as 100% profitable. Costs from your sheet (ingredient, operating and packaging) are on each dish. Dishes that came only from the engineering sheet start switched off, so check each one before you switch it on.
- **Selling prices** are not changed by the engineering sheet. Where its MRP differs from your menu price, the dish keeps the menu price.

## Printer settings, bill content and the UPI QR

- **Per device** (profile menu → Printer settings): paper (58 mm at 48 or 54 mm, or 80 mm), text size, bill copies, kitchen-ticket copies, tear-off space, QR size, and automatic printing of the bill and/or kitchen ticket when you place an order. There are test prints for both, with a live preview. Each device keeps its own, because each has its own printer.
- **For every device** (Settings → Bill & printing, owner only): tagline, phone, email, website, social handle, an extra header line, the thank-you line, small print, switches for what the bill shows (channel, customer block, GSTIN, FSSAI, unique items, total quantity, CGST/SGST split, note, "Paid by"), and the UPI QR. Kitchen name, address, GSTIN and FSSAI stay in the Business tab.
- **UPI QR**: prints a standard `upi://pay` code with your UPI ID, payee name, the exact bill amount and a note such as "Bill B1042". Choose to show it on UPI orders only, or on every order that the platform has not already paid for. Swiggy and Zomato orders never get one. The code is generated in the app with no outside service, and was decoded back from a printed PDF to check it.
- **Kitchen ticket (KOT)**: big quantities, no prices. Print it from the order drawer or from a ticket on the kitchen screen.
- Limit: the app cannot see whether a customer paid by scanning. Check your bank or UPI app, then record the payment mode. Automatic confirmation needs a payment-gateway integration (Razorpay, PhonePe and so on), which is not built.

## GST

Settings → GST (each outlet has its own):
- **Registration**: regular (GST at each dish's rate), composition (no tax charged, bill says BILL OF SUPPLY) or not registered. With a GSTIN set, regular bills are headed TAX INVOICE.
- **Prices include GST**: off = tax added on top; on = the customer pays the menu price and tax is shown as part of it. Sales and profit always leave tax out.
- **Rate for new dishes**, **GST on packaging**, and a bulk tool to set every dish or one category to a rate.
- **Swiggy and Zomato**: tick to charge no GST on their orders (they collect and pay it themselves).
- The bill shows a CGST and SGST pair per rate, with the taxable amount when there is more than one rate. Each order remembers the rules it was billed under, so old bills never change when you change settings.
- Not covered: GST returns, HSN codes, IGST for sales across states.

## Several outlets

Each outlet is a separate database file, so menus and prices, customers, stock, orders, expenses, channels, GST, bill wording and automations cannot mix. What is shared: people (with a list of outlets each can use; the owner can use all) and the outlet list.
- Settings → Outlets (owner): add an outlet, empty or copied from another (menu and recipes, rates and wording, automation rules; never orders, customers, expenses or stock counts), close one, and see all outlets side by side (orders, sales and net today and this month).
- People can be given outlets in Settings → People. Those with more than one get an outlet switcher in the top bar. Switching affects only that device. A device with saved, unsent actions cannot switch until they are sent.
- Bills use the outlet's prefix, such as KR1042. Order numbers start at 1001 in every outlet.
- Website ordering: `/order?outlet=<link name>`. With more than one open outlet, `/order` shows a picker.
- Partner and WhatsApp webhooks: add `?outlet=<link name>` to the address, or enter the partner's store ID in that outlet's Settings → Channels and the right outlet is found from the order. With more than one outlet and neither, the webhook is refused rather than guessed.
- Existing single-kitchen data becomes outlet 1 on first start, with everyone assigned to it. Nothing to do.
- Limits: one set of social media accounts and WhatsApp numbers per server (environment variables), not per outlet. A person has one role everywhere. No stock transfers between outlets, and no combined customer list.

## Order types, charges, split payments, day close

- **Order types**: Dine-in (with a table), Takeaway and Delivery on every order. Shown on the board, the bill and the kitchen ticket. Walk-in defaults to Takeaway, other channels to Delivery.
- **Charges** (Settings → GST): a delivery charge (with an optional "free above" amount) on Delivery orders and a service charge on Dine-in orders. Own channels only, never Swiggy or Zomato. GST on these charges is a separate rate.
- **Split payments**: pay one bill in cash, UPI and card. Open an order → Payment → Change to record or fix it. The bill shows each mode, "Balance due" when not fully paid, and the UPI QR then asks for just the balance.
- **Cancel reasons**: cancelling asks for a reason from a list (customer request, did not pick up, out of stock, and so on). They appear in the day report.
- **Day close** (owner and manager): sales, discounts, charges, tax by rate with CGST/SGST, payments by mode, channel and order type, cancellations, and a cash drawer check (opening cash + cash sales − cash expenses = expected, compared with what you counted). Close it to keep a record, print it on the thermal printer, and see recent closings.
- **Exports**: dish-wise sales and bill-wise sales with the tax split, as CSV for Excel or Google Sheets.
- Not built: editing items on an order after it is placed (cancel and re-enter instead), store timings, table maps, delivery rider tracking, loyalty points.

## Add-ons on any dish

Open **Menu → Add-ons** to make groups of choices: *Size* (pick one, required), *Extras* (extra cheese, dips, up to 3), *Spice level*, *No onion / no garlic* and so on.

- Each option has a **price**, an optional **cost**, and can be tied to a **stock item** with the amount one use takes (two cheese slices, say). Stock goes down when the order is accepted and comes back if it is cancelled. Cost feeds the order profit.
- Attach a group to **chosen dishes, every dish, or a whole category**. A dish with several sizes carries the same groups on every size. You can also tick groups inside the dish editor.
- A group can be **required** ("must choose at least 1") and **limited** ("at most 3"). One-pick groups show as a pick-one list; others as +/- steppers. The server checks all of it, and always works out the price itself.
- The counter shows a choice box when you tap a dish that has add-ons, with a note field for that dish. The website order page shows the same choices. Add-ons appear on the kitchen ticket, the bill and the order board.
- Add-ons are taxed at the dish's GST rate, as part of the dish price. The Add-ons dialog shows what each add-on sold and earned over the last 30 days.
- Switching an add-on off, or running out of its stock item, hides it everywhere without touching old orders.

## Hosted mode: many businesses on one server

Set `MULTI_TENANT=1` and the same app serves many businesses. Each one gets its own folder under `DATA_DIR/tenants/<id>/`, so one business can never see another's data and each can be restored alone. Business #1 is the original data folder, so an existing install keeps working.

- **Sign-up:** `/signup` creates a business with a 14-day trial, no card. The owner signs in with email and password. Set `SIGNUPS=closed` to stop new sign-ups.
- **Staff:** staff sign in by PIN, and only on shop devices the owner has approved (Settings, Devices). The public list of staff names is not shown to unknown devices.
- **Plans and limits:** Starter (3 people, 1 outlet), Growth (10 people, 1 outlet), Pro (unlimited). Prices are per outlet before 18% GST; limits are enforced by the server.
- **Billing:** the owner sees a GST invoice (CGST and SGST, or IGST when the buyer is in another state) and a pay button. With `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` set, the button opens a payment link. Point the Razorpay webhook (event `payment_link.paid`) at `/api/webhooks/razorpay` and set `RAZORPAY_WEBHOOK_SECRET`; a signed, paid event extends the paid-until date once, even if it arrives twice. Without keys, set `MANUAL_PAYMENT_NOTE` and record payments through the operator API. After the trial or plan ends there is a 3-day grace period, then the app shows a pay screen and the server answers 402.
- **Operator API:** set `PLATFORM_TOKEN` (16 characters or more) and call `/api/platform/accounts` (list, `PATCH` to change plan, status or trial, `POST .../payments` to record a payment, `POST .../impersonate` for a support session) and `/api/platform/invoices` with `Authorization: Bearer <token>`.
- **Your own company on invoices:** `SELLER_NAME`, `SELLER_GSTIN`, `SELLER_ADDRESS`, `SELLER_STATE`, `SELLER_SAC`, `SELLER_EMAIL`. Have an accountant confirm the service code and place of supply first.

## Silent printing (print helper)

Browsers always show a print dialog, so a small helper does the printing. In Settings, Printers, add a printer, choose "Set up the print helper", and copy the command it shows. On the shop PC (Node 18 or newer, no packages):

```
node tools/print-agent.mjs --server https://your-kitflo.example --key ag_...
```

The helper only makes outbound requests, so nothing is opened on the shop network. A printer is reached as a network printer (`tcp:192.168.1.50:9100`), a device file (`device:/dev/usb/lp0`) or an installed system printer (`os:<name>`). Bills and kitchen tickets are plain ESC/POS for 58 mm or 80 mm paper, with a built-in QR for UPI. They use English letters only; other scripts such as Hindi dish names print as question marks, so give dishes a Latin name for the printer. When the helper is online, the Print buttons send the job silently, and orders can print automatically on accept; when it is offline, printing falls back to the browser. `--once` prints what is waiting and exits, which is handy for testing.

## Backups and restore

The server makes a consistent copy of every database, plus pictures and receipts, each night at `BACKUP_HOUR` (default 3, server time) into `BACKUP_DIR` (default `DATA_DIR/backups`), keeping the last `BACKUP_KEEP` (default 7). Set `BACKUP_COMMAND` to run your own step after each backup, for example an `rclone` or `aws s3 sync` line, so copies leave the server. `BACKUP_ENABLED=0` turns it off. A single-business install also has a "Back up now" button in Settings.

```
node server/backup.js backup
node server/backup.js list
node server/backup.js restore <backup name>                 # everything
node server/backup.js restore <backup name> --tenant 7      # one business only
```

Stop the server before a restore. What was there is kept in `DATA_DIR/before-restore-<time>`. Try a restore on a spare folder before your first paying customer.

## Integration partners (Dyno, UrbanPiper, LimeTray, FoodEngine, direct)

In **Settings, Channels** pick a partner for Swiggy, Zomato and, if your website orders come through LimeTray or FoodEngine, the Website channel. Each partner has its own address to give them: `/api/webhooks/aggregator/limetray`, `/foodengine`, `/dyno`, `/urbanpiper`, `/direct`, sent with the header `X-Webhook-Secret`.

Orders from LimeTray and FoodEngine arrive as Swiggy, Zomato or Website depending on the order's source field. If there is no source, they count as Website. Accept, ready, cancel and out-of-stock updates are sent to that partner's outbound address as `{ provider, action, payload }`.

**Honest limits:** I could not find public developer documentation for LimeTray, and found nothing for FoodEngine. The field names and the outbound call format are a generic guess that accepts common spellings. Ask each company for its partner API documents and sandbox, then adjust the names in `server/integrations/aggregator.js`. Tested here against a made-up partner only. Nothing was tested against LimeTray's or FoodEngine's real systems.

## Deploy so every device can reach it

Any host that runs Node and keeps a disk works (Fly.io, Railway, Render with a disk, a small VPS). Put it behind HTTPS (needed for installing the app and for alerts).

1. Set `NODE_ENV=production`, `DATA_DIR=/data` on a persistent volume, `TZ=Asia/Kolkata`.
2. Back up the `.db` file in `DATA_DIR` daily. It is one SQLite file.
3. Run one instance only (SQLite and live updates are per process).
4. Behind a proxy or load balancer set `TRUST_PROXY=1`, so sign-in limits use each person's own address.

A `Dockerfile` and an example `fly.toml` are included (health check at `/healthz`). The Docker image has not been built here, so build and run it once locally before relying on it.

**Sign-in protection:** 5 wrong PINs from one address lock that user for 1 minute. 10 wrong PINs from anywhere lock the account for 5 minutes, doubling up to 1 hour. The catch: someone who knows a user's name can lock that person out for a while. Use 6-digit PINs for Owner and Manager.

## Settings (environment variables)

| Variable | Purpose |
|---|---|
| `PORT`, `DATA_DIR`, `TZ`, `NODE_ENV` | basics |
| `TRUST_PROXY=1` | read the client address from `X-Forwarded-For` (use behind one proxy) |
| `SEED_DEMO=1` | first run loads a demo kitchen instead of your menu |
| `<NAME>_PIN` | fixed first-run PIN, e.g. `OWNER_PIN=4821` |
| `ENABLE_SIMULATOR=1` | enables `/api/dev/simulate-order` outside development |
| `PUBLIC_BASE_URL` | shown in webhook addresses and post links |
| `AGGREGATOR_WEBHOOK_SECRET` | required header `X-Webhook-Secret` on Swiggy/Zomato partner webhooks |
| `AGGREGATOR_OUTBOUND_URL`, `AGGREGATOR_OUTBOUND_TOKEN` | where accept, ready, reject and stock updates are sent |
| `LIMETRAY_WEBHOOK_SECRET`, `LIMETRAY_OUTBOUND_URL`, `LIMETRAY_OUTBOUND_TOKEN` | LimeTray only. Optional. Each partner (`FOODENGINE_…`, `DYNO_…`, `URBANPIPER_…`, `DIRECT_…`) can have its own set. Anything not set falls back to the shared `AGGREGATOR_…` values |
| `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_ID`, `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_APP_SECRET` | WhatsApp Cloud API orders |
| `MULTI_TENANT=1`, `SIGNUPS`, `PLATFORM_TOKEN`, `RAZORPAY_*`, `SELLER_*`, `MANUAL_PAYMENT_NOTE` | hosted mode, see above |
| `BACKUP_DIR`, `BACKUP_HOUR`, `BACKUP_KEEP`, `BACKUP_COMMAND`, `BACKUP_ENABLED` | backups, see above |
| `SOCIAL_ADAPTER=meta`, `META_PAGE_ID`, `META_PAGE_TOKEN`, `META_IG_USER_ID` | real Instagram and Facebook publishing |

## What is real and what is simulated

Verified by the tests and in a browser:
- Orders from walk-in, website and the aggregator webhook. Duplicate webhooks and retried requests create one order.
- Stock deducts on accept and returns on cancel. Profit, expenses, recurring costs, roles and live updates work.
- A surplus ingredient creates a discounted promo draft that waits for approval.

**Not verified against live services** (no credentials were available):
- Swiggy and Zomato through Dyno or UrbanPiper. The inbound webhook and outbound calls use a generic adapter. Map your provider's field names in `server/integrations/aggregator.js` and test with their sandbox first.
- WhatsApp Cloud API and Meta Graph publishing.
- Printing on a real thermal printer: the ESC/POS bytes are tested and a test helper prints them to a local socket, but no paper has been tried. Test on a 58 mm and an 80 mm printer first.
- Razorpay: the payment link call and the signed webhook are tested against a local stand-in, not the live service.
- Backups are tested for restore on a spare folder, but nothing copies them off the server until you set `BACKUP_COMMAND`.

**Simulated by default:** social publishing (the `mock` adapter marks posts published without sending them) and engagement numbers. The Social screen shows a banner while this is on.

## Layout

```
server/   db.js domain.js analytics.js social.js automations.js auth.js bus.js http.js index.js seed.js integrations/
public/   index.html order.html css/app.css js/core.js js/charts.js js/app.js js/views/*.js sw.js
menu-master.csv   your menu in the import format
test/     api.test.js
```
