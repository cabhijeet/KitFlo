// Stop and restart a whole category (for example when the kitchen runs out of gravies, or Late Night Meals are over).
import { h, modal, post, toast, field, select, toggle, badge, hhmm, dshort, busy } from './core.js';

const OPTIONS = [['', 'Until I switch it back on'], ['30', 'For 30 minutes'], ['60', 'For 1 hour'], ['120', 'For 2 hours'], ['240', 'For 4 hours'], ['tomorrow', 'Until tomorrow 6 am']];
const untilIso = (v) => {
  if (!v) return null;
  if (v === 'tomorrow') { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(6, 0, 0, 0); return d.toISOString(); }
  return new Date(Date.now() + Number(v) * 60000).toISOString();
};
export const stoppedText = (c) => (c.until ? `Back on at ${hhmm(c.until)}${new Date(c.until).toDateString() !== new Date().toDateString() ? ', ' + dshort(c.until) : ''}` : 'Stopped until you switch it on');

/** Asks how long to stop the category, then stops it. Resolves true if it was stopped. */
export function stopCategory(cat) {
  return new Promise((resolve) => {
    let done = false; const sel = select(OPTIONS, '');
    const m = modal({
      title: `Stop ${cat.name}?`, size: 'sm', onClose: () => { if (!done) resolve(false); },
      body: h('div', { class: 'stack' }, h('p', {}, `None of the ${cat.items} dishes in ${cat.name} can be ordered while it is stopped. This covers the counter, your website and WhatsApp. If Swiggy and Zomato are connected they are told too. Dishes you switched off one by one stay off when it comes back.`), field('How long', sel)),
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'),
        h('button', { class: 'btn danger', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { await post('/api/menu-categories/availability', { name: cat.name, off: true, until: untilIso(sel.value) }); done = true; resolve(true); m.close(); toast(`${cat.name} is stopped`); }) }, 'Stop category')],
    });
  });
}
export async function startCategory(cat) { await post('/api/menu-categories/availability', { name: cat.name, off: false }); toast(`${cat.name} is back on`); }

/** One row per category with a switch. `onDone` is called after a change so the screen can reload. */
export function categoryList(cats, canChange, onDone) {
  return h('div', { class: 'avail' }, cats.map((c) => h('div', { class: 'sw' },
    h('div', {}, c.name, h('div', { class: 'small muted' }, c.off ? stoppedText(c) : `${c.items} dish${c.items === 1 ? '' : 'es'}`)),
    canChange ? toggle(!c.off, async (on, input) => {
      try { if (on) await startCategory(c); else { input.checked = true; if (!(await stopCategory(c))) return; input.checked = false; } onDone && onDone(); }
      catch (e) { input.checked = !on; toast(e.message, 'bad'); }
    }, '') : badge(c.off ? 'Stopped' : 'On', c.off ? 'bad' : 'good'))));
}
