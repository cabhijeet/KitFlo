// Customer bill for thermal printers (58 mm and 80 mm). One layout is used for the preview and for printing.
// Paper and text size are remembered per device, because each device has its own printer.
import { qrSvg, upiLink } from './qr.js';
import { h, mount, readPref, savePref, inr2, dtime, CH, get, post, toast, modal, S, field, select, toggle, seg, can } from './core.js';

export const PAPERS = [
  ['48', '58 mm roll (prints 48 mm wide)', 58],
  ['54', '58 mm roll, full width (54 mm)', 58],
  ['72', '80 mm roll (prints 72 mm wide)', 80],
];
export const TYPE_LABEL = { dine_in: 'Dine-in', takeaway: 'Takeaway', delivery: 'Delivery' };
export const SIZES = [['m', 'Medium', 14], ['l', 'Large', 16], ['xl', 'Extra large', 18], ['xxl', 'Huge', 20]];
export const QR_SIZES = [['s', 'Small', 55], ['m', 'Medium', 70], ['l', 'Large', 88]];
export const printPrefs = () => ({ paper: '48', size: 'l', auto: false, kot_auto: false, copies: 1, kot_copies: 1, qr: 'm', feed: 14, ...readPref('print', {}) });
const px = (k) => (SIZES.find((s) => s[0] === k) || SIZES[1])[2];

const money = (n) => inr2(n).replace('₹', '₹');
const qty = (n) => (Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100));

// Same defaults as the server, so a bill still prints if an old server does not send the layout.
export const LAYOUT = {
  tagline: '', phone: '', email: '', website: '', social: '', header_note: '', footer: 'Thank you! Order again soon.', footer_note: '',
  show: { channel: true, customer: true, gstin: true, fssai: true, unique_items: true, total_qty: true, tax_split: true, notes: true, paid_by: true },
  upi: { enabled: false, vpa: '', payee: '', when: 'upi', note: 'Bill {bill_no}', caption: 'Scan to pay with any UPI app' },
};
export const layoutOf = (b) => { const l = b.layout || {}; return { ...LAYOUT, ...l, show: { ...LAYOUT.show, ...(l.show || {}) }, upi: { ...LAYOUT.upi, ...(l.upi || {}) } }; };

/** Whether this bill gets a payment QR: UPI switched on with a valid ID, not an order the platform already collected money for. */
export function wantsQr(b, L = layoutOf(b)) {
  const u = L.upi; if (!u.enabled || !u.vpa || !(b.total > 0)) return false;
  if (['swiggy', 'zomato'].includes(b.channel) || b.payment_mode === 'Prepaid by platform') return false;
  if (b.balance > 0.005 && b.payments?.length) return true; // something is still to be paid
  return u.when === 'always' ? true : b.payment_mode === 'UPI';
}
export const upiFor = (b, L = layoutOf(b)) => upiLink({ vpa: L.upi.vpa, payee: L.upi.payee || (b.business || {}).name || 'Cloud Kitchen', amount: b.balance > 0.005 && b.payments?.length ? b.balance : b.total, note: (L.upi.note || '').replace(/\{bill_no\}/g, b.bill_no).replace(/\{order_no\}/g, b.order_no) });

const pct = (n) => `${Math.round(n * 100) / 100}%`;
/** Tax lines: one CGST and SGST pair per GST rate, or a single GST line, or a note for composition and unregistered kitchens. */
function taxRows(b, sh) {
  const g = b.gst, row = (l, r) => h('div', { class: 'rc-row' }, h('span', {}, l), h('span', {}, r));
  if (!g) return sh.tax_split ? [row('CGST', money(b.cgst)), row('SGST', money(b.sgst))] : row('GST', money(b.tax)); // an older server
  if (g.mode !== 'regular') return g.note ? h('div', { class: 'rc-small rc-wrap' }, g.note) : null;
  const inc = g.inclusive ? ' (incl.)' : '', groups = (g.breakup || []).filter((x) => x.cgst + x.sgst > 0);
  if (!groups.length) return null;
  if (!sh.tax_split) return [row('GST' + inc, money(b.tax)), g.inclusive ? h('div', { class: 'rc-small' }, 'Prices include GST') : null];
  return [groups.length > 1 || g.inclusive ? h('div', { class: 'rc-small' }, g.inclusive ? 'Prices include GST' : 'GST') : null,
    groups.map((x) => [groups.length > 1 ? h('div', { class: 'rc-small' }, `${pct(x.rate)} on ${money(x.taxable)}`) : null, row(`CGST ${pct(x.rate / 2)}${inc}`, money(x.cgst)), row(`SGST ${pct(x.rate / 2)}${inc}`, money(x.sgst))])];
}

/** The bill as an element. `b` is what /api/orders/:id/bill returns. */
export function receipt(b, prefs = printPrefs()) {
  const biz = b.business || {}, L = layoutOf(b), sh = L.show;
  const row = (l, r, cls = '') => h('div', { class: `rc-row ${cls}` }, h('span', {}, l), h('span', {}, r));
  const rule = () => h('div', { class: 'rc-rule' });
  const discountLines = [];
  if (b.promo_discount > 0) discountLines.push(row(`Promo ${b.promo_code || ''}`.trim(), '−' + money(b.promo_discount)));
  if (b.manual_discount > 0) { discountLines.push(row('Discount', '−' + money(b.manual_discount))); const note = [b.discount_type === 'percent' && b.discount_value ? `${qty(b.discount_value)}%` : '', b.discount_reason || ''].filter(Boolean).join(' · '); if (note) discountLines.push(h('div', { class: 'rc-small' }, note)); }
  if (!discountLines.length && b.discount > 0) discountLines.push(row('Discount', '−' + money(b.discount)));
  const hasCust = b.customer || b.phone || b.address;
  const qrOn = wantsQr(b, L), qrPct = (QR_SIZES.find((x) => x[0] === prefs.qr) || QR_SIZES[1])[2];
  const small = (t) => (t ? h('div', { class: 'rc-center rc-small' }, t) : null);
  return h('div', { class: 'receipt', style: { '--pw': prefs.paper + 'mm', '--pf': px(prefs.size) + 'px' } },
    h('div', { class: 'rc-center rc-name' }, biz.name || 'Cloud Kitchen'),
    small(L.tagline), small(biz.address), small(L.phone && `Ph: ${L.phone}`), small(L.email), small(L.website), small(L.social),
    sh.gstin && biz.gstin ? small(`GSTIN ${biz.gstin}`) : null,
    sh.fssai && biz.fssai ? small(`FSSAI ${biz.fssai}`) : null,
    L.header_note ? h('div', { class: 'rc-center rc-small rc-wrap', style: { marginTop: '3px' } }, L.header_note) : null,
    b.gst?.title ? h('div', { class: 'rc-center rc-b', style: { marginTop: '3px' } }, b.gst.title) : null,
    rule(),
    row('Bill', b.bill_no, 'rc-b'), row('Order', `#${b.order_no}`), row('Date', dtime(b.date)), sh.channel ? row('Via', CH[b.channel] || b.channel) : null, b.order_type ? row('Type', (TYPE_LABEL[b.order_type] || b.order_type) + (b.table_no ? ` · ${b.table_no}` : '')) : null,
    sh.customer ? [rule(), h('div', { class: 'rc-b' }, 'Customer'),
      hasCust ? [b.customer ? h('div', {}, b.customer) : null, b.phone ? h('div', {}, `Ph: ${b.phone}`) : null, b.address ? h('div', { class: 'rc-wrap' }, b.address) : null] : h('div', {}, 'Walk-in customer')] : null,
    rule(),
    b.lines.map((l) => h('div', { class: 'rc-item' }, h('div', { class: 'rc-iname' }, l.name), l.modifiers ? h('div', { class: 'rc-small' }, l.modifiers) : null, row(`${qty(l.qty)} × ${money(l.rate)}`, money(l.amount)))),
    rule(),
    sh.unique_items ? row('Unique items', String(b.unique_items), 'rc-b') : null, sh.total_qty ? row('Total quantity', qty(b.total_qty), 'rc-b') : null,
    sh.unique_items || sh.total_qty ? rule() : null,
    row('Subtotal', money(b.subtotal)), discountLines,
    b.packaging_fee ? row('Packaging', money(b.packaging_fee)) : null, b.delivery_fee ? row('Delivery charge', money(b.delivery_fee)) : null, b.service_charge ? row('Service charge', money(b.service_charge)) : null,
    taxRows(b, sh),
    h('div', { class: 'rc-rule rc-solid' }),
    row('TOTAL', money(b.total), 'rc-total'),
    sh.paid_by ? (b.payments?.length > 1 ? [h('div', { class: 'rc-b' }, 'Paid'), b.payments.map((x) => row(x.mode, money(x.amount)))] : h('div', { class: 'rc-center' }, `Paid by ${b.payment_mode || '–'}`)) : null,
    b.balance > 0.005 ? row('Balance due', money(b.balance), 'rc-total') : null,
    qrOn ? h('div', { class: 'rc-qr' }, L.upi.caption ? h('div', { class: 'rc-center rc-b' }, L.upi.caption) : null, h('div', { class: 'rc-qrbox', style: { width: qrPct + '%' } }, qrSvg(upiFor(b, L))), h('div', { class: 'rc-center rc-small' }, `${money(b.balance > 0.005 && b.payments?.length ? b.balance : b.total)} to ${L.upi.vpa}`)) : null,
    sh.notes && b.notes ? [rule(), h('div', { class: 'rc-b' }, 'Note'), h('div', { class: 'rc-wrap' }, b.notes)] : null,
    rule(), L.footer ? h('div', { class: 'rc-center rc-b rc-wrap' }, L.footer) : null, L.footer_note ? h('div', { class: 'rc-center rc-small rc-wrap', style: { marginTop: '3px' } }, L.footer_note) : null);
}

/** Kitchen order ticket: big quantities, no prices, for the kitchen printer. */
export function kot(b, prefs = printPrefs()) {
  const rule = () => h('div', { class: 'rc-rule' });
  return h('div', { class: 'receipt kot', style: { '--pw': prefs.paper + 'mm', '--pf': px(prefs.size) + 'px' } },
    h('div', { class: 'rc-center rc-name' }, 'KITCHEN ORDER'),
    h('div', { class: 'rc-center rc-big' }, `#${b.order_no}`),
    b.order_type ? h('div', { class: 'rc-center rc-b' }, (TYPE_LABEL[b.order_type] || b.order_type).toUpperCase() + (b.table_no ? ` · TABLE ${b.table_no}` : '')) : null,
    h('div', { class: 'rc-row' }, h('span', {}, CH[b.channel] || b.channel), h('span', {}, dtime(b.date))),
    rule(),
    b.lines.map((l) => h('div', { class: 'rc-kline' }, h('span', { class: 'rc-kq' }, `${qty(l.qty)}×`), h('span', {}, h('b', {}, l.name), l.modifiers ? h('div', { class: 'rc-small' }, l.modifiers) : null))),
    rule(), h('div', { class: 'rc-row rc-b' }, h('span', {}, 'Items'), h('span', {}, `${b.unique_items} dishes · ${qty(b.total_qty)} qty`)),
    b.notes ? [rule(), h('div', { class: 'rc-b' }, 'Note'), h('div', { class: 'rc-wrap rc-bignote' }, b.notes)] : null);
}

const rollOf = (prefs) => (PAPERS.find((p) => p[0] === prefs.paper) || PAPERS[0])[2];
/** Chrome ignores "size: 58mm auto" and falls back to a Letter page, which the printer then shrinks to fit the roll. That is why bills came out tiny. So the page gets the real roll width and the real bill height. */
function pageStyle(prefs) {
  const roll = rollOf(prefs), pa = document.getElementById('print-area'), keep = pa.style.cssText;
  pa.style.cssText = `display:block;position:absolute;left:-9999px;top:0;width:${roll}mm`;
  const one = pa.firstElementChild, mm = Math.ceil((one ? one.getBoundingClientRect().height : pa.scrollHeight) * 25.4 / 96) + Math.max(0, Number(prefs.feed) || 0); // blank paper at the end to tear off
  pa.style.cssText = keep;
  let st = document.getElementById('print-page');
  if (!st) { st = document.createElement('style'); st.id = 'print-page'; document.head.append(st); }
  st.textContent = `@page { size: ${roll}mm ${mm}mm; margin: 0; }`;
}

function printNodes(make, copies) {
  const prefs = printPrefs(), n = Math.min(5, Math.max(1, Number(copies) || 1)), pa = document.getElementById('print-area');
  mount(pa, Array.from({ length: n }, () => make(prefs)));
  pageStyle(prefs);
  setTimeout(() => window.print(), 80);
}
/** Prints a bill for an order. */
export async function printBill(orderId) { if (await viaHelper(orderId, 'bill')) return; printReceipt(await get(`/api/orders/${orderId}/bill`)); }
/** Sends the print to the shop's print helper when it is connected, so no print window opens. False means print in the browser instead. */
async function viaHelper(orderId, kind) {
  const p = S.print; if (!p?.online || !p.printers.some((x) => x.role === 'both' || x.role === kind)) return false;
  try { await post(`/api/orders/${orderId}/print`, { kind }); toast(kind === 'kot' ? 'Kitchen ticket sent to the printer' : 'Bill sent to the printer'); return true; } catch { return false; }
}
/** Prints any element built for the receipt printer, such as the day report. */
export const printNode = (make) => printNodes(make, 1);
export const printReceipt = (b) => printNodes((p) => receipt(b, p), printPrefs().copies);
/** Prints the kitchen ticket for an order. */
export async function printKot(orderId) { if (await viaHelper(orderId, 'kot')) return; printKotFor(await get(`/api/orders/${orderId}/bill`)); }
export const printKotFor = (b) => printNodes((p) => kot(b, p), printPrefs().kot_copies);

export const SAMPLE = {
  bill_no: 'B1042', order_no: 1042, date: new Date().toISOString(), channel: 'walkin', customer: 'Rhea Sharma', phone: '9876543210', address: 'Flat 4B, Green Park, near the metro station', notes: 'Less spicy',
  lines: [{ name: 'Matar Paneer · Half 500 ML (Serves 2-3)', qty: 1, rate: 409, amount: 409 }, { name: 'Wheat Phulka', qty: 6, rate: 19, amount: 114 }, { name: 'Sweet Lassi', qty: 2, rate: 79, amount: 158 }],
  unique_items: 3, total_qty: 9, subtotal: 681, discount: 68.1, promo_code: null, promo_discount: 0, manual_discount: 68.1, discount_type: 'percent', discount_value: 10, discount_reason: 'Regular customer',
  taxable: 612.9, cgst: 15.32, sgst: 15.32, tax: 30.64, gst: { mode: 'regular', inclusive: false, title: 'BILL', note: '', breakup: [{ rate: 5, taxable: 612.9, cgst: 15.32, sgst: 15.32 }] }, packaging_fee: 10, total: 653.54, payment_mode: 'UPI', business: { name: 'Cloud Kitchen', address: 'Your address here', gstin: '', fssai: '' },
};

/** Settings for this device's printer, with a live preview and test prints. What the bill says (header, footer, UPI) is shared, and lives in Settings. */
export async function printSettings() {
  const p = printPrefs(), prev = h('div', { class: 'rc-preview' }); let view = 'bill', sample = { ...SAMPLE };
  try { const [cfg, me] = [await get('/api/bill-layout')]; sample = { ...SAMPLE, layout: cfg.layout, business: cfg.business }; } catch { /* sample falls back to defaults */ }
  const save = () => { savePref('print', p); draw(); };
  const draw = () => mount(prev, view === 'bill' ? receipt(sample, p) : kot(sample, p));
  const num = (k, lo, hi, step = 1) => h('input', { type: 'number', min: lo, max: hi, step, value: p[k], onchange: (e) => { p[k] = Math.min(hi, Math.max(lo, Number(e.target.value) || lo)); e.target.value = p[k]; save(); } });
  const m = modal({
    title: 'Printer settings for this device', size: 'lg',
    body: h('div', { class: 'neworder' },
      h('div', { class: 'stack' },
        field('Paper', select(PAPERS.map((x) => [x[0], x[1]]), p.paper, { onchange: (e) => { p.paper = e.target.value; save(); } }), 'Most 58 mm printers print 48 mm. If the bill is cut off on the right, choose the 48 mm option. If there is a wide empty margin, choose the 54 mm option.'),
        field('Text size', seg(SIZES.map((x) => [x[0], x[1]]), p.size, (v) => { p.size = v; save(); }), 'Make it bigger until it is easy to read at arm’s length.'),
        h('div', { class: 'form-grid' }, field('Bill copies', num('copies', 1, 5)), field('Kitchen ticket copies', num('kot_copies', 1, 5)), field('Space to tear off (mm)', num('feed', 0, 60, 2))),
        field('Payment QR size', seg(QR_SIZES.map((x) => [x[0], x[1]]), p.qr, (v) => { p.qr = v; save(); }), 'Bigger codes scan faster across the counter. Turn the QR on or off for all devices in Settings.'),
        toggle(p.auto, (on) => { p.auto = on; savePref('print', p); }, 'Print the bill automatically when I place an order'),
        toggle(p.kot_auto, (on) => { p.kot_auto = on; savePref('print', p); }, 'Print the kitchen ticket automatically when I place an order'),
        h('div', { class: 'notice info small' }, h('strong', {}, 'In the print window: '), 'choose your thermal printer and the paper size that matches your roll (58 mm or 80 mm), set margins to None and scale to 100% (not “Fit to page”), and untick Headers and footers. If text is still small, raise the size here rather than zooming. The bill is sent at the true roll width, so it should not be shrunk.'),
        h('div', { class: 'row' }, h('button', { class: 'btn primary', type: 'button', onclick: () => printReceipt(sample) }, 'Print a test bill'), h('button', { class: 'btn', type: 'button', onclick: () => printKotFor(sample) }, 'Print a test kitchen ticket'),
          can('settings') ? h('button', { class: 'btn', type: 'button', onclick: () => { savePref('set_tab', 'bill'); m.close(); location.hash = '#/settings'; } }, 'Edit header, footer and UPI…') : null)),
      h('div', {}, h('div', { class: 'row between', style: { marginBottom: '6px' } }, h('p', { class: 'small muted' }, 'Preview'), seg([['bill', 'Bill'], ['kot', 'Kitchen ticket']], view, (v) => { view = v; draw(); })), prev)),
    actions: [h('button', { class: 'btn', type: 'button', onclick: () => { m.close(); toast('Printer settings saved on this device'); } }, 'Done')],
  });
  draw();
}
