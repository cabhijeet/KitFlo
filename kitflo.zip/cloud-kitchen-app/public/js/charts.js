// Charts drawn as SVG/CSS from the API's numbers. Colours come from CSS variables so light and dark mode both work.
// Rules followed: thin marks, one axis, recessive grid, direct labels, tooltips on hover/tap, a table view for every chart.
import { h, mount, inr, num, pct, dshort, tip, ico, seg } from './core.js';

const NS = 'http://www.w3.org/2000/svg';
export function s(tag, attrs = {}, ...kids) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) { if (v === undefined || v === null || v === false) continue; if (k === 'style' && typeof v === 'object') Object.assign(el.style, v); else el.setAttribute(k, v); }
  for (const k of kids.flat()) if (k !== null && k !== undefined && k !== false) el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return el;
}
export const short = (n) => { const a = Math.abs(n), sg = n < 0 ? '−' : ''; return a >= 1e7 ? `${sg}₹${num(a / 1e7, 1)}Cr` : a >= 1e5 ? `${sg}₹${num(a / 1e5, 1)}L` : a >= 1e3 ? `${sg}₹${num(a / 1e3, a >= 1e4 ? 0 : 1)}k` : `${sg}₹${Math.round(a)}`; };
function niceMax(max, n = 4) { if (max <= 0) return { max: 1, step: 0.25 }; const raw = max / n, pow = 10 ** Math.floor(Math.log10(raw)); const f = raw / pow; const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * pow; return { max: step * Math.ceil(max / step), step }; }
const ticksOf = (lo, hi, step) => { const t = []; for (let v = lo; v <= hi + 1e-9; v += step) t.push(Math.round(v * 1e6) / 1e6); return t; };

export function responsive(box, draw) {
  let w = 0;
  const run = () => { const nw = Math.floor(box.clientWidth); if (nw > 40 && nw !== w) { w = nw; mount(box, draw(nw)); } };
  new ResizeObserver(run).observe(box); run();
}

/** A card with a title, optional legend, the chart, and a "Table" switch so numbers are readable without colour or hover. */
export function chartCard({ title, sub, legend, draw, table, wide = false, note }) {
  const body = h('div', { class: 'chart-body' });
  const showChart = () => { mount(body); draw(body); };
  const showTable = () => mount(body, h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, table.head.map((c, i) => h('th', { class: i ? 'num' : '' }, c)))), h('tbody', {}, table.rows.map((r) => h('tr', {}, r.map((c, i) => h('td', { class: i ? 'num' : '' }, c))))))));
  const card = h('section', { class: `card chart-card${wide ? ' wide' : ''}` },
    h('header', { class: 'card-h' }, h('div', {}, h('h3', {}, title), sub ? h('p', { class: 'muted small' }, sub) : null),
      table ? seg([['chart', 'Chart'], ['table', 'Table']], 'chart', (v) => (v === 'chart' ? showChart() : showTable())) : null),
    legend ? h('ul', { class: 'legend' }, legend.map((l) => h('li', {}, h('i', { style: { background: l.color } }), l.label))) : null, body, note ? h('p', { class: 'muted small' }, note) : null);
  showChart(); return card;
}

export function sparkline(values, { w = 96, hgt = 28, color = 'var(--accent)' } = {}) {
  if (!values.length) return h('span');
  const lo = Math.min(...values), hi = Math.max(...values), span = hi - lo || 1;
  const pts = values.map((v, i) => [values.length === 1 ? w / 2 : (i / (values.length - 1)) * (w - 4) + 2, hgt - 3 - ((v - lo) / span) * (hgt - 6)]);
  return s('svg', { viewBox: `0 0 ${w} ${hgt}`, width: w, height: hgt, 'aria-hidden': 'true', class: 'spark' },
    s('path', { d: 'M' + pts.map((p) => p.map((n) => n.toFixed(1)).join(',')).join('L'), fill: 'none', style: { stroke: color }, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }),
    s('circle', { cx: pts.at(-1)[0], cy: pts.at(-1)[1], r: 3, style: { fill: color } }));
}

/** Time series with hover crosshair. series: [{name, color, values}], labels: ISO dates. */
export function lineChart(box, { labels, series, height = 230, fmt = inr }) {
  responsive(box, (W) => {
    const m = { l: 46, r: 12, t: 12, b: 26 }, iw = W - m.l - m.r, ih = height - m.t - m.b;
    const all = series.flatMap((x) => x.values), lo0 = Math.min(0, ...all), hi0 = Math.max(...all, 1);
    const { max, step } = niceMax(hi0 - Math.min(0, lo0)), lo = lo0 < 0 ? -niceMax(-lo0).max : 0, top = lo0 < 0 ? niceMax(hi0).max : max;
    const X = (i) => m.l + (labels.length === 1 ? iw / 2 : (i / (labels.length - 1)) * iw), Y = (v) => m.t + ih - ((v - lo) / (top - lo || 1)) * ih;
    const svg = s('svg', { viewBox: `0 0 ${W} ${height}`, width: W, height, role: 'img', 'aria-label': series.map((x) => x.name).join(' and ') + ' by day' });
    ticksOf(lo, top, step).forEach((t) => { svg.append(s('line', { x1: m.l, x2: W - m.r, y1: Y(t), y2: Y(t), class: 'grid' }), s('text', { x: m.l - 8, y: Y(t) + 4, 'text-anchor': 'end', class: 'axis' }, short(t))); });
    const nl = Math.min(labels.length, Math.max(2, Math.floor(iw / 78))), idx = Array.from({ length: nl }, (_, k) => Math.round((k / (nl - 1 || 1)) * (labels.length - 1)));
    [...new Set(idx)].forEach((i) => svg.append(s('text', { x: X(i), y: height - 6, 'text-anchor': i === 0 ? 'start' : i === labels.length - 1 ? 'end' : 'middle', class: 'axis' }, dshort(labels[i]))));
    series.forEach((x, si) => {
      const d = 'M' + x.values.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join('L');
      if (si === 0 && x.values.length > 1) svg.append(s('path', { d: `${d}L${X(x.values.length - 1)},${Y(Math.max(lo, 0))}L${X(0)},${Y(Math.max(lo, 0))}Z`, style: { fill: x.color }, 'fill-opacity': 0.1 }));
      svg.append(s('path', { d, fill: 'none', style: { stroke: x.color }, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
    });
    const cross = s('line', { y1: m.t, y2: m.t + ih, class: 'cross', style: { display: 'none' } }), dots = series.map((x) => s('circle', { r: 4.5, style: { fill: x.color, stroke: 'var(--surface)', display: 'none' }, 'stroke-width': 2 }));
    svg.append(cross, ...dots);
    const tipBox = h('div', { class: 'chart-tip', style: { display: 'none' } }), wrap = h('div', { class: 'chart-wrap' }, svg, tipBox);
    const hit = s('rect', { x: m.l, y: m.t, width: iw, height: ih, fill: 'transparent' });
    const move = (e) => {
      const r = svg.getBoundingClientRect(), px = e.clientX - r.left, i = Math.max(0, Math.min(labels.length - 1, Math.round(((px - m.l) / iw) * (labels.length - 1))));
      cross.setAttribute('x1', X(i)); cross.setAttribute('x2', X(i)); cross.style.display = '';
      dots.forEach((d, k) => { d.setAttribute('cx', X(i)); d.setAttribute('cy', Y(series[k].values[i])); d.style.display = ''; });
      mount(tipBox, h('strong', {}, dshort(labels[i])), series.map((x) => h('div', {}, h('i', { class: 'sw', style: { background: x.color } }), `${x.name}: ${fmt(x.values[i])}`)));
      tipBox.style.display = 'block'; const tw = tipBox.offsetWidth; tipBox.style.left = Math.min(W - tw - 4, Math.max(4, X(i) + 12)) + 'px'; tipBox.style.top = '8px';
    };
    const leave = () => { cross.style.display = 'none'; dots.forEach((d) => (d.style.display = 'none')); tipBox.style.display = 'none'; };
    hit.addEventListener('pointermove', move); hit.addEventListener('pointerdown', move); hit.addEventListener('pointerleave', leave); svg.append(hit);
    return wrap;
  });
}

/** Profit bridge: sales, then each deduction, ending at net profit. steps: [{label, value, kind: total|minus|result}] */
export function waterfall(box, { steps, height = 250 }) {
  responsive(box, (W) => {
    const m = { l: 8, r: 8, t: 26, b: 44 }, iw = W - m.l - m.r, ih = height - m.t - m.b;
    let run = 0; const bars = steps.map((st) => { const from = st.kind === 'minus' ? run - st.value : 0, to = st.kind === 'minus' ? run : st.value; if (st.kind === 'minus') run -= st.value; else run = st.value; return { ...st, lo: Math.min(from, to), hi: Math.max(from, to) }; });
    const top = Math.max(...bars.map((b) => b.hi), 1), bot = Math.min(0, ...bars.map((b) => b.lo));
    const Y = (v) => m.t + ih - ((v - bot) / (top - bot || 1)) * ih, bw = Math.min(64, iw / bars.length - 14), cx = (i) => m.l + (i + 0.5) * (iw / bars.length);
    const svg = s('svg', { viewBox: `0 0 ${W} ${height}`, width: W, height, role: 'img', 'aria-label': 'Profit bridge from sales to net profit' });
    svg.append(s('line', { x1: m.l, x2: W - m.r, y1: Y(0), y2: Y(0), class: 'axisline' }));
    bars.forEach((b, i) => {
      const fill = b.kind === 'minus' ? 'var(--cost)' : b.kind === 'result' && b.value < 0 ? 'var(--bad)' : 'var(--accent)';
      const y = Y(b.hi), hgt = Math.max(2, Y(b.lo) - Y(b.hi));
      const g = s('g', {}, s('rect', { x: cx(i) - bw / 2, y, width: bw, height: hgt, rx: 4, style: { fill } }),
        s('text', { x: cx(i), y: y - 7, 'text-anchor': 'middle', class: 'val' }, (b.kind === 'minus' ? '−' : '') + short(Math.abs(b.value)).replace('−', '')),
        s('text', { x: cx(i), y: height - 24, 'text-anchor': 'middle', class: 'axis' }, b.label), b.sub ? s('text', { x: cx(i), y: height - 9, 'text-anchor': 'middle', class: 'axis dim' }, b.sub) : null);
      const level = Y(b.kind === 'minus' ? b.lo : b.hi); // running total after this step
      if (i < bars.length - 1 && b.kind !== 'result') svg.append(s('line', { x1: cx(i) + bw / 2, x2: cx(i + 1) - bw / 2, y1: level, y2: level, class: 'link' }));
      tip(g, `${b.label}: ${inr(b.kind === 'minus' ? -b.value : b.value)}${b.sub ? ' (' + b.sub + ')' : ''}`); svg.append(g);
    });
    return svg;
  });
}

/** Horizontal stacked bars (parts of a whole) as flex rows. rows: [{label, dot, parts:[{key,value}]}] */
export function stackedRows({ rows, parts, fmt = inr, totalLabel }) {
  const max = Math.max(1, ...rows.map((r) => r.parts.reduce((a, p) => a + Math.max(0, p.value), 0)));
  return h('div', { class: 'srows' }, rows.map((r) => {
    const total = r.parts.reduce((a, p) => a + Math.max(0, p.value), 0);
    return h('div', { class: 'srow' }, h('div', { class: 'srow-l' }, r.dot ? h('i', { class: 'dot', style: { background: r.dot } }) : null, h('span', {}, r.label)),
      h('div', { class: 'srow-bar', 'aria-hidden': 'true' }, h('div', { class: 'srow-fill', style: { width: (total / max) * 100 + '%' } }, r.parts.filter((p) => p.value > 0).map((p) => { const def = parts.find((x) => x.key === p.key); return tip(h('b', { style: { flexGrow: p.value, background: def.color } }), `${r.label} · ${def.label}: ${fmt(p.value)}`); }))),
      h('div', { class: 'srow-v' }, r.note || fmt(total)));
  }));
}

/** Units sold vs margin per dish. Dots that are popular but thin-margin get the warning colour and a name. */
export function scatter(box, { points, height = 280 }) {
  responsive(box, (W) => {
    const m = { l: 44, r: 16, t: 12, b: 36 }, iw = W - m.l - m.r, ih = height - m.t - m.b;
    if (!points.length) return h('p', { class: 'muted' }, 'No completed orders in this period yet.');
    const xs = points.map((p) => p.x), ys = points.map((p) => p.y), xmax = niceMax(Math.max(...xs), 4), ylo = Math.min(0, Math.floor(Math.min(...ys) / 10) * 10), yhi = Math.max(100, Math.ceil(Math.max(...ys) / 10) * 10);
    const X = (v) => m.l + (v / xmax.max) * iw, Y = (v) => m.t + ih - ((v - ylo) / (yhi - ylo)) * ih, med = (a) => [...a].sort((p, q) => p - q)[Math.floor(a.length / 2)];
    const mx = med(xs), floor = 50;
    const svg = s('svg', { viewBox: `0 0 ${W} ${height}`, width: W, height, role: 'img', 'aria-label': 'Dishes by units sold and margin' });
    ticksOf(ylo, yhi, 20).forEach((t) => svg.append(s('line', { x1: m.l, x2: W - m.r, y1: Y(t), y2: Y(t), class: 'grid' }), s('text', { x: m.l - 8, y: Y(t) + 4, 'text-anchor': 'end', class: 'axis' }, t + '%')));
    ticksOf(0, xmax.max, xmax.step).forEach((t) => svg.append(s('text', { x: X(t), y: height - 18, 'text-anchor': 'middle', class: 'axis' }, num(t, 0))));
    svg.append(s('text', { x: m.l + iw / 2, y: height - 3, 'text-anchor': 'middle', class: 'axis dim' }, 'Units sold'), s('line', { x1: m.l, x2: W - m.r, y1: Y(floor), y2: Y(floor), class: 'ref' }), s('text', { x: W - m.r - 2, y: Y(floor) - 5, 'text-anchor': 'end', class: 'axis dim' }, '50% margin'));
    const flagged = (p) => p.x >= mx && p.y < floor;
    [...points].sort((a, b) => flagged(a) - flagged(b)).forEach((p) => {
      const fl = flagged(p), c = s('circle', { cx: X(p.x), cy: Y(p.y), r: 6.5, style: { fill: fl ? 'var(--warn)' : 'var(--ink-3)', stroke: 'var(--surface)' }, 'stroke-width': 2, tabindex: 0 });
      tip(c, [h('strong', {}, p.name), h('div', {}, `${num(p.x, 0)} units · ${pct(p.y)} margin`), h('div', {}, `Revenue ${inr(p.revenue)}`)]); svg.append(c);
      if (fl || p.x === Math.max(...xs)) svg.append(s('text', { x: Math.min(X(p.x) + 10, W - m.r - 4), y: Y(p.y) + 4, class: 'axis ink', 'text-anchor': X(p.x) + 10 + p.name.length * 6 > W ? 'end' : 'start' }, p.name));
    });
    return svg;
  });
}

/** One bar split into labelled segments (customers: new, repeat, lapsed). */
export function segmentBar(parts) {
  const total = parts.reduce((a, p) => a + p.value, 0) || 1;
  return h('div', {}, h('div', { class: 'segbar' }, parts.filter((p) => p.value > 0).map((p) => tip(h('b', { style: { flexGrow: p.value, background: p.color } }), `${p.label}: ${p.value}`))),
    h('ul', { class: 'legend wrap' }, parts.map((p) => h('li', {}, h('i', { style: { background: p.color } }), `${p.label} ${p.value} (${Math.round((p.value / total) * 100)}%)`))));
}

/** Budget bars: how much of each monthly limit is used. Status is also written in words, never colour alone. */
export function budgetBars(rows) {
  if (!rows.length) return h('p', { class: 'muted' }, 'No budgets set yet.');
  return h('div', { class: 'budgets' }, rows.map((b) => {
    const st = b.pct >= 100 ? 'bad' : b.pct >= 80 ? 'warn' : 'good';
    return h('div', { class: 'bud' }, h('div', { class: 'bud-h' }, h('strong', {}, b.category), h('span', { class: `st ${st}` }, b.pct >= 100 ? 'Over budget' : b.pct >= 80 ? 'Nearly used' : 'On track')),
      h('div', { class: 'bud-bar' }, h('i', { class: st, style: { width: Math.min(100, b.pct) + '%' } })), h('div', { class: 'muted small' }, `${inr(b.spent)} of ${inr(b.limit)} (${b.pct}%)`));
  }));
}
export { ico };
