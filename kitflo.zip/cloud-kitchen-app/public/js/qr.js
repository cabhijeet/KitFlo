// Small QR code encoder: byte mode, error correction M, versions 1 to 10 (up to 213 characters). No libraries.
// Built for UPI payment links, which are about 100 characters. Layout follows the QR standard (ISO 18004).

const ECC_PER_BLOCK = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26];
const BLOCKS = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];

const alignPositions = (v) => {
  if (v === 1) return [];
  const n = Math.floor(v / 7) + 2, size = v * 4 + 17, step = Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2, out = [6];
  for (let p = size - 7; out.length < n; p -= step) out.splice(1, 0, p);
  return out;
};
const rawModules = (v) => { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; };

// Reed-Solomon over GF(256)
const EXP = new Uint8Array(512), LOG = new Uint8Array(256);
{ let x = 1; for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; } for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]; }
const gmul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
function rsRemainder(data, deg) {
  let gen = [1];
  for (let i = 0; i < deg; i++) { const next = new Array(gen.length + 1).fill(0); gen.forEach((c, j) => { next[j] ^= c; next[j + 1] ^= gmul(c, EXP[i]); }); gen = next; }
  const rem = new Array(deg).fill(0);
  for (const b of data) { const f = b ^ rem.shift(); rem.push(0); for (let i = 0; i < deg; i++) rem[i] ^= gmul(gen[i + 1], f); }
  return rem;
}

/** Returns the QR code as an array of rows of booleans (true = dark). Throws if the text is too long. */
export function qrMatrix(text) {
  const bytes = [...new TextEncoder().encode(String(text))];
  let ver = 1;
  for (; ver <= 10; ver++) { const cap = (Math.floor(rawModules(ver) / 8) - ECC_PER_BLOCK[ver] * BLOCKS[ver]) * 8; if (4 + (ver < 10 ? 8 : 16) + bytes.length * 8 <= cap) break; }
  if (ver > 10) throw new Error('QR text is too long');
  const size = ver * 4 + 17, raw = Math.floor(rawModules(ver) / 8), dataCw = raw - ECC_PER_BLOCK[ver] * BLOCKS[ver];

  // bit stream
  const bits = [], put = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
  put(4, 4); put(bytes.length, ver < 10 ? 8 : 16); bytes.forEach((b) => put(b, 8));
  put(0, Math.min(4, dataCw * 8 - bits.length)); while (bits.length % 8) bits.push(0);
  const data = []; for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let pad = 0xec; data.length < dataCw; pad ^= 0xec ^ 0x11) data.push(pad);

  // blocks, error correction, interleave
  const nb = BLOCKS[ver], ecc = ECC_PER_BLOCK[ver], shortCount = nb - (raw % nb), shortLen = Math.floor(raw / nb), blocks = [];
  for (let i = 0, k = 0; i < nb; i++) { const len = shortLen - ecc + (i < shortCount ? 0 : 1), d = data.slice(k, k + len); k += len; blocks.push({ d, e: rsRemainder(d, ecc) }); }
  const words = [];
  for (let i = 0; i <= shortLen - ecc; i++) blocks.forEach((b) => { if (i < b.d.length) words.push(b.d[i]); });
  for (let i = 0; i < ecc; i++) blocks.forEach((b) => words.push(b.e[i]));

  // function patterns
  const m = Array.from({ length: size }, () => new Array(size).fill(false)), fn = Array.from({ length: size }, () => new Array(size).fill(false));
  const set = (x, y, dark) => { if (x >= 0 && y >= 0 && x < size && y < size) { m[y][x] = !!dark; fn[y][x] = true; } };
  for (let i = 0; i < size; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
  for (const [cx, cy] of [[3, 3], [size - 4, 3], [3, size - 4]]) for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)); set(cx + dx, cy + dy, d !== 2 && d !== 4); }
  const ap = alignPositions(ver);
  ap.forEach((cx, i) => ap.forEach((cy, j) => { if ((i === 0 && j === 0) || (i === 0 && j === ap.length - 1) || (i === ap.length - 1 && j === 0)) return; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }));
  const formatBits = (mask) => { let rem = mask; for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537); return ((mask << 10) | rem) ^ 0x5412; };
  const drawFormat = (mask) => {
    const f = formatBits(mask), bit = (i) => ((f >>> i) & 1) === 1;
    for (let i = 0; i <= 5; i++) set(8, i, bit(i)); set(8, 7, bit(6)); set(8, 8, bit(7)); set(7, 8, bit(8));
    for (let i = 9; i < 15; i++) set(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) set(size - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i++) set(8, size - 15 + i, bit(i));
    set(8, size - 8, true);
  };
  drawFormat(0);
  if (ver >= 7) { let rem = ver; for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25); const v = (ver << 12) | rem; for (let i = 0; i < 18; i++) { const bt = ((v >>> i) & 1) === 1, a = size - 11 + (i % 3), b = Math.floor(i / 3); set(a, b, bt); set(b, a, bt); } }

  // data modules, zigzag
  let k = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) {
      const x = right - j, y = ((right + 1) & 2) === 0 ? size - 1 - vert : vert;
      if (!fn[y][x] && k < words.length * 8) { m[y][x] = ((words[k >>> 3] >>> (7 - (k & 7))) & 1) === 1; k++; }
    }
  }

  // pick the mask with the lowest penalty
  const cond = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x, y) => x % 3 === 0, (x, y) => (x + y) % 3 === 0, (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0, (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0];
  const apply = (mask) => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && cond[mask](x, y)) m[y][x] = !m[y][x]; };
  const penalty = () => {
    let p = 0, dark = 0;
    const line = (get) => { // runs and finder-like patterns along one line
      let run = 1, hist = [];
      for (let i = 0; i < size; i++) { if (get(i)) dark++; if (i > 0 && get(i) === get(i - 1)) run++; else { if (i > 0) { hist.push(run); if (run >= 5) p += 3 + run - 5; } run = 1; } }
      hist.push(run); if (run >= 5) p += 3 + run - 5;
      const s = Array.from({ length: size }, (_, i) => (get(i) ? 1 : 0)).join('');
      for (const pat of ['10111010000', '00001011101']) for (let i = s.indexOf(pat); i >= 0; i = s.indexOf(pat, i + 1)) p += 40;
    };
    for (let y = 0; y < size; y++) line((i) => m[y][i]);
    for (let x = 0; x < size; x++) line((i) => m[i][x]);
    for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
    const total = size * size; p += (Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1) * 10;
    return p;
  };
  let best = 0, bestP = Infinity;
  for (let mask = 0; mask < 8; mask++) { apply(mask); drawFormat(mask); const p = penalty(); if (p < bestP) { best = mask; bestP = p; } apply(mask); }
  apply(best); drawFormat(best);
  return m;
}

/** An SVG element for the code, with a 4-module quiet zone. Sharp edges so thermal printers get clean squares. */
export function qrSvg(text, { size = '100%' } = {}) {
  const m = qrMatrix(text), n = m.length, quiet = 4, ns = 'http://www.w3.org/2000/svg', svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${n + quiet * 2} ${n + quiet * 2}`); svg.setAttribute('shape-rendering', 'crispEdges'); svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', 'UPI payment QR code');
  svg.style.width = size; svg.style.height = 'auto'; svg.style.display = 'block';
  const bg = document.createElementNS(ns, 'rect'); bg.setAttribute('width', n + quiet * 2); bg.setAttribute('height', n + quiet * 2); bg.setAttribute('fill', '#fff'); svg.append(bg);
  let d = ''; m.forEach((row, y) => { let x = 0; while (x < n) { if (!row[x]) { x++; continue; } let e = x; while (e < n && row[e]) e++; d += `M${x + quiet} ${y + quiet}h${e - x}v1h${x - e}z`; x = e; } });
  const path = document.createElementNS(ns, 'path'); path.setAttribute('d', d); path.setAttribute('fill', '#000'); svg.append(path);
  return svg;
}

/** The standard UPI deep link that every UPI app understands when scanned. */
export function upiLink({ vpa, payee, amount, note }) {
  const p = [`pa=${encodeURIComponent(vpa)}`, `pn=${encodeURIComponent(payee || '')}`];
  if (amount > 0) p.push(`am=${(Math.round(amount * 100) / 100).toFixed(2)}`);
  p.push('cu=INR'); if (note) p.push(`tn=${encodeURIComponent(note)}`);
  return `upi://pay?${p.join('&')}`;
}
