// Add-on choices for one dish: shared by the counter screen and the public order page.
import { h, mount, modal, inr } from './core.js';

/** The groups that apply to a dish, with only the options that can be sold right now. */
export const groupsFor = (dish, groups) => (dish.addon_group_ids || []).map((id) => groups.find((g) => g.id === id)).filter((g) => g && !g.off)
  .map((g) => ({ ...g, addons: g.addons.filter((a) => !a.off && a.available !== false) })).filter((g) => g.addons.length || g.min_pick > 0);
const lim = (g) => (g.max_pick > 0 ? g.max_pick : 99);
export const needText = (g) => (g.min_pick > 0 ? (g.max_pick === 1 || (g.min_pick === 1 && !g.max_pick) ? 'Choose 1' : `Choose ${g.min_pick}${g.max_pick && g.max_pick !== g.min_pick ? ` to ${g.max_pick}` : ''}`) : g.max_pick ? `Up to ${g.max_pick}` : 'Optional');
export const textOf = (groups, picks) => picks.map((p) => { const a = groups.flatMap((g) => g.addons).find((x) => x.id === p.id); return a ? `${p.qty > 1 ? p.qty + '× ' : ''}${a.name}` : ''; }).filter(Boolean).join(', ');
export const extraOf = (groups, picks) => picks.reduce((s, p) => s + p.qty * (groups.flatMap((g) => g.addons).find((x) => x.id === p.id)?.price || 0), 0);
export const lineKey = (id, picks, note = '') => `${id}|${picks.map((p) => `${p.id}x${p.qty}`).sort().join(',')}|${note}`;

/** Opens the choice dialog. onDone gets { picks:[{id,qty}], text, extra, note }. */
export function pickAddons({ dish, groups, basePrice, withNote = false, title }, onDone) {
  const gs = groupsFor(dish, groups), chosen = new Map(); let note = '';
  const countIn = (g) => g.addons.reduce((s, a) => s + (chosen.get(a.id) || 0), 0);
  const body = h('div', { class: 'stack addon-pick' }), foot = h('div', { class: 'small muted' });
  const picks = () => [...chosen].filter(([, q]) => q > 0).map(([id, qty]) => ({ id, qty }));
  const problem = () => gs.map((g) => (countIn(g) < g.min_pick ? `${g.name}: ${needText(g).toLowerCase()}` : '')).find(Boolean) || '';
  const draw = () => {
    mount(body, gs.map((g) => {
      const n = countIn(g), single = g.max_pick === 1;
      return h('section', { class: 'addon-group' }, h('div', { class: 'row between' }, h('h4', {}, g.name), h('span', { class: `small ${g.min_pick > n ? 'req' : 'muted'}` }, needText(g))),
        g.addons.map((a) => {
          const q = chosen.get(a.id) || 0, price = a.price > 0 ? `+${inr(a.price)}` : 'Free';
          if (single) return h('button', { type: 'button', class: `opt${q ? ' on' : ''}`, 'aria-pressed': q ? 'true' : 'false', onclick: () => { for (const x of g.addons) chosen.delete(x.id); if (!q || g.min_pick > 0) chosen.set(a.id, 1); draw(); } }, h('span', {}, a.name), h('span', { class: 'muted' }, price));
          return h('div', { class: `opt${q ? ' on' : ''}` }, h('span', {}, a.name), h('span', { class: 'row', style: { gap: '10px' } }, h('span', { class: 'muted' }, price),
            h('span', { class: 'step' }, h('button', { type: 'button', 'aria-label': `Less ${a.name}`, disabled: !q, onclick: () => { chosen.set(a.id, q - 1); draw(); } }, '−'), h('span', {}, q), h('button', { type: 'button', 'aria-label': `More ${a.name}`, disabled: n >= lim(g) || q >= 9, onclick: () => { chosen.set(a.id, q + 1); draw(); } }, '+'))));
        }));
    }), withNote ? h('label', { class: 'field' }, h('span', { class: 'lbl' }, 'Note for this dish'), h('input', { placeholder: 'Less spicy, no onion…', value: note, maxlength: 120, oninput: (e) => (note = e.target.value) })) : null);
    const p = problem(), extra = extraOf(gs, picks());
    mount(foot, p ? h('span', { class: 'req' }, p) : `${inr(basePrice + extra)} each${extra ? ` (includes ${inr(extra)} of add-ons)` : ''}`);
    add.disabled = !!p;
  };
  const add = h('button', { class: 'btn primary', type: 'button', onclick: () => { const pk = picks(); m.close(); onDone({ picks: pk, text: textOf(gs, pk), extra: extraOf(gs, pk), note: note.trim() }); } }, 'Add to order');
  const m = modal({ title: title || dish.display_name || dish.name, body: h('div', { class: 'stack' }, body, foot), actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), add] });
  draw();
}
