// Unified analytics: one page from orders to expenses to stock to customers to social posts.
import { h, mount, ico, S, can, get, inr, inr2, num, pct, dshort, ymd, addDays, debounce, empty, badge, seg, sum, qtyFmt, CH } from '../core.js';
import { chartCard, lineChart, stackedRows, scatter, segmentBar, budgetBars, sparkline } from '../charts.js';

export default async function insights(ctx) {
  const el = h('div', { class: 'page' });
  const full = can('analytics'), today = ymd(), monthStart = today.slice(0, 8) + '01';
  const st = { range: '7', data: null };
  const params = () => (st.range === 'month' ? { from: monthStart, to: today } : st.range === 'today' ? { from: today, to: today } : { days: st.range });

  async function load() {
    const p = params();
    if (!full) { const [soc, roi] = await Promise.all([get('/api/analytics/social'), get('/api/analytics/social/roi')]); st.data = { soc, roi }; return draw(); }
    const [summary, channels, menu, exp, inv, cust, ins, soc, roi] = await Promise.all([get('/api/analytics/summary', p), get('/api/analytics/channels', p), get('/api/analytics/menu', p), get('/api/analytics/expenses', p), get('/api/analytics/inventory', p), get('/api/analytics/customers'), get('/api/analytics/insights', p), get('/api/analytics/social'), get('/api/analytics/social/roi')]);
    st.data = { summary, channels, menu, exp, inv, cust, ins: ins.insights, soc, roi }; draw();
  }
  const reload = debounce(() => load().catch(() => {}), 900);
  const delta = (cur, prev, money = true) => { if (!prev) return h('span', { class: 'd' }, 'No earlier data'); const d = cur - prev, p = Math.round((d / Math.abs(prev)) * 100); return h('span', { class: `d ${d >= 0 ? 'up' : 'down'}` }, `${d >= 0 ? '▲' : '▼'} ${Math.abs(p)}% vs previous period`); };
  const tile = (k, v, d, spark) => h('div', { class: 'tile' }, h('span', { class: 'k' }, k), h('div', { class: 'spark-row' }, h('span', { class: 'v' }, v), spark ? sparkline(spark) : null), d);
  const rangeBar = () => seg([['today', 'Today'], ['7', '7 days'], ['30', '30 days'], ['month', 'This month']], st.range, (v) => { st.range = v; load(); });

  function marketing(roi, soc) {
    const posts = soc.posts;
    return h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Marketing to revenue'), h('p', { class: 'muted small' }, 'Orders that used a post’s promo code, after the discount it gave.'))),
      soc.simulated ? h('div', { class: 'notice', style: { marginBottom: '10px' } }, 'Reach and engagement are simulated until Instagram or Facebook is connected. Orders and profit are real.') : null,
      roi.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Post', 'Promo code', 'Orders', 'Sales', 'Discount given', 'Profit'].map((c, k) => h('th', { class: k >= 2 ? 'num' : '' }, c)))),
        h('tbody', {}, roi.map((r) => h('tr', {}, h('td', {}, r.title), h('td', {}, h('code', {}, r.promo_code)), h('td', { class: 'num' }, r.orders), h('td', { class: 'num' }, inr(r.revenue)), h('td', { class: 'num' }, inr(r.discount_given)), h('td', { class: `num ${r.profit < 0 ? 'down' : 'up'}` }, inr(r.profit))))))) : empty('No promo-code orders yet', posts.length ? 'Add a promo code to a post to see which posts bring in orders.' : 'Publish a post with a promo code to start tracking.', can('social') ? h('a', { class: 'btn', href: '#/social' }, 'Open social scheduler') : null));
  }

  function draw() {
    const d = st.data;
    if (!full) return mount(el, h('div', { class: 'page-h' }, h('h2', {}, 'Social performance')), marketing(d.roi, d.soc));
    const s = d.summary, series = s.series, labels = series.map((x) => x.date);
    const ch = d.channels.filter((c) => c.orders > 0);
    const chRows = ch.map((c) => ({ label: CH[c.channel], dot: `var(--c-${c.channel})`, parts: [{ key: 'profit', value: c.profit }, { key: 'food', value: c.food_cost }, { key: 'comm', value: c.commission }], note: `${inr(c.sales)} · ${c.margin_pct === null ? '–' : num(c.margin_pct, 0) + '%'} margin` }));
    const parts = [{ key: 'profit', label: 'Profit', color: 'var(--accent)' }, { key: 'food', label: 'Food cost', color: 'var(--cost)' }, { key: 'comm', label: 'Commission', color: 'var(--slate)' }];
    const cu = d.cust;
    const lowCover = d.inv.filter((i) => i.days_of_cover !== null).sort((a, b) => a.days_of_cover - b.days_of_cover).slice(0, 5), waste = d.inv.filter((i) => i.wastage_cost > 0).sort((a, b) => b.wastage_cost - a.wastage_cost).slice(0, 5);
    mount(el, h('div', { class: 'page-h' }, h('div', {}, h('h2', {}, 'How the business is doing'), h('p', { class: 'muted small' }, `${dshort(s.range.from)} to ${dshort(s.range.to)}. Completed orders only.`)), rangeBar()),
      d.ins.length ? h('div', { class: 'insights' }, d.ins.map((t) => h('div', { class: 'insight' }, ico('bolt', 18), h('span', {}, t)))) : null,
      h('div', { class: 'tiles' }, tile('Sales', inr(s.sales), delta(s.sales, s.previous.sales), series.map((x) => x.sales)), tile('Orders', s.orders, delta(s.orders, s.previous.orders), series.map((x) => x.orders)), tile('Average order', inr(s.avg_order_value), h('span', { class: 'd' }, s.avg_prep_minutes === null ? 'Prep time not recorded' : `${num(s.avg_prep_minutes, 0)} min average prep`)), tile('Net profit', inr(s.net), delta(s.net, s.previous.net), series.map((x) => x.net)), tile('Net margin', s.margin_pct === null ? '–' : num(s.margin_pct, 1) + '%', h('span', { class: 'd' }, 'of sales'))),
      h('div', { class: 'grid2' },
        chartCard({ title: 'Sales and net profit by day', legend: [{ color: 'var(--accent)', label: 'Sales' }, { color: 'var(--slate)', label: 'Net profit' }], draw: (box) => lineChart(box, { labels, series: [{ name: 'Sales', color: 'var(--accent)', values: series.map((x) => x.sales) }, { name: 'Net profit', color: 'var(--slate)', values: series.map((x) => x.net) }] }), table: { head: ['Day', 'Sales', 'Orders', 'Net profit'], rows: series.map((x) => [dshort(x.date), inr(x.sales), x.orders, inr(x.net)]) } }),
        chartCard({ title: 'Where each channel’s sales go', sub: 'Bar length is sales; split into what you keep and what it costs.', legend: parts, draw: (box) => mount(box, chRows.length ? stackedRows({ rows: chRows, parts }) : h('p', { class: 'muted' }, 'No completed orders in this period.')), table: { head: ['Channel', 'Orders', 'Sales', 'Commission', 'Food cost', 'Profit'], rows: d.channels.map((c) => [CH[c.channel], c.orders, inr(c.sales), inr(c.commission), inr(c.food_cost), inr(c.profit)]) } })),
      h('div', { class: 'grid2' },
        chartCard({ title: 'Dishes: how many sold and how much you keep', sub: 'Orange dots sell a lot but earn under 50% margin: the best ones to reprice.', draw: (box) => scatter(box, { points: d.menu.map((m) => ({ name: m.name, x: m.units, y: m.margin_pct ?? 0, revenue: m.revenue })) }), table: { head: ['Dish', 'Units', 'Revenue', 'Margin'], rows: d.menu.map((m) => [m.name, num(m.units, 0), inr(m.revenue), pct(m.margin_pct)]) } }),
        h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Spending against budget'), h('p', { class: 'muted small' }, `${inr(d.exp.total)} spent in this period`))), budgetBars(d.exp.budgets), d.exp.by_category.length ? h('div', { class: 'table-wrap', style: { marginTop: '14px' } }, h('table', { class: 'tbl compact' }, h('tbody', {}, d.exp.by_category.map((c) => h('tr', {}, h('td', {}, c.category), h('td', { class: 'num' }, inr(c.amount)), h('td', { class: 'num muted' }, `${num((c.amount / d.exp.total) * 100, 0)}%`)))))) : null)),
      h('div', { class: 'grid2' },
        h('section', { class: 'card' }, h('h3', { style: { marginBottom: '10px' } }, 'Stock cover and wastage'), h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, h('th', {}, 'Running out first'), h('th', { class: 'num' }, 'On hand'), h('th', { class: 'num' }, 'Cover'))), h('tbody', {}, lowCover.length ? lowCover.map((i) => h('tr', {}, h('td', {}, i.name), h('td', { class: 'num' }, `${qtyFmt(i.on_hand)} ${i.unit}`), h('td', { class: `num ${i.days_of_cover < 2 ? 'down' : ''}` }, `${num(i.days_of_cover, 1)} d`))) : h('tr', {}, h('td', { colspan: 3, class: 'muted' }, 'Not enough usage yet.'))))),
          h('div', { class: 'table-wrap', style: { marginTop: '12px' } }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, h('th', {}, 'Most wasted'), h('th', { class: 'num' }, 'Quantity'), h('th', { class: 'num' }, 'Cost'))), h('tbody', {}, waste.length ? waste.map((i) => h('tr', {}, h('td', {}, i.name), h('td', { class: 'num' }, `${qtyFmt(i.wastage_qty)} ${i.unit}`), h('td', { class: 'num' }, inr(i.wastage_cost)))) : h('tr', {}, h('td', { colspan: 3, class: 'muted' }, 'No wastage logged in this period.')))))),
        h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Customers'), h('p', { class: 'muted small' }, `${cu.total} customers · ${cu.repeat_rate_pct}% have ordered more than once`)), can('customers') ? h('a', { class: 'btn sm', href: '#/customers' }, 'Open customers') : null),
          segmentBar([{ label: 'New', value: cu.new, color: 'var(--slate)' }, { label: 'Repeat', value: cu.repeat, color: 'var(--accent)' }, { label: 'Lapsed', value: cu.lapsed, color: 'var(--warn)' }]),
          cu.top.length ? h('div', { class: 'table-wrap', style: { marginTop: '12px' } }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, h('th', {}, 'Top customers'), h('th', { class: 'num' }, 'Orders'), h('th', { class: 'num' }, 'Spent'))), h('tbody', {}, cu.top.slice(0, 5).map((c) => h('tr', {}, h('td', {}, c.name), h('td', { class: 'num' }, c.orders), h('td', { class: 'num' }, inr(c.lifetime_value))))))) : null)),
      marketing(d.roi, d.soc));
  }
  await load();
  return { el, onEvent(e) { if (/^(order\.completed|expense\.|stock\.|post\.published|stream\.open)/.test(e.type)) reload(); } };
}
