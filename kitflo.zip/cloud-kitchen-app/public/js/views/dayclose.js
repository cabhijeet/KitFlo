// Day close: the end-of-day report (sales, tax, payments, cancellations), a cash count, and sales exports.
import { h, mount, ico, get, post, toast, busy, field, inr, inr2, dtime, badge, CH, S } from '../core.js';
import { printNode } from '../bill.js';

const TYPE = { dine_in: 'Dine-in', takeaway: 'Takeaway', delivery: 'Delivery', unknown: 'Not recorded' };
const today = () => new Date().toLocaleDateString('en-CA');
const csvCell = (v) => { const t = String(v ?? ''); return /[",\n\r]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t; };
function download(name, columns, rows) {
  const text = [columns, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n');
  const a = h('a', { href: URL.createObjectURL(new Blob(['﻿' + text], { type: 'text/csv;charset=utf-8' })), download: name }); document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

export default async function dayclose(ctx) {
  const el = h('div', { class: 'page stack' });
  let date = today(), data = null;
  const f = { open: h('input', { type: 'number', step: 'any', min: 0, inputmode: 'decimal' }), counted: h('input', { type: 'number', step: 'any', min: 0, inputmode: 'decimal', placeholder: 'Count the drawer' }), notes: h('input', { placeholder: 'Anything to remember about today' }) };
  const dateIn = h('input', { type: 'date', value: date, max: today(), onchange: (e) => { date = e.target.value || today(); load(); } });

  async function load() { data = await get('/api/day-close', { date }); const c = data.closed; f.open.value = c ? c.opening_cash : (data.report.cash.suggested_opening || 0); f.counted.value = c && c.counted_cash != null ? c.counted_cash : ''; f.notes.value = c?.notes || ''; draw(); }
  const table = (cols, rows) => h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, cols.map((c, i) => h('th', { class: i ? 'num' : '' }, c)))), h('tbody', {}, rows.length ? rows.map((r) => h('tr', {}, r.map((v, i) => h('td', { class: i ? 'num' : '' }, v)))) : h('tr', {}, h('td', { colSpan: cols.length, class: 'muted' }, 'Nothing yet')))));
  const stat = (label, value, sub) => h('div', { class: 'card stat' }, h('div', { class: 'muted small' }, label), h('div', { class: 'big' }, value), sub ? h('div', { class: 'muted small' }, sub) : null);

  const expected = () => (Number(f.open.value) || 0) + data.report.cash.sales - data.report.cash.expenses;
  const varianceText = h('strong', {});
  const calc = () => { const e = expected(); mount(varianceText, f.counted.value === '' ? `Expected in drawer ${inr2(e)}` : (() => { const v = Number(f.counted.value) - e; return Math.abs(v) < 0.005 ? 'Drawer matches' : v > 0 ? `${inr2(v)} extra in the drawer` : `${inr2(-v)} short`; })()); };
  [f.open, f.counted].forEach((i) => i.addEventListener('input', calc));

  const closeBtn = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(closeBtn, async () => { await post('/api/day-close', { date, opening_cash: f.open.value === '' ? 0 : Number(f.open.value), counted_cash: f.counted.value === '' ? null : Number(f.counted.value), notes: f.notes.value }); toast(`Day closed for ${date}`); await load(); }) }, 'Close the day');
  const printBtn = h('button', { class: 'btn', type: 'button', onclick: () => printZ() }, ico('print', 18), 'Print report');

  function printZ() {
    const r = data.report, c = data.closed, row = (l, v, cls = '') => h('div', { class: `rc-row ${cls}` }, h('span', {}, l), h('span', {}, v)), rule = () => h('div', { class: 'rc-rule' });
    printNode((prefs) => h('div', { class: 'receipt', style: { '--pw': prefs.paper + 'mm', '--pf': ({ m: 14, l: 16, xl: 18, xxl: 20 }[prefs.size] || 16) + 'px' } },
      h('div', { class: 'rc-center rc-name' }, S.config.business?.name || 'Kitchen'), h('div', { class: 'rc-center rc-b' }, 'DAY REPORT'), h('div', { class: 'rc-center rc-small' }, r.date), rule(),
      row('Orders', String(r.orders), 'rc-b'), row('Gross sales', inr2(r.gross)), row('Discounts', '−' + inr2(r.discounts)), r.packaging ? row('Packaging', inr2(r.packaging)) : null, r.delivery ? row('Delivery', inr2(r.delivery)) : null, r.service ? row('Service', inr2(r.service)) : null,
      row('Net sales', inr2(r.net_sales), 'rc-b'), row('Tax collected', inr2(r.tax)), row('Total billed', inr2(r.billed), 'rc-total'), rule(),
      h('div', { class: 'rc-b' }, 'Tax by rate'), r.tax_by_rate.map((t) => row(`${t.rate}% on ${inr2(t.taxable)}`, inr2(t.tax))), rule(),
      h('div', { class: 'rc-b' }, 'Payments'), r.payments.map((p) => row(p.mode, inr2(p.amount))), rule(),
      h('div', { class: 'rc-b' }, 'Channels'), r.by_channel.map((x) => row(`${CH[x.key] || x.key} (${x.orders})`, inr2(x.billed))), rule(),
      row('Cancelled', `${r.cancelled.orders} · ${inr2(r.cancelled.value)}`), rule(),
      h('div', { class: 'rc-b' }, 'Cash'), row('Opening', inr2(Number(f.open.value) || 0)), row('Cash sales', inr2(r.cash.sales)), row('Cash expenses', '−' + inr2(r.cash.expenses)), row('Expected', inr2(expected()), 'rc-b'),
      f.counted.value !== '' ? [row('Counted', inr2(Number(f.counted.value))), row('Difference', inr2(Number(f.counted.value) - expected()), 'rc-b')] : null,
      c ? h('div', { class: 'rc-small', style: { marginTop: '4px' } }, `Closed by ${c.closed_by}, ${dtime(c.closed_at)}`) : null));
  }

  function draw() {
    const r = data.report, c = data.closed;
    calc();
    const from = h('input', { type: 'date', value: date.slice(0, 8) + '01', max: today() }), to = h('input', { type: 'date', value: date, max: today() });
    const exp = (kind, label) => h('button', { class: 'btn', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { const x = await get('/api/reports/sales', { from: from.value, to: to.value, kind }); if (!x.rows.length) return toast('No completed orders in that period', 'warn'); download(`${kind === 'items' ? 'dish-sales' : 'bills'}-${from.value}-to-${to.value}.csv`, x.columns, x.rows); }) }, ico('copy', 16), label);
    mount(el,
      h('div', { class: 'page-h' }, h('div', {}, h('h2', {}, 'Day close'), h('p', { class: 'muted small' }, 'Check the day’s numbers and the cash drawer, then close. Completed orders only.')), h('div', { class: 'row' }, dateIn, printBtn)),
      r.open_orders ? h('div', { class: 'notice warn small' }, `${r.open_orders} order${r.open_orders === 1 ? ' is' : 's are'} still open. They are counted on the day they are completed.`) : null,
      h('div', { class: 'stats' }, stat('Orders', r.orders, `${r.items_sold} items`), stat('Net sales', inr(r.net_sales), 'before tax'), stat('Total billed', inr(r.billed), `tax ${inr(r.tax)}`), stat('Discounts', inr(r.discounts)), stat('Cancelled', r.cancelled.orders, inr(r.cancelled.value))),
      h('div', { class: 'two' },
        h('section', { class: 'card stack' }, h('h3', {}, 'Payments received'), table(['Mode', 'Amount'], r.payments.map((p) => [p.mode, inr2(p.amount)]))),
        h('section', { class: 'card stack' }, h('h3', {}, 'Tax collected'), table(['Rate', 'Taxable', 'CGST', 'SGST'], [...r.tax_by_rate.map((t) => [`${t.rate}%`, inr2(t.taxable), inr2(t.tax / 2), inr2(t.tax / 2)]), ...(r.tax_by_rate.length ? [['Total', '', inr2(r.cgst), inr2(r.sgst)]] : [])]))),
      h('div', { class: 'two' },
        h('section', { class: 'card stack' }, h('h3', {}, 'By channel'), table(['Channel', 'Orders', 'Billed'], r.by_channel.map((x) => [CH[x.key] || x.key, x.orders, inr2(x.billed)]))),
        h('section', { class: 'card stack' }, h('h3', {}, 'By order type'), table(['Type', 'Orders', 'Billed'], r.by_type.map((x) => [TYPE[x.key] || x.key, x.orders, inr2(x.billed)])))),
      r.cancelled.orders ? h('section', { class: 'card stack' }, h('h3', {}, 'Why orders were cancelled'), table(['Reason', 'Orders'], r.cancelled.reasons.map((x) => [x.reason, x.orders]))) : null,
      h('section', { class: 'card stack' }, h('div', { class: 'row between' }, h('h3', {}, 'Cash drawer'), c ? badge(`Closed by ${c.closed_by}, ${dtime(c.closed_at)}`, 'good') : badge('Not closed yet', 'warn')),
        h('div', { class: 'form-grid' }, field('Cash at start of day (₹)', f.open, 'Filled from the last count'), field('Cash sales (₹)', h('input', { value: r.cash.sales.toFixed(2), readonly: true })), field('Cash expenses (₹)', h('input', { value: r.cash.expenses.toFixed(2), readonly: true })), field('Cash counted now (₹)', f.counted)),
        h('p', {}, varianceText), field('Note', f.notes), h('div', {}, closeBtn), c ? h('p', { class: 'muted small' }, 'Closing again replaces the saved report with the latest numbers.') : null),
      h('section', { class: 'card stack' }, h('h3', {}, 'Sales exports'), h('p', { class: 'muted small' }, 'Spreadsheet files (CSV) that open in Excel or Google Sheets. Bill-wise has the tax split for your accountant.'), h('div', { class: 'row' }, h('label', { class: 'row small' }, 'From', from), h('label', { class: 'row small' }, 'To', to), exp('items', 'Dish-wise sales'), exp('bills', 'Bill-wise with GST'))),
      h('section', { class: 'card stack' }, h('h3', {}, 'Recent closings'), table(['Date', 'Expected cash', 'Counted', 'Difference'], data.history.map((x) => [x.date, inr2(x.expected_cash), x.counted_cash == null ? '–' : inr2(x.counted_cash), x.variance == null ? '–' : (Math.abs(x.variance) < 0.005 ? 'Matches' : inr2(x.variance))]))));
  }
  await load();
  return { el, onEvent(e) { if (/^order\.completed|^expense\./.test(e.type) && date === today()) load().catch(() => {}); } };
}
