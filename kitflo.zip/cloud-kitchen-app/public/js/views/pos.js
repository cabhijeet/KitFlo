// Orders board: new → in kitchen → ready, today's finished orders, new-order entry, order drawer, bill printing.
import { h, mount, ico, can, get, post, patch, send, toast, modal, confirmBox, busy, field, select, seg, inr, inr2, hhmm, dtime, minsSince, chip, badge, empty, toggle, CH, STATUS, debounce, onQueue, groupMenu, sizeShort, S } from '../core.js';
import { printBill, printKot, printPrefs } from '../bill.js';
import { categoryList } from '../categories.js';
import { pickAddons, groupsFor, lineKey } from '../addons.js';

const TYPE_LABEL = { dine_in: 'Dine-in', takeaway: 'Takeaway', delivery: 'Delivery' };
const FLOW = { new: ['accepted', 'Accept'], accepted: ['preparing', 'Start cooking'], preparing: ['ready', 'Mark ready'], ready: ['completed', 'Handed over'] };
const COLS = [['new', 'New', ['new']], ['kitchen', 'In kitchen', ['accepted', 'preparing']], ['ready', 'Ready', ['ready']]];

export default async function pos(ctx) {
  let orders = [], menu = [], cats = [], addonGs = [], mcol = 'new', flashId = null;
  const board = h('div', { class: 'board', dataset: { col: mcol } });
  const doneBox = h('div', { class: 'done-list' });
  const side = h('div', { class: 'side' });
  const mtabs = h('div', { class: 'seg mcols' });
  const el = h('div', { class: 'page' },
    h('div', { class: 'page-h' }, h('div', {}, h('h2', {}, 'Live orders'), h('p', { class: 'muted small' }, 'Every channel in one place. New orders appear by themselves.')),
      h('div', { class: 'row' }, can('orders_create') ? h('button', { class: 'btn primary', type: 'button', onclick: () => newOrder() }, ico('plus', 18), 'New order') : null)),
    mtabs, h('div', { class: 'pos-grid' }, h('div', { class: 'stack' }, board, h('div', {}, h('h3', { style: { marginBottom: '8px' } }, 'Finished today'), doneBox)), side));

  const load = async () => {
    const [o, m, c, a] = await Promise.all([get('/api/orders'), get('/api/menu-items'), get('/api/menu-categories'), get('/api/addons').catch(() => addonGs)]);
    orders = o; menu = m; cats = c; addonGs = a; draw();
  };
  const reload = debounce(() => load().catch(() => {}), 250);

  function promiseBar(o) {
    const total = Math.max(1, (new Date(o.promised_at) - new Date(o.placed_at)) / 60000), used = minsSince(o.placed_at), left = Math.round(total - used);
    const pctUsed = Math.min(100, Math.round(used / total * 100));
    return h('div', {}, h('div', { class: `promise ${left < 0 ? 'bad' : left < 5 ? 'warn' : ''}` }, h('i', { style: { width: pctUsed + '%' } })),
      h('div', { class: 'small muted', style: { marginTop: '3px' } }, left >= 0 ? `Due in ${left} min` : `${-left} min late`));
  }
  function card(o) {
    const act = FLOW[o.status];
    const nextBtn = act && can('orders') ? h('button', { class: 'btn primary sm', type: 'button', onclick: (e) => { e.stopPropagation(); busy(e.currentTarget, () => move(o, act[0])); } }, act[1]) : null;
    return h('article', { class: `order ch-${o.channel}${flashId === o.id ? ' flash' : ''}`, tabindex: 0, onclick: () => drawer(o.id), onkeydown: (e) => { if (e.key === 'Enter') drawer(o.id); } },
      h('div', { class: 'oh' }, h('b', {}, `#${o.order_no}`), chip(o.channel), o.order_type && o.channel !== 'swiggy' && o.channel !== 'zomato' ? badge(TYPE_LABEL[o.order_type] + (o.table_no ? ` ${o.table_no}` : ''), '') : null, o.needs_review ? badge('Check items', 'warn') : null, h('span', { class: 'time' }, hhmm(o.placed_at))),
      h('ul', {}, o.items.map((i) => h('li', {}, h('span', { class: 'q' }, `${i.qty}×`), h('span', {}, i.name, i.modifiers ? h('span', { class: 'muted' }, ` (${i.modifiers})`) : null)))),
      o.notes ? h('div', { class: 'note' }, o.notes) : null,
      o.status !== 'ready' ? promiseBar(o) : null,
      h('div', { class: 'of' }, h('strong', {}, inr(o.total)), nextBtn));
  }
  function draw() {
    const open = orders.filter((o) => ['new', 'accepted', 'preparing', 'ready'].includes(o.status)).sort((a, b) => a.placed_at.localeCompare(b.placed_at));
    mount(board, COLS.map(([k, label, sts]) => { const list = open.filter((o) => sts.includes(o.status)); return h('section', { class: `col ${k}` }, h('h3', {}, label, h('span', { class: 'count' }, list.length)), list.length ? list.map(card) : h('div', { class: 'empty small' }, k === 'new' ? 'Nothing waiting' : 'Nothing here')); }));
    board.dataset.col = mcol;
    mount(mtabs, COLS.map(([k, label, sts]) => h('button', { type: 'button', class: mcol === k ? 'on' : '', onclick: () => { mcol = k; draw(); } }, `${label} ${open.filter((o) => sts.includes(o.status)).length}`)));
    const done = orders.filter((o) => ['completed', 'cancelled'].includes(o.status)).sort((a, b) => b.placed_at.localeCompare(a.placed_at)).slice(0, 25);
    mount(doneBox, done.length ? done.map((o) => h('div', { class: 'done-row', tabindex: 0, onclick: () => drawer(o.id) }, h('b', {}, `#${o.order_no}`), chip(o.channel), h('span', { class: 'muted small' }, hhmm(o.placed_at)), h('span', { class: 'grow' }), o.status === 'cancelled' ? badge('Cancelled', 'bad') : null, h('strong', {}, inr(o.total)))) : h('div', { class: 'empty small' }, 'Nothing finished yet today'));
    drawSide(open);
  }
  function drawSide(open) {
    const totals = new Map(); for (const o of open.filter((x) => ['accepted', 'preparing'].includes(x.status))) for (const i of o.items) totals.set(i.name, (totals.get(i.name) || 0) + i.qty);
    const prep = [...totals].sort((a, b) => b[1] - a[1]);
    const issues = groupMenu(menu.filter((m) => !m.available || m.off)).slice(0, 40);
    const nBad = menu.filter((m) => !m.available).length;
    mount(side,
      h('div', { class: 'card' }, h('h3', {}, 'To prepare now'), prep.length ? h('ul', { class: 'prep-list' }, prep.map(([n, q]) => h('li', {}, h('b', {}, q), n))) : h('p', { class: 'muted small' }, 'No dishes in the kitchen right now.')),
      cats.length ? h('div', { class: 'card' }, h('h3', {}, 'Categories'), h('p', { class: 'muted small', style: { marginBottom: '6px' } }, cats.some((c) => c.off) ? `${cats.filter((c) => c.off).length} stopped` : 'Switch off a whole category when you cannot serve it.'), categoryList(cats, can('stock_write'), reload)) : null,
      h('div', { class: 'card' }, h('h3', {}, 'Dish availability'), h('p', { class: 'muted small', style: { marginBottom: '6px' } }, nBad ? `${nBad} size${nBad > 1 ? 's' : ''} cannot be sold right now` : 'Everything can be sold. Switch dishes on or off on the Menu page.'),
        h('div', { class: 'avail' }, issues.map((g) => h('div', { class: 'sw' }, h('div', {}, g.name, g.variants.some((v) => v.short_of.length) ? h('div', { class: 'small', style: { color: 'var(--bad)' } }, `Short of ${[...new Set(g.variants.flatMap((v) => v.short_of))].join(', ')}`) : null),
          can('stock_write') ? toggle(g.variants.some((v) => !v.off), async (on, input) => { try { for (const v of g.variants) await post(`/api/menu-items/${v.id}/availability`, { off: !on }); toast(`${g.name} is ${on ? 'back on' : 'switched off'}`); } catch (e) { input.checked = !on; toast(e.message, 'bad'); } }, '') : badge(g.variants.every((v) => v.off) ? 'Off' : 'Short', 'bad'))))));
  }

  async function move(o, to, reason) {
    try { const r = await post(`/api/orders/${o.id}/status`, { status: to, reason }); orders = orders.map((x) => (x.id === o.id ? { ...x, ...r } : x)); draw(); return r; }
    catch (e) { toast(e.message, 'bad', 6000); throw e; }
  }

  // ───────── drawer ─────────
  async function drawer(id) {
    const o = await get(`/api/orders/${id}`);
    const act = FLOW[o.status];
    const rows = o.items.map((i) => h('tr', {}, h('td', {}, i.name, i.modifiers ? h('div', { class: 'muted small' }, i.modifiers) : null), h('td', { class: 'num' }, i.qty), h('td', { class: 'num' }, inr2(i.unit_price * i.qty))));
    const line = (k, v, cls) => h('div', { class: cls }, h('span', {}, k), h('span', {}, v));
    const m = modal({
      title: `Order #${o.order_no}`, side: true, size: 'md',
      body: h('div', { class: 'stack' },
        h('div', { class: 'row' }, chip(o.channel), badge(STATUS[o.status], o.status === 'cancelled' ? 'bad' : o.status === 'completed' ? 'good' : 'accent'), h('span', { class: 'muted small' }, dtime(o.placed_at))),
        o.customer_name || o.customer_phone ? h('p', {}, h('strong', {}, o.customer_name || 'Customer'), ' ', o.customer_phone ? h('span', { class: 'muted' }, o.customer_phone) : null) : null,
        o.order_type ? h('p', { class: 'small' }, h('strong', {}, TYPE_LABEL[o.order_type]), o.table_no ? ` · table ${o.table_no}` : '') : null,
        o.address ? h('p', { class: 'muted small' }, o.address) : null, o.notes ? h('div', { class: 'note' }, o.notes) : null,
        h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, h('th', {}, 'Item'), h('th', { class: 'num' }, 'Qty'), h('th', { class: 'num' }, 'Amount'))), h('tbody', {}, rows))),
        h('div', { class: 'totals' }, line('Subtotal', inr2(o.subtotal)), o.discount - (o.manual_discount || 0) > 0.004 ? line(`Promo${o.promo_code ? ' ' + o.promo_code : ''}`, '−' + inr2(o.discount - (o.manual_discount || 0))) : null, o.manual_discount > 0 ? line(`Discount${o.discount_type === 'percent' ? ` ${o.discount_value}%` : ''}${o.discount_reason ? ' (' + o.discount_reason + ')' : ''}`, '−' + inr2(o.manual_discount)) : null, line('GST', inr2(o.tax)), o.packaging_fee ? line('Packaging', inr2(o.packaging_fee)) : null, line('Total', inr2(o.total), 'grand')),
        h('div', { class: 'card' }, h('div', { class: 'row between' }, h('h3', {}, 'Payment'), can('orders_create') && o.status !== 'cancelled' ? h('button', { class: 'btn sm', type: 'button', onclick: () => { m.close(); paymentsDialog(o); } }, 'Change') : null),
          o.payments ? JSON.parse(o.payments).map((p) => line(p.mode, inr2(p.amount))) : line(o.payment_mode || '–', inr2(o.total)),
          o.payments && JSON.parse(o.payments).reduce((x, p) => x + p.amount, 0) < o.total - 0.01 ? h('p', { class: 'small', style: { color: 'var(--bad, #b3261e)' } }, `${inr2(o.total - JSON.parse(o.payments).reduce((x, p) => x + p.amount, 0))} still to collect`) : null),
        can('analytics') ? h('div', { class: 'card' }, h('h3', {}, 'What you keep'), h('div', { class: 'totals' }, line('Net sales', inr2(o.net_sales)), line('Channel commission', '−' + inr2(o.commission)), line('Food cost', '−' + inr2(o.food_cost)), line('Order profit', inr2(o.order_profit), 'grand'))) : null,
        o.status === 'cancelled' && o.cancel_reason ? h('p', { class: 'muted' }, `Cancelled: ${o.cancel_reason}`) : null),
      actions: [
        h('button', { class: 'btn', type: 'button', onclick: (e) => busy(e.currentTarget, () => printBill(o.id)) }, ico('print', 18), 'Print bill'),
        h('button', { class: 'btn', type: 'button', onclick: (e) => busy(e.currentTarget, () => printKot(o.id)) }, ico('print', 18), 'Print kitchen ticket'),
        !['completed', 'cancelled'].includes(o.status) && can('orders_create') ? h('button', { class: 'btn danger', type: 'button', onclick: () => { m.close(); cancelDialog(o); } }, 'Cancel order') : null,
        act && can('orders') ? h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { await move(o, act[0]); m.close(); }) }, act[1]) : null],
    });
  }
  function cancelDialog(o) {
    const reasons = S.config.cancel_reasons || ['Customer request', 'Other'], pick = select(reasons.map((r) => [r, r]), reasons[0]), more = h('input', { placeholder: 'More detail (optional)' });
    const go = h('button', { class: 'btn danger', type: 'button', onclick: () => busy(go, async () => { try { await post(`/api/orders/${o.id}/status`, { status: 'cancelled', reason: more.value ? `${pick.value}: ${more.value}` : pick.value }); m.close(); reload(); toast(`Order #${o.order_no} cancelled`); } catch (e) { toast(e.message, 'bad', 6000); } }) }, 'Cancel order');
    const m = modal({ title: `Cancel order #${o.order_no}?`, size: 'sm', body: [h('p', { class: 'muted' }, 'Stock used for this order goes back. The reason is kept for your day-close report.'), field('Reason', pick), field('Detail', more)], actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Keep order'), go] });
  }
  /** Record or change how an order was paid. Several modes can share one bill. */
  function paymentsDialog(o) {
    const cur = o.payments ? JSON.parse(o.payments) : [{ mode: o.payment_mode, amount: o.total }], amt = Object.fromEntries(['Cash', 'UPI', 'Card'].map((k) => [k, (cur.find((p) => p.mode === k) || {}).amount || '']));
    const inputs = Object.fromEntries(Object.keys(amt).map((k) => [k, h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: amt[k], placeholder: '0' })]));
    const left = h('p', { class: 'muted small' }), calc = () => { const sum = Object.values(inputs).reduce((x, i) => x + (Number(i.value) || 0), 0); left.textContent = sum >= o.total - 0.01 ? (sum > o.total + 0.01 ? 'More than the bill' : 'Fully paid') : `${inr2(o.total - sum)} still to collect`; };
    Object.values(inputs).forEach((i) => i.addEventListener('input', calc)); calc();
    const go = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(go, async () => { try { await post(`/api/orders/${o.id}/payments`, { payments: Object.entries(inputs).map(([mode, i]) => ({ mode, amount: Number(i.value) || 0 })).filter((p) => p.amount > 0) }); m.close(); toast('Payment saved'); reload(); } catch (e) { toast(e.message, 'bad', 6000); } }) }, 'Save');
    const m = modal({ title: `Payment for #${o.order_no}`, size: 'sm', body: [h('p', {}, `Bill total ${inr2(o.total)}`), h('div', { class: 'form-grid' }, field('Cash', inputs.Cash), field('UPI', inputs.UPI), field('Card', inputs.Card)), left], actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Close'), go] });
  }
  // ───────── new order ─────────
  function newOrder() {
    const cart = new Map(); let channel = 'walkin', orderType = 'takeaway', typeTouched = false, table = '', payment = 'UPI', split = { Cash: '', UPI: '', Card: '' }, phone = '', name = '', notes = '', promo = '', address = '', dType = 'percent', dVal = '', dWhy = '';
    const grid = h('div', { class: 'dish-grid' }), cartBox = h('div', { class: 'cart' }), groups = groupMenu(menu), cats = [...new Set(groups.map((g) => g.category))]; let cat = 'All', term = '', openKey = null;
    const price = (d) => Number(d.prices[channel] ?? d.prices.default ?? 0);
    const addLine = (d, o = { picks: [], text: '', note: '', extra: 0 }) => { const key = lineKey(d.id, o.picks, o.note), cur = cart.get(key); cart.set(key, cur ? { ...cur, q: cur.q + 1 } : { d, ...o, q: 1 }); if (!d.available) toast(`${d.display_name} is marked unavailable. Check stock first.`, 'warn'); redraw(); };
    const add = (d) => (groupsFor(d, addonGs).length ? pickAddons({ dish: d, groups: addonGs, basePrice: price(d), withNote: true }, (o) => addLine(d, o)) : addLine(d));
    const manualOf = (sub) => { const v = Number(dVal); return v > 0 ? Math.round((dType === 'percent' ? sub * Math.min(v, 100) / 100 : Math.min(v, sub)) * 100) / 100 : 0; };
    const chargeLines = (sub) => {
      const c = S.config.charges || {}, net = sub - manualOf(sub), out = [];
      if (own() && orderType === 'delivery' && c.delivery_fee > 0) out.push(h('div', {}, h('span', {}, 'Delivery charge'), h('span', {}, c.delivery_free_above > 0 && net >= c.delivery_free_above ? 'Free' : inr(c.delivery_fee))));
      if (own() && orderType === 'dine_in' && c.service_pct > 0) out.push(h('div', {}, h('span', {}, `Service charge ${c.service_pct}%`), h('span', {}, inr(net * c.service_pct / 100))));
      return out;
    };
    const redraw = () => {
      const list = groups.filter((g) => (cat === 'All' || g.category === cat) && (!term || `${g.name} ${g.subcategory}`.toLowerCase().includes(term)));
      const open = openKey && groups.find((g) => g.key === openKey);
      mount(grid, open ? h('div', { class: 'card', style: { gridColumn: '1/-1' } }, h('div', { class: 'row between' }, h('h3', {}, open.name), h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { openKey = null; redraw(); } }, 'Close')),
          h('div', { class: 'sizes' }, open.variants.map((v) => h('div', { class: 'size-row' }, h('span', { class: 'sn' }, v.variant_name || 'Regular', v.available ? null : h('small', {}, ' · unavailable')), h('span', { class: 'row' }, h('strong', {}, inr(price(v))), h('button', { class: 'btn sm primary', type: 'button', onclick: () => add(v) }, 'Add')))))) : null,
        list.map((g) => { const v0 = g.variants[0], many = g.variants.length > 1, ok = g.variants.some((v) => v.available);
          return h('button', { type: 'button', class: `dish${ok ? '' : ' out'}${many ? ' has-sizes' : ''}`, onclick: () => (many ? (openKey = g.key, redraw()) : add(v0)) }, h('b', {}, g.name), h('span', {}, ok ? (many ? `from ${inr(Math.min(...g.variants.map(price)))}` : inr(price(v0))) : 'Unavailable')); }));
      const lines = [...cart].map(([key, l]) => ({ ...l, key }));
      const sub = lines.reduce((s, l) => s + (price(l.d) + l.extra) * l.q, 0);
      mount(cartBox, lines.length ? lines.map((l) => h('div', { class: 'line' }, h('span', {}, l.d.display_name, l.text || l.note ? h('span', { class: 'addon-line' }, [l.text ? '+ ' + l.text : '', l.note].filter(Boolean).join(' · ')) : null), h('span', { class: 'step' }, h('button', { type: 'button', 'aria-label': 'Less', onclick: () => { l.q > 1 ? cart.set(l.key, { ...cart.get(l.key), q: l.q - 1 }) : cart.delete(l.key); redraw(); } }, '−'), h('span', {}, l.q), h('button', { type: 'button', 'aria-label': 'More', onclick: () => { cart.set(l.key, { ...cart.get(l.key), q: l.q + 1 }); redraw(); } }, '+')), h('strong', {}, inr((price(l.d) + l.extra) * l.q)))) : h('p', { class: 'muted' }, 'Tap dishes to add them'),
        h('div', { class: 'totals' }, h('div', {}, h('span', {}, 'Subtotal'), h('span', {}, inr(sub))), manualOf(sub) > 0 ? h('div', {}, h('span', {}, `Discount${dType === 'percent' ? ` ${dVal}%` : ''}`), h('span', {}, '−' + inr(manualOf(sub)))) : null, chargeLines(sub), h('p', { class: 'small muted' }, 'GST and packaging are added when you place the order.')));
    };
    const typeBox = h('div', { class: 'stack' }), addressField = field('Delivery address', h('input', { placeholder: 'Optional for walk-in', autocomplete: 'off', oninput: (e) => (address = e.target.value) }));
    const own = () => ['walkin', 'whatsapp', 'website'].includes(channel);
    const drawType = () => { mount(typeBox, field('Order type', seg([['dine_in', 'Dine-in'], ['takeaway', 'Takeaway'], ['delivery', 'Delivery']], orderType, (v) => { orderType = v; typeTouched = true; drawType(); redraw(); })),
      orderType === 'dine_in' ? field('Table', h('input', { placeholder: 'e.g. T4', maxlength: 12, value: table, oninput: (e) => (table = e.target.value) })) : null); addressField.hidden = orderType !== 'delivery'; };
    const splitBox = h('div', { class: 'form-grid' }, ...['Cash', 'UPI', 'Card'].map((k) => field(k, h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', placeholder: '0', oninput: (e) => (split[k] = e.target.value) })))); splitBox.hidden = true;
    const info = h('div', { class: 'stack' },
      field('Channel', select([['walkin', 'Walk-in'], ['whatsapp', 'WhatsApp'], ['website', 'Website'], ['swiggy', 'Swiggy (manual)'], ['zomato', 'Zomato (manual)']], channel, { onchange: (e) => { channel = e.target.value; if (!typeTouched) orderType = channel === 'walkin' ? 'takeaway' : 'delivery'; drawType(); redraw(); } })),
      typeBox,
      field('Payment', select(['UPI', 'Cash', 'Card', 'Split'], payment, { onchange: (e) => { payment = e.target.value; splitBox.hidden = payment !== 'Split'; } })),
      splitBox,
      h('div', { class: 'form-grid' }, field('Customer phone', h('input', { inputmode: 'tel', placeholder: '10 digits', oninput: (e) => (phone = e.target.value) })), field('Name', h('input', { oninput: (e) => (name = e.target.value) }))),
      addressField,
      field('Discount', h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, seg([['percent', '%'], ['fixed', '₹']], dType, (v) => { dType = v; redraw(); }), h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', placeholder: 'Amount', 'aria-label': 'Discount amount', oninput: (e) => { dVal = e.target.value; redraw(); } })), S.user?.role === 'cashier' ? `No code needed. You can give up to ${S.config.discount_limit_pct ?? 30}%.` : 'No code needed. Applied to the whole order.'),
      h('input', { placeholder: 'Reason (optional), e.g. regular customer', 'aria-label': 'Discount reason', oninput: (e) => (dWhy = e.target.value) }),
      field('Promo code', h('input', { placeholder: 'Optional', oninput: (e) => (promo = e.target.value) })), field('Notes for the kitchen', h('input', { placeholder: 'Less spicy, no onion…', oninput: (e) => (notes = e.target.value) })));
    const catSeg = seg([['All', 'All'], ...cats.map((c) => [c, c])], 'All', (v) => { cat = v; openKey = null; redraw(); });
    const search = h('input', { type: 'search', placeholder: 'Search dishes', 'aria-label': 'Search dishes', oninput: (e) => { term = e.target.value.trim().toLowerCase(); openKey = null; redraw(); } });
    const m = modal({
      title: 'New order', size: 'lg',
      body: h('div', { class: 'neworder' }, h('div', { class: 'stack' }, search, catSeg, grid), h('div', { class: 'stack' }, cartBox, info)),
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'),
        h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => {
          if (!cart.size) return toast('Add at least one dish', 'warn');
          const pays = payment === 'Split' ? Object.entries(split).map(([mode, a]) => ({ mode, amount: Number(a) || 0 })).filter((x) => x.amount > 0) : null;
          if (payment === 'Split' && !pays.length) return toast('Enter how much was paid in cash, UPI or card', 'warn');
          const body = { channel, order_type: orderType, table_no: orderType === 'dine_in' ? table || undefined : undefined, payments: pays || undefined, payment_mode: pays ? undefined : payment, accept: true, notes: notes || undefined, promo_code: promo || undefined, address: address || undefined, manual_discount: Number(dVal) > 0 ? { type: dType, value: Number(dVal), reason: dWhy } : undefined, customer: phone || name ? { phone, name } : undefined, items: [...cart.values()].map((l) => ({ menu_item_id: l.d.id, qty: l.q, addons: l.picks.length ? l.picks : undefined, modifiers: l.note || undefined })) };
          const r = await send('POST', '/api/orders', body);
          if (r && r.queued) { toast('No connection. The order is saved on this device and will be sent when you are back online.', 'warn', 7000); m.close(); return; }
          (r.warnings || []).forEach((w) => toast(w, 'warn'));
          flashId = r.order.id; m.close(); toast(`Order #${r.order.order_no} placed. ${inr(r.order.total)}`); await load();
          { const pp = printPrefs(), srv = S.print?.online && S.print.auto; if (!srv && pp.kot_auto) printKot(r.order.id).catch(() => {}); if (!srv && pp.auto) setTimeout(() => printBill(r.order.id).catch(() => {}), pp.kot_auto ? 1500 : 0); }
        }) }, 'Place order')],
    });
    drawType(); redraw();
  }

  await load();
  ctx.every(60000, draw); // refresh "due in" labels
  return {
    el,
    onEvent(e) { if (/^order\./.test(e.type) || e.type === 'stream.open') { if (e.type === 'order.received' && e.payload?.id) flashId = e.payload.id; reload(); } else if (e.type === 'menu.updated' || e.type === 'stock.changed') reload(); },
  };
}
