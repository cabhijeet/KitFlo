// Menu: every dish with photo, description, category, sizes and prices, stock switch, recipe and IDs. Import and export as CSV.
import { h, mount, ico, can, get, post, put, del, toast, modal, confirmBox, busy, field, select, seg, toggle, inr, inr2, num, badge, empty, debounce, groupMenu, sizeShort, foodImg, CH } from '../core.js';
import { parseCsv } from '../csv.js';
import { categoryList, stopCategory, startCategory, stoppedText } from '../categories.js';
import { engineeringPanel } from './engineering.js';
import { addonManager } from './addons-admin.js';

const COST_KEYS = ['product_code', 'mrp', 'main_ingredients', 'extra_ingredients', 'method', 'ingredient_cost', 'op_cost', 'pack_cost'];
const CHANNELS = ['swiggy', 'zomato', 'website', 'whatsapp', 'walkin'];
const COLS = [['category', 'Category'], ['subcategory', 'Subcategory'], ['catalogue_id', 'Catalogue ID'], ['name', 'Item Name'], ['variant_id', 'Variant ID'], ['variant_name', 'Variant Name'], ['price', 'Price (₹)'], ['description', 'Description'], ['image_url', 'Image URL'], ['in_stock', 'In Stock'], ['product_code', 'Product Code'], ['mrp', 'MRP'], ['main_ingredients', 'Main Ingredients'], ['extra_ingredients', 'Additional Ingredients'], ['method', 'Recipe Method'], ['ingredient_cost', 'Ingredient Cost'], ['op_cost', 'Operational Cost'], ['pack_cost', 'Packaging Cost']];

// ───────── CSV ─────────
const csvCell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
function download(name, text) { const a = h('a', { href: URL.createObjectURL(new Blob(['﻿' + text], { type: 'text/csv;charset=utf-8' })), download: name }); document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
const rawCell = (r, i) => (i >= 0 ? String(r[i] ?? '').trim() : '');
const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
function rowsFromCsv(text) {
  const all = parseCsv(text); if (all.length < 2) throw new Error('The file has no data rows');
  let hi = all.findIndex((r) => r.some((c) => norm(c) === 'itemname'));
  if (hi < 0) throw new Error('Could not find the "Item Name" column. Use the same columns as the template.');
  const head = all[hi].map(norm); const idx = (k, ...alts) => head.findIndex((x) => [norm(k), ...alts.map(norm)].includes(x));
  const at = { category: idx('Category'), subcategory: idx('Subcategory'), catalogue_id: idx('Catalogue ID'), name: idx('Item Name'), variant_id: idx('Variant ID'), variant_name: idx('Variant Name'), price: head.findIndex((x) => x.startsWith('price')), description: idx('Description'), image_url: idx('Image URL'), in_stock: idx('In Stock'), product_code: idx('Product Code'), mrp: idx('MRP'), main_ingredients: idx('Main Ingredients'), extra_ingredients: idx('Additional Ingredients'), method: idx('Recipe Method'), ingredient_cost: idx('Ingredient Cost'), op_cost: idx('Operational Cost'), pack_cost: idx('Packaging Cost') };
  return all.slice(hi + 1).map((r) => { const g = (k) => (at[k] >= 0 ? String(r[at[k]] ?? '').trim() : ''); return { category: g('category').replace(/\.$/, ''), subcategory: g('subcategory').replace(/\.$/, ''), catalogue_id: g('catalogue_id'), name: g('name'), variant_id: g('variant_id'), variant_name: g('variant_name'), price: g('price') === '' ? NaN : Number(g('price').replace(/[₹,\s]/g, '')), description: g('description'), image_url: g('image_url'), in_stock: at.in_stock >= 0 ? g('in_stock') || 'YES' : 'YES', product_code: g('product_code'), mrp: g('mrp'), main_ingredients: rawCell(r, at.main_ingredients), extra_ingredients: rawCell(r, at.extra_ingredients), method: rawCell(r, at.method), ingredient_cost: g('ingredient_cost'), op_cost: g('op_cost'), pack_cost: g('pack_cost') }; }).filter((r) => r.name);
}

export default async function menu(ctx) {
  const canEdit = can('menu_write'), canStock = can('stock_write');
  const st = { items: [], inv: [], cats: [], q: '', cat: 'All', flag: '', tab: 'dishes' };
  const engHost = h('div', {}); let engBuilt = false;
  const body = h('div', { class: 'stack' }), el = h('div', { class: 'page' });

  async function load() {
    const [items, inv, cats] = await Promise.all([get('/api/menu-items'), canEdit && can('stock_read') ? get('/api/inventory-items') : st.inv, get('/api/menu-categories')]);
    st.items = items; st.inv = inv; st.cats = cats; draw();
  }
  const reload = debounce(() => load().catch(() => {}), 400);

  const priceText = (v) => inr(v.prices.website ?? v.prices.default ?? 0);
  const flagsOf = (g) => ({
    off: g.variants.every((v) => v.off), short: g.variants.some((v) => !v.off && !v.cat_off && !v.available), norecipe: g.variants.some((v) => !v.has_cost), catoff: !!g.variants[0].cat_off, noimg: !g.image_url, nodesc: !g.description,
  });

  function draw() {
    const groups = groupMenu(st.items);
    const cats = ['All', ...new Set(groups.map((g) => g.category))];
    if (!cats.includes(st.cat)) st.cat = 'All';
    const needle = st.q.trim().toLowerCase();
    const list = groups.filter((g) => (st.cat === 'All' || g.category === st.cat) && (!needle || `${g.name} ${g.description} ${g.subcategory} ${g.variants.map((v) => v.variant_name + ' ' + v.variant_id).join(' ')} ${g.key}`.toLowerCase().includes(needle))
      && (!st.flag || flagsOf(g)[st.flag]));
    const n = (f) => groups.filter((g) => flagsOf(g)[f]).length;
    const head = h('div', { class: 'page-h' }, h('div', {}, h('h2', {}, 'Menu'), h('p', { class: 'muted small' }, `${groups.length} dishes · ${st.items.length} sizes and prices · ${st.items.filter((v) => v.off).length} switched off`)),
      h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: () => addonManager({ items: st.items, inv: st.inv, onChange: load }).catch((e) => toast(e.message, 'bad')) }, 'Add-ons'), h('button', { class: 'btn', type: 'button', onclick: exportCsv }, 'Export CSV'), canEdit ? h('button', { class: 'btn', type: 'button', onclick: importDlg }, 'Import CSV') : null, canEdit ? h('button', { class: 'btn primary', type: 'button', onclick: () => editor(null) }, ico('plus', 18), 'New dish') : null));
    const filters = h('div', { class: 'stack', style: { gap: '10px' } },
      h('div', { class: 'filters' }, h('input', { type: 'search', placeholder: 'Search dishes, sizes or IDs', 'aria-label': 'Search menu', value: st.q, style: { maxWidth: '300px' }, oninput: (e) => { st.q = e.target.value; const p = e.target.selectionStart; draw(); const i = $input(); i.focus(); i.setSelectionRange(p, p); } }),
        select([['', 'All dishes'], ['off', `Switched off (${n('off')})`], ['short', `Short of stock (${n('short')})`], ['norecipe', `No cost or recipe yet (${n('norecipe')})`], ['catoff', `In a stopped category (${n('catoff')})`], ['noimg', `No photo (${n('noimg')})`], ['nodesc', `No description (${n('nodesc')})`]], st.flag, { 'aria-label': 'Show', onchange: (e) => { st.flag = e.target.value; draw(); }, style: { maxWidth: '230px' } })),
      seg(cats.map((c) => [c, c === 'All' ? 'All' : `${c} ${groups.filter((g) => g.category === c).length}`]), st.cat, (v) => { st.cat = v; draw(); }));
    const sections = [...new Set(list.map((g) => g.category))].map((c) => {
      const gs = list.filter((g) => g.category === c);
      const ci = st.cats.find((x) => x.name === c);
      return h('section', { class: 'stack', style: { gap: '10px' } }, h('div', { class: 'row between' }, h('h3', {}, c, h('span', { class: 'muted small', style: { fontWeight: 400 } }, `  ${gs.length} dish${gs.length > 1 ? 'es' : ''}`), ci?.off ? h('span', { style: { marginLeft: '8px' } }, badge(stoppedText(ci), 'bad')) : null),
        ci && canStock ? h('button', { class: `btn sm${ci.off ? ' primary' : ''}`, type: 'button', onclick: async () => { try { if (ci.off) { await startCategory(ci); load(); } else if (await stopCategory(ci)) load(); } catch (e) { toast(e.message, 'bad'); } } }, ci.off ? 'Start category' : 'Stop category') : null), h('div', { class: 'mgrid' }, gs.map(card)));
    });
    const stopped = st.cats.filter((c) => c.off);
    mount(el, head, tabsEl(), st.tab === 'eng' ? engHost : h('div', { class: 'stack' }, stopped.length ? h('div', { class: 'notice' }, h('strong', {}, `${stopped.length} categor${stopped.length > 1 ? 'ies are' : 'y is'} stopped: `), stopped.map((c) => `${c.name} (${stoppedText(c).toLowerCase()})`).join(', ')) : null, filters, sections.length ? sections : empty('No dishes match', 'Clear the search or choose another category.')));
    if (st.tab === 'eng' && !engBuilt) { engBuilt = true; engineeringPanel().then((p) => mount(engHost, p)).catch((e) => { engBuilt = false; mount(engHost, empty('Could not load the analysis', e.message)); }); }
  }
  const tabsEl = () => (can('analytics') ? seg([['dishes', 'Dishes'], ['eng', 'Menu engineering']], st.tab, (v) => { st.tab = v; draw(); }) : null);
  const $input = () => el.querySelector('input[type=search]');

  function card(g) {
    const f = flagsOf(g), allOff = f.off;
    return h('article', { class: `dcard${allOff ? ' off' : ''}`, tabindex: 0, onclick: () => editor(g), onkeydown: (e) => { if (e.key === 'Enter') editor(g); } },
      foodImg(g.image_url, 'dimg', g.name),
      h('div', { class: 'dbody' },
        h('div', { class: 'row between', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } }, h('h4', {}, g.name),
          canStock ? h('span', { onclick: (e) => e.stopPropagation() }, toggle(!allOff, async (on, input) => { try { for (const v of g.variants) await post(`/api/menu-items/${v.id}/availability`, { off: !on }); toast(`${g.name} is ${on ? 'on sale' : 'switched off'}`); reload(); } catch (e) { input.checked = !on; toast(e.message, 'bad'); } }, '')) : null),
        g.description ? h('p', { class: 'ddesc' }, g.description) : h('p', { class: 'ddesc muted' }, 'No description yet'),
        h('div', { class: 'vchips' }, g.variants.map((v) => h('span', { class: `vchip${v.off ? ' off' : ''}` }, g.variants.length > 1 ? h('small', {}, sizeShort(v.variant_name)) : null, h('b', {}, priceText(v))))),
        h('div', { class: 'tag-row' }, allOff ? badge('Switched off', 'bad') : f.short ? badge('Short of stock', 'warn') : null, f.catoff ? badge('Category stopped', 'bad') : null, f.norecipe ? badge('No cost yet', '') : null, !allOff && !f.short && !f.catoff ? badge('On sale', 'good') : null, g.variants[0].margin_pct !== null && g.variants[0].has_cost ? badge(`${num(g.variants[0].margin_pct, 0)}% margin`, '') : null)));
  }

  // ───────── cost block for one size ─────────
  function costBlock(v) {
    const out = h('p', { class: 'small' });
    const calc = () => {
      const price = Number(v.prices.website ?? v.prices.default ?? 0), food = v.recipe.length ? v.cost : Number(v.ingredient_cost) || 0, ok = v.recipe.length > 0 || Number(v.ingredient_cost) > 0;
      const total = food + (Number(v.op_cost) || 0) + (Number(v.pack_cost) || 0);
      mount(out, ok && price > 0 ? [h('strong', {}, `Total cost ${inr2(total)}`), ` · margin ${inr2(price - total)} (${num((price - total) / price * 100, 0)}%) at ${inr(price)}`, v.mrp !== '' && v.mrp !== null && Number(v.mrp) !== price ? h('span', { class: 'muted' }, ` · MRP is ${inr(Number(v.mrp))}`) : null] : h('span', { class: 'muted' }, 'Add the ingredient cost or a recipe to see the margin.'));
    };
    const num_ = (k, label, hint) => field(label, h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: v[k] ?? '', disabled: !canEdit, oninput: (e) => { v[k] = e.target.value; calc(); } }), hint);
    const txt = (k, label, rows) => field(label, h('textarea', { rows, disabled: !canEdit, oninput: (e) => (v[k] = e.target.value) }, v[k] || ''));
    calc();
    return h('div', { class: 'stack', style: { gap: '10px' } },
      h('div', { class: 'form-grid' }, num_('mrp', 'MRP (₹)'), num_('ingredient_cost', 'Ingredient cost (₹)', v.recipe.length ? 'A recipe is set, so its cost is used instead.' : 'Used for food cost until you add a recipe.'), num_('op_cost', 'Operational cost (₹)'), num_('pack_cost', 'Packaging cost (₹)')), out,
      h('details', {}, h('summary', {}, 'Ingredients, method and product code'), h('div', { class: 'stack', style: { marginTop: '10px', gap: '10px' } }, field('Product code', h('input', { value: v.product_code || '', disabled: !canEdit, oninput: (e) => (v.product_code = e.target.value) })), txt('main_ingredients', 'Main ingredients', 5), txt('extra_ingredients', 'Additional ingredients', 4), txt('method', 'Recipe method', 6))));
  }

  // ───────── editor ─────────
  async function editor(g) {
    const isNew = !g;
    const sh = { name: g?.name || '', category: g?.category || '', subcategory: g?.subcategory || '', description: g?.description || '', image_url: g?.image_url || '', gst_rate: g?.variants[0].gst_rate ?? 5, catalogue_id: g && !g.key.startsWith('item-') ? g.key : '' };
    let vars = (g?.variants || [{ id: null, variant_name: '', variant_id: '', prices: {}, off: false, recipe: [], has_recipe: false, external_ids: {} }]).map((v) => ({ id: v.id, variant_name: v.variant_name || '', variant_id: v.variant_id || '', prices: { ...v.prices }, off: !!v.off, recipe: (v.recipe || []).map((r) => ({ ...r })), margin: v.margin_pct, cost: v.recipe_cost, ...Object.fromEntries(COST_KEYS.map((k) => [k, v[k] ?? (k.endsWith('cost') || k === 'mrp' ? '' : '')])) }));
    let addonGs = []; try { addonGs = await get('/api/addons'); } catch { /* optional */ }
    sh.addon_group_ids = [...(g?.variants[0].addon_group_ids || [])];
    const cats = [...new Set(st.items.map((m) => m.category).filter(Boolean))], subs = [...new Set(st.items.map((m) => m.subcategory).filter(Boolean))];
    const inp = (k, props = {}) => h('input', { value: sh[k] ?? '', oninput: (e) => { sh[k] = e.target.value; if (k === 'image_url') previewBox(); }, disabled: !canEdit, ...props });
    const pv = h('div', { class: 'pv' }); const previewBox = () => mount(pv, foodImg(sh.image_url, 'dimg big', sh.name));
    const desc = h('textarea', { rows: 3, oninput: (e) => (sh.description = e.target.value), disabled: !canEdit, placeholder: 'What the dish is, what it comes with, serving size' }, sh.description);
    const varBox = h('div', { class: 'stack', style: { gap: '10px' } });

    const drawVars = () => mount(varBox, vars.map((v, i) => {
      const price = h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: v.prices.default ?? '', disabled: !canEdit, oninput: (e) => { v.prices.default = e.target.value === '' ? undefined : Number(e.target.value); } });
      const recBox = h('div', { class: 'recipe-edit' });
      const drawRec = () => mount(recBox, v.recipe.map((r, ri) => h('div', { class: 'rl' },
        field('Ingredient', select([['', 'Choose…'], ...st.inv.map((x) => [String(x.id), `${x.name} (${x.unit})`])], String(r.inventory_item_id || ''), { disabled: !canEdit, onchange: (e) => { r.inventory_item_id = Number(e.target.value); } })),
        field('Qty per dish', h('input', { type: 'number', step: 'any', min: 0, value: r.qty_per_portion ?? '', disabled: !canEdit, oninput: (e) => { r.qty_per_portion = Number(e.target.value); } })),
        field('Waste %', h('input', { type: 'number', min: 0, max: 100, value: r.wastage_pct ?? 0, disabled: !canEdit, oninput: (e) => { r.wastage_pct = Number(e.target.value); } })),
        canEdit ? h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove ingredient', onclick: () => { v.recipe.splice(ri, 1); drawRec(); } }, ico('trash', 18)) : null)));
      drawRec();
      const copyFrom = vars.length > 1 ? (() => { const src = select(vars.map((x, xi) => [String(xi), x.variant_name || `Size ${xi + 1}`]).filter(([xi]) => Number(xi) !== i), String(i === 0 ? 1 : 0), { 'aria-label': 'Copy from size' }), fac = h('input', { type: 'number', min: 0, step: 'any', value: 1, 'aria-label': 'Multiply by', style: { width: '80px' } });
        return h('div', { class: 'row' }, h('span', { class: 'small muted' }, 'Copy recipe from'), src, h('span', { class: 'small muted' }, '×'), fac, h('button', { class: 'btn sm', type: 'button', onclick: () => { const s = vars[Number(src.value)]; v.recipe = s.recipe.map((r) => ({ ...r, qty_per_portion: Math.round((r.qty_per_portion || 0) * Number(fac.value || 1) * 10000) / 10000 })); drawRec(); } }, 'Copy')); })() : null;
      const chan = h('div', { class: 'form-grid' }, CHANNELS.map((c) => field(`${CH[c]} price`, h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', placeholder: 'Same as default', value: v.prices[c] ?? '', disabled: !canEdit, oninput: (e) => { if (e.target.value === '') delete v.prices[c]; else v.prices[c] = Number(e.target.value); } }))));
      return h('div', { class: 'vrow card' },
        h('div', { class: 'form-grid' }, field(vars.length > 1 ? 'Size' : 'Size (optional)', h('input', { value: v.variant_name, placeholder: 'Portion 250 ML (Serves 1)', disabled: !canEdit, oninput: (e) => { v.variant_name = e.target.value; } })), field('Price (₹)', price), field('Variant ID', h('input', { value: v.variant_id, placeholder: 'From the platform', disabled: !canEdit, oninput: (e) => { v.variant_id = e.target.value; } })),
          field('In stock', toggle(!v.off, (on) => { v.off = !on; }, ''))),
        costBlock(v, vars.length > 1),
        h('details', {}, h('summary', {}, 'Prices on other channels'), h('div', { style: { marginTop: '10px' } }, chan)),
        st.inv.length || v.recipe.length ? h('details', {}, h('summary', {}, `Recipe${v.recipe.length ? ` (${v.recipe.length} ingredient${v.recipe.length > 1 ? 's' : ''})` : ' (not set)'}`), h('div', { class: 'stack', style: { marginTop: '10px', gap: '10px' } }, recBox, canEdit ? h('div', { class: 'row' }, h('button', { class: 'btn sm', type: 'button', onclick: () => { v.recipe.push({ inventory_item_id: '', qty_per_portion: '', wastage_pct: 0 }); drawRec(); } }, ico('plus', 16), 'Add ingredient'), copyFrom) : null, v.cost ? h('p', { class: 'small muted' }, `Food cost ${inr2(v.cost)}${v.margin !== null && v.margin !== undefined ? ` · ${num(v.margin, 0)}% margin at the default price` : ''}`) : null)) : null,
        canEdit && vars.length > 1 ? h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { vars.splice(i, 1); drawVars(); } }, ico('trash', 16), 'Remove this size')) : null);
    }));
    previewBox(); drawVars();

    const m = modal({
      title: isNew ? 'New dish' : g.name, size: 'lg',
      body: h('div', { class: 'stack' },
        h('div', { class: 'editgrid' }, h('div', { class: 'stack' }, pv, field('Photo link', inp('image_url', { placeholder: 'https://…', inputmode: 'url' }), 'Paste a link to the photo.')),
          h('div', { class: 'stack' }, h('div', { class: 'form-grid' }, field('Dish name', inp('name')), field('Category', inp('category', { list: 'cats' })), field('Subcategory', inp('subcategory', { list: 'subs' })), field('GST %', inp('gst_rate', { type: 'number', min: 0 })), field('Catalogue ID', inp('catalogue_id', { placeholder: 'Optional' }))), field('Description', desc))),
        h('datalist', { id: 'cats' }, cats.map((c) => h('option', { value: c }))), h('datalist', { id: 'subs' }, subs.map((c) => h('option', { value: c }))),
        h('div', {}, h('div', { class: 'row between', style: { marginBottom: '8px' } }, h('h3', {}, 'Sizes and prices'), canEdit ? h('button', { class: 'btn sm', type: 'button', onclick: () => { vars.push({ id: null, variant_name: '', variant_id: '', prices: {}, off: false, recipe: [] }); drawVars(); } }, ico('plus', 16), 'Add size') : null), varBox),
        h('div', { class: 'stack', style: { gap: '6px' } }, h('h3', {}, 'Add-ons'), addonGs.length ? h('div', { class: 'dishpick addon-edit' }, addonGs.map((ag) => h('label', {}, h('input', { type: 'checkbox', disabled: !canEdit, checked: sh.addon_group_ids.includes(ag.id), onchange: (e) => { sh.addon_group_ids = e.target.checked ? [...sh.addon_group_ids, ag.id] : sh.addon_group_ids.filter((x) => x !== ag.id); } }), h('span', {}, ag.name), h('span', { class: 'muted small' }, `${ag.min_pick > 0 ? 'required · ' : ''}${ag.addons.map((a) => a.name).slice(0, 4).join(', ')}`)))) : h('p', { class: 'muted small' }, 'No add-on groups yet. Use the Add-ons button on the Menu page to create Size, Extras and the like.'))),
      actions: canEdit ? [!isNew ? h('button', { class: 'btn danger', type: 'button', onclick: async () => { if (!(await confirmBox('Delete this dish?', `${g.name} and all its sizes will be removed.`, 'Delete', true))) return; try { await del(`/api/menu-groups/${encodeURIComponent(g.key)}`); m.close(); toast('Dish deleted'); load(); } catch (e) { toast(e.message, 'bad', 7000); } } }, 'Delete') : null,
        h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'),
        h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => {
          const cleaned = vars.map((v) => ({ id: v.id, variant_name: v.variant_name.trim(), variant_id: v.variant_id.trim(), off: v.off, prices: Object.fromEntries(Object.entries(v.prices).filter(([, x]) => x !== undefined && x !== null && !Number.isNaN(x))), recipe: v.recipe.filter((r) => r.inventory_item_id && r.qty_per_portion > 0), ...Object.fromEntries(COST_KEYS.map((k) => [k, v[k]])) }));
          if (cleaned.length > 1 && cleaned.some((v) => !v.variant_name)) throw new Error('Give every size a name, for example Half 500 ML');
          if (cleaned.some((v) => v.prices.default === undefined)) throw new Error('Enter a price for every size');
          const payload = { shared: { ...sh, name: sh.name.trim(), category: sh.category.trim() || 'Other' }, variants: cleaned };
          if (isNew) await post('/api/menu-groups', payload); else await put(`/api/menu-groups/${encodeURIComponent(g.key)}`, payload);
          m.close(); toast('Menu saved'); load();
        }) }, 'Save')] : [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Close')],
    });
  }

  // ───────── CSV in / out ─────────
  function exportCsv() {
    const rows = st.items.map((v) => [v.category, v.subcategory, v.catalogue_id, v.name, v.variant_id, v.variant_name, v.prices.default ?? v.prices.website ?? '', v.description, v.image_url, v.off ? 'NO' : 'YES', v.product_code, v.mrp ?? '', v.main_ingredients, v.extra_ingredients, v.method, v.ingredient_cost ?? '', v.op_cost ?? '', v.pack_cost ?? '']);
    download(`menu-${new Date().toISOString().slice(0, 10)}.csv`, [COLS.map((c) => c[1]), ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n'));
  }
  function importDlg() {
    let rows = null; const info = h('div', { class: 'muted' }, 'Choose a CSV file with the same columns as your menu sheet.');
    const file = h('input', { type: 'file', accept: '.csv,text/csv', onchange: async () => {
      const f = file.files[0]; if (!f) return; rows = null; go.disabled = true;
      try { rows = rowsFromCsv(await f.text()); const bad = rows.filter((r) => Number.isNaN(r.price)).length; mount(info, h('div', {}, h('strong', {}, `${rows.length} rows found`), `: ${new Set(rows.map((r) => r.catalogue_id || r.name)).size} dishes. `, bad ? h('span', { style: { color: 'var(--warn)' } }, `${bad} without a price will be skipped. `) : null, 'Dishes you already have are updated, new ones are added. Nothing is deleted, and recipes and other-channel prices are kept.')); go.disabled = false; }
      catch (e) { mount(info, h('div', { class: 'notice bad' }, e.message)); }
    } });
    const go = h('button', { class: 'btn primary', type: 'button', disabled: true, onclick: (e) => busy(e.currentTarget, async () => {
      const r = await post('/api/menu-items/import', { rows }); const errs = r.errors || [];
      mount(info, h('div', { class: 'stack', style: { gap: '8px' } }, h('strong', {}, `${r.created} added, ${r.updated} updated${errs.length ? `, ${errs.length} skipped` : ''}`), errs.slice(0, 8).map((x) => h('div', { class: 'small', style: { color: 'var(--bad)' } }, `Row ${x.row} ${x.name}: ${x.error}`)), errs.length > 8 ? h('div', { class: 'small muted' }, `and ${errs.length - 8} more`) : null));
      go.disabled = true; load();
    }) }, 'Import');
    const m = modal({ title: 'Import menu from CSV', size: 'md', body: h('div', { class: 'stack' }, h('p', { class: 'small muted' }, 'In Excel choose File, Save As, CSV UTF-8. Columns: Category, Subcategory, Catalogue ID, Item Name, Variant ID, Variant Name, Price, Description, Image URL, In Stock. Rows with the same Catalogue ID become sizes of one dish.'), file, info),
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Close'), go] });
  }

  await load();
  return { el, onEvent(e) { if (e.type === 'menu.updated' || e.type === 'stock.changed' || e.type === 'stream.open') reload(); } };
}
