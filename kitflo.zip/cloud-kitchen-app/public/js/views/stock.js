// Stock & menu: on-hand with cover and expiry, purchases, wastage, reorder list, dishes with recipe cost and margin.
import { h, mount, ico, can, get, post, patch, put, del, toast, modal, confirmBox, busy, field, select, seg, inr, inr2, num, qtyFmt, dtime, dshort, badge, empty, debounce, S, ymd } from '../core.js';

export default async function stock(ctx) {
  const st = { items: [], menu: [], suppliers: [], alerts: { purchase_list: [] }, tab: 'stock', q: '', only: '' };
  const body = h('div', {}), el = h('div', { class: 'page' });
  const canEdit = can('menu_write'), canMove = can('stock_write');

  async function load() {
    const [items, suppliers, alerts] = await Promise.all([get('/api/inventory-items'), get('/api/suppliers'), get('/api/inventory/alerts')]);
    Object.assign(st, { items, suppliers, alerts }); draw();
  }
  const reload = debounce(() => load().catch(() => {}), 400);
  const tabs = seg([['stock', 'Ingredients'], ['buy', 'Shopping list']], st.tab, (v) => { st.tab = v; draw(); });

  function draw() {
    mount(el, h('div', { class: 'page-h' }, h('div', {}, h('h2', {}, 'Stock'), h('p', { class: 'muted small' }, 'Stock drops by itself when an order is accepted and comes back if it is cancelled. Dishes, sizes and recipes are on the Menu page.')),
      h('div', { class: 'row' }, canEdit ? h('button', { class: 'btn', type: 'button', onclick: () => itemForm() }, ico('plus', 18), 'New ingredient') : null)), tabs, body);
    st.tab === 'stock' ? drawStock() : drawBuy();
  }

  function cover(i) {
    const tags = [];
    if (i.on_hand <= 0) tags.push(badge('Out', 'bad')); else if (i.low) tags.push(badge('Low', 'warn'));
    if (i.expires_in_days !== null && i.expires_in_days <= 2 && i.on_hand > 0) tags.push(badge(i.expires_in_days < 0 ? 'Expired' : `Expires in ${i.expires_in_days} d`, 'bad'));
    if (i.surplus) tags.push(badge('Surplus', 'accent'));
    return h('div', { class: 'tag-row' }, tags);
  }
  function drawStock() {
    const list = st.items.filter((i) => (!st.q || i.name.toLowerCase().includes(st.q.toLowerCase())) && (!st.only || (st.only === 'low' ? i.low : st.only === 'surplus' ? i.surplus : i.expires_in_days !== null && i.expires_in_days <= 2)));
    const lowN = st.items.filter((i) => i.low).length, surN = st.items.filter((i) => i.surplus).length;
    mount(body, h('div', { class: 'stack' },
      h('div', { class: 'tiles' }, h('div', { class: 'tile' }, h('span', { class: 'k' }, 'Items'), h('span', { class: 'v' }, st.items.length)), h('div', { class: 'tile' }, h('span', { class: 'k' }, 'Running low'), h('span', { class: 'v', style: { color: lowN ? 'var(--warn)' : '' } }, lowN)), h('div', { class: 'tile' }, h('span', { class: 'k' }, 'Surplus to sell'), h('span', { class: 'v' }, surN)), h('div', { class: 'tile' }, h('span', { class: 'k' }, 'Stock value'), h('span', { class: 'v' }, inr(st.items.reduce((s, i) => s + Math.max(0, i.on_hand) * i.unit_cost, 0))))),
      h('div', { class: 'filters' }, h('input', { type: 'search', placeholder: 'Search ingredients', value: st.q, 'aria-label': 'Search', style: { maxWidth: '260px' }, oninput: (e) => { st.q = e.target.value; drawStock(); e.target.focus(); } }),
        seg([['', 'All'], ['low', 'Low'], ['surplus', 'Surplus'], ['exp', 'Expiring']], st.only, (v) => { st.only = v; drawStock(); })),
      h('div', { class: 'card' }, h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
        h('thead', {}, h('tr', {}, h('th', {}, 'Ingredient'), h('th', { class: 'num' }, 'On hand'), h('th', { class: 'hide-m num' }, 'Cover'), h('th', { class: 'hide-m' }, 'Supplier'), h('th', {}, 'Status'), h('th', {}))),
        h('tbody', {}, list.length ? list.map((i) => h('tr', { class: 'stock-row' }, h('td', {}, h('div', { class: 'name' }, i.name), h('div', { class: 'sub' }, `${i.category || ''} · ${inr2(i.unit_cost)}/${i.unit}`)),
          h('td', { class: 'num' }, h('strong', {}, qtyFmt(i.on_hand)), ' ', i.unit), h('td', { class: 'hide-m num' }, i.days_of_cover === null ? '–' : `${i.days_of_cover} d`), h('td', { class: 'hide-m muted' }, i.supplier || '–'), h('td', {}, cover(i)),
          h('td', { class: 'acts' }, canMove ? h('button', { class: 'btn sm', type: 'button', onclick: () => purchase(i) }, 'Bought') : null, ' ', canMove ? h('button', { class: 'btn sm ghost', type: 'button', onclick: () => wastage(i) }, 'Waste') : null, ' ', canEdit ? h('button', { class: 'icon-btn', type: 'button', 'aria-label': `Edit ${i.name}`, onclick: () => itemForm(i) }, ico('edit', 18)) : null))) : h('tr', {}, h('td', { colspan: 6 }, empty('No ingredients match', 'Change the filter or add a new ingredient.')))))))));
  }
  function drawBuy() {
    const l = st.alerts.purchase_list;
    mount(body, h('div', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Shopping list'), h('p', { class: 'muted small' }, 'Items below their reorder point, topped up to the par level.')), h('strong', {}, `About ${inr(l.reduce((s, x) => s + x.est_cost, 0))}`)),
      l.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, 'Item'), h('th', { class: 'num' }, 'Have'), h('th', { class: 'num' }, 'Buy'), h('th', { class: 'hide-m' }, 'Supplier'), h('th', { class: 'num' }, 'Est. cost'))),
        h('tbody', {}, l.map((x) => h('tr', {}, h('td', {}, x.name), h('td', { class: 'num' }, `${qtyFmt(x.on_hand)} ${x.unit}`), h('td', { class: 'num' }, h('strong', {}, `${x.suggested_qty} ${x.unit}`)), h('td', { class: 'hide-m muted' }, x.supplier || '–'), h('td', { class: 'num' }, inr(x.est_cost))))))) : empty('Nothing to buy', 'Everything is above its reorder level.'),
      l.length ? h('div', { class: 'row', style: { marginTop: '12px' } }, h('button', { class: 'btn', type: 'button', onclick: () => navigator.clipboard?.writeText(l.map((x) => `${x.name}: ${x.suggested_qty} ${x.unit}`).join('\n')).then(() => toast('List copied. Paste it into WhatsApp.')) }, ico('copy', 18), 'Copy list')) : null));
  }
  // ───────── forms ─────────
  function purchase(i) {
    const qty = h('input', { type: 'number', step: 'any', min: 0, inputmode: 'decimal' }), cost = h('input', { type: 'number', step: 'any', min: 0, inputmode: 'decimal', value: i.unit_cost }), sup = h('input', { value: i.supplier || '', list: 'sups' });
    const total = h('p', { class: 'muted' }, ''); const upd = () => (total.textContent = Number(qty.value) > 0 ? `Total ${inr2(qty.value * cost.value)}. This is added to expenses as Ingredients.` : '');
    qty.oninput = cost.oninput = upd;
    const m = modal({ title: `Bought ${i.name}`, size: 'sm', body: h('div', { class: 'stack' }, field(`Quantity (${i.unit})`, qty), field(`Cost per ${i.unit} (₹)`, cost), field('Supplier', sup), h('datalist', { id: 'sups' }, st.suppliers.map((s) => h('option', { value: s.name }))), total),
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { if (!(Number(qty.value) > 0)) { qty.focus(); throw new Error('Enter the quantity'); } await post('/api/stock-movements', { type: 'purchase', inventory_item_id: i.id, qty: Number(qty.value), unit_cost: Number(cost.value), supplier: sup.value }); m.close(); toast(`${i.name} stock updated`); load(); }) }, 'Save')] });
    qty.focus();
  }
  function wastage(i) {
    const qty = h('input', { type: 'number', step: 'any', min: 0, inputmode: 'decimal' }), why = select(['Spoiled', 'Spilled or dropped', 'Expired', 'Cooking mistake', 'Staff meal', 'Other'], 'Spoiled');
    const m = modal({ title: `Waste: ${i.name}`, size: 'sm', body: h('div', { class: 'stack' }, field(`Quantity wasted (${i.unit})`, qty), field('Reason', why), h('p', { class: 'muted small' }, `On hand now: ${qtyFmt(i.on_hand)} ${i.unit}. Wastage counts against profit.`)),
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { if (!(Number(qty.value) > 0)) { qty.focus(); throw new Error('Enter the quantity'); } await post('/api/stock-movements', { type: 'wastage', inventory_item_id: i.id, qty: Number(qty.value), note: why.value }); m.close(); toast('Wastage recorded'); load(); }) }, 'Record')] });
    qty.focus();
  }
  function itemForm(i) {
    const f = { name: h('input', { value: i?.name || '' }), category: h('input', { value: i?.category || '', placeholder: 'Produce, Dairy, Dry…' }), unit: select(['kg', 'g', 'l', 'ml', 'pcs', 'pack'], i?.unit || 'kg'),
      cost: h('input', { type: 'number', step: 'any', min: 0, value: i?.unit_cost ?? '' }), reorder: h('input', { type: 'number', step: 'any', min: 0, value: i?.reorder_level ?? '' }), par: h('input', { type: 'number', step: 'any', min: 0, value: i?.par_level ?? '' }),
      open: h('input', { type: 'number', step: 'any', min: 0, placeholder: '0' }), exp: h('input', { type: 'date', value: i?.expiry_date || '' }), sup: select([['', 'None'], ...st.suppliers.map((s) => [String(s.id), s.name])], String(i?.supplier_id || '')) };
    const m = modal({ title: i ? `Edit ${i.name}` : 'New ingredient', body: h('div', { class: 'form-grid' }, field('Name', f.name), field('Category', f.category), field('Unit', f.unit), field('Cost per unit (₹)', f.cost), field('Reorder when below', f.reorder), field('Keep up to (par)', f.par), field('Supplier', f.sup), field('Expiry date', f.exp), i ? null : field('Opening stock', f.open)),
      actions: [i && can('menu_write') ? h('button', { class: 'btn danger', type: 'button', onclick: async () => { if (!(await confirmBox('Delete ingredient?', `${i.name} will be removed.`, 'Delete', true))) return; try { await del(`/api/inventory-items/${i.id}`); m.close(); load(); } catch (e) { toast(e.message, 'bad', 6000); } } }, 'Delete') : null, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'),
        h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { const b = { name: f.name.value, category: f.category.value, unit: f.unit.value, unit_cost: f.cost.value || 0, reorder_level: f.reorder.value || 0, par_level: f.par.value || 0, supplier_id: f.sup.value || null, expiry_date: f.exp.value || null, opening_qty: f.open.value || 0 }; i ? await patch(`/api/inventory-items/${i.id}`, b) : await post('/api/inventory-items', b); m.close(); toast('Saved'); load(); }) }, 'Save')] });
  }
  await load();
  return { el, onEvent(e) { if (/^(stock|order\.(accepted|cancelled))/.test(e.type) || e.type === 'stream.open') reload(); } };
}
