// Kitchen display: big tickets, oldest promise first, one-tap progress. Works on a wall tablet.
import { printKot } from '../bill.js';
import { h, mount, ico, can, get, post, toast, busy, inr, hhmm, minsSince, chip, badge, debounce, S } from '../core.js';

export default async function kds(ctx) {
  let queue = { orders: [], to_prepare: [] }, fresh = [];
  const top = h('div', { class: 'kds-top' }), strip = h('div', { class: 'newstrip' }), grid = h('div', { class: 'kds-grid' });
  const el = h('div', { class: 'page kds' }, top, strip, grid);

  async function load() {
    const [q, all] = await Promise.all([get('/api/kitchen/queue'), get('/api/orders')]);
    queue = q; fresh = all.filter((o) => o.status === 'new').sort((a, b) => a.placed_at.localeCompare(b.placed_at)); draw();
  }
  const reload = debounce(() => load().catch(() => {}), 250);
  async function step(o, to) { try { await post(`/api/orders/${o.id}/status`, { status: to }); await load(); } catch (e) { toast(e.message, 'bad', 6000); } }

  const timer = (o) => {
    const prep = Math.max(1, Math.round((new Date(o.promised_at) - new Date(o.placed_at)) / 60000)), left = prep - minsSince(o.placed_at);
    return h('span', { class: `timer ${left < 0 ? 'bad' : left < 5 ? 'warn' : ''}` }, left >= 0 ? `${left} min left` : `${-left} min late`);
  };
  function ticket(o) {
    const cooking = o.status === 'preparing';
    return h('article', { class: `kcard ch-${o.channel}${cooking ? ' cooking' : ''}` },
      h('div', { class: 'kh' }, h('b', {}, `#${o.order_no}`), chip(o.channel), timer(o)),
      h('ul', {}, o.items.map((i) => h('li', {}, h('span', { class: 'q' }, `${i.qty}×`), h('span', {}, i.name, i.modifiers ? h('div', { class: 'mod' }, i.modifiers) : null)))),
      o.notes ? h('div', { class: 'note' }, o.notes) : null,
      h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, h('button', { class: 'btn primary lg grow', type: 'button', onclick: (e) => busy(e.currentTarget, () => step(o, cooking ? 'ready' : 'preparing')) }, cooking ? 'Ready for pickup' : 'Start cooking'),
        h('button', { class: 'btn lg', type: 'button', title: 'Print kitchen ticket', 'aria-label': 'Print kitchen ticket', onclick: (e) => busy(e.currentTarget, () => printKot(o.id)) }, ico('print', 20))));
  }
  function draw() {
    mount(top, h('div', { class: 'prep' }, queue.to_prepare.length ? queue.to_prepare.map((p) => h('span', { class: 'prep-chip' }, h('b', {}, p.qty), p.name)) : h('span', { class: 'muted' }, 'Nothing to prepare')),
      h('button', { class: 'btn', type: 'button', onclick: () => (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.()) }, ico('expand', 18), 'Full screen'));
    mount(strip, fresh.map((o) => h('div', { class: 'newrow' }, h('b', {}, `#${o.order_no}`), chip(o.channel), h('span', {}, o.items.map((i) => `${i.qty}× ${i.name}`).join(', ')), h('span', { class: 'grow' }), h('span', { class: 'muted small' }, hhmm(o.placed_at)),
      can('orders') ? h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, () => step(o, 'accepted')) }, 'Accept') : badge('Waiting for cashier', 'warn'))));
    mount(grid, queue.orders.length ? queue.orders.map(ticket) : h('div', { class: 'empty', style: { gridColumn: '1/-1' } }, h('strong', {}, 'Kitchen is clear'), h('p', {}, 'New orders will show up here by themselves.')));
  }
  await load();
  ctx.every(30000, draw);
  return { el, onEvent(e) { if (/^order\./.test(e.type) || e.type === 'stream.open') reload(); } };
}
