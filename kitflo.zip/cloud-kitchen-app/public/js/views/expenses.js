// Expenses: quick add (with receipt photo), live profit, recurring costs, budgets, profit bridge.
import { h, mount, ico, S, get, post, patch, put, del, send, toast, modal, confirmBox, busy, field, select, toggle, seg, inr, inr2, num, dshort, dlong, ymd, addDays, debounce, empty, badge, SRC, sum, shrinkImage, tip } from '../core.js';
import { chartCard, waterfall, budgetBars, stackedRows } from '../charts.js';

const CAT_COLORS = ['var(--c-website)', 'var(--c-swiggy)', 'var(--c-whatsapp)', 'var(--c-walkin)', 'var(--c-zomato)'];

export default async function expenses(ctx) {
  const el = h('div', { class: 'page' });
  const cats = S.config.expense_categories, modes = S.config.payment_modes.filter((p) => p !== 'Prepaid by platform');
  const today = ymd(), monthStart = today.slice(0, 8) + '01';
  const st = { live: null, list: { rows: [], total: 0 }, todayTotal: 0, monthTotal: 0, recurring: [], budgets: [], range: 'month', category: '', source: '', summary: null, loaded: false };
  const range = () => (st.range === 'today' ? [today, today] : st.range === '7' ? [addDays(today, -6), today] : st.range === '30' ? [addDays(today, -29), today] : [monthStart, today]);

  async function load() {
    const [from, to] = range();
    const [live, list, t, mo, rec, bud, sum_] = await Promise.all([get('/api/analytics/profit/live'), get('/api/expenses', { from, to, category: st.category, source: st.source }), get('/api/expenses', { from: today, to: today }), get('/api/expenses', { from: monthStart, to: today }), get('/api/recurring-expenses'), get('/api/budgets'), get('/api/analytics/summary', { from, to })]);
    Object.assign(st, { live, list, todayTotal: t.total, monthTotal: mo.total, recurring: rec, budgets: bud, summary: sum_, loaded: true }); draw();
  }
  const reload = debounce(() => load().catch(() => {}), 450);
  const tile = (k, v, d, cls = '') => h('div', { class: 'tile' }, h('span', { class: 'k' }, k), h('span', { class: `v ${cls}` }, v), h('span', { class: 'd' }, d));
  const delta = (cur, prev) => (!prev ? '' : `${cur >= prev ? 'Up' : 'Down'} ${inr(Math.abs(cur - prev))} on the same day last week`);

  // ───────── quick add ─────────
  function quickAdd() {
    const amount = h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', placeholder: '0', 'aria-label': 'Amount in rupees', style: { fontSize: '1.4rem', fontWeight: 700 } });
    const cat = select(cats, 'Ingredients'), vendor = h('input', { placeholder: 'Vendor (optional)' }), mode = select(modes, 'UPI'), notes = h('input', { placeholder: 'Note (optional)' }), date = h('input', { type: 'date', value: today, max: today });
    let receipt = null; const prev = h('div', { class: 'muted small' }), file = h('input', { type: 'file', accept: 'image/*', capture: 'environment', hidden: true });
    file.addEventListener('change', async () => { const f = file.files[0]; if (!f) return; prev.textContent = 'Preparing photo…'; try { const url = await shrinkImage(f); const r = await post('/api/uploads/receipt', { data_url: url }); receipt = r.file; prev.textContent = 'Receipt attached'; } catch (e) { receipt = null; prev.textContent = ''; toast(e.message, 'bad'); } });
    const go = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(go, async () => {
      if (!(Number(amount.value) > 0)) { amount.focus(); throw new Error('Enter the amount'); }
      const r = await send('POST', '/api/expenses', { amount: Number(amount.value), category: cat.value, vendor: vendor.value, payment_mode: mode.value, notes: notes.value, date: date.value, receipt });
      toast(r.queued ? 'Saved on this device' : `Added ${inr2(Number(amount.value))} to ${cat.value}`); amount.value = vendor.value = notes.value = ''; receipt = null; prev.textContent = ''; file.value = ''; amount.focus(); if (!r.queued) load();
    }) }, ico('plus', 18), 'Add expense');
    return h('section', { class: 'card' }, h('h3', { style: { marginBottom: '10px' } }, 'Add an expense'), h('div', { class: 'form-grid' }, field('Amount (₹)', amount), field('Category', cat), field('Paid by', mode)), h('div', { class: 'form-grid', style: { marginTop: '10px' } }, field('Vendor', vendor), field('Note', notes), field('Date', date)),
      h('div', { class: 'row', style: { marginTop: '12px' } }, go, h('button', { class: 'btn', type: 'button', onclick: () => file.click() }, ico('camera', 18), 'Attach receipt'), file, prev));
  }

  // ───────── list ─────────
  function listCard() {
    const rows = st.list.rows;
    const filters = h('div', { class: 'filters' }, seg([['today', 'Today'], ['7', '7 days'], ['30', '30 days'], ['month', 'This month']], st.range, (v) => { st.range = v; load(); }),
      select([['', 'All categories'], ...cats], st.category, { 'aria-label': 'Category', onchange: (e) => { st.category = e.target.value; load(); }, style: { width: 'auto' } }),
      select([['', 'All sources'], ['manual', 'Manual'], ['stock_purchase', 'From stock'], ['recurring', 'Recurring']], st.source, { 'aria-label': 'Source', onchange: (e) => { st.source = e.target.value; load(); }, style: { width: 'auto' } }));
    return h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Expenses'), h('p', { class: 'muted small' }, `${rows.length} entries · ${inr(st.list.total)} in total`)), filters),
      rows.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Date', 'Category', 'Vendor / note', 'Paid by', 'Source', 'Amount', ''].map((c, k) => h('th', { class: k === 5 ? 'num' : '' }, c)))),
        h('tbody', {}, rows.map((e) => h('tr', {}, h('td', { class: 'nowrap' }, dshort(e.date)), h('td', {}, e.category), h('td', {}, e.vendor || '', e.notes ? h('div', { class: 'muted small' }, e.notes) : null), h('td', {}, e.payment_mode || '–'),
          h('td', {}, badge(SRC[e.source] || e.source, e.source === 'manual' ? '' : 'accent')), h('td', { class: 'num' }, inr2(e.amount)),
          h('td', { class: 'acts' }, e.receipt ? h('a', { class: 'btn sm ghost', target: '_blank', rel: 'noopener', href: `/api/receipts/${e.receipt}?token=${encodeURIComponent(S.token)}` }, 'Receipt') : null, e.movement_id ? null : h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Edit expense', onclick: () => editExpense(e) }, ico('edit', 17)))))))) : empty('No expenses in this view', 'Add one above, or change the filters.'));
  }
  function editExpense(e) {
    const f = { date: h('input', { type: 'date', value: e.date }), category: select(cats, e.category), amount: h('input', { type: 'number', step: 'any', value: e.amount }), vendor: h('input', { value: e.vendor || '' }), mode: select(modes, e.payment_mode || 'UPI'), notes: h('input', { value: e.notes || '' }) };
    const go = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(go, async () => { await patch(`/api/expenses/${e.id}`, { date: f.date.value, category: f.category.value, amount: Number(f.amount.value), vendor: f.vendor.value, payment_mode: f.mode.value, notes: f.notes.value }); m.close(); toast('Expense updated'); load(); }) }, 'Save');
    const rm = h('button', { class: 'btn danger ghost', type: 'button', onclick: async () => { if (await confirmBox('Delete this expense?', `${inr2(e.amount)} on ${e.category} will be removed from profit.`, 'Delete', true)) { try { await del(`/api/expenses/${e.id}`); m.close(); toast('Expense deleted'); load(); } catch (x) { toast(x.message, 'bad'); } } } }, 'Delete');
    const m = modal({ title: 'Edit expense', size: 'sm', body: [h('div', { class: 'form-grid' }, field('Date', f.date), field('Amount (₹)', f.amount)), h('div', { class: 'form-grid' }, field('Category', f.category), field('Paid by', f.mode)), field('Vendor', f.vendor), field('Note', f.notes)], actions: [rm, h('span', { class: 'grow' }), h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), go] });
  }

  // ───────── recurring + budgets ─────────
  function recurringCard() {
    const due = (r) => r.next_due <= today, list = [...st.recurring].sort((a, b) => a.next_due.localeCompare(b.next_due));
    return h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Recurring costs'), h('p', { class: 'muted small' }, 'Confirm with one tap when due.')), h('button', { class: 'btn sm', type: 'button', onclick: () => recurringForm() }, ico('plus', 16), 'Add')),
      list.length ? h('div', { class: 'stack', style: { gap: '10px' } }, list.map((r) => h('div', { class: 'row between', style: { flexWrap: 'nowrap', opacity: r.active ? 1 : 0.5 } },
        h('div', {}, h('strong', {}, r.name), h('div', { class: 'muted small' }, `${inr(r.amount)} ${r.frequency} · ${r.auto_post ? 'posts automatically' : 'asks you to confirm'}`), h('div', { class: `small ${due(r) && r.active ? 'down' : 'muted'}` }, due(r) ? `Due ${dshort(r.next_due)}` : `Next ${dlong(r.next_due)}`)),
        h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '6px' } }, due(r) && r.active ? [(() => { const c = h('button', { class: 'btn sm primary', type: 'button', onclick: () => busy(c, async () => { await post(`/api/recurring-expenses/${r.id}/confirm`); toast(`${r.name} recorded`); load(); }) }, 'Confirm'); return c; })(), h('button', { class: 'btn sm', type: 'button', onclick: async () => { await post(`/api/recurring-expenses/${r.id}/skip`).catch((e) => toast(e.message, 'bad')); load(); } }, 'Skip')] : null,
          h('button', { class: 'icon-btn', type: 'button', 'aria-label': `Edit ${r.name}`, onclick: () => recurringForm(r) }, ico('edit', 17)))))) : empty('No recurring costs', 'Add rent, salaries and subscriptions once.'));
  }
  function recurringForm(r) {
    const f = { name: h('input', { value: r?.name || '', placeholder: 'e.g. Kitchen rent' }), cat: select(cats, r?.category || 'Rent'), amt: h('input', { type: 'number', step: 'any', value: r?.amount ?? '' }), freq: select([['daily', 'Daily'], ['weekly', 'Weekly'], ['monthly', 'Monthly'], ['yearly', 'Yearly']], r?.frequency || 'monthly'), due: h('input', { type: 'date', value: r?.next_due || today }) };
    let auto = !!r?.auto_post, active = r ? !!r.active : true;
    const go = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(go, async () => { const body = { name: f.name.value, category: f.cat.value, amount: Number(f.amt.value), frequency: f.freq.value, next_due: f.due.value, auto_post: auto, active }; r ? await patch(`/api/recurring-expenses/${r.id}`, body) : await post('/api/recurring-expenses', body); m.close(); toast('Saved'); load(); }) }, 'Save');
    const rm = r ? h('button', { class: 'btn danger ghost', type: 'button', onclick: async () => { if (await confirmBox('Delete recurring cost?', `${r.name} will stop appearing. Past expenses stay.`, 'Delete', true)) { await del(`/api/recurring-expenses/${r.id}`); m.close(); load(); } } }, 'Delete') : null;
    const m = modal({ title: r ? `Edit ${r.name}` : 'Add recurring cost', size: 'sm', body: [field('Name', f.name), h('div', { class: 'form-grid' }, field('Category', f.cat), field('Amount (₹)', f.amt)), h('div', { class: 'form-grid' }, field('How often', f.freq), field('Next due', f.due)), toggle(auto, (v) => { auto = v; }, 'Post automatically on the due date'), r ? toggle(active, (v) => { active = v; }, 'Active') : null], actions: [rm, h('span', { class: 'grow' }), h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), go] });
  }
  function budgetCard() {
    return h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Monthly budgets'), h('p', { class: 'muted small' }, 'You get one alert when a category passes its limit.')), h('button', { class: 'btn sm', type: 'button', onclick: budgetForm }, 'Set budgets')), budgetBars(st.budgets));
  }
  function budgetForm() {
    const cur = Object.fromEntries(st.budgets.map((b) => [b.category, b.limit])), inputs = Object.fromEntries(cats.map((c) => [c, h('input', { type: 'number', min: 0, step: 'any', value: cur[c] ?? '', placeholder: 'No limit' })]));
    const go = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(go, async () => { await put('/api/budgets', Object.fromEntries(cats.map((c) => [c, inputs[c].value]))); m.close(); toast('Budgets saved'); load(); }) }, 'Save budgets');
    const m = modal({ title: 'Monthly budgets (₹)', size: 'sm', body: [h('p', { class: 'muted small' }, 'Leave blank for no limit.'), h('div', { class: 'form-grid' }, cats.map((c) => field(c, inputs[c])))], actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), go] });
  }

  // ───────── charts ─────────
  function bridgeCard() {
    const s = st.summary; const [from, to] = range();
    return chartCard({ title: 'Where the money went', sub: `${dshort(from)} to ${dshort(to)}: sales down to net profit`, wide: true,
      draw: (box) => waterfall(box, { steps: [{ label: 'Sales', value: s.sales, kind: 'total', sub: `${s.orders} orders` }, { label: 'Commission', value: s.commission, kind: 'minus', sub: s.sales ? `${num((s.commission / s.sales) * 100, 0)}% of sales` : '' }, { label: 'Food cost', value: s.food_cost, kind: 'minus', sub: s.sales ? `${num((s.food_cost / s.sales) * 100, 0)}% of sales` : '' }, { label: 'Wastage', value: s.wastage, kind: 'minus' }, { label: 'Expenses', value: s.opex, kind: 'minus', sub: 'excl. ingredients' }, { label: 'Net profit', value: s.net, kind: 'result', sub: s.margin_pct === null ? '' : `${num(s.margin_pct, 0)}% margin` }] }),
      table: { head: ['Step', 'Amount'], rows: [['Sales', inr(s.sales)], ['Commission', '−' + inr(s.commission)], ['Food cost', '−' + inr(s.food_cost)], ['Wastage', '−' + inr(s.wastage)], ['Expenses (excl. ingredients)', '−' + inr(s.opex)], ['Net profit', inr(s.net)]] },
      note: 'Ingredient purchases are not subtracted again: their cost is already counted as food cost when dishes are sold.' });
  }
  function categoryCard() {
    const by = {}; for (const e of st.list.rows) by[e.category] = (by[e.category] || 0) + e.amount;
    const rows = Object.entries(by).sort((a, b) => b[1] - a[1]); if (!rows.length) return null;
    const top = rows.slice(0, 5), rest = sum(rows.slice(5), (r) => r[1]), data = rest > 0 ? [...top, ['Other categories', rest]] : top;
    return h('section', { class: 'card' }, h('h3', { style: { marginBottom: '12px' } }, 'Spend by category'), stackedRows({ rows: data.map(([c, v], i) => ({ label: c, dot: i < 5 ? CAT_COLORS[i] : 'var(--ink-3)', parts: [{ key: 'v', value: v }], note: `${inr(v)} · ${num((v / st.list.total) * 100, 0)}%` })), parts: [{ key: 'v', label: 'Spend', color: 'var(--accent)' }] }));
  }

  function draw() {
    const l = st.live, n = l.today.net, nm = l.month.net;
    const dueCount = st.recurring.filter((r) => r.active && r.next_due <= today && !r.auto_post).length;
    mount(el, h('div', { class: 'tiles' }, tile('Spent today', inr(st.todayTotal), 'all categories'), tile('Spent this month', inr(st.monthTotal), `${dshort(monthStart)} to today`), tile('Net profit today', inr(n), delta(n, l.same_day_last_week.net), n >= 0 ? 'up' : 'down'), tile('Net profit this month', inr(nm), `${l.month.orders} orders completed`, nm >= 0 ? 'up' : 'down')),
      dueCount ? h('div', { class: 'notice info' }, `${dueCount} recurring cost${dueCount === 1 ? ' is' : 's are'} due. Confirm below to record ${dueCount === 1 ? 'it' : 'them'}.`) : null,
      h('div', { class: 'split' }, h('div', { class: 'stack' }, quickAdd(), listCard(), bridgeCard()), h('div', { class: 'stack' }, recurringCard(), budgetCard(), categoryCard())));
  }

  await load();
  return { el, onEvent(e) { if (/^(expense\.|recurring\.|budget\.|order\.completed|stock\.purchased|stream\.open)/.test(e.type)) reload(); } };
}
