// Add-on groups: make Size, Extras, Spice level and the like, price them, and attach them to any dishes.
import { h, mount, ico, can, get, post, put, del, toast, modal, confirmBox, busy, field, select, toggle, inr, inr2, num, badge, empty, groupMenu } from '../core.js';
import { needText } from '../addons.js';

/** The manager dialog. `items` is the menu list, `inv` the stock items; onChange runs after anything is saved. */
export async function addonManager({ items, inv, onChange }) {
  const canEdit = can('menu_write'); let groups = [], sales = [];
  const box = h('div', { class: 'stack addon-edit' });
  const load = async () => { [groups, sales] = await Promise.all([get('/api/addons'), can('analytics') ? get('/api/addons/sales', { days: 30 }).catch(() => []) : []]); draw(); };
  const dishes = groupMenu(items);
  const draw = () => mount(box,
    h('p', { class: 'muted small' }, 'An add-on group is a set of choices, for example Size, Extras or Spice level. Attach it to any dish. Each add-on has its own price, and can use up stock.'),
    groups.length ? h('div', { class: 'stack', style: { gap: '8px' } }, groups.map((g) => {
      const dn = new Set(items.filter((m) => g.item_ids.includes(m.id)).map((m) => m.group_key)).size;
      return h('div', { class: 'card row between' }, h('div', {}, h('b', {}, g.name), h('div', { class: 'small muted' }, `${needText(g)} · ${g.addons.length} option${g.addons.length === 1 ? '' : 's'} · on ${dn} dish${dn === 1 ? '' : 'es'}`, g.off ? ' · switched off' : ''), h('div', { class: 'small' }, g.addons.slice(0, 6).map((a) => `${a.name}${a.price ? ' ' + inr(a.price) : ''}`).join(' · '), g.addons.length > 6 ? ' …' : '')),
        canEdit ? h('div', { class: 'row' }, h('button', { class: 'btn sm', type: 'button', onclick: () => editGroup(g) }, 'Edit'), h('button', { class: 'icon-btn', type: 'button', 'aria-label': `Delete ${g.name}`, onclick: async () => { if (!(await confirmBox('Delete this group?', `${g.name} will be removed from every dish. Past orders keep what was sold.`, 'Delete', true))) return; try { await del(`/api/addons/${g.id}`); toast('Group deleted'); await load(); onChange(); } catch (e) { toast(e.message, 'bad'); } } }, ico('trash', 18))) : null);
    })) : empty('No add-ons yet', canEdit ? 'Create a group such as Extras (cheese, dip) or Size (regular, large).' : 'Ask the owner or a manager to set them up.'),
    canEdit ? h('div', {}, h('button', { class: 'btn primary', type: 'button', onclick: () => editGroup(null) }, ico('plus', 18), 'New add-on group')) : null,
    sales.length ? h('div', { class: 'stack', style: { gap: '6px' } }, h('h3', {}, 'Add-on sales, last 30 days'), h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Add-on', 'Group', 'Sold', 'Revenue', 'Profit'].map((x, i) => h('th', { class: i > 1 ? 'num' : '' }, x)))),
      h('tbody', {}, sales.slice(0, 12).map((r) => h('tr', {}, h('td', {}, r.name), h('td', { class: 'muted' }, r.group), h('td', { class: 'num' }, num(r.qty, 0)), h('td', { class: 'num' }, inr2(r.revenue)), h('td', { class: 'num' }, inr2(r.profit)))))))) : null);

  function editGroup(g) {
    const isNew = !g;
    const f = { name: g?.name || '', min_pick: g?.min_pick ?? 0, max_pick: g?.max_pick ?? 0, off: !!g?.off };
    const opts = (g?.addons || [{ name: '', price: '' }]).map((a) => ({ id: a.id, name: a.name, price: a.price ?? '', cost: a.cost || '', inventory_item_id: a.inventory_item_id || '', qty_per_use: a.qty_per_use || '', off: !!a.off }));
    const picked = new Set(g ? g.item_ids : []);
    const optBox = h('div', { class: 'stack', style: { gap: '0' } }), dishBox = h('div', { class: 'dishpick' }); let term = '';
    const drawOpts = () => mount(optBox, opts.map((a, i) => h('div', { class: 'arow' },
      field('Option', h('input', { value: a.name, placeholder: 'Extra cheese', maxlength: 60, oninput: (e) => (a.name = e.target.value) })),
      field('Price ₹', h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: a.price, placeholder: '0', oninput: (e) => (a.price = e.target.value) })),
      field('Cost ₹', h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: a.cost, placeholder: '0', oninput: (e) => (a.cost = e.target.value) })),
      field('Uses stock', select([['', 'Nothing'], ...inv.map((x) => [String(x.id), `${x.name} (${x.unit})`])], String(a.inventory_item_id || ''), { onchange: (e) => { a.inventory_item_id = e.target.value; drawOpts(); } })),
      a.inventory_item_id ? field('Per use', h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: a.qty_per_use, oninput: (e) => (a.qty_per_use = e.target.value) })) : h('span'),
      field('Sold', toggle(!a.off, (on) => { a.off = !on; }, '')),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove option', onclick: () => { opts.splice(i, 1); drawOpts(); } }, ico('trash', 18)))));
    const ids = (d) => d.variants.map((v) => v.id), on = (d) => ids(d).every((x) => picked.has(x));
    const drawDishes = () => mount(dishBox, dishes.filter((d) => !term || d.name.toLowerCase().includes(term)).map((d) => h('label', {}, h('input', { type: 'checkbox', checked: on(d), onchange: (e) => { for (const x of ids(d)) e.target.checked ? picked.add(x) : picked.delete(x); count(); } }), h('span', {}, d.name), h('span', { class: 'muted small' }, d.category))));
    const cnt = h('span', { class: 'small muted' }), count = () => { cnt.textContent = `${dishes.filter(on).length} of ${dishes.length} dishes`; };
    const cats = [...new Set(dishes.map((d) => d.category))], catSel = select(cats, cats[0] || '', { 'aria-label': 'Category' });
    drawOpts(); drawDishes(); count();
    const m = modal({
      title: isNew ? 'New add-on group' : `Edit ${g.name}`, size: 'lg',
      body: h('div', { class: 'stack addon-edit' },
        h('div', { class: 'form-grid' }, field('Group name', h('input', { value: f.name, placeholder: 'Extras, Size, Spice level…', maxlength: 60, oninput: (e) => (f.name = e.target.value) })),
          field('Must choose at least', h('input', { type: 'number', min: 0, max: 20, value: f.min_pick, oninput: (e) => (f.min_pick = e.target.value) }), '0 means optional, 1 means the customer has to pick'),
          field('Can choose at most', h('input', { type: 'number', min: 0, max: 50, value: f.max_pick, oninput: (e) => (f.max_pick = e.target.value) }), '0 means no limit; 1 shows a pick-one list'),
          field('Group is on', toggle(!f.off, (v) => { f.off = !v; }, ''))),
        h('div', {}, h('div', { class: 'row between', style: { marginBottom: '4px' } }, h('h3', {}, 'Options'), h('button', { class: 'btn sm', type: 'button', onclick: () => { opts.push({ name: '', price: '' }); drawOpts(); } }, ico('plus', 16), 'Add option')), optBox),
        h('div', { class: 'stack', style: { gap: '8px' } }, h('div', { class: 'row between' }, h('h3', {}, 'Which dishes get this group'), cnt),
          h('div', { class: 'row' }, h('input', { type: 'search', placeholder: 'Find a dish', 'aria-label': 'Find a dish', style: { maxWidth: '220px' }, oninput: (e) => { term = e.target.value.trim().toLowerCase(); drawDishes(); } }),
            h('button', { class: 'btn sm', type: 'button', onclick: () => { for (const d of dishes) for (const x of ids(d)) picked.add(x); drawDishes(); count(); } }, 'Every dish'),
            h('button', { class: 'btn sm', type: 'button', onclick: () => { picked.clear(); drawDishes(); count(); } }, 'None'),
            catSel, h('button', { class: 'btn sm', type: 'button', onclick: () => { for (const d of dishes.filter((x) => x.category === catSel.value)) for (const x of ids(d)) picked.add(x); drawDishes(); count(); } }, 'Add this category')), dishBox)),
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => {
        if (!f.name.trim()) throw new Error('Give the group a name');
        const addons = opts.filter((a) => a.name.trim()).map((a) => ({ ...a, name: a.name.trim(), inventory_item_id: a.inventory_item_id ? Number(a.inventory_item_id) : null }));
        if (!addons.length && Number(f.min_pick) > 0) throw new Error('A required group needs at least one option');
        const body = { name: f.name.trim(), min_pick: Number(f.min_pick) || 0, max_pick: Number(f.max_pick) || 0, off: f.off, addons, item_ids: [...picked] };
        try { if (isNew) await post('/api/addons', body); else await put(`/api/addons/${g.id}`, body); } catch (er) { toast(er.message, 'bad'); throw er; }
        m.close(); toast('Add-ons saved'); await load(); onChange();
      }) }, 'Save')],
    });
  }
  await load();
  const m0 = modal({ title: 'Add-ons', size: 'lg', body: box, actions: [h('button', { class: 'btn', type: 'button', onclick: () => m0.close() }, 'Close')] });
}
