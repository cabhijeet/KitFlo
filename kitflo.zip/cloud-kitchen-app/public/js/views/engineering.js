// Menu engineering: which dishes are Stars, Plowhorses, Puzzles and Dogs, plus the break-even targets from the sheet.
import { h, mount, ico, get, put, post, toast, modal, busy, field, select, seg, inr, inr2, num, badge, empty, tip, can } from '../core.js';
import { s } from '../charts.js';
import { parseCsv } from '../csv.js';

const COLORS = { Star: 'var(--c-whatsapp)', Plowhorse: 'var(--c-walkin)', Puzzle: 'var(--c-website)', Dog: 'var(--c-zomato)' };
const HINT = { Star: 'Popular and profitable', Plowhorse: 'Popular, thin margin', Puzzle: 'Profitable, not popular', Dog: 'Neither popular nor profitable' };

export async function engineeringPanel() {
  const st = { source: 'auto', days: '30', category: '', cls: '', data: null };
  const el = h('div', { class: 'stack' }), chartBox = h('div', { class: 'chart-wrap' });

  async function load() {
    st.data = await get('/api/analytics/menu-engineering', { source: st.source, days: st.days, category: st.category });
    draw();
  }

  function tile(k) {
    const d = st.data, n = d.counts[k];
    return h('button', { type: 'button', class: `tile${st.cls === k ? ' on' : ''}`, style: { textAlign: 'left', cursor: 'pointer', borderLeft: `5px solid ${COLORS[k]}` }, onclick: () => { st.cls = st.cls === k ? '' : k; draw(); } },
      h('span', { class: 'k' }, k === 'Plowhorse' ? 'Plowhorses' : k + 's'), h('span', { class: 'v' }, n), h('span', { class: 'd' }, HINT[k]));
  }

  function matrix(items, th) {
    const pts = items.filter((i) => COLORS[i.class]); mount(chartBox);
    if (!pts.length) return mount(chartBox, h('p', { class: 'muted' }, 'No dishes with a cost and sales yet.'));
    const W = Math.max(320, chartBox.clientWidth || 640), H = 340, m = { l: 52, r: 16, t: 16, b: 44 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
    const xmax = Math.max(th.popularity_pct * 2.2, ...pts.map((p) => p.mix_pct)) * 1.08 || 1, ys = pts.map((p) => p.cm), ylo = Math.min(0, ...ys), yhi = Math.max(th.avg_cm * 1.6, ...ys) * 1.08 || 1;
    const X = (v) => m.l + (v / xmax) * iw, Y = (v) => m.t + ih - ((v - ylo) / (yhi - ylo)) * ih;
    const svg = s('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, role: 'img', 'aria-label': 'Dishes by popularity and margin per unit' });
    svg.append(s('rect', { x: X(th.popularity_pct), y: m.t, width: m.l + iw - X(th.popularity_pct), height: Y(th.avg_cm) - m.t, fill: 'var(--accent-soft)', opacity: 0.5 }),
      s('line', { x1: X(th.popularity_pct), x2: X(th.popularity_pct), y1: m.t, y2: m.t + ih, class: 'ref' }), s('line', { x1: m.l, x2: m.l + iw, y1: Y(th.avg_cm), y2: Y(th.avg_cm), class: 'ref' }),
      s('text', { x: m.l + iw - 6, y: m.t + 14, 'text-anchor': 'end', class: 'axis ink' }, 'Stars'), s('text', { x: m.l + 6, y: m.t + 14, class: 'axis ink' }, 'Puzzles'),
      s('text', { x: m.l + iw - 6, y: m.t + ih - 8, 'text-anchor': 'end', class: 'axis ink' }, 'Plowhorses'), s('text', { x: m.l + 6, y: m.t + ih - 8, class: 'axis ink' }, 'Dogs'),
      s('text', { x: m.l + iw / 2, y: H - 6, 'text-anchor': 'middle', class: 'axis dim' }, 'Share of units sold (%)'), s('text', { x: 12, y: m.t + ih / 2, 'text-anchor': 'middle', class: 'axis dim', transform: `rotate(-90 12 ${m.t + ih / 2})` }, 'Margin per unit (₹)'),
      s('line', { x1: m.l, x2: m.l, y1: m.t, y2: m.t + ih, class: 'axisline' }), s('line', { x1: m.l, x2: m.l + iw, y1: m.t + ih, y2: m.t + ih, class: 'axisline' }));
    for (const t of [0, 0.25, 0.5, 0.75, 1]) { const v = ylo + (yhi - ylo) * t; svg.append(s('text', { x: m.l - 6, y: Y(v) + 4, 'text-anchor': 'end', class: 'axis' }, num(v, 0))); const xv = xmax * t; svg.append(s('text', { x: X(xv), y: m.t + ih + 16, 'text-anchor': 'middle', class: 'axis' }, num(xv, 1))); }
    for (const p of pts) { const c = s('circle', { cx: X(p.mix_pct), cy: Y(p.cm), r: 6, fill: COLORS[p.class], stroke: 'var(--surface)', 'stroke-width': 1.5, tabindex: 0 }); tip(c, () => [h('strong', {}, p.name), h('div', {}, `${p.class} · ${num(p.units, 0)} sold (${num(p.mix_pct, 1)}%)`), h('div', {}, `Price ${inr(p.price)}, food cost ${inr(p.food_cost)}, margin ${inr(p.cm)}`)]); svg.append(c); }
    mount(chartBox, svg);
  }

  function draw() {
    const d = st.data; if (!d) return;
    const th = d.thresholds, items = d.items.filter((i) => !st.cls || i.class === st.cls);
    const costed = d.items.length - d.counts['Needs cost'];
    const srcText = d.source === 'sheet' ? `Sales from your sheet (${num(d.baseline_units, 0)} units)` : `Orders in this app, last ${d.days} days (${num(d.orders_units, 0)} units)`;
    mount(el,
      h('div', { class: 'card' }, h('div', { class: 'card-h' }, h('div', {}, h('h3', {}, 'Menu engineering'), h('p', { class: 'muted small' }, 'Each dish is rated on how often it sells and how many rupees it leaves after food cost. Click a tile to filter.')),
        h('div', { class: 'row' }, seg([['auto', 'Auto'], ['orders', 'My orders'], ['sheet', 'Sales sheet']], st.source, (v) => { st.source = v; load(); }),
          st.source !== 'sheet' ? select([['7', '7 days'], ['30', '30 days'], ['90', '90 days']], st.days, { 'aria-label': 'Period', onchange: (e) => { st.days = e.target.value; load(); } }) : null,
          select([['', 'All categories'], ...d.categories.map((c) => [c, c])], st.category, { 'aria-label': 'Category', onchange: (e) => { st.category = e.target.value; load(); } }))),
        h('p', { class: 'small' }, h('strong', {}, srcText), `. A dish counts as popular at ${num(th.popularity_pct, 1)}% of units or more, and as profitable at ${inr(th.avg_cm)} or more per unit (the average across what sells).`),
        d.source === 'sheet' && d.orders_units > 0 ? h('p', { class: 'small muted' }, 'Auto switches to your own orders once you have 100 or more units sold.') : null),
      costed === 0 ? h('div', { class: 'notice' }, 'No dish has a cost yet, so none can be rated. Add the ingredient cost (or a recipe) on each dish.') : null,
      h('div', { class: 'tiles' }, ['Star', 'Plowhorse', 'Puzzle', 'Dog'].map(tile)),
      d.counts['Needs cost'] ? h('div', { class: 'notice' }, h('strong', {}, `${d.counts['Needs cost']} of ${d.items.length} dishes have no cost yet`), ' and are left out of the ratings, because a missing cost would make them look 100% profitable. Add costs on the Dishes tab (filter: No cost or recipe yet).') : null,
      h('div', { class: 'card' }, h('h3', { style: { marginBottom: '8px' } }, 'Popularity and margin'), chartBox, h('p', { class: 'muted small', style: { marginTop: '6px' } }, 'Top right is best. Dashed lines are the two cut-offs.')),
      h('div', { class: 'card' }, h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
        h('thead', {}, h('tr', {}, ['Dish', 'Rating', 'Sold', 'Mix', 'Price', 'Food cost', 'Margin', 'After all costs'].map((x, i) => h('th', { class: i > 1 ? 'num' : '' }, x)), h('th', { class: 'hide-m' }, 'What to do'))),
        h('tbody', {}, items.length ? items.map((i) => h('tr', {}, h('td', {}, h('div', { class: 'name' }, i.name), h('div', { class: 'sub muted small' }, `${i.category}${i.sizes > 1 ? ` · ${i.sizes} sizes` : ''}${i.on_sale ? '' : ' · switched off'}`)),
          h('td', {}, h('span', { class: 'chip', style: { '--chc': COLORS[i.class] || 'var(--ink-3)' } }, i.class)), h('td', { class: 'num' }, num(i.units, 0)), h('td', { class: 'num' }, i.costed ? num(i.mix_pct, 1) + '%' : '–'),
          h('td', { class: 'num' }, inr(i.price)), h('td', { class: 'num' }, i.food_cost === null ? '–' : inr(i.food_cost)), h('td', { class: 'num' }, i.cm === null ? '–' : `${inr(i.cm)} (${num(i.cm_pct, 0)}%)`), h('td', { class: 'num' }, i.full_margin === null ? '–' : inr(i.full_margin)),
          h('td', { class: 'hide-m small' }, i.advice))) : h('tr', {}, h('td', { colspan: 9 }, empty('Nothing to show', 'Change the filters above.'))))))),
      targetsCard(d.targets),
      can('menu_write') ? h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: importSales }, 'Import sales from CSV'), h('span', { class: 'muted small' }, 'Columns: Name, Qty, Amount. Replaces the sales sheet figures.')) : null);
    matrix(items.length ? items : d.items, th);
  }

  function targetsCard(t) {
    const f = { monthly_operational_cost: t.monthly_operational_cost, avg_ticket: t.avg_ticket, cost_share_pct: t.cost_share_pct, days: t.days };
    const inp = (k, label, hint) => field(label, h('input', { type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: f[k], oninput: (e) => (f[k] = Number(e.target.value)) }), hint);
    const row = (k, v, w) => h('div', { class: 'row between' }, h('span', { class: 'muted' }, k), h('strong', {}, v), w ? h('span', { class: `small ${w.cls}` }, w.text) : null);
    const gap = (act, req) => (act === null || !req ? null : act >= req ? { cls: 'up', text: 'on target' } : { cls: 'down', text: `${num((1 - act / req) * 100, 0)}% short` });
    return h('div', { class: 'card' }, h('h3', {}, 'Break-even targets'), h('p', { class: 'muted small', style: { marginBottom: '10px' } }, 'From your sheet: monthly sales needed = operational cost ÷ the share of sales it should be. Actuals are the last 30 days of orders in this app.'),
      h('div', { class: 'grid2' }, h('div', { class: 'stack', style: { gap: '10px' } }, h('div', { class: 'form-grid' }, inp('monthly_operational_cost', 'Monthly operational cost (₹)'), inp('avg_ticket', 'Average bill (₹)'), inp('cost_share_pct', 'Operational cost as % of sales'), inp('days', 'Selling days a month')),
        h('div', {}, h('button', { class: 'btn primary', type: 'button', onclick: (e) => busy(e.currentTarget, async () => { await put('/api/targets', f); toast('Targets saved'); load(); }) }, 'Save targets'))),
        h('div', { class: 'stack', style: { gap: '8px' } }, row('Sales needed a month', inr(t.required_monthly_sales)), row('Sales needed a day', inr(t.required_per_day), gap(t.actual_sales_per_day, t.required_per_day) && { ...gap(t.actual_sales_per_day, t.required_per_day), text: `you do ${inr(t.actual_sales_per_day)}: ${gap(t.actual_sales_per_day, t.required_per_day).text}` }),
          row('Bills needed a day', t.required_tickets_per_day === null ? '–' : num(t.required_tickets_per_day, 1), gap(t.actual_tickets_per_day, t.required_tickets_per_day) && { ...gap(t.actual_tickets_per_day, t.required_tickets_per_day), text: `you do ${num(t.actual_tickets_per_day, 1)}: ${gap(t.actual_tickets_per_day, t.required_tickets_per_day).text}` }),
          row('Your average bill', t.actual_avg_ticket === null ? 'No orders yet' : inr(t.actual_avg_ticket), t.actual_avg_ticket === null ? null : { cls: t.actual_avg_ticket >= t.avg_ticket ? 'up' : 'down', text: `target ${inr(t.avg_ticket)}` }))));
  }

  function importSales() {
    let rows = null; const info = h('div', { class: 'muted' }, 'Choose a CSV with the columns Name, Qty, Amount.');
    const file = h('input', { type: 'file', accept: '.csv,text/csv', onchange: async () => {
      const f = file.files[0]; if (!f) return; rows = null; go.disabled = true;
      try { const all = parseCsv(await f.text()); const hi = all.findIndex((r) => r.some((c) => String(c).trim().toLowerCase() === 'name')); if (hi < 0) throw new Error('Could not find a "Name" column'); const hd = all[hi].map((c) => String(c).trim().toLowerCase()); const ni = hd.indexOf('name'), qi = hd.indexOf('qty'), ai = hd.indexOf('amount');
        rows = all.slice(hi + 1).map((r) => ({ name: r[ni], qty: Number(String(r[qi] || '').replace(/[,\s]/g, '')) || 0, amount: Number(String(r[ai] || '').replace(/[₹,\s]/g, '')) || 0 })).filter((r) => r.name); mount(info, `${rows.length} rows, ${num(rows.reduce((a, r) => a + r.qty, 0), 0)} units.`); go.disabled = !rows.length; }
      catch (e) { mount(info, h('div', { class: 'notice bad' }, e.message)); }
    } });
    const go = h('button', { class: 'btn primary', type: 'button', disabled: true, onclick: (e) => busy(e.currentTarget, async () => { const r = await post('/api/menu-sales', { rows }); toast(`${r.dishes} dishes, ${num(r.units, 0)} units saved`); m.close(); load(); }) }, 'Import');
    const m = modal({ title: 'Import sales', size: 'sm', body: h('div', { class: 'stack' }, h('p', { class: 'small muted' }, 'Use this for sales before you started using the app. Once you have 100 or more units of your own orders, “Auto” uses those instead.'), file, info), actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), go] });
  }

  await load();
  return el;
}
