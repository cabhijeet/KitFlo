// Customers: segments, lifetime value, favourites, WhatsApp opt-in, and win-back messages for lapsed customers.
import { h, mount, ico, get, patch, toast, modal, busy, field, select, toggle, seg, inr, num, dshort, ago, debounce, empty, badge, chip, waLink, copyText, CH, qtyFmt, dtime, S } from '../core.js';

export default async function customers(ctx) {
  const el = h('div', { class: 'page' });
  const st = { list: [], seg: 'all', q: '', loaded: false };
  const lapsedDays = 30;
  async function load() { st.list = await get('/api/customers'); st.loaded = true; draw(); }
  const reload = debounce(() => load().catch(() => {}), 800);
  const SK = { New: '', Repeat: 'good', Lapsed: 'warn' };
  const tile = (k, v, d) => h('div', { class: 'tile' }, h('span', { class: 'k' }, k), h('span', { class: 'v' }, v), h('span', { class: 'd' }, d));

  function winback() {
    const targets = st.list.filter((c) => c.segment === 'Lapsed' && c.whatsapp_opt_in && c.phone);
    let text = `Hi {name}, we miss you at ${S.config.business?.name || 'our kitchen'}! Order this week and enjoy 10% off with code COMEBACK10. Reply "menu" to see today's dishes.`;
    const ta = h('textarea', { rows: 4, value: text, oninput: () => { text = ta.value; drawList(); } }), listBox = h('div', { class: 'stack', style: { gap: '8px' } });
    const drawList = () => mount(listBox, targets.length ? targets.map((c) => h('div', { class: 'row between', style: { flexWrap: 'nowrap' } }, h('div', {}, h('strong', {}, c.name || c.phone), h('div', { class: 'muted small' }, `${c.order_count} orders · last ${ago(c.last_order_at)}`)), h('a', { class: 'btn sm primary', target: '_blank', rel: 'noopener', href: waLink(c.phone, text.replace(/\{name\}/g, c.name || 'there')) }, ico('chat', 16), 'Message'))) : h('p', { class: 'muted' }, 'No lapsed customers have opted in to WhatsApp messages.'));
    modal({ title: 'Win back lapsed customers', body: [h('p', { class: 'muted small' }, `Only customers who opted in to WhatsApp are listed. Each button opens WhatsApp with the message ready; you send it yourself. Create the promo code in the social scheduler first so orders can be tracked.`), field('Message', ta, 'Use {name} for the customer name'), listBox] }); drawList();
  }
  async function open(c) {
    const body = h('div', { class: 'skeleton' }, h('i')); const m = modal({ title: c.name || c.phone, side: true, body });
    try {
      const r = await get(`/api/customers/${c.id}/orders`);
      let optIn = c.whatsapp_opt_in;
      mount(body, h('div', { class: 'row' }, badge(c.segment, SK[c.segment]), h('span', { class: 'muted' }, c.phone), c.email ? h('span', { class: 'muted' }, c.email) : null), h('div', { class: 'tiles' }, tile('Orders', c.order_count, `first via ${CH[c.first_channel] || '–'}`), tile('Lifetime value', inr(c.lifetime_value), c.last_order_at ? `last order ${ago(c.last_order_at)}` : 'no orders yet')),
        toggle(optIn, async (v, input) => { try { await patch(`/api/customers/${c.id}`, { whatsapp_opt_in: v }); c.whatsapp_opt_in = v; toast(v ? 'Marked as opted in to WhatsApp' : 'Opt-in removed'); load(); } catch (e) { input.checked = !v; toast(e.message, 'bad'); } }, 'Agreed to WhatsApp offers'),
        r.favourites.length ? h('section', { class: 'card' }, h('h3', { style: { marginBottom: '8px' } }, 'Favourite dishes'), h('div', { class: 'chips' }, r.favourites.map((f) => badge(`${f.name} ×${qtyFmt(f.qty)}`, 'accent')))) : null,
        h('section', { class: 'card' }, h('h3', { style: { marginBottom: '8px' } }, 'Order history'), r.orders.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('tbody', {}, r.orders.map((o) => h('tr', {}, h('td', {}, `#${o.order_no}`), h('td', {}, chip(o.channel)), h('td', { class: 'muted small' }, dtime(o.placed_at)), h('td', { class: 'num' }, inr(o.total)), h('td', {}, badge(o.status, o.status === 'cancelled' ? 'bad' : '')))))) ) : h('p', { class: 'muted' }, 'No orders yet.')));
    } catch (e) { mount(body, h('p', { class: 'err' }, e.message)); }
  }
  function draw() {
    const all = st.list, count = (s) => all.filter((c) => c.segment === s).length, opted = all.filter((c) => c.whatsapp_opt_in).length, lapsedOpt = all.filter((c) => c.segment === 'Lapsed' && c.whatsapp_opt_in).length;
    const shown = all.filter((c) => (st.seg === 'all' || c.segment === st.seg) && `${c.name || ''} ${c.phone || ''}`.toLowerCase().includes(st.q.toLowerCase()));
    const search = h('input', { type: 'search', placeholder: 'Search name or phone', value: st.q, style: { width: '220px' }, oninput: (e) => { st.q = e.target.value; clearTimeout(search._t); search._t = setTimeout(draw, 250); } });
    mount(el, h('div', { class: 'tiles' }, tile('Customers', all.length, `${opted} agreed to WhatsApp offers`), tile('Repeat', count('Repeat'), 'ordered 2 or more times'), tile('New', count('New'), 'one order so far'), tile('Lapsed', count('Lapsed'), `no order in ${lapsedDays}+ days`)),
      h('div', { class: 'row between' }, h('div', { class: 'filters' }, seg([['all', 'All'], ['New', 'New'], ['Repeat', 'Repeat'], ['Lapsed', 'Lapsed']], st.seg, (v) => { st.seg = v; draw(); }), search), h('button', { class: 'btn primary', type: 'button', disabled: !lapsedOpt, title: lapsedOpt ? '' : 'No lapsed customers have opted in', onclick: winback }, ico('chat', 18), `Win back lapsed (${lapsedOpt})`)),
      h('section', { class: 'card' }, shown.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Customer', 'Segment', 'Orders', 'Lifetime value', 'Last order', 'WhatsApp'].map((c, k) => h('th', { class: k === 2 || k === 3 ? 'num' : '' }, c)))),
        h('tbody', {}, shown.map((c) => h('tr', { class: 'click', tabindex: 0, onclick: () => open(c), onkeydown: (e) => { if (e.key === 'Enter') open(c); } }, h('td', {}, h('strong', {}, c.name || 'No name'), h('div', { class: 'muted small' }, c.phone)), h('td', {}, badge(c.segment, SK[c.segment])), h('td', { class: 'num' }, c.order_count), h('td', { class: 'num' }, inr(c.lifetime_value)), h('td', {}, c.last_order_at ? ago(c.last_order_at) : '–'), h('td', {}, c.whatsapp_opt_in ? badge('Opted in', 'good') : h('span', { class: 'muted' }, 'No'))))))) : empty(all.length ? 'No customers match' : 'No customers yet', all.length ? 'Change the filter or search.' : 'Customers are added automatically when an order has a phone number.')));
  }
  await load();
  return { el, onEvent(e) { if (/^(order\.(completed|received)|stream\.open)/.test(e.type)) reload(); } };
}
