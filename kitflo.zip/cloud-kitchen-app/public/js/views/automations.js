// Automations: rules as data (trigger, conditions, actions), switch on/off, test, edit, run log, live event feed.
import { h, mount, ico, get, post, patch, del, toast, modal, confirmBox, busy, field, select, toggle, seg, dtime, ago, debounce, empty, badge, onEvent } from '../core.js';

const TRIGGERS = [['order.received', 'An order arrives'], ['order.accepted', 'An order is accepted'], ['order.completed', 'An order is completed'], ['order.cancelled', 'An order is cancelled'], ['stock.low', 'An ingredient runs low'], ['stock.surplus', 'An ingredient is in surplus'], ['stock.changed', 'Stock changes'], ['expense.added', 'An expense is added'], ['expense.deleted', 'An expense is deleted'], ['schedule.morning', 'Every morning (from 6:00)'], ['schedule.slow_day', 'Late morning check (from 11:00)'], ['post.published', 'A post is published'], ['budget.exceeded', 'A budget is passed']];
const ACTIONS = {
  create_promo_post: { label: 'Draft a discounted promo post', hint: 'Picks the best-margin dish that uses the ingredient and creates a promo code.', params: [['discount_pct', 'Discount %', 15], ['min_margin_pct', 'Only dishes with margin of at least %', 45]] },
  slow_day_offer: { label: 'Draft a slow-day offer post', hint: 'If orders are below the usual pace for this weekday.', params: [['threshold', 'Trigger when orders are below this share of usual (0.6 = 60%)', 0.6], ['discount_pct', 'Discount %', 10], ['min_margin_pct', 'Only dishes with margin of at least %', 50]] },
  sync_availability: { label: 'Mark sold-out dishes unavailable on Swiggy and Zomato', hint: 'Dishes also switch off on the website and POS automatically.', params: [] },
  notify: { label: 'Send an alert to every device', hint: 'Use {item}, {on_hand}, {unit} in the text for stock events.', params: [['text', 'Message', ''], ['level', 'Style', 'info', ['info', 'warn', 'bad']]] },
  post_recurring: { label: 'Post due recurring costs', hint: 'Auto-post ones are recorded; the rest ask for confirmation.', params: [] },
  recalc_profit: { label: 'Recalculate live profit', hint: '', params: [] },
  check_budget: { label: 'Check the budget and alert once a month', hint: '', params: [] },
  auto_accept: { label: 'Accept the order automatically', hint: 'Starts the kitchen clock and deducts stock without a tap.', params: [] },
};
const OPS = [['eq', 'is'], ['ne', 'is not'], ['gt', 'is above'], ['gte', 'is at least'], ['lt', 'is below'], ['lte', 'is at most']];
const trigLabel = (t) => t.split(',').map((x) => (TRIGGERS.find((y) => y[0] === x.trim()) || [0, x.trim()])[1]).join(' or ');

export default async function automations(ctx) {
  const el = h('div', { class: 'page' });
  const st = { rules: [], runs: [], events: [], loaded: false };
  async function load() { const [r, runs, ev] = await Promise.all([get('/api/automations'), get('/api/automations/runs', { limit: 30 }), get('/api/events', { limit: 25 })]); Object.assign(st, { rules: r.rules, runs, events: ev, loaded: true }); draw(); }
  const reload = debounce(() => load().catch(() => {}), 600);

  function ruleCard(r) {
    const conds = r.conditions.map((c) => `${c.field} ${(OPS.find((o) => o[0] === c.op) || [0, c.op])[1]} ${c.value}`);
    const test = h('button', { class: 'btn sm', type: 'button', onclick: () => busy(test, async () => { const x = await post(`/api/automations/${r.id}/test`); toast(x.latest_run ? `${x.latest_run.status === 'ok' ? 'Ran' : 'Failed'}: ${x.latest_run.output || x.latest_run.error || 'no output'}` : 'Ran', x.latest_run?.status === 'ok' ? 'info' : 'bad', 7000); load(); }) }, 'Test run');
    return h('article', { class: 'card rule' }, h('div', { class: 'row between', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } }, h('div', {}, h('h3', {}, r.name), r.description ? h('p', { class: 'muted small' }, r.description) : null),
      toggle(r.active, async (v, input) => { try { await patch(`/api/automations/${r.id}`, { active: v }); r.active = v; toast(`${r.name} is ${v ? 'on' : 'off'}`); } catch (e) { input.checked = !v; toast(e.message, 'bad'); } }, '')),
      h('div', { class: 'flow' }, h('span', { class: 'step-box' }, 'When ' + trigLabel(r.trigger)), conds.length ? [h('span', { class: 'arrow' }, '→'), h('span', { class: 'step-box' }, 'if ' + conds.join(' and '))] : null, r.actions.map((a) => [h('span', { class: 'arrow' }, '→'), h('span', { class: 'step-box' }, ACTIONS[a.type]?.label || a.type)])),
      h('div', { class: 'row between' }, h('div', { class: 'row small muted' }, r.requires_approval ? badge('Asks for approval before posting', 'warn') : null, h('span', {}, r.run_count ? `Ran ${r.run_count} time${r.run_count === 1 ? '' : 's'}${r.last_run_at ? `, last ${ago(r.last_run_at)}` : ''}` : 'Has not run yet')), h('div', { class: 'row' }, test, h('button', { class: 'btn sm', type: 'button', onclick: () => edit(r) }, ico('edit', 16), 'Edit'))), r.last_error ? h('div', { class: 'notice bad' }, `Last error: ${r.last_error}`) : null);
  }

  function edit(r) {
    const isNew = !r; r = r || { name: '', trigger: 'order.received', conditions: [], actions: [{ type: 'notify', text: '', level: 'info' }], active: true, requires_approval: false, description: '' };
    const trig = new Set(r.trigger.split(',').map((s) => s.trim())), conds = r.conditions.map((c) => ({ ...c })), acts = r.actions.map((a) => ({ ...a }));
    let approval = r.requires_approval, active = r.active;
    const name = h('input', { value: r.name, placeholder: 'e.g. Alert when paneer runs low' }), desc = h('input', { value: r.description || '', placeholder: 'What this does, in a sentence' });
    const trigBox = h('div', { class: 'stack', style: { gap: '4px' } }, TRIGGERS.map(([k, l]) => { const i = h('input', { type: 'checkbox', checked: trig.has(k), onchange: () => (i.checked ? trig.add(k) : trig.delete(k)) }); return h('label', { class: 'row small', style: { gap: '8px' } }, i, l); }));
    const condBox = h('div'), actBox = h('div');
    const drawCond = () => mount(condBox, conds.map((c, k) => h('div', { class: 'row', style: { marginBottom: '6px', flexWrap: 'nowrap' } }, h('input', { value: c.field, placeholder: 'field, e.g. channel', oninput: (e) => { c.field = e.target.value; } }), select(OPS, c.op, { onchange: (e) => { c.op = e.target.value; }, style: { width: '130px' } }), h('input', { value: c.value, placeholder: 'value', oninput: (e) => { c.value = e.target.value; } }), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove condition', onclick: () => { conds.splice(k, 1); drawCond(); } }, ico('trash', 17)))), h('button', { class: 'btn sm', type: 'button', onclick: () => { conds.push({ field: '', op: 'eq', value: '' }); drawCond(); } }, ico('plus', 16), 'Add condition'));
    const drawAct = () => mount(actBox, acts.map((a, k) => { const def = ACTIONS[a.type]; return h('div', { class: 'act-edit' }, h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, select(Object.entries(ACTIONS).map(([t, d]) => [t, d.label]), a.type, { onchange: (e) => { acts[k] = { type: e.target.value }; ACTIONS[e.target.value].params.forEach(([key, , dflt]) => (acts[k][key] = dflt)); drawAct(); } }), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove action', onclick: () => { acts.splice(k, 1); drawAct(); } }, ico('trash', 17))), def?.hint ? h('p', { class: 'muted small' }, def.hint) : null, def?.params.length ? h('div', { class: 'form-grid' }, def.params.map(([key, label, dflt, opts]) => field(label, opts ? select(opts, a[key] ?? dflt, { onchange: (e) => { a[key] = e.target.value; } }) : h('input', { value: a[key] ?? dflt, type: typeof dflt === 'number' ? 'number' : 'text', step: 'any', oninput: (e) => { a[key] = typeof dflt === 'number' ? Number(e.target.value) : e.target.value; } })))) : null); }), h('button', { class: 'btn sm', type: 'button', onclick: () => { acts.push({ type: 'notify', text: '', level: 'info' }); drawAct(); } }, ico('plus', 16), 'Add action'));
    const go = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(go, async () => {
      if (!trig.size) throw new Error('Pick at least one thing that starts this automation');
      const cleaned = conds.filter((c) => c.field).map((c) => ({ field: c.field, op: c.op, value: isNaN(Number(c.value)) || c.value === '' ? c.value : Number(c.value) }));
      const body = { name: name.value, trigger: [...trig].join(','), conditions: cleaned, actions: acts, active, requires_approval: approval, description: desc.value };
      isNew ? await post('/api/automations', body) : await patch(`/api/automations/${r.id}`, body); m.close(); toast('Automation saved'); load();
    }) }, isNew ? 'Create automation' : 'Save');
    const rm = !isNew ? h('button', { class: 'btn danger ghost', type: 'button', onclick: async () => { if (await confirmBox('Delete automation?', `${r.name} will stop running.`, 'Delete', true)) { await del(`/api/automations/${r.id}`); m.close(); load(); } } }, 'Delete') : null;
    const m = modal({ title: isNew ? 'New automation' : `Edit ${r.name}`, size: 'lg', body: [field('Name', name), field('Description', desc), h('div', { class: 'grid2' }, h('section', {}, h('h3', { style: { marginBottom: '8px' } }, 'When this happens'), trigBox), h('section', {}, h('h3', { style: { marginBottom: '8px' } }, 'Only if (optional)'), condBox, h('p', { class: 'muted small', style: { marginTop: '6px' } }, 'Fields come from the event, e.g. channel is swiggy.'))), h('section', {}, h('h3', { style: { marginBottom: '8px' } }, 'Then do'), actBox), h('div', { class: 'row' }, toggle(approval, (v) => { approval = v; }, 'Ask for approval before anything is posted publicly'), toggle(active, (v) => { active = v; }, 'Active'))], actions: [rm, h('span', { class: 'grow' }), h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), go] });
    drawCond(); drawAct();
  }

  function draw() {
    mount(el, h('div', { class: 'page-h' }, h('div', {}, h('h2', {}, 'Automations'), h('p', { class: 'muted small' }, 'Rules that connect orders, stock, expenses and social posts. Every run is logged, retried three times, and you are told if it fails.')), h('button', { class: 'btn primary', type: 'button', onclick: () => edit() }, ico('plus', 18), 'New automation')),
      h('div', { class: 'split' }, h('div', { class: 'stack' }, st.rules.map(ruleCard)),
        h('div', { class: 'stack' }, h('section', { class: 'card' }, h('h3', { style: { marginBottom: '8px' } }, 'Recent runs'), st.runs.length ? h('div', { class: 'feed' }, st.runs.map((r) => h('div', {}, badge(r.status === 'ok' ? 'OK' : 'Failed', r.status === 'ok' ? 'good' : 'bad'), h('span', {}, h('strong', {}, r.rule_name), h('div', { class: 'muted small' }, r.output || r.error || ''), h('div', { class: 'muted small' }, ago(r.at)))))) : h('p', { class: 'muted' }, 'Nothing has run yet.')),
          h('section', { class: 'card' }, h('h3', { style: { marginBottom: '8px' } }, 'Live events'), st.events.length ? h('div', { class: 'feed' }, st.events.map((e) => h('div', {}, h('code', {}, e.type), h('span', { class: 'muted small' }, ago(e.at))))) : h('p', { class: 'muted' }, 'Events appear as things happen.')))));
  }
  await load();
  return { el, onEvent(e) { if (e.type !== 'stream.open' || true) reload(); } };
}
