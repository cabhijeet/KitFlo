// Hosted accounts: business sign-in, sign-up, the paywall, and the Billing, Printers, Shop devices and Backups panels in Settings.
import { h, mount, S, get, post, put, del, toast, busy, field, select, toggle, seg, inr, inr2, dtime, copyText, readPref, savePref, modal, confirmBox, ico, badge } from '../core.js';

const logo = () => h('div', { class: 'logo' }, h('img', { class: 'lg-d', src: '/icons/logo.png', alt: 'KitFlo. Your Kitchen\'s Digital Nerve' }), h('img', { class: 'lg-l', src: '/icons/logo-light.png', alt: '', 'aria-hidden': 'true' }));
const deviceLabel = () => { const ua = navigator.userAgent; return (/Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : 'Device') + ' shop device'; };
const input = (p = {}) => h('input', p);

/** Email and password sign-in for the business owner. A "shop device" tick makes this tablet or PC one that may show staff names and take a PIN. */
export function showBusinessLogin(root, { message, onDone, signups = true } = {}) {
  const email = input({ type: 'email', autocomplete: 'username', placeholder: 'you@example.com', value: readPref('last_email', '') }), pw = input({ type: 'password', autocomplete: 'current-password' });
  let shop = !readPref('device'); const err = h('div', { class: 'err', role: 'alert' }, message || '');
  const go = h('button', { class: 'btn primary block', type: 'submit' }, 'Sign in');
  const form = h('form', { class: 'stack', onsubmit: (e) => { e.preventDefault(); busy(go, async () => {
    err.textContent = '';
    try { const r = await post('/api/account/login', { email: email.value, password: pw.value, shop_device: shop, device_name: deviceLabel() }); savePref('last_email', email.value.trim()); if (r.device_key) savePref('device', r.device_key); onDone(r.token); }
    catch (x) { err.textContent = x.message; }
  }); } },
    field('Business email', email), field('Password', pw),
    toggle(shop, (v) => { shop = v; }, 'This is a shop device (staff can sign in here with a PIN)'), err, go,
    signups ? h('p', { class: 'muted small center' }, 'New here? ', h('a', { href: '/signup' }, 'Start a free trial')) : null);
  mount(root, h('div', { class: 'login' }, h('div', { class: 'box' }, logo(), h('p', { class: 'muted' }, 'Sign in to your business'), form)));
}

/** Free-trial sign-up. */
export async function showSignup(root, { onDone }) {
  let mode = {}; try { mode = await get('/api/auth/mode'); } catch { /* shown below */ }
  if (!mode.signups) return mount(root, h('div', { class: 'login' }, h('div', { class: 'box' }, logo(), h('p', {}, 'Sign-ups are not open here.'), h('a', { class: 'btn', href: '/' }, 'Back to sign in'))));
  const f = { business: input({ placeholder: 'Your kitchen or brand' }), name: input({ placeholder: 'Your name', autocomplete: 'name' }), email: input({ type: 'email', autocomplete: 'email' }), phone: input({ type: 'tel', inputmode: 'numeric', placeholder: '10-digit mobile', maxlength: 14 }),
    password: input({ type: 'password', autocomplete: 'new-password', placeholder: 'At least 8 characters' }), pin: input({ type: 'password', inputmode: 'numeric', maxlength: 8, placeholder: '4 to 8 digits', autocomplete: 'off' }) };
  let plan = 'growth', shop = true; const err = h('div', { class: 'err', role: 'alert' });
  const plans = Object.entries(mode.plans || {}), go = h('button', { class: 'btn primary block', type: 'submit' }, `Start ${mode.trial_days || 14}-day free trial`);
  const planBox = h('div', { class: 'plan-pick' }); const drawPlans = () => mount(planBox, plans.map(([k, p]) => h('button', { type: 'button', class: 'plan' + (plan === k ? ' on' : ''), onclick: () => { plan = k; drawPlans(); } }, h('strong', {}, p.name), h('span', {}, inr(p.monthly) + ' / month'), h('small', {}, `${p.users ? p.users + ' people' : 'Unlimited people'}, ${p.outlets ? p.outlets + ' outlet' : 'many outlets'}`))));
  drawPlans();
  const form = h('form', { class: 'stack', onsubmit: (e) => { e.preventDefault(); busy(go, async () => {
    err.textContent = '';
    try { const r = await post('/api/signup', { business: f.business.value, name: f.name.value, email: f.email.value, phone: f.phone.value, password: f.password.value, pin: f.pin.value, plan, shop_device: shop, device_name: deviceLabel() }); if (r.device_key) savePref('device', r.device_key); history.replaceState(null, '', '/'); onDone(r.token); }
    catch (x) { err.textContent = x.message; }
  }); } },
    h('div', { class: 'form-grid' }, field('Business name', f.business), field('Your name', f.name), field('Email', f.email), field('Mobile', f.phone), field('Password', f.password), field('Your sign-in PIN', f.pin, 'You will use this on the counter screen')),
    h('div', {}, h('strong', { class: 'small' }, 'Plan after the trial'), h('p', { class: 'muted small' }, 'Per outlet, before GST. No card needed now. Change it any time.'), planBox),
    toggle(shop, (v) => { shop = v; }, 'This is a shop device'), err, go, h('p', { class: 'muted small center' }, 'Already have an account? ', h('a', { href: '/' }, 'Sign in')));
  mount(root, h('div', { class: 'login' }, h('div', { class: 'box wide' }, logo(), h('p', { class: 'muted' }, 'Run your kitchen from one screen, with true profit on every order.'), form)));
}

// ───────── plans, paying, paywall ─────────
const CYCLE = { monthly: 'month', yearly: 'year' };
function planCards(b, on) {
  return h('div', { class: 'plan-pick' }, Object.entries(b.plans).map(([k, p]) => {
    const price = (b.cycle === 'yearly' ? p.yearly : p.monthly) * b.outlets;
    return h('button', { type: 'button', class: 'plan' + (b.plan === k ? ' on' : ''), onclick: () => on(k, b.cycle) }, h('strong', {}, p.name), h('span', {}, `${inr(price)} / ${CYCLE[b.cycle]}`), h('small', {}, `${p.users ? p.users + ' people' : 'Unlimited people'}, ${p.outlets ? p.outlets + ' outlet' : 'many outlets'}`));
  }));
}
async function payNow(b, after) {
  const r = await post('/api/billing/invoice', {});
  if (r.pay_link) { window.open(r.pay_link, '_blank', 'noopener'); toast('Payment page opened. Come back here when you have paid.', 'info', 8000); }
  else toast(b.manual_payment_note || `Invoice ${r.number} for ${inr2(r.total)} is ready. Pay as instructed by your KitFlo contact.`, 'info', 12000);
  after && after();
}
/** Full-screen screen when a trial or plan has ended. The owner can pick a plan and pay; others are told to ask the owner. */
export async function showPaywall(root, { message, code, onRetry, onSignOut }) {
  let b = null; try { b = await get('/api/billing'); } catch { /* shown as a plain notice */ }
  const owner = !!b?.plans && !['suspended', 'cancelled'].includes(code || b?.code);
  const body = h('div', { class: 'stack' });
  const draw = () => {
    if (!owner) return mount(body, h('p', {}, message || b?.message || 'This account is paused.'), h('p', { class: 'muted' }, ['suspended', 'cancelled'].includes(code || b?.code) ? 'Please contact KitFlo support.' : 'Please ask the business owner to renew the plan.'), h('button', { class: 'btn', type: 'button', onclick: onRetry }, 'Check again'), h('button', { class: 'btn ghost', type: 'button', onclick: onSignOut }, 'Sign out'));
    const open = b.open_invoice, sel = (plan, cycle) => post('/api/billing/plan', { plan, cycle }).then(() => get('/api/billing')).then((x) => { b = x; draw(); }).catch((e) => toast(e.message, 'bad'));
    const pay = h('button', { class: 'btn primary block', type: 'button', onclick: () => busy(pay, () => payNow(b, () => {})) }, `Pay ${inr2(b.total)} (incl. GST)`);
    mount(body, h('p', {}, message || b.message), seg([['monthly', 'Monthly'], ['yearly', 'Yearly (2 months free)']], b.cycle, (v) => sel(b.plan, v)), planCards(b, sel),
      h('div', { class: 'row between' }, h('span', { class: 'muted small' }, `${b.outlets} outlet${b.outlets > 1 ? 's' : ''} × ${inr(b.price_ex_gst / b.outlets)} + ${b.gst_pct}% GST`), h('strong', {}, inr2(b.total))), pay,
      h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: onRetry }, 'I have paid. Continue'), h('button', { class: 'btn ghost', type: 'button', onclick: onSignOut }, 'Sign out')), h('p', { class: 'muted small' }, 'Your data is safe and will be here when you come back.'));
  };
  draw(); mount(root, h('div', { class: 'login' }, h('div', { class: 'box wide' }, logo(), h('h2', {}, owner ? 'Choose a plan to continue' : 'Account paused'), body)));
}

// ───────── Settings panels ─────────
export function billingPanel(reload) {
  const el = h('div', { class: 'stack' });
  (async () => {
    const b = await get('/api/billing'), invs = await get('/api/billing/invoices').catch(() => []);
    if (!b.hosted) return mount(el, h('section', { class: 'card' }, h('p', { class: 'muted' }, 'Billing is only used on KitFlo-hosted accounts. This installation is self-hosted and has no plan.')));
    const sel = (plan, cycle) => post('/api/billing/plan', { plan, cycle }).then(() => { toast('Plan updated'); reload(); }).catch((e) => toast(e.message, 'bad'));
    const d = b.details, f = { gstin: input({ value: d.gstin, placeholder: '15 characters', maxlength: 15, style: { textTransform: 'uppercase' } }), name: input({ value: d.billing_name }), addr: input({ value: d.billing_address }), state: input({ value: d.billing_state, placeholder: 'e.g. Karnataka' }) };
    const save = h('button', { class: 'btn', type: 'button', onclick: () => busy(save, async () => { await post('/api/billing/details', { gstin: f.gstin.value, billing_name: f.name.value, billing_address: f.addr.value, billing_state: f.state.value }); toast('Invoice details saved'); reload(); }) }, 'Save invoice details');
    const pay = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(pay, () => payNow(b, reload)) }, b.state === 'active' && !b.renew_soon ? 'Pay early' : `Pay ${inr2(b.total)}`);
    mount(el,
      h('section', { class: 'card stack' }, h('div', { class: 'row between' }, h('div', {}, h('h3', {}, `${b.plan_name} plan`), h('p', { class: 'muted small' }, b.message || (b.paid_until ? `Paid until ${dtime(b.paid_until).split(',')[0]}` : ''))), badge(b.state === 'trial' ? 'Free trial' : b.state === 'active' ? 'Active' : b.state === 'past_due' ? 'Payment due' : b.state, b.ok ? 'ok' : 'bad')),
        seg([['monthly', 'Monthly'], ['yearly', 'Yearly (2 months free)']], b.cycle, (v) => sel(b.plan, v)), planCards(b, sel),
        h('div', { class: 'row between' }, h('span', { class: 'muted small' }, `${b.outlets} outlet${b.outlets > 1 ? 's' : ''}. ${inr(b.price_ex_gst)} + ${b.gst_pct}% GST`), h('strong', {}, `${inr2(b.total)} per ${CYCLE[b.cycle]}`)),
        h('div', { class: 'row' }, pay, b.online_payments ? null : h('span', { class: 'muted small' }, b.manual_payment_note || 'Online payment is not switched on yet. An invoice is made and you pay as instructed.'))),
      h('section', { class: 'card stack' }, h('div', {}, h('h3', {}, 'Invoice details'), h('p', { class: 'muted small' }, 'Used on your GST invoice. Add your GSTIN to claim input tax credit.')), h('div', { class: 'form-grid' }, field('GSTIN', f.gstin), field('Billing name', f.name), field('State', f.state, 'Decides CGST and SGST or IGST'), field('Address', f.addr)), h('div', {}, save)),
      h('section', { class: 'card' }, h('h3', { style: { marginBottom: '8px' } }, 'Invoices'), invs.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Number', 'Date', 'Plan', 'Total', 'Status', ''].map((c) => h('th', {}, c)))),
        h('tbody', {}, invs.map((i) => h('tr', {}, h('td', {}, i.number), h('td', { class: 'nowrap' }, dtime(i.issued_at).split(',')[0]), h('td', {}, `${i.plan} ${i.cycle}`), h('td', {}, inr2(i.total)), h('td', {}, badge(i.status, i.status === 'paid' ? 'ok' : i.status === 'due' ? 'warn' : '')), h('td', {}, h('button', { class: 'btn sm', type: 'button', onclick: () => showInvoice(i.number) }, 'View')))))))
        : h('p', { class: 'muted' }, 'No invoices yet.')));
  })().catch((e) => mount(el, h('p', { class: 'err' }, e.message)));
  return el;
}
async function showInvoice(number) {
  const i = await get('/api/billing/invoices/' + encodeURIComponent(number)), s = i.seller, row = (l, v) => h('div', { class: 'row between' }, h('span', {}, l), h('span', {}, v));
  const body = h('div', { class: 'stack invoice', id: 'inv-print' }, h('div', { class: 'row between' }, h('div', {}, h('strong', {}, s.name), s.address ? h('div', { class: 'small' }, s.address) : null, s.gstin ? h('div', { class: 'small' }, `GSTIN ${s.gstin}`) : null), h('div', { class: 'right' }, h('strong', {}, i.gst_pct ? 'TAX INVOICE' : 'INVOICE'), h('div', { class: 'small' }, i.number), h('div', { class: 'small' }, dtime(i.issued_at).split(',')[0]))),
    h('div', {}, h('div', { class: 'small muted' }, 'Billed to'), h('strong', {}, i.buyer.name), i.buyer.address ? h('div', { class: 'small' }, i.buyer.address) : null, i.buyer.gstin ? h('div', { class: 'small' }, `GSTIN ${i.buyer.gstin}`) : null, i.buyer.state ? h('div', { class: 'small' }, i.buyer.state) : null),
    h('hr'), row(`KitFlo ${i.plan} plan, ${i.cycle}, ${i.outlets} outlet${i.outlets > 1 ? 's' : ''}${s.sac ? ` (SAC ${s.sac})` : ''}`, inr2(i.taxable)), h('div', { class: 'small muted' }, `Period ${dtime(i.period_from).split(',')[0]} to ${dtime(i.period_to).split(',')[0]}`),
    i.cgst ? row(`CGST ${i.gst_pct / 2}%`, inr2(i.cgst)) : null, i.sgst ? row(`SGST ${i.gst_pct / 2}%`, inr2(i.sgst)) : null, i.igst ? row(`IGST ${i.gst_pct}%`, inr2(i.igst)) : null, h('hr'), row('Total', inr2(i.total)), h('div', { class: 'small' }, i.status === 'paid' ? `Paid ${dtime(i.paid_at).split(',')[0]}${i.payment_ref ? ` · ref ${i.payment_ref}` : ''}` : 'Payment due'));
  const m = modal({ title: `Invoice ${i.number}`, size: 'md', body, actions: [h('button', { class: 'btn', type: 'button', onclick: () => window.print() }, 'Print or save as PDF'), h('button', { class: 'btn primary', type: 'button', onclick: () => m.close() }, 'Close')] });
}

const PRINT_ROLES = [['both', 'Bill and kitchen ticket'], ['bill', 'Bills only'], ['kot', 'Kitchen tickets only']];
/** Printers the print helper sends to, the helper key, and recent jobs. */
export function printersPanel() {
  const el = h('div', { class: 'stack' });
  const load = async () => {
    const c = await get('/api/print/config'); let list = c.printers.map((p) => ({ ...p }));
    const row = (p, i) => {
      const f = { name: input({ value: p.name, placeholder: 'e.g. Counter' }), conn: input({ value: p.connection, placeholder: 'tcp:192.168.1.50:9100' }) };
      const sync = () => { p.name = f.name.value; p.connection = f.conn.value.trim(); };
      return h('div', { class: 'card stack printer' }, h('div', { class: 'form-grid' }, field('Name', f.name, null), field('Connection', f.conn, 'Network: tcp:192.168.1.50:9100. USB: device:/dev/usb/lp0 or device:COM3. Installed printer: os:PrinterName')),
        h('div', { class: 'form-grid' }, field('Prints', select(PRINT_ROLES, p.role, { onchange: (e) => { p.role = e.target.value; } })), field('Paper', select([['58', '58 mm roll'], ['80', '80 mm roll']], p.paper, { onchange: (e) => { p.paper = e.target.value; } })), field('Copies', input({ type: 'number', min: 1, max: 5, value: p.copies || 1, onchange: (e) => { p.copies = Number(e.target.value) || 1; } }))),
        h('div', { class: 'row' }, toggle(p.auto_kot, (v) => { p.auto_kot = v; }, 'Print kitchen ticket when an order is accepted'), toggle(p.auto_bill, (v) => { p.auto_bill = v; }, 'Print bill when an order is accepted')),
        h('div', { class: 'row' }, p.id ? (() => { const t = h('button', { class: 'btn sm', type: 'button', onclick: () => busy(t, async () => { await post('/api/print/test', { printer_id: p.id }); toast('Test page sent to the helper'); }) }, 'Print a test page'); return t; })() : null,
          h('button', { class: 'btn sm danger', type: 'button', onclick: () => { sync(); list.splice(i, 1); drawList(); } }, 'Remove')), f.name.addEventListener('input', sync), f.conn.addEventListener('input', sync)) ;
    };
    const listBox = h('div', { class: 'stack' });
    const drawList = () => mount(listBox, list.length ? list.map(row) : h('p', { class: 'muted' }, 'No printers yet. Add the printer the counter uses, and one for the kitchen if you have it.'));
    const save = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(save, async () => { await put('/api/print/printers', { printers: list }); toast('Printers saved'); load(); }) }, 'Save printers');
    const a = c.agent;
    const key = h('button', { class: 'btn', type: 'button', onclick: () => busy(key, async () => {
      if (a.has_token && !(await confirmBox('Make a new helper key?', 'The old key stops working. You will need to start the helper again with the new key.', 'Make new key'))) return;
      const r = await post('/api/print/agent-token', {}), cmd = `node print-agent.mjs --server ${location.origin} --key ${r.token}`;
      const m = modal({ title: 'Print helper key', body: h('div', { class: 'stack' }, h('p', {}, 'On the shop PC, with Node installed, run this. Keep this key private; it is shown only once.'), h('pre', { class: 'code' }, cmd), h('button', { class: 'btn', type: 'button', onclick: () => copyText(cmd, 'Command copied') }, 'Copy command'), h('p', { class: 'muted small' }, 'Get print-agent.mjs from the tools folder of your KitFlo download. Leave it running while the shop is open.')), actions: [h('button', { class: 'btn primary', type: 'button', onclick: () => m.close() }, 'Done')], onClose: load });
    }) }, a.has_token ? 'Make a new helper key' : 'Set up the print helper');
    mount(el, h('section', { class: 'card stack' }, h('div', { class: 'row between' }, h('div', {}, h('h3', {}, 'Print helper'), h('p', { class: 'muted small' }, 'A small program on the shop PC prints bills and kitchen tickets without any print window. Without it, printing uses the browser as before.')), badge(a.online ? 'Connected' : a.has_token ? 'Not connected' : 'Not set up', a.online ? 'ok' : 'warn')), h('div', {}, key)),
      listBox, h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: () => { list.push({ name: '', role: 'both', connection: '', paper: '58', copies: 1 }); drawList(); } }, ico('plus', 18), 'Add a printer'), save),
      c.recent.length ? h('section', { class: 'card' }, h('h3', { style: { marginBottom: '6px' } }, 'Recent print jobs'), h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['When', 'What', 'Order', 'Result'].map((x) => h('th', {}, x)))), h('tbody', {}, c.recent.map((j) => h('tr', {}, h('td', { class: 'nowrap' }, dtime(j.created_at)), h('td', {}, j.kind === 'kot' ? 'Kitchen ticket' : 'Bill'), h('td', {}, j.order_id ? `#${j.order_id}` : 'Test'), h('td', {}, j.status === 'done' ? 'Printed' : j.status === 'failed' ? `Failed: ${j.error || ''}` : j.status === 'sent' ? 'Sent to helper' : j.error ? `Waiting. ${j.error}` : 'Waiting'))))))) : null);
    drawList();
  };
  load().catch((e) => mount(el, h('p', { class: 'err' }, e.message)));
  return el;
}

/** Shop devices (hosted): the places staff may sign in with a PIN. */
export function shopDevicesPanel() {
  const el = h('section', { class: 'card stack' });
  const load = async () => {
    const list = (await get('/api/staff-devices')).filter((d) => !d.revoked);
    mount(el, h('div', {}, h('h3', {}, 'Shop devices'), h('p', { class: 'muted small' }, 'Only these devices show your staff list and take a PIN. To add one, sign in on that device with your email and tick “shop device”.')),
      list.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Device', 'Added', 'Last used', ''].map((c) => h('th', {}, c)))), h('tbody', {}, list.map((d) => h('tr', {}, h('td', {}, d.label), h('td', { class: 'nowrap' }, dtime(d.created_at)), h('td', { class: 'nowrap' }, d.last_seen ? dtime(d.last_seen) : '–'), h('td', {}, h('button', { class: 'btn sm danger', type: 'button', onclick: async () => { if (await confirmBox('Remove this device?', 'Staff will no longer be able to sign in on it.', 'Remove', true)) { await del('/api/staff-devices/' + d.id); toast('Device removed'); load(); } } }, 'Remove'))))))) : h('p', { class: 'muted' }, 'No shop devices yet.'));
  };
  load().catch((e) => mount(el, h('p', { class: 'err' }, e.message)));
  return el;
}

/** Backups (self-hosted). */
export function backupsPanel() {
  const el = h('section', { class: 'card stack' });
  const load = async () => {
    const list = await get('/api/admin/backups'), run = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(run, async () => { const r = await post('/api/admin/backups', {}); toast(`Backup ${r.name} saved (${(r.bytes / 1048576).toFixed(1)} MB)`); load(); }) }, 'Back up now');
    mount(el, h('div', {}, h('h3', {}, 'Backups'), h('p', { class: 'muted small' }, 'A copy of everything is made every night at 3 am and the last 7 are kept on this server. Copy them somewhere else too. To restore one, see the README.')), h('div', {}, run),
      list.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['Backup', 'Taken', 'Size'].map((c) => h('th', {}, c)))), h('tbody', {}, list.map((b) => h('tr', {}, h('td', {}, b.name), h('td', { class: 'nowrap' }, dtime(b.at)), h('td', {}, `${(b.bytes / 1048576).toFixed(1)} MB`)))))) : h('p', { class: 'muted' }, 'No backups yet.'));
  };
  load().catch((e) => mount(el, h('p', { class: 'err' }, e.message)));
  return el;
}
