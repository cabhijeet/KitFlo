// Social scheduler: week calendar (drag to reschedule), composer with previews, approval queue, performance.
import { h, mount, ico, S, get, post, patch, del, toast, modal, confirmBox, busy, field, select, seg, inr, num, pct, hhmm, dshort, dlong, dtime, ymd, addDays, toLocalInput, debounce, empty, badge, chip, tip, shrinkImage, ago, sum } from '../core.js';
import { chartCard } from '../charts.js';

const EDITABLE = ['draft', 'pending_approval', 'scheduled', 'failed'];
const STATUS = { draft: 'Draft', pending_approval: 'Needs approval', scheduled: 'Scheduled', publishing: 'Publishing', published: 'Published', failed: 'Failed' };
const SKIND = { draft: '', pending_approval: 'warn', scheduled: 'accent', publishing: 'accent', published: 'good', failed: 'bad' };
const PCOLOR = { Instagram: 'var(--c-zomato)', Facebook: 'var(--c-website)', 'Google Business': 'var(--c-walkin)', 'WhatsApp Status': 'var(--c-whatsapp)' };
const mondayOf = (s) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return ymd(d); };

export default async function social(ctx) {
  const el = h('div', { class: 'page' });
  const platforms = S.config.platforms, simulated = S.config.social_adapter !== 'meta';
  const st = { tab: 'calendar', week: mondayOf(ymd()), posts: [], all: [], menu: [], analytics: null, roi: [], loaded: false, dragId: null };

  async function load() {
    const to = addDays(st.week, 6);
    const [cal, all, menu, an, roi] = await Promise.all([get('/api/social/calendar', { from: st.week, to }), get('/api/social/posts'), get('/api/menu-items'), get('/api/analytics/social'), get('/api/analytics/social/roi')]);
    Object.assign(st, { posts: cal.posts, all, menu, analytics: an, roi, loaded: true }); draw();
  }
  const reload = debounce(() => load().catch(() => {}), 450);
  const pmeta = (p) => p.platforms.map((x) => h('i', { class: 'dot', title: x, style: { background: PCOLOR[x] || 'var(--ink-3)' } }));

  // ───────── calendar ─────────
  function postCard(p) {
    const can_ = EDITABLE.includes(p.status);
    const c = h('article', { class: `post ${p.status}`, draggable: can_ ? 'true' : null, tabindex: 0, role: 'button', 'aria-label': `${p.title}, ${STATUS[p.status]}`, onclick: () => (can_ ? composer(p) : details(p)), onkeydown: (e) => { if (e.key === 'Enter') (can_ ? composer(p) : details(p)); },
      ondragstart: (e) => { st.dragId = p.id; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(p.id)); } },
      p.media ? h('img', { class: 'th', src: p.media, alt: '', loading: 'lazy' }) : null, h('div', { class: 'pt' }, p.title),
      h('div', { class: 'pm' }, hhmm(p.scheduled_at), ...pmeta(p), badge(STATUS[p.status], SKIND[p.status]), p.origin === 'automation' ? badge('Auto', 'accent') : null, p.simulated ? badge('Simulated') : null));
    return c;
  }
  function calendar() {
    const days = Array.from({ length: 7 }, (_, i) => addDays(st.week, i)), today = ymd();
    const nav = h('div', { class: 'row' }, h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Previous week', onclick: () => { st.week = addDays(st.week, -7); load(); } }, ico('chevL')), h('strong', {}, `${dshort(st.week)} to ${dshort(days[6])}`), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Next week', onclick: () => { st.week = addDays(st.week, 7); load(); } }, ico('chevR')), h('button', { class: 'btn sm', type: 'button', onclick: () => { st.week = mondayOf(today); load(); } }, 'This week'));
    const grid = h('div', { class: 'cal' }, days.map((d) => {
      const list = st.posts.filter((p) => ymd(new Date(p.scheduled_at)) === d).sort((a, b) => a.scheduled_at.localeCompare(b.scheduled_at));
      const col = h('section', { class: `day${d === today ? ' today' : ''}`, 'aria-label': dlong(d),
        ondragover: (e) => { if (st.dragId) { e.preventDefault(); col.classList.add('over'); } }, ondragleave: () => col.classList.remove('over'),
        ondrop: async (e) => { e.preventDefault(); col.classList.remove('over'); const id = st.dragId; st.dragId = null; const p = st.posts.find((x) => x.id === id); if (!p || ymd(new Date(p.scheduled_at)) === d) return; const old = new Date(p.scheduled_at), n = new Date(d + 'T00:00:00'); n.setHours(old.getHours(), old.getMinutes(), 0, 0); if (n < new Date()) return toast('Pick a time in the future', 'warn'); try { await patch(`/api/social/posts/${id}`, { scheduled_at: n.toISOString() }); toast(`Moved to ${dlong(d)}`); load(); } catch (x) { toast(x.message, 'bad'); } } },
        h('div', { class: 'dh' }, h('b', {}, dlong(d)), h('button', { class: 'icon-btn', type: 'button', 'aria-label': `New post on ${dlong(d)}`, onclick: () => { const t = new Date(d + 'T19:00:00'); composer(null, t < new Date() ? new Date(Date.now() + 3600000) : t); } }, ico('plus', 16))), list.length ? list.map(postCard) : h('span', { class: 'muted small' }, 'Nothing planned'));
      return col;
    }));
    return h('div', { class: 'stack' }, h('div', { class: 'row between' }, nav, h('button', { class: 'btn primary', type: 'button', onclick: () => composer() }, ico('plus', 18), 'New post')), grid, h('p', { class: 'muted small' }, 'Drag a post to another day to reschedule it. Times stay the same.'));
  }

  // ───────── queue ─────────
  function queue() {
    const waiting = st.all.filter((p) => ['pending_approval', 'draft', 'failed'].includes(p.status)).sort((a, b) => (a.status === 'pending_approval' ? -1 : 1) - (b.status === 'pending_approval' ? -1 : 1));
    if (!waiting.length) return empty('Nothing waiting', 'Drafts, automation suggestions and failed posts show up here.');
    return h('div', { class: 'stack' }, waiting.map((p) => {
      const ok = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(ok, async () => { await post(`/api/social/posts/${p.id}/approve`); toast(`Approved. Scheduled for ${dtime((await get(`/api/social/posts/${p.id}`)).scheduled_at)}`); load(); }) }, 'Approve and schedule');
      const retry = h('button', { class: 'btn primary', type: 'button', onclick: () => busy(retry, async () => { const r = await post(`/api/social/posts/${p.id}/publish-now`); toast(r.status === 'published' ? 'Published' : 'Could not publish yet. It will retry.', r.status === 'published' ? 'info' : 'warn'); load(); }) }, 'Retry now');
      return h('article', { class: `q-item${p.origin === 'automation' ? ' auto' : ''}` }, h('div', { class: 'row between' }, h('div', { class: 'row' }, h('strong', {}, p.title), badge(STATUS[p.status], SKIND[p.status]), p.origin === 'automation' ? badge('From automation', 'accent') : null), h('div', { class: 'row' }, ...pmeta(p), p.scheduled_at ? h('span', { class: 'muted small' }, dtime(p.scheduled_at)) : null)),
        p.trigger_note ? h('div', { class: 'notice info' }, `Why this was suggested: ${p.trigger_note}`) : null, p.error ? h('div', { class: 'notice bad' }, p.error) : null,
        h('p', { style: { whiteSpace: 'pre-wrap' } }, p.caption), p.promo_code ? h('div', { class: 'muted small' }, `Promo code ${p.promo_code}`) : null,
        h('div', { class: 'row' }, p.status === 'failed' ? retry : p.status !== 'scheduled' ? ok : null, h('button', { class: 'btn', type: 'button', onclick: () => composer(p) }, 'Edit'), h('button', { class: 'btn ghost danger-text', type: 'button', onclick: async () => { if (await confirmBox('Dismiss this post?', 'It will be deleted.', 'Delete', true)) { await del(`/api/social/posts/${p.id}`).catch((e) => toast(e.message, 'bad')); load(); } } }, 'Dismiss')));
    }));
  }

  // ───────── performance ─────────
  function performance() {
    const a = st.analytics, posts = a.posts;
    if (!posts.length) return empty('No published posts yet', 'Once posts go out, reach, engagement and orders from promo codes appear here.');
    const reach = sum(posts, (p) => p.reach), eng = sum(posts, (p) => p.likes + p.comments + p.shares), orders = sum(posts, (p) => p.attributed_orders), profit = sum(posts, (p) => p.attributed_profit);
    return h('div', { class: 'stack' }, a.simulated ? h('div', { class: 'notice' }, 'These engagement numbers are simulated. Publishing is not connected to Instagram or Facebook yet. Orders and profit from promo codes are real.') : null,
      h('div', { class: 'tiles' }, tile('Posts published', posts.length, 'all time'), tile('Reach', num(reach, 0), 'people'), tile('Engagement rate', reach ? pct((eng / reach) * 100) : '–', 'likes, comments and shares'), tile('Orders from promo codes', orders, `${inr(profit)} profit after discounts`)),
      h('div', { class: 'grid2' }, chartCard({ title: 'Reach and engagement by platform', draw: (box) => mount(box, h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['Platform', 'Posts', 'Reach', 'Engagement'].map((c, k) => h('th', { class: k ? 'num' : '' }, c)))), h('tbody', {}, a.by_platform.map((x) => h('tr', {}, h('td', {}, h('i', { class: 'dot', style: { background: PCOLOR[x.platform] || 'var(--ink-3)', display: 'inline-block', marginRight: '8px' } }), x.platform), h('td', { class: 'num' }, x.posts), h('td', { class: 'num' }, num(x.reach, 0)), h('td', { class: 'num' }, pct(x.engagement_rate_pct)))))))) }),
        chartCard({ title: 'Posts ranked by profit from promo codes', draw: (box) => mount(box, st.roi.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['Post', 'Orders', 'Profit'].map((c, k) => h('th', { class: k ? 'num' : '' }, c)))), h('tbody', {}, st.roi.map((r) => h('tr', {}, h('td', {}, r.title, h('div', { class: 'muted small' }, `Code ${r.promo_code}`)), h('td', { class: 'num' }, r.orders), h('td', { class: `num ${r.profit < 0 ? 'down' : ''}` }, inr(r.profit))))))) : h('p', { class: 'muted' }, 'Posts with promo codes show here once orders use them.')) })),
      h('section', { class: 'card' }, h('h3', { style: { marginBottom: '10px' } }, 'Every published post'), h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Post', 'Published', 'Reach', 'Engagement rate', 'Clicks', 'Orders', ''].map((c, k) => h('th', { class: k >= 2 && k <= 5 ? 'num' : '' }, c)))),
        h('tbody', {}, posts.map((p) => h('tr', { class: 'click', onclick: () => details(p) }, h('td', {}, h('strong', {}, p.title), h('div', { class: 'row small' }, ...pmeta(p), p.promo_code ? h('span', { class: 'muted' }, p.promo_code) : null)), h('td', {}, dshort(p.published_at)), h('td', { class: 'num' }, num(p.reach, 0)), h('td', { class: 'num' }, pct(p.engagement_rate)), h('td', { class: 'num' }, num(p.clicks, 0)), h('td', { class: 'num' }, p.attributed_orders), h('td', {}, p.winner ? badge('Winner', 'good') : null))))))));
  }
  const tile = (k, v, d) => h('div', { class: 'tile' }, h('span', { class: 'k' }, k), h('span', { class: 'v' }, v), h('span', { class: 'd' }, d));
  function details(p) {
    modal({ title: p.title, body: [h('div', { class: 'row' }, badge(STATUS[p.status], SKIND[p.status]), ...pmeta(p), p.published_at ? h('span', { class: 'muted small' }, `Published ${dtime(p.published_at)}`) : null, p.simulated ? badge('Simulated') : null), p.media ? h('img', { src: p.media, alt: '', style: { maxWidth: '100%', borderRadius: '10px' } }) : null, h('p', { style: { whiteSpace: 'pre-wrap' } }, p.caption),
      p.status === 'published' ? h('div', { class: 'tiles' }, tile('Reach', num(p.reach, 0), `${num(p.impressions, 0)} impressions`), tile('Engagement', pct(p.engagement_rate), `${p.likes} likes · ${p.comments} comments · ${p.shares} shares`), tile('Clicks', num(p.clicks, 0), ''), p.promo_code ? tile('From code ' + p.promo_code, `${p.attributed_orders} orders`, `${inr(p.attributed_revenue)} sales · ${inr(p.attributed_profit)} profit`) : null) : null] });
  }

  // ───────── composer ─────────
  function composer(p, when) {
    const f = { title: h('input', { value: p?.title || '', placeholder: 'Internal name, e.g. Weekend biryani' }), caption: h('textarea', { rows: 6, value: p?.caption || '', placeholder: 'Write your caption…', maxlength: 2200 }), at: h('input', { type: 'datetime-local', value: p?.scheduled_at ? toLocalInput(p.scheduled_at) : when ? toLocalInput(when) : '' }), promo: h('input', { value: p?.promo_code || '', placeholder: 'Optional', style: { textTransform: 'uppercase' } }) };
    let media = p?.media || null, picked = new Set(p?.platforms || ['Instagram', 'Facebook']), previewOn = [...picked][0] || platforms[0], dish = p?.menu_item_id || '';
    const count = h('span', { class: 'muted small' }), previewBox = h('div'), mediaBox = h('div', { class: 'row' }), pbox = h('div', { class: 'row' }), sugg = h('div', { class: 'stack', style: { gap: '6px' } });
    const drawPreview = () => { count.textContent = `${f.caption.value.length} / 2200`; mount(previewBox, h('div', { class: 'row', style: { marginBottom: '6px' } }, seg([...picked].map((x) => [x, x]), previewOn, (v) => { previewOn = v; drawPreview(); })), h('div', { class: 'preview' }, h('div', { class: 'ph' }, h('i', { class: 'dot', style: { background: PCOLOR[previewOn] || 'var(--ink-3)' } }), previewOn || 'Pick a platform'), media ? h('img', { src: media, alt: '' }) : null, h('p', {}, f.caption.value || 'Your caption appears here.'))); if (!picked.size) mount(previewBox, h('p', { class: 'muted small' }, 'Pick at least one platform.')); };
    const drawPlat = () => mount(pbox, platforms.map((x) => { const i = h('input', { type: 'checkbox', checked: picked.has(x), onchange: () => { i.checked ? picked.add(x) : picked.delete(x); if (!picked.has(previewOn)) previewOn = [...picked][0]; drawPreview(); } }); return h('label', { class: 'row small', style: { gap: '6px' } }, i, h('i', { class: 'dot', style: { background: PCOLOR[x] } }), x); }));
    const drawMedia = () => mount(mediaBox, media ? h('img', { class: 'thumb', src: media, alt: 'Attached image' }) : null, h('button', { class: 'btn sm', type: 'button', onclick: () => fileIn.click() }, ico('camera', 16), media ? 'Replace image' : 'Add image'), media ? h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { media = null; drawMedia(); drawPreview(); } }, 'Remove') : null);
    const fileIn = h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async () => { const file = fileIn.files[0]; if (!file) return; try { const r = await post('/api/uploads/media', { data_url: await shrinkImage(file, 1440) }); media = r.url; drawMedia(); drawPreview(); } catch (e) { toast(e.message, 'bad'); } } });
    const dishSel = select([['', 'Choose a dish for caption ideas'], ...st.menu.map((m) => [m.id, m.name])], dish, { onchange: () => { dish = dishSel.value; } });
    const suggest = h('button', { class: 'btn sm', type: 'button', onclick: () => busy(suggest, async () => { const m = st.menu.find((x) => x.id === Number(dish)); const r = await post('/api/social/captions/suggest', { dish: m?.name, price: m ? m.prices.website ?? m.prices.default : undefined, code: f.promo.value }); mount(sugg, h('p', { class: 'muted small' }, r.note), r.options.map((o) => h('button', { class: 'btn', type: 'button', style: { whiteSpace: 'normal', textAlign: 'left', justifyContent: 'flex-start', height: 'auto', padding: '8px 12px' }, onclick: () => { f.caption.value = o; if (m && !f.title.value) f.title.value = m.name; drawPreview(); } }, o))); }) }, 'Suggest captions');
    f.caption.addEventListener('input', drawPreview);
    const body = () => ({ title: f.title.value || f.caption.value.slice(0, 40), caption: f.caption.value, platforms: [...picked], media, promo_code: f.promo.value || undefined, menu_item_id: dish ? Number(dish) : undefined, scheduled_at: f.at.value ? new Date(f.at.value).toISOString() : undefined });
    const save = async (status, btn) => busy(btn, async () => {
      const b = body(); if (status === 'scheduled' && !b.scheduled_at) throw new Error('Pick a date and time to schedule');
      if (status === 'scheduled' && new Date(b.scheduled_at) < new Date(Date.now() - 60000)) throw new Error('That time is in the past. Pick a later time or use Publish now.');
      b.status = status; p ? await patch(`/api/social/posts/${p.id}`, b) : await post('/api/social/posts', b); m.close(); toast(status === 'scheduled' ? `Scheduled for ${dtime(b.scheduled_at)}` : 'Draft saved'); load();
    });
    const draft = h('button', { class: 'btn', type: 'button', onclick: () => save('draft', draft) }, 'Save draft'), sched = h('button', { class: 'btn primary', type: 'button', onclick: () => save('scheduled', sched) }, 'Schedule');
    const now_ = h('button', { class: 'btn', type: 'button', onclick: () => busy(now_, async () => { const b = body(); delete b.scheduled_at; let id = p?.id; if (id) await patch(`/api/social/posts/${id}`, { ...b, status: 'draft' }); else id = (await post('/api/social/posts', { ...b, status: 'draft' })).id; const r = await post(`/api/social/posts/${id}/publish-now`); m.close(); toast(r.status === 'published' ? (r.simulated ? 'Published (simulated: not sent to the platform)' : 'Published') : 'Could not publish. It will retry automatically.', r.status === 'published' ? 'info' : 'warn'); load(); }) }, 'Publish now');
    const rm = p ? h('button', { class: 'btn danger ghost', type: 'button', onclick: async () => { if (await confirmBox('Delete this post?', 'It will not be published.', 'Delete', true)) { await del(`/api/social/posts/${p.id}`).catch((e) => toast(e.message, 'bad')); m.close(); load(); } } }, 'Delete') : null;
    const m = modal({ title: p ? 'Edit post' : 'New post', size: 'lg', body: [simulated ? h('div', { class: 'notice' }, 'Publishing is in simulation mode. Nothing is sent to Instagram or Facebook until Meta credentials are set on the server.') : null,
      h('div', { class: 'neworder' }, h('div', { class: 'stack' }, field('Name', f.title), h('label', { class: 'field' }, h('span', { class: 'lbl' }, 'Caption'), f.caption, count), h('div', { class: 'row' }, dishSel, suggest), sugg, h('div', {}, h('span', { class: 'lbl small', style: { fontWeight: 600 } }, 'Image'), mediaBox, fileIn)),
        h('div', { class: 'stack' }, h('div', {}, h('span', { class: 'lbl small', style: { fontWeight: 600 } }, 'Platforms'), pbox), field('Publish at', f.at, 'IST'), field('Promo code', f.promo, 'Orders using this code are credited to the post'), previewBox))], actions: [rm, h('span', { class: 'grow' }), h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Close'), draft, now_, sched] });
    drawPlat(); drawMedia(); drawPreview();
  }

  function draw() {
    const waiting = st.all.filter((p) => ['pending_approval', 'failed'].includes(p.status)).length;
    mount(el, h('div', { class: 'page-h' }, seg([['calendar', 'Calendar'], ['queue', waiting ? `Queue (${waiting})` : 'Queue'], ['performance', 'Performance']], st.tab, (v) => { st.tab = v; draw(); })),
      simulated && st.tab !== 'performance' ? h('div', { class: 'notice' }, 'Publishing is in simulation mode: posts are marked published but not sent to any platform until Meta credentials are added.') : null,
      st.tab === 'calendar' ? calendar() : st.tab === 'queue' ? queue() : performance());
  }
  await load();
  return { el, onEvent(e) { if (/^(post\.|order\.completed|stream\.open)/.test(e.type)) reload(); } };
}
