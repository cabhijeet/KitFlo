// App shell: sign-in, navigation by role, live profit + link status, notifications, routing.
import { printSettings } from './bill.js';
import { showBusinessLogin, showSignup, showPaywall } from './views/account.js';
import { h, $, mount, clear, ico, S, can, get, post, setSession, connectStream, disconnectStream, onEvent, onLink, onQueue, onAuthLost, onPaywall, toast, beep, systemNotify, inr, debounce, readPref, savePref, flushQueue, queueSize, modal, CH, ApiError } from './core.js';

const VIEWS = [
  { id: 'pos', label: 'Orders', icon: 'receipt', cap: 'orders_create', load: () => import('./views/pos.js') },
  { id: 'kitchen', label: 'Kitchen', icon: 'flame', cap: 'kitchen', load: () => import('./views/kds.js') },
  { id: 'menu', label: 'Menu', icon: 'menu', cap: 'menu_read', load: () => import('./views/menu.js') },
  { id: 'stock', label: 'Stock', short: 'Stock', icon: 'box', cap: 'stock_read', load: () => import('./views/stock.js') },
  { id: 'expenses', label: 'Expenses', icon: 'wallet', cap: 'expenses', load: () => import('./views/expenses.js') },
  { id: 'dayclose', label: 'Day close', short: 'Close', icon: 'lock', cap: 'analytics', load: () => import('./views/dayclose.js') },
  { id: 'social', label: 'Social', icon: 'calendar', cap: 'social', load: () => import('./views/social.js') },
  { id: 'insights', label: 'Insights', icon: 'chart', cap: 'analytics_social', load: () => import('./views/insights.js') },
  { id: 'customers', label: 'Customers', icon: 'users', cap: 'customers', load: () => import('./views/customers.js') },
  { id: 'automations', label: 'Automations', short: 'Auto', icon: 'bolt', cap: 'automations', load: () => import('./views/automations.js') },
  { id: 'settings', label: 'Settings', icon: 'gear', cap: 'settings', load: () => import('./views/settings.js') },
];
const root = $('#root');
let current = null, cleanups = [], deferredInstall = null, shell = null;

// ───────── theme ─────────
const theme = () => readPref('theme', 'auto');
function applyTheme() { const t = theme(); if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t); }
applyTheme();
addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredInstall = e; });
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));

// ───────── sign-in ─────────
const logo = () => h('div', { class: 'logo' }, h('img', { class: 'lg-d', src: '/icons/logo.png', alt: 'KitFlo. Your Kitchen\'s Digital Nerve' }), h('img', { class: 'lg-l', src: '/icons/logo-light.png', alt: '', 'aria-hidden': 'true' }));
let ownerLogin = false;
async function showLogin(message) {
  disconnectStream(); teardown(); document.title = 'Sign in · KitFlo';
  const mode = await get('/api/auth/mode').catch(() => null), hosted = !!mode?.multi_tenant;
  if (hosted && (!readPref('device') || ownerLogin)) { ownerLogin = false; return showBusinessLogin(root, { message, signups: mode.signups, onDone: (t) => { setSession(t); boot(); } }); }
  let users = [];
  try { users = await get('/api/users'); } catch (e) { if (hosted && e.status === 403) { savePref('device', null); return showBusinessLogin(root, { message: 'This device is not approved any more. Sign in with your business email.', signups: mode.signups, onDone: (t) => { setSession(t); boot(); } }); } return showOffline(e); }
  let picked = null, pin = '', busyNow = false;
  const err = h('div', { class: 'err', role: 'alert' }, message || '');
  const dots = h('div', { class: 'pin-dots', 'aria-label': 'PIN digits entered' });
  const box = h('div', { class: 'box' });
  const draw = () => {
    if (!picked) {
      mount(box, h('div', {}, logo(), h('p', { class: 'muted' }, 'Who is signing in?')),
        h('div', { class: 'users' }, users.map((u) => h('button', { type: 'button', onclick: () => { picked = u; pin = ''; err.textContent = ''; draw(); } }, h('strong', {}, u.name), h('small', {}, u.role)))), err,
        hosted ? h('p', { class: 'muted small center' }, h('a', { href: '#', onclick: (e) => { e.preventDefault(); ownerLogin = true; showLogin(); } }, 'Owner sign-in with email')) : null);
    } else {
      mount(dots); for (let i = 0; i < Math.max(4, pin.length); i++) dots.append(h('i', { class: i < pin.length ? 'on' : '' }));
      mount(box, h('div', { class: 'row between' }, h('div', {}, h('h1', {}, picked.name), h('p', { class: 'muted' }, 'Enter your PIN')), h('button', { class: 'btn ghost sm', type: 'button', onclick: () => { picked = null; draw(); } }, 'Change')), dots, err,
        h('div', { class: 'keypad' }, ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', '↵'].map((k) => h('button', { type: 'button', 'aria-label': k === '⌫' ? 'Delete' : k === '↵' ? 'Sign in' : k, onclick: () => key(k) }, k))));
    }
  };
  const key = async (k) => {
    if (busyNow) return; err.textContent = '';
    if (k === '⌫') pin = pin.slice(0, -1);
    else if (k === '↵' || k === 'Enter') { if (pin.length < 4) { err.textContent = 'PINs have 4 to 8 digits'; return; } return submit(); }
    else if (/^\d$/.test(k) && pin.length < 8) pin += k;
    draw();
  };
  const submit = async () => {
    busyNow = true;
    try { const r = await post('/api/login', { user_id: picked.id, pin, device: deviceName() }); setSession(r.token); document.removeEventListener('keydown', onKey); await boot(); }
    catch (e) { pin = ''; err.textContent = e.message; draw(); } finally { busyNow = false; }
  };
  const onKey = (e) => { if (!picked || e.ctrlKey || e.metaKey) return; if (/^\d$/.test(e.key) || e.key === 'Backspace' || e.key === 'Enter') { e.preventDefault(); key(e.key === 'Backspace' ? '⌫' : e.key); } };
  document.addEventListener('keydown', onKey);
  mount(root, h('div', { class: 'login' }, box)); draw();
}
const deviceName = () => { const ua = navigator.userAgent; const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : 'Device'; const br = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : /Firefox\//.test(ua) ? 'Firefox' : 'Browser'; return `${br} on ${os}`; };
function showOffline(e) {
  mount(root, h('div', { class: 'login' }, h('div', { class: 'box' }, h('h1', {}, 'Cannot reach the server'), h('p', { class: 'muted' }, e?.message || 'Check your internet connection. Orders already on screen are safe on the server.'), h('button', { class: 'btn primary', type: 'button', onclick: () => boot() }, 'Try again'))));
}
onAuthLost(() => { setSession(null); showLogin('You were signed out. Sign in again.'); });
onPaywall((d) => { if (d?.code === 'subscription_required' || d?.code === 'suspended' || d?.code === 'cancelled') { disconnectStream(); showPaywall(root, { message: d.error, code: d.code, onRetry: boot, onSignOut: () => signOut() }); } });

// ───────── boot + shell ─────────
async function boot() {
  if (!S.token && location.pathname === '/signup') return showSignup(root, { onDone: (t) => { setSession(t); boot(); } });
  if (!S.token) return showLogin();
  try { const me = await get('/api/me'); S.billing = me.billing || null; S.hosted = !!me.hosted;
    if (me.billing && !me.billing.ok) return showPaywall(root, { message: me.billing.message, code: me.billing.code, onRetry: boot, onSignOut: () => signOut() });
    S.user = me.user; S.caps = me.caps; S.config = me.config; S.outlet = me.outlet; S.outlets = me.outlets || []; }
  catch (e) { if (e instanceof ApiError && e.offline) return showOffline(e); return showLogin(); }
  buildShell(); connectStream(); flushQueue(); route();
  const pollPrint = () => get('/api/print/status').then((p) => { S.print = p; }).catch(() => { S.print = null; }); pollPrint(); const pt = setInterval(() => (S.user ? pollPrint() : clearInterval(pt)), 20000);
  refreshProfit(); refreshBadges();
}
const allowed = () => VIEWS.filter((v) => can(v.cap));
const homeFor = () => (S.user.role === 'kitchen' ? 'kitchen' : S.user.role === 'marketer' ? 'social' : 'pos');

let profitPill, linkPill, queuePill, navEl, titleEl, userMenu;
function buildShell() {
  navEl = h('nav', { class: 'nav', 'aria-label': 'Main' }, h('div', { class: 'brand' }, h('div', { class: 'mark' }, ico('flame', 18)), h('span', { class: 'name' }, S.config.business?.name || 'Kitchen')),
    allowed().map((v) => h('a', { class: 'item', href: '#/' + v.id, dataset: { id: v.id } }, ico(v.icon, 20), h('span', {}, v.short || v.label), v.id === 'pos' ? h('span', { class: 'dotc', hidden: true, id: 'badge-pos' }, '0') : null)));
  titleEl = h('h1', {}, '');
  profitPill = h('span', { class: 'pill profit', hidden: !can('analytics'), title: 'Net profit today: sales minus commission, food cost, wastage and expenses' }, '');
  linkPill = h('span', { class: 'pill' }, h('i', { class: 'live' }), h('span', {}, 'Live'));
  queuePill = h('span', { class: 'pill', hidden: true }, '');
  const bl = S.billing, billShow = !!bl && can('settings') && (bl.state === 'trial' || bl.state === 'past_due' || bl.renew_soon);
  const billPill = h('button', { class: 'pill warn', type: 'button', hidden: !billShow, title: bl?.message || '', onclick: () => { savePref('set_tab', 'billing'); location.hash = '#/settings'; route(); } }, bl?.state === 'trial' ? `Trial: ${bl.days_left} day${bl.days_left === 1 ? '' : 's'} left` : bl?.state === 'past_due' ? 'Payment due' : 'Renews soon');
  const outletBtn = S.outlets.length > 1 ? h('button', { class: 'pill outlet', type: 'button', title: 'Switch outlet', onclick: (e) => { e.stopPropagation(); pickOutlet(); } }, ico('menu', 16), h('span', {}, S.outlet?.name || 'Outlet')) : null;
  const userBtn = h('button', { class: 'pill', type: 'button', 'aria-haspopup': 'menu', onclick: (e) => { e.stopPropagation(); toggleMenu(); } }, ico('user', 16), h('span', { class: 'hide-m' }, S.user.name));
  shell = h('div', { class: 'shell' }, navEl, h('div', { class: 'main' }, h('header', { class: 'top' }, titleEl, h('span', { class: 'grow' }), outletBtn, billPill, profitPill, queuePill, linkPill, userBtn), h('main', { id: 'view', tabindex: '-1' })));
  mount(root, shell);
  onLink((ok) => { linkPill.classList.toggle('off', !ok); mount(linkPill, h('i', { class: 'live' }), h('span', {}, ok ? 'Live' : 'Reconnecting')); if (ok) { refreshProfit(); refreshBadges(); current?.view.onEvent?.({ type: 'stream.open', payload: {} }); } });
  onQueue((n) => { queuePill.hidden = !n; queuePill.textContent = `${n} waiting to send`; });
  document.addEventListener('click', () => userMenu && userMenu.remove());
}
function toggleMenu() {
  if (userMenu && userMenu.isConnected) return userMenu.remove();
  const t = theme(), item = (label, right, fn) => h('button', { type: 'button', role: 'menuitem', onclick: (e) => { e.stopPropagation(); fn(e); } }, h('span', {}, label), h('span', { class: 'muted small' }, right || ''));
  userMenu = h('div', { class: 'menu', role: 'menu' }, h('div', { class: 'who' }, h('strong', {}, S.user.name), h('div', { class: 'muted small', style: { textTransform: 'capitalize' } }, S.user.role)),
    item('Appearance', t === 'auto' ? 'Automatic' : t === 'light' ? 'Light' : 'Dark', () => { savePref('theme', t === 'auto' ? 'light' : t === 'light' ? 'dark' : 'auto'); applyTheme(); userMenu.remove(); }),
    item('Bill printing', 'Paper and size', () => { userMenu.remove(); printSettings(); }),
    item('Sound for new orders', readPref('sound', true) ? 'On' : 'Off', () => { savePref('sound', !readPref('sound', true)); beep('order'); userMenu.remove(); }),
    item('Alerts when app is in background', readPref('alerts', false) ? 'On' : 'Off', async () => {
      userMenu.remove(); if (readPref('alerts', false)) { savePref('alerts', false); return toast('Background alerts are off'); }
      if (!('Notification' in window)) return toast('This browser does not support alerts', 'warn');
      const p = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
      if (p === 'granted') { savePref('alerts', true); toast('Alerts on. You will get a notification for new orders while this app is open in the background.'); } else toast('Alerts are blocked in this browser’s settings', 'warn');
    }),
    deferredInstall ? item('Install on this device', '', async () => { userMenu.remove(); deferredInstall.prompt(); deferredInstall = null; }) : null,
    item('Switch user', '', () => signOut(false)), item('Sign out', '', () => signOut(true)));
  shell.append(userMenu);
}
/** Pick which outlet this device works in. Each outlet has its own menu, orders, customers and stock. */
function pickOutlet() {
  if (queueSize()) return toast(`${queueSize()} saved action${queueSize() === 1 ? ' is' : 's are'} still waiting to send. Wait until they are sent before switching outlet.`, 'warn', 7000);
  const m = modal({ title: 'Switch outlet', size: 'sm', body: h('div', { class: 'stack' }, S.outlets.map((o) => h('button', { class: `btn block${o.id === S.outlet?.id ? ' primary' : ''}`, type: 'button', style: { justifyContent: 'space-between' }, onclick: async () => {
    if (o.id === S.outlet?.id) return m.close();
    try { await post('/api/outlets/switch', { outlet_id: o.id }); location.hash = '#/' + homeFor(); location.reload(); } catch (e) { toast(e.message, 'bad'); }
  } }, h('strong', {}, o.name), h('span', { class: 'small' }, o.city || '')))), actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Close')] });
}
async function signOut(full) { userMenu?.remove(); try { await post('/api/logout'); } catch { /* already gone */ } setSession(null); S.user = null; showLogin(); }

// ───────── live numbers ─────────
const refreshProfit = debounce(async () => {
  if (!can('analytics') || !profitPill) return;
  try { const p = await get('/api/analytics/profit/live'); const n = p.today.net; profitPill.className = 'pill profit ' + (n >= 0 ? 'up' : 'down'); profitPill.textContent = `Today net ${inr(n)}`; } catch { /* shown on next event */ }
}, 700);
const refreshBadges = debounce(async () => {
  if (!can('orders_create')) return;
  try { const o = await get('/api/orders'); const n = o.filter((x) => x.status === 'new').length; const b = $('#badge-pos'); if (b) { b.hidden = !n; b.textContent = n; } } catch { /* ignore */ }
}, 600);

onEvent((e) => {
  const p = e.payload || {};
  if (e.type === 'order.received' && can('orders')) {
    beep('order'); toast(`New ${CH[p.channel] || ''} order #${p.order_no}`, 'info'); systemNotify('New order', `#${p.order_no} on ${CH[p.channel] || p.channel}. ${inr(p.total)}`);
  } else if (e.type === 'notice') { toast(p.text, p.level === 'bad' ? 'bad' : p.level === 'warn' ? 'warn' : 'info', 7000); if (p.level === 'bad') beep('bad'); systemNotify('KitFlo', p.text); }
  else if (e.type === 'post.drafted' && p.needs_approval && can('social')) toast(`Post "${p.title}" is waiting for your approval`, 'info', 7000);
  else if (e.type === 'post.failed' && can('social')) toast(`Post "${p.title}" failed to publish`, 'bad', 8000);
  else if (e.type === 'settings.updated') get('/api/me').then((me) => { S.config = me.config; }).catch(() => {});
  if (/^(order\.|expense\.|stock\.|profit\.)/.test(e.type)) refreshProfit();
  if (e.type.startsWith('order.')) refreshBadges();
  current?.view.onEvent?.(e);
});

// ───────── routing ─────────
function teardown() { cleanups.forEach((f) => { try { f(); } catch { /* ignore */ } }); cleanups = []; if (current?.view.destroy) try { current.view.destroy(); } catch { /* ignore */ } current = null; }
let token = 0;
async function route() {
  if (!S.user) return;
  const id = (location.hash.match(/^#\/(\w+)/) || [])[1];
  let v = allowed().find((x) => x.id === id);
  if (!v) { v = allowed().find((x) => x.id === homeFor()) || allowed()[0]; if (!v) return; if (id !== v.id) { history.replaceState(null, '', '#/' + v.id); } }
  const mine = ++token;
  teardown();
  navEl.querySelectorAll('a.item').forEach((a) => (a.getAttribute('data-id') === v.id ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
  titleEl.textContent = v.label; document.title = `${v.label} · ${S.config.business?.name || 'KitFlo'}`;
  const host = $('#view'); mount(host, h('div', { class: 'page' }, h('div', { class: 'skeleton' }, h('i'), h('i'), h('i'))));
  try {
    const mod = await v.load(); if (mine !== token) return;
    const ctx = { user: S.user, can, config: S.config, every: (ms, fn) => { const t = setInterval(fn, ms); cleanups.push(() => clearInterval(t)); return t; }, later: (fn) => cleanups.push(fn), go: (x) => { location.hash = '#/' + x; }, setTitle: (t) => { titleEl.textContent = t; } };
    const view = await mod.default(ctx); if (mine !== token) return;
    current = { id: v.id, view }; mount(host, view.el); host.focus({ preventScroll: true });
  } catch (e) { if (mine === token) mount(host, h('div', { class: 'page' }, h('div', { class: 'empty' }, h('strong', {}, 'This screen did not load'), h('p', {}, e.message), h('button', { class: 'btn', onclick: route }, 'Try again')))); }
}
addEventListener('hashchange', route);
document.addEventListener('fullscreenchange', () => document.body.classList.toggle('fs', !!document.fullscreenElement));
boot();
