// Public ordering page: menu, cart, checkout (pay on delivery), and order tracking. No sign-in.
import { h, mount, ico, inr, inr2, hhmm, toast, busy, field, select, readPref, savePref, minsSince, qtyFmt, empty, groupMenu, foodImg } from './core.js';

import { pickAddons, groupsFor, lineKey } from './addons.js';

const root = document.getElementById('root');
const STEPS = [['new', 'Received'], ['accepted', 'Accepted'], ['preparing', 'Cooking'], ['ready', 'Ready'], ['completed', 'Delivered']];
const cart = new Map(); let addonGs = [], paused = [], menu = null, business = 'Kitchen', cat = 'All', tracked = readPref('track', null), timer = null;

let outletSlug = new URLSearchParams(location.search).get('outlet') || '';
const bizKey = new URLSearchParams(location.search).get('k') || '';
async function api(path, opts) {
  const extra = [outletSlug && 'outlet=' + encodeURIComponent(outletSlug), bizKey && 'k=' + encodeURIComponent(bizKey)].filter(Boolean).join('&'), res = await fetch(extra ? path + (path.includes('?') ? '&' : '?') + extra : path, opts), data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}
const total = () => [...cart.values()].reduce((s, l) => s + l.q * (l.m.price + l.extra), 0);
const count = () => [...cart.values()].reduce((a, l) => a + l.q, 0);
const bump = (key, by) => { const l = cart.get(key); if (!l) return; l.q + by <= 0 ? cart.delete(key) : cart.set(key, { ...l, q: l.q + by }); draw(); };
const addDish = (m) => {
  const put = (o) => { const key = lineKey(m.id, o.picks), l = cart.get(key); l ? cart.set(key, { ...l, q: l.q + 1 }) : cart.set(key, { m, picks: o.picks, text: o.text, extra: o.extra, q: 1 }); draw(); };
  if (groupsFor(m, addonGs).length) pickAddons({ dish: { ...m, display_name: m.variant_name ? `${m.name} · ${m.variant_name}` : m.name }, groups: addonGs, basePrice: m.price }, put); else put({ picks: [], text: '', extra: 0 });
};
const inCart = (m) => [...cart.values()].filter((l) => l.m.id === m.id).reduce((a, l) => a + l.q, 0);

function draw() {
  const cats = ['All', ...new Set(menu.map((m) => m.category).filter(Boolean))];
  const list = menu.filter((m) => cat === 'All' || m.category === cat);
  const catBar = h('div', { class: 'seg' }, cats.map((c) => h('button', { type: 'button', class: c === cat ? 'on' : '', onclick: () => { cat = c; draw(); } }, c)));
  const label = (m) => (m.variant_name ? `${m.name} · ${m.variant_name}` : m.name);
  const stepper = (m) => { const q = inCart(m), custom = groupsFor(m, addonGs).length > 0, key = lineKey(m.id, []);
    if (custom || !q) return h('span', { class: 'row', style: { gap: '8px' } }, q ? h('span', { class: 'muted small' }, `${q} in order`) : null, h('button', { class: 'btn sm', type: 'button', 'aria-label': `Add ${label(m)}`, onclick: () => addDish(m) }, custom ? 'Choose' : 'Add'));
    return h('span', { class: 'step' }, h('button', { type: 'button', 'aria-label': `Remove one ${label(m)}`, onclick: () => bump(key, -1) }, '−'), h('span', {}, q), h('button', { type: 'button', 'aria-label': `Add one ${label(m)}`, onclick: () => bump(key, 1) }, '+')); };
  const items = list.length ? groupMenu(list).map((g) => { const many = g.variants.length > 1;
    return h('div', { class: 'menu-item' }, g.image_url ? foodImg(g.image_url, 'mi-img', g.name) : null,
      h('div', { class: 'mi-body' }, h('b', {}, g.name), g.description ? h('span', { class: 'mi-desc' }, g.description) : null,
        many ? h('div', { class: 'sizes' }, g.variants.map((v) => h('div', { class: 'size-row' }, h('span', { class: 'sn' }, v.variant_name), h('span', { class: 'row' }, h('strong', {}, inr(v.price)), stepper(v)))))
          : h('div', { class: 'size-row' }, h('strong', {}, inr(g.variants[0].price)), stepper(g.variants[0]))));
  }) : [empty('Nothing available right now', 'Please check back soon.')];
  const lines = [...cart].map(([key, l]) => ({ ...l, key }));
  const cartCard = h('aside', { class: 'card stack', style: { position: 'sticky', top: '12px' } }, h('h2', {}, 'Your order'), lines.length ? lines.map((l) => h('div', { class: 'stack', style: { gap: '4px' } }, h('div', { class: 'row between' }, h('span', {}, `${l.q} × ${label(l.m)}`), h('span', {}, inr((l.m.price + l.extra) * l.q))), l.text ? h('span', { class: 'addon-line' }, '+ ' + l.text) : null, h('span', { class: 'step', style: { alignSelf: 'flex-start' } }, h('button', { type: 'button', 'aria-label': 'Remove one', onclick: () => bump(l.key, -1) }, '−'), h('span', {}, l.q), h('button', { type: 'button', 'aria-label': 'Add one', onclick: () => bump(l.key, 1) }, '+')))) : h('p', { class: 'muted' }, 'Add dishes to start your order.'),
    h('div', { class: 'row between' }, h('strong', {}, 'Subtotal'), h('strong', {}, inr(total()))), h('p', { class: 'muted small' }, 'GST and a small packaging fee are added when you place the order. You pay on delivery.'), h('button', { class: 'btn primary lg block', type: 'button', disabled: !count(), onclick: checkout }, count() ? `Checkout · ${inr(total())}` : 'Checkout'));
  mount(root, h('div', { class: 'shop' }, h('header', {}, h('div', {}, h('h1', {}, business), h('p', { class: 'muted' }, 'Fresh food, delivered')), tracked ? h('button', { class: 'btn', type: 'button', onclick: showTrack }, 'Track my order') : h('button', { class: 'btn', type: 'button', onclick: askTrack }, 'Track an order')), h('div', { class: 'shop-grid' }, h('div', { class: 'stack' }, paused.length ? h('div', { class: 'notice' }, `Not taking orders right now for: ${paused.join(', ')}. Please check back soon.`) : null, catBar, h('div', { class: 'menu-list' }, items)), cartCard)));
}

function checkout() {
  const saved = readPref('cust', {}), f = { name: h('input', { value: saved.name || '', autocomplete: 'name', required: true }), phone: h('input', { type: 'tel', inputmode: 'numeric', value: saved.phone || '', autocomplete: 'tel', placeholder: '10-digit mobile number', required: true }), addr: h('textarea', { rows: 3, value: saved.addr || '', autocomplete: 'street-address', placeholder: 'House or flat number, street, landmark' }), note: h('input', { placeholder: 'Special instructions (optional)' }), promo: h('input', { placeholder: 'Promo code (optional)', style: { textTransform: 'uppercase' } }) };
  const err = h('div', { class: 'err', role: 'alert' });
  const go = h('button', { class: 'btn primary lg block', type: 'button', onclick: () => busy(go, async () => {
    err.textContent = '';
    try {
      const r = await api('/api/public/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID?.() || String(Date.now()) }, body: JSON.stringify({ customer: { name: f.name.value, phone: f.phone.value }, address: f.addr.value, notes: f.note.value, promo_code: f.promo.value, items: [...cart.values()].map((l) => ({ menu_item_id: l.m.id, qty: l.q, addons: l.picks.length ? l.picks : undefined })) }) });
      savePref('cust', { name: f.name.value, phone: f.phone.value, addr: f.addr.value }); tracked = { order_no: r.order_no, phone: f.phone.value }; savePref('track', tracked); cart.clear(); (r.warnings || []).forEach((w) => toast(w, 'warn')); done(r);
    } catch (e) { err.textContent = e.message; throw e; }
  }) }, 'Place order');
  mount(root, h('div', { class: 'shop' }, h('header', {}, h('h1', {}, 'Checkout'), h('button', { class: 'btn', type: 'button', onclick: draw }, 'Back to menu')), h('section', { class: 'card stack', style: { maxWidth: '560px' } }, field('Your name', f.name), field('Mobile number', f.phone, 'We use this to confirm and track your order'), field('Delivery address', f.addr), field('Instructions', f.note), field('Promo code', f.promo), h('div', { class: 'row between' }, h('strong', {}, 'Subtotal'), h('strong', {}, inr(total()))), h('p', { class: 'muted small' }, 'Pay on delivery (cash or UPI). GST and packaging are added to your final total.'), err, go)));
}
function done(r) {
  mount(root, h('div', { class: 'shop' }, h('section', { class: 'card stack', style: { maxWidth: '560px' } }, h('h1', {}, 'Order placed'), h('p', {}, `Your order number is `, h('strong', {}, `#${r.order_no}`), `. Total to pay on delivery: `, h('strong', {}, inr2(r.total)), r.discount ? ` (includes ${inr2(r.discount)} off)` : '', '.'), h('button', { class: 'btn primary', type: 'button', onclick: showTrack }, 'Track my order'), h('button', { class: 'btn', type: 'button', onclick: draw }, 'Order something else'))));
}
function askTrack() {
  const n = h('input', { type: 'number', inputmode: 'numeric', placeholder: 'Order number, e.g. 1042' }), p = h('input', { type: 'tel', inputmode: 'numeric', placeholder: 'Mobile number used for the order' }), err = h('div', { class: 'err' });
  const go = h('button', { class: 'btn primary', type: 'button', onclick: () => { tracked = { order_no: Number(n.value), phone: p.value }; savePref('track', tracked); showTrack(); } }, 'Track');
  mount(root, h('div', { class: 'shop' }, h('header', {}, h('h1', {}, 'Track an order'), h('button', { class: 'btn', type: 'button', onclick: draw }, 'Back to menu')), h('section', { class: 'card stack', style: { maxWidth: '460px' } }, field('Order number', n), field('Mobile number', p), err, go)));
}
async function showTrack() {
  clearInterval(timer);
  const box = h('section', { class: 'card tracker', style: { maxWidth: '560px' } }), back = h('button', { class: 'btn', type: 'button', onclick: () => { clearInterval(timer); draw(); } }, 'Back to menu');
  mount(root, h('div', { class: 'shop' }, h('header', {}, h('h1', {}, 'Your order'), back), box));
  const load = async () => {
    try {
      const r = await api(`/api/public/track?order_no=${tracked.order_no}&phone=${encodeURIComponent(tracked.phone)}`), idx = STEPS.findIndex((s) => s[0] === r.status);
      mount(box, h('h2', {}, `Order #${r.order_no}`), r.status === 'cancelled' ? h('div', { class: 'notice bad' }, 'This order was cancelled. Please call us if you were charged.') : [h('div', { class: 'steps', 'aria-hidden': 'true' }, STEPS.map((s, i) => h('i', { class: i <= idx ? 'on' : '' }))), h('p', {}, h('strong', {}, STEPS[idx]?.[1] || r.status), h('span', { class: 'muted' }, ` · placed ${hhmm(r.placed_at)}, ${minsSince(r.placed_at)} min ago`))], h('p', { class: 'muted' }, `Total ${inr2(r.total)}, pay on delivery`));
      if (r.status === 'completed' || r.status === 'cancelled') clearInterval(timer);
    } catch (e) { clearInterval(timer); mount(box, h('h2', {}, 'We could not find that order'), h('p', { class: 'muted' }, e.message), h('button', { class: 'btn', type: 'button', onclick: askTrack }, 'Try another number')); }
  };
  await load(); timer = setInterval(load, 20000);
}

(async () => {
  try {
    if (!outletSlug) {
      const list = await api('/api/public/outlets');
      if (list.length > 1) {
        document.title = 'Choose a kitchen';
        return mount(root, h('div', { class: 'shop' }, h('div', { class: 'box', style: { margin: '40px auto', maxWidth: '420px' } }, h('h2', {}, 'Which kitchen are you ordering from?'),
          h('div', { class: 'stack', style: { marginTop: '12px' } }, list.map((o) => h('a', { class: 'btn block', href: `/order?outlet=${encodeURIComponent(o.slug)}${bizKey ? '&k=' + encodeURIComponent(bizKey) : ''}`, style: { justifyContent: 'space-between' } }, h('strong', {}, o.name), h('span', { class: 'small' }, o.city || '')))))));
      }
    }
    const r = await api('/api/public/menu'); menu = r.items; addonGs = r.addon_groups || []; paused = r.paused || []; business = r.business || business; document.title = `Order from ${business}`; draw(); }
  catch (e) { mount(root, h('div', { class: 'shop' }, empty('The menu could not load', e.message, h('button', { class: 'btn', onclick: () => location.reload() }, 'Try again')))); }
})();
