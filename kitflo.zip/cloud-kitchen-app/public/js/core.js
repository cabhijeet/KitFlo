// Core toolkit shared by every screen: DOM helper, API client with offline queue, live stream, modals, formatting.
// No framework and no inline scripts (the server's Content-Security-Policy allows scripts from this origin only).

// ───────────────────────── DOM ─────────────────────────
const SETLATE = new Set(['value', 'checked', 'selected', 'disabled', 'indeterminate']);
export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  const late = [];
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith('--')) el.style.setProperty(sk, sv); else el.style[sk] = sv; } }
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (SETLATE.has(k)) late.push([k, v]);
    else el.setAttribute(k, v === true ? '' : v);
  }
  add(el, kids);
  for (const [k, v] of late) el[k] = v;
  return el;
}
function add(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
export const mount = (el, ...kids) => { clear(el); add(el, kids); return el; };

const ICONS = {
  menu: 'M4 6h16M4 12h16M4 18h10',
  receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6',
  flame: 'M12 3c1 3 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z',
  box: 'M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10',
  wallet: 'M4 7h15a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1zM4 7l2-3h11l1 3M16 14h2',
  lock: 'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',
  calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  chart: 'M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6',
  users: 'M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20a6 6 0 0 1 12 0M16 11a2.5 2.5 0 1 0 0-5M17 20a5 5 0 0 0-3-4.5',
  bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14 3h-4l-.6 2.6a7 7 0 0 0-2 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2 1.2L10 21h4l.6-2.6a7 7 0 0 0 2-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z',
  plus: 'M12 5v14M5 12h14', x: 'M6 6l12 12M18 6L6 18', check: 'M5 12l4 4 10-10', minus: 'M5 12h14',
  search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  bell: 'M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 21h4',
  print: 'M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z',
  trash: 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13',
  edit: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4',
  chat: 'M4 5h16v11H9l-5 4z',
  camera: 'M4 8h4l2-3h4l2 3h4v11H4zM12 17a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z',
  copy: 'M9 9h11v11H9zM5 15V4h11',
  alert: 'M12 4l9 16H3zM12 10v4M12 17v.5',
  sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5',
  chevL: 'M15 5l-7 7 7 7', chevR: 'M9 5l7 7-7 7', clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2',
  refresh: 'M20 11a8 8 0 0 0-14-4M4 4v4h4M4 13a8 8 0 0 0 14 4M20 20v-4h-4',
  logout: 'M10 4H5v16h5M15 8l4 4-4 4M19 12H9',
};
export function ico(name, size = 20) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.8');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round'); s.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', ICONS[name] || ICONS.box); s.append(p);
  return s;
}

// ───────────────────────── formatting ─────────────────────────
const IN0 = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });
const IN2 = new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const inr = (n) => { const v = Math.round(Number(n) || 0); return (v < 0 ? '−' : '') + '₹' + IN0.format(Math.abs(v)); };
export const inr2 = (n) => { const v = Number(n) || 0; return (v < 0 ? '−' : '') + '₹' + IN2.format(Math.abs(v)); };
export const num = (n, d = 1) => new Intl.NumberFormat('en-IN', { maximumFractionDigits: d }).format(Number(n) || 0);
export const pct = (n) => (n === null || n === undefined ? '–' : num(n, 1) + '%');
export const hhmm = (iso) => (iso ? new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' }) : '–');
export const dshort = (s) => new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? s + 'T00:00:00' : s).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
export const dlong = (s) => new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? s + 'T00:00:00' : s).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
export const dtime = (iso) => (iso ? `${dshort(iso)}, ${hhmm(iso)}` : '–');
const p2 = (n) => String(n).padStart(2, '0');
export const ymd = (d = new Date()) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
export const addDays = (s, n) => { const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? s + 'T00:00:00' : s); d.setDate(d.getDate() + n); return ymd(d); };
export const toLocalInput = (iso) => { const d = new Date(iso); return `${ymd(d)}T${p2(d.getHours())}:${p2(d.getMinutes())}`; };
export const minsSince = (iso) => Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
export const ago = (iso) => { const m = minsSince(iso); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.floor(m / 60)} h ago` : `${Math.floor(m / 1440)} d ago`; };
export const qtyFmt = (n) => num(n, 3);

export const CH = { swiggy: 'Swiggy', zomato: 'Zomato', website: 'Website', whatsapp: 'WhatsApp', walkin: 'Walk-in' };
export const chip = (ch) => h('span', { class: `chip ch ch-${ch}` }, CH[ch] || ch);
export const STATUS = { new: 'New', accepted: 'Accepted', preparing: 'Preparing', ready: 'Ready', completed: 'Completed', cancelled: 'Cancelled' };
export const SRC = { manual: 'Manual', stock_purchase: 'From stock', recurring: 'Recurring' };

export const debounce = (fn, ms = 400) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export const uid = () => (globalThis.crypto?.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));
export const sum = (a, f = (x) => x) => a.reduce((s, x) => s + (Number(f(x)) || 0), 0);
export const readPref = (k, d = null) => { try { const v = localStorage.getItem('ck_' + k); return v === null ? d : JSON.parse(v); } catch { return d; } };
export const savePref = (k, v) => { try { localStorage.setItem('ck_' + k, JSON.stringify(v)); } catch { /* private mode */ } };

// ───────────────────────── session + API ─────────────────────────
export const S = { token: readPref('token'), user: null, caps: [], config: {}, online: true, outlet: null, outlets: [] };
export const can = (cap) => S.caps.includes(cap);
export function setSession(token) { S.token = token; savePref('token', token); }

export class ApiError extends Error { constructor(msg, status, offline = false) { super(msg); this.status = status; this.offline = offline; } }
const authLost = new Set(), payFns = new Set();
/** Called when the server says the plan or trial has ended (HTTP 402). */
export const onPaywall = (fn) => { payFns.add(fn); return () => payFns.delete(fn); };
export const onAuthLost = (fn) => { authLost.add(fn); return () => authLost.delete(fn); };

async function raw(method, path, body, key) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}), ...(readPref('device') ? { 'X-Device': readPref('device') } : {}), ...(key ? { 'Idempotency-Key': key } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch { throw new ApiError('No connection to the server', 0, true); }
  const text = await res.text();
  let data = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (res.status === 401 && S.token && !path.startsWith('/api/login')) { authLost.forEach((f) => f()); }
  if (res.status === 402) payFns.forEach((f) => f(data));
  if (!res.ok) throw Object.assign(new ApiError((data && data.error) || `Request failed (${res.status})`, res.status), { code: data && data.code });
  return data;
}
const qs = (o) => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o || {})) if (v !== undefined && v !== null && v !== '') p.set(k, v); const s = p.toString(); return s ? '?' + s : ''; };
export const get = (path, params) => raw('GET', path + qs(params));
export const post = (path, body = {}) => raw('POST', path, body, uid());
export const patch = (path, body = {}) => raw('PATCH', path, body, uid());
export const put = (path, body = {}) => raw('PUT', path, body, uid());
export const del = (path) => raw('DELETE', path);

// Writes that must survive a dropped connection (status taps, walk-in orders, expenses). Sent later with the same
// Idempotency-Key, so a retry can never create a second order or a second expense.
const QK = 'ck_queue';
const readQ = () => { try { return JSON.parse(localStorage.getItem(QK) || '[]'); } catch { return []; } };
const writeQ = (q) => { try { localStorage.setItem(QK, JSON.stringify(q)); } catch { /* full */ } queueListeners.forEach((f) => f(q.length)); };
const queueListeners = new Set();
export const queueSize = () => readQ().length;
export const onQueue = (fn) => { queueListeners.add(fn); fn(readQ().length); return () => queueListeners.delete(fn); };
export async function send(method, path, body, { queue = true } = {}) {
  const key = uid();
  try { return await raw(method, path, body, key); }
  catch (e) {
    if (e.offline && queue) { writeQ([...readQ(), { key, method, path, body, at: Date.now() }]); toast('No connection. Saved on this device and will send when you are back online.', 'warn'); return { queued: true }; }
    throw e;
  }
}
let flushing = false;
export async function flushQueue() {
  if (flushing) return; flushing = true;
  try {
    let q = readQ();
    while (q.length) {
      const it = q[0];
      try { await raw(it.method, it.path, it.body, it.key); }
      catch (e) { if (e.offline) break; /* server rejected it: drop it so the queue cannot jam */ if (e.status !== 401) toast(`A saved action was not accepted: ${e.message}`, 'bad'); }
      q = readQ().slice(1); writeQ(q);
    }
  } finally { flushing = false; }
}

// ───────────────────────── live stream ─────────────────────────
const evListeners = new Set(), statusListeners = new Set();
export const onEvent = (fn) => { evListeners.add(fn); return () => evListeners.delete(fn); };
export const onLink = (fn) => { statusListeners.add(fn); fn(S.online); return () => statusListeners.delete(fn); };
let es = null;
export function connectStream() {
  disconnectStream();
  if (!S.token) return;
  es = new EventSource('/api/stream?token=' + encodeURIComponent(S.token));
  const set = (v) => { if (S.online !== v) { S.online = v; statusListeners.forEach((f) => f(v)); if (v) flushQueue(); } };
  es.addEventListener('hello', () => { set(true); evListeners.forEach((f) => f({ type: 'stream.open', payload: {} })); });
  es.addEventListener('msg', (m) => { let e; try { e = JSON.parse(m.data); } catch { return; } evListeners.forEach((f) => f(e)); });
  es.onerror = () => set(false);
}
export function disconnectStream() { if (es) { es.close(); es = null; } }
addEventListener('online', () => { flushQueue(); if (S.token && (!es || es.readyState === 2)) connectStream(); });

// ───────────────────────── sound + alerts ─────────────────────────
let actx;
export function beep(kind = 'order') {
  if (!readPref('sound', true)) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const notes = kind === 'order' ? [880, 1175] : kind === 'bad' ? [330, 247] : [660];
    notes.forEach((f, i) => { const o = actx.createOscillator(), g = actx.createGain(); o.frequency.value = f; o.connect(g); g.connect(actx.destination); const t = actx.currentTime + i * 0.16; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.2, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18); o.start(t); o.stop(t + 0.2); });
  } catch { /* audio blocked until the first tap */ }
}
export function systemNotify(title, body) {
  if (!readPref('alerts', false) || !document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
  navigator.serviceWorker?.ready.then((r) => r.showNotification(title, { body, icon: '/icons/icon-192.png', tag: 'ck' })).catch(() => { try { new Notification(title, { body }); } catch { /* unsupported */ } });
}

// ───────────────────────── toast, modal, tooltip ─────────────────────────
export function toast(text, level = 'info', ms = 4500) {
  let box = $('#toasts'); if (!box) { box = h('div', { id: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(box); }
  const t = h('div', { class: `toast ${level}` }, text);
  box.append(t); setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 250); }, ms);
}
export function modal({ title, body, actions = [], size = 'md', side = false, onClose }) {
  const dlg = h('dialog', { class: `modal ${size}${side ? ' side' : ''}` });
  const content = h('div', { class: 'modal-body' }, body);
  dlg.append(h('header', {}, h('h2', {}, title), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close', onclick: () => dlg.close() }, ico('x'))), content);
  const foot = actions.length ? h('footer', {}, ...actions) : null; if (foot) dlg.append(foot);
  dlg.addEventListener('close', () => { dlg.remove(); onClose && onClose(); });
  dlg.addEventListener('mousedown', (e) => { if (e.target === dlg) dlg.close(); });
  document.body.append(dlg); dlg.showModal();
  return { el: dlg, body: content, close: () => dlg.close(), setActions: (a) => { foot && clear(foot); a.forEach((x) => foot.append(x)); } };
}
export function confirmBox(title, message, okLabel = 'Confirm', danger = false) {
  return new Promise((res) => {
    let done = false;
    const m = modal({ title, size: 'sm', body: h('p', {}, message), onClose: () => { if (!done) res(false); },
      actions: [h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, type: 'button', onclick: () => { done = true; res(true); m.close(); } }, okLabel)] });
  });
}
export async function busy(btn, fn) {
  if (btn.disabled) return;
  btn.disabled = true; btn.classList.add('busy');
  try { return await fn(); }
  catch (e) { toast(e.message || 'Something went wrong', 'bad', 6000); }
  finally { btn.disabled = false; btn.classList.remove('busy'); }
}
let tipEl;
export function tip(el, text) {
  const show = (e) => { tipEl = tipEl || document.body.appendChild(h('div', { id: 'tip', role: 'tooltip' })); const t = typeof text === 'function' ? text() : text; mount(tipEl, ...(Array.isArray(t) ? t : [t])); tipEl.style.display = 'block'; move(e); };
  const move = (e) => { if (!tipEl) return; const r = tipEl.getBoundingClientRect(); let x = e.clientX + 14, y = e.clientY + 14; if (x + r.width > innerWidth - 8) x = e.clientX - r.width - 14; if (y + r.height > innerHeight - 8) y = e.clientY - r.height - 14; tipEl.style.left = Math.max(8, x) + 'px'; tipEl.style.top = Math.max(8, y) + 'px'; };
  const hide = () => { if (tipEl) tipEl.style.display = 'none'; };
  el.addEventListener('pointerenter', show); el.addEventListener('pointermove', move); el.addEventListener('pointerleave', hide); el.addEventListener('pointerdown', show);
  return el;
}

// ───────────────────────── small form + layout parts ─────────────────────────
export const field = (label, input, hint) => h('label', { class: 'field' }, h('span', { class: 'lbl' }, label), input, hint ? h('span', { class: 'hint' }, hint) : null);
export const select = (options, value, props = {}) => h('select', props, options.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return h('option', { value: v, selected: String(v) === String(value) }, l); }));
export const toggle = (checked, onchange, label) => { const i = h('input', { type: 'checkbox', checked: !!checked, role: 'switch', onchange: () => onchange(i.checked, i) }); return h('label', { class: 'switch' }, i, h('span', { class: 'track' }), label ? h('span', { class: 'sw-label' }, label) : null); };
export const seg = (options, value, onchange) => { const box = h('div', { class: 'seg', role: 'tablist' }); const draw = (v) => { mount(box, options.map(([val, label]) => h('button', { type: 'button', role: 'tab', 'aria-selected': String(val === v), class: val === v ? 'on' : '', onclick: () => { draw(val); onchange(val); } }, label))); }; draw(value); return box; };
export const empty = (title, text, action) => h('div', { class: 'empty' }, h('strong', {}, title), text ? h('p', {}, text) : null, action || null);
export const skeleton = (n = 3) => h('div', { class: 'skeleton' }, Array.from({ length: n }, () => h('i')));
export const badge = (text, kind = '') => h('span', { class: `badge ${kind}` }, text);
export function copyText(text, msg = 'Copied') { (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(() => toast(msg), () => { const t = h('textarea', { value: text }); document.body.append(t); t.select(); try { document.execCommand('copy'); toast(msg); } catch { toast('Copy is blocked in this browser', 'warn'); } t.remove(); }); }
export const waLink = (phone, text) => `https://wa.me/91${String(phone || '').replace(/\D/g, '').slice(-10)}?text=${encodeURIComponent(text || '')}`;

/** Downscale a photo to at most `max` px on its long side and return a JPEG data URL (keeps uploads small on mobile data). */
export function shrinkImage(file, max = 1600, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => { const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); resolve(c.toDataURL('image/jpeg', quality)); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('That file is not an image the browser can read')); };
    img.src = url;
  });
}

// ───────────────────────── menu helpers (shared by Menu, Orders and the public page) ─────────────────────────
/** Variants of one dish share a group_key. Returns [{key, name, category, subcategory, description, image_url, variants:[…]}] in menu order. */
export function groupMenu(items) {
  const map = new Map();
  for (const m of items) {
    if (!map.has(m.group_key)) map.set(m.group_key, { key: m.group_key, name: m.name, category: m.category || 'Other', subcategory: m.subcategory || '', description: m.description || '', image_url: m.image_url || '', variants: [] });
    map.get(m.group_key).variants.push(m);
  }
  return [...map.values()];
}
/** "Portion 250 ML (Serves 1)" -> "Portion" for compact chips. */
export const sizeShort = (v) => String(v || '').split(' (')[0].replace(/\s*\d+\s*ML$/i, '') || 'Regular';
/** Food photo with a plain placeholder if the link is missing or broken. */
export function foodImg(url, cls = 'fimg', alt = '') {
  const ph = () => h('div', { class: `${cls} fimg-ph`, role: 'img', 'aria-label': alt || 'No photo' }, ico('box', 22));
  if (!url) return ph();
  const img = h('img', { class: cls, src: url, alt, loading: 'lazy', referrerpolicy: 'no-referrer' });
  img.addEventListener('error', () => img.replaceWith(ph()), { once: true });
  return img;
}
